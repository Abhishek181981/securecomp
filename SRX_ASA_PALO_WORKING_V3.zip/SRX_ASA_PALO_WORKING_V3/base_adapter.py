
# -*- coding: utf-8 -*-
from typing import Optional, Tuple, Set, List

class FirewallAdapter:
    """
    Vendor-neutral adapter contract.
    The GUI must call these methods only (never issue raw device CLI directly).
    """

    def __init__(self, logger=None, debug: bool = True):
        self.conn = None
        self.logger = logger
        self.debug = debug

    # ---------- lifecycle ----------
    def attach(self, conn) -> None:
        """Attach an active Netmiko connection provided by the GUI."""
        self.conn = conn

    # ---------- discovery / parsing ----------
    def list_interfaces(self) -> Set[str]:
        """Return a set of interface names (logical where applicable)."""
        raise NotImplementedError

    def list_manual_interfaces(self) -> List[str]:
        """Return a list of interface names for the manual dropdown."""
        raise NotImplementedError

    def detect_interfaces(self, src_ip: Optional[str], dst_ip: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """Return (src_if, dst_if)."""
        raise NotImplementedError

    # ---------- verification / troubleshooting ----------
    def packet_tracer(
        self,
        in_if: str,
               protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 120,
        delay_factor: int = 2
    ) -> str:
        """Run ASA packet-tracer or SRX match-policies and return raw text (never None)."""
        raise NotImplementedError

    def check_status(self) -> Tuple[str, str]:
        """
        Return (status_text, color), color in {'green','orange','red','blue'}.
        ASA: based on 'show failover'.
        SRX: based on 'show chassis cluster status' (safe fallback).
        """
