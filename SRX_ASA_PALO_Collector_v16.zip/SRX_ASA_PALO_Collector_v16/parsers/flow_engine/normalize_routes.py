import re
import ipaddress
from .models import RouteEntry

def _mask_to_prefix(mask: str) -> int:
    try:
        return ipaddress.IPv4Network(f'0.0.0.0/{mask}').prefixlen
    except Exception:
        return 0

def parse_routes(rows):
    out = []
    groups = {}
    for r in rows:
        key = ((r.get('hostname') or '').strip(), (r.get('context') or '').strip(), (r.get('platform') or '').strip().lower())
        groups.setdefault(key, []).append((r.get('line') or '').rstrip())

    for (host, ctx, plat), lines in groups.items():
        if not host:
            continue

        # SRX 2-line join: prefix line then '> to X via IF'
        if 'srx' in plat or 'juniper' in plat or 'junos' in plat:
            current_prefix = None
            current_proto = ''
            for ln in lines:
                m = re.match(r'^(\d+\.\d+\.\d+\.\d+/\d+)\s+.*\[(\w+)', ln)
                if m:
                    current_prefix = m.group(1)
                    current_proto = m.group(2)
                    continue
                m = re.search(r'>\s+to\s+(\d+\.\d+\.\d+\.\d+)\s+via\s+(\S+)', ln)
                if m and current_prefix:
                    out.append(RouteEntry(host, ctx, plat, current_prefix, m.group(1), m.group(2), current_proto, ln))
                    current_prefix = None
                    current_proto = ''
            continue

        # ASA: 'S <net> <mask> ... via <nh>, <iface>'
        if 'asa' in plat:
            for ln in lines:
                m = re.search(r'^(\w)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+\[[^\]]+\]\s+via\s+(\d+\.\d+\.\d+\.\d+),\s*([^\s]+)', ln)
                if m:
                    code = m.group(1)
                    net = m.group(2)
                    mask = m.group(3)
                    plen = _mask_to_prefix(mask)
                    prefix = f'{net}/{plen}'
                    out.append(RouteEntry(host, ctx, plat, prefix, m.group(4), m.group(5), code, ln))
            continue

        # Palo Alto: 'prefix nexthop metric flags age interface'
        if 'palo' in plat or 'pan' in plat:
            for ln in lines:
                m = re.match(r'^(\d+\.\d+\.\d+\.\d+/\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+\d+\s+\S+\s+\S+\s+(\S+)', ln)
                if m:
                    out.append(RouteEntry(host, ctx, plat, m.group(1), m.group(2), m.group(3), 'static', ln))
            continue

    return out
