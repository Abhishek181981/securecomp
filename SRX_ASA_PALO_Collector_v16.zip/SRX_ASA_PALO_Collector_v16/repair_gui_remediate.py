# -*- coding: utf-8 -*-
#!/usr/bin/env python3
"""
repair_gui_remediate_v2.py
--------------------------
Repairs gui_remediate.py by:
  - Normalizing indentation (tabs->spaces)
  - Ensuring these methods are inside class ASAACLTool:
      _generate_remediation_plan, _run_remediator,
      _find_latest_plan_path, _open_plan_viewer,
      _apply_rc_chart_visibility
  - Removing stray PERMIT_ONLY block from class scope and reinserting it
    inside _generate_remediation_plan() after rows collection
  - Adding 'stay on Zero-hit tab' tweak inside _generate_remediation_plan()
  - Fixing newline appends in _run_remediator()

USAGE:
  python repair_gui_remediate_v2.py gui_remediate.py
"""
import io, os, re, sys
from shutil import copyfile

PERMIT_START = "# PERMIT_ONLY_FILTER_START"
PERMIT_END   = "# PERMIT_ONLY_FILTER_END"
STAY_MARKER  = "# STAY_ON_ZERO_TAB_AFTER_PLAN"

PERMIT_SNIPPET = """
        # PERMIT_ONLY_FILTER_START
        # Keep only explicit permit/allow actions; drop deny/reject/empty
        filtered = []
        for _r in rows:
            _act = (str(_r.get('action') or '')).strip().lower()
            if _act in ('permit', 'allow'):
                filtered.append(_r)
        if not filtered:
            self._append_ctx("[REMED] No permit rules found in selection/page; skipping plan generation.\\n", ctx='logs')
            try:
                from tkinter import messagebox
                messagebox.showinfo('Remediate', 'No permit rules in the current selection/page.')
            except Exception:
                pass
            return
        rows = filtered
        # PERMIT_ONLY_FILTER_END
""".strip("\n")

STAY_SNIPPET = """
        # STAY_ON_ZERO_TAB_AFTER_PLAN
        # Stay on Zero-hit tab after generating the plan (cosmetic)
        try:
            self.nb.select(self.tab_zero)
        except Exception:
            pass
""".strip("\n")

REMEDEFS = [
    "_generate_remediation_plan",
    "_run_remediator",
    "_find_latest_plan_path",
    "_open_plan_viewer",
    "_apply_rc_chart_visibility",  # fix for your current crash
]

def normalize(text: str) -> str:
    text = text.replace("\r\n","\n").replace("\r","\n")
    text = text.replace("\t", "    ")
    text = "\n".join(ln.rstrip() for ln in text.split("\n"))
    # Undo common paste-escapes like \_ \[ \] \( \) \< \> \# \*
    text = re.sub(r"\\([_\[\]\(\)<>#*])", r"\1", text)
    return text

def read_utf8(p):  return io.open(p,"r",encoding="utf-8",errors="replace").read()
def write_utf8(p,t): io.open(p,"w",encoding="utf-8",newline="").write(t)

def backup_once(path):
    bak = path + ".bak"
    if not os.path.exists(bak):
        try: copyfile(path, bak); print(f"[repair] Backup created: {bak}")
        except Exception as e: print(f"[repair] WARN: could not create backup: {e}")

def find_class_bounds(src: str, name="ASAACLTool"):
    m = re.search(rf"^\s*class\s+{name}\s*:\s*$", src, flags=re.M)
    if not m: return None, None
    start = m.end()
    m2 = re.search(r"^\s*if\s+__name__\s*==\s*['\"]__main__['\"]\s*:", src, flags=re.M)
    end = m2.start() if m2 else len(src)
    return start, end

def move_def_into_class(src: str, class_start: int, class_end: int, def_name: str) -> str:
    # Find def at module-scope
    m = re.search(rf"^def\s+{def_name}\s*\(\s*self", src, flags=re.M)
    if not m: return src
    if class_start <= m.start() < class_end: return src  # already inside
    # Extract def block
    tail = src[m.start():]
    endm = re.search(r"^def\s+\w+\s*\(|^\s*class\s+\w+\s*:|^\s*if\s+__name__", tail, flags=re.M)
    end = m.start() + (endm.start() if endm else len(tail))
    before, block, after = src[:m.start()], src[m.start():end], src[end:]
    # Indent to class scope (4 spaces)
    block = "\n".join(("    " + ln) if ln.strip() else ln for ln in block.splitlines())
    # Insert block straight after class header
    return src[:class_start] + src[class_start:] + block + after

def strip_stray_permit(class_text: str) -> str:
    pat = re.compile(rf"^\s*{re.escape(PERMIT_START)}[\s\S]*?^\s*{re.escape(PERMIT_END)}\s*$", re.M)
    new, n = pat.subn("", class_text)
    if n: print(f"[repair] Removed {n} stray PERMIT_ONLY block(s) at class scope.")
    return new

def insert_permit_and_stay(src: str, class_start: int, class_end: int) -> str:
    ctext = src[class_start:class_end]
    m = re.search(r"^\s*def\s+_generate_remediation_plan\s*\(\s*self\s*\)\s*:\s*", ctext, flags=re.M)
    if not m:
        print("[repair] WARN: _generate_remediation_plan not found in class.")
        return src
    gstart = m.start()
    tail = ctext[gstart:]
    n = re.search(r"^\s*def\s+\w+\s*\(", tail, flags=re.M)
    gend = gstart + (n.start() if n else len(tail))
    body = ctext[gstart:gend]

    if PERMIT_START not in body:
        a = re.search(r"rows\s*=\s*self\._collect_zero_selection_rows\s*\(\s*\)", body)
        if a:
            ls = body.rfind("\n", 0, a.end()) + 1
            indent = ""
            i = ls
            while i < len(body) and body[i] in (" ","\t"):
                indent += body[i]; i += 1
            snippet = "\n".join(indent + ln for ln in PERMIT_SNIPPET.splitlines())
            body = body[:a.end()] + "\n" + snippet + body[a.end():]
        else:
            # place after signature (fallback)
            first_nl = body.find("\n") + 1
            body = body[:first_nl] + "        " + PERMIT_SNIPPET.replace("\n","\n        ") + "\n" + body[first_nl:]

    if STAY_MARKER not in body:
        call = re.search(r"self\._run_remediator\s*\(\s*plan_path\s*\)\s*", body)
        ins = call.end() if call else len(body)
        body = body[:ins] + "\n        " + STAY_SNIPPET.replace("\n","\n        ") + "\n" + body[ins:]

    ctext = ctext[:gstart] + body + ctext[gend:]
    return src[:class_start] + ctext + src[class_end:]

def fix_run_remediator_newlines(src: str) -> str:
    src = re.sub(
        r"if out:\s*self\._append_ctx\(out \+ \(.*?\), ctx='logs'\)",
        "if out: self._append_ctx(out + ('\\n' if not out.endswith('\\n') else ''), ctx='logs')",
        src, flags=re.S
    )
    src = re.sub(
        r"if err:\s*self\._append_ctx\('\[stderr\]'\s*\+\s*err\s*\+\s*\(.*?\), ctx='logs'\)",
        "if err: self._append_ctx('[stderr]\\n' + err + ('\\n' if not err.endswith('\\n') else ''), ctx='logs')",
        src, flags=re.S
    )
    return src

def main():
    if len(sys.argv) < 2:
        print("Usage: python repair_gui_remediate_v2.py gui_remediate.py")
        sys.exit(2)
    path = sys.argv[1]
    if not os.path.isfile(path):
        print(f"[repair] File not found: {path}")
        sys.exit(2)

    backup_once(path)
    src = normalize(read_utf8(path))

    cls_start, cls_end = find_class_bounds(src, "ASAACLTool")
    if cls_start is None:
        print("[repair] ERROR: class ASAACLTool not found.")
        sys.exit(3)

    # Move key defs into class if needed (includes _apply_rc_chart_visibility)
    for nm in REMEDEFS:
        src = move_def_into_class(src, cls_start, cls_end, nm)
        cls_start, cls_end = find_class_bounds(src, "ASAACLTool")

    # Remove stray class-scope PERMIT block, reinsert properly
    ctext = src[cls_start:cls_end]
    ctext = strip_stray_permit(ctext)
    src   = src[:cls_start] + ctext + src[cls_end:]
    cls_start, cls_end = find_class_bounds(src, "ASAACLTool")

    # Insert permit-only + stay-on-zero inside _generate_remediation_plan
    src = insert_permit_and_stay(src, cls_start, cls_end)

    # Fix newline appends for logs in _run_remediator
    src = fix_run_remediator_newlines(src)

    # Final compile sanity
    try:
        compile(src, path, "exec")
        print("[repair] Compile OK. Indentation and placement repaired.")
    except Exception as e:
        print(f"[repair] Still failing: {e.__class__.__name__}: {e}")
        print("        Paste the traceback and I will adapt the fixer.")

    write_utf8(path, src)

if __name__ == "__main__":
    main()