# -*- coding: utf-8 -*-
"""
PaloAdapter (PAN-OS) — CLI (timing) integration

Highlights (patched):
- Monitor: show which policy (rule name) allowed/denied traffic in near real-time.
  * Prefer traffic logs (contain Rule Name + Action).
  * Fallback to live sessions (resolve rule via 'show session id <ID>') when logs unavailable.
- Interface detection (labels → tables → compact FIB), VR discovery, ARP/network fallbacks.
- Zone discovery: CSV (optional), show interface logical (NEW, authoritative), XML parse, 'show zone' text fallback,
  per-interface detail fallback ('show interface <iface>'), reverse XML search.
- VSYS targeting applied before operations; Option-1: auto-read VSYS from firewall.csv.
- Diagnostics helpers: diagnose_egress(), diagnose_zones(), ha_state(), check_status().

Policy test & push (patched):
- test security-policy-match:
  * Uses IP protocol numbers (TCP=6, UDP=17).
  * Forces target-vsys if provided; validates zones in current VSYS; falls back to 'any' when unknown.
  * Defensive retry if device responds 'from is invalid' → re-run without 'from' (retains 'to' when valid).
- push_policy():
  * Creates address/service objects and an allow rule (TEMP-ALLOW-<timestamp>), with log-setting default.
  * Rule placement:
    - Respects explicit move_rule from caller.
    - If caller used default 'top', optionally overrides using PA_RULE_ANCHORS.CSV (Palo-only):
      ('top' 'bottom' 'before <rule>' 'after <rule>'), matched by firewall_id hostname or connection host IP.

Traffic capture (Palo-only):
- clear_capture_filters(), start_capture(...), stop_capture(), capture_status(), export_capture(...)
  * Hardening:
    - Clear ALL packet-diag state and unmark sessions before defining a filter.
    - Define ONE filter (src/dst + protocol number), enable filter.
    - Opportunistically add sport/dport; skip if device rejects (Invalid syntax/Server error).
    - Default stage: 'firewall'.

Optional settings.json keys:
- prefer_route_for_ingress (bool), prefer_interface_all_zone_parse (bool)
- apply_target_vsys (bool), vsys (str)
- virtual_router (str) : optional static VR name
- log_file_path (str) : optional adapter log path
- prefer_csv_zones (bool), csv_zones_path (str)
- firewall_csv_path (str) : path to firewall.csv (VSYS context; Option-1)
- rule_anchors_csv_path (str) : path to PA_RULE_ANCHORS.CSV (anchors for placement)

This file affects only PAN-OS behavior; ASA/SRX adapters are not modified.
"""

from __future__ import annotations
import re
import ipaddress
from datetime import datetime, timedelta
from typing import Optional, Tuple, Set, List, Dict, Union
import json
import os
import logging
import threading
import csv

from base_adapter import FirewallAdapter

# Recognize PAN‑OS interface names (+ optional management), with dot‑form coverage
SAFE_IFACE_RE = re.compile(
    r'^(?:'
    r'ethernet\d+/\d+(?:\.\d+)?'       # ethernet1/17 or ethernet1/17.123
    r'|ae\d+(?:\.\d+)?'                # ae1 or ae1.200
    r'|vlan(?:\.\d+)?'                 # vlan or vlan.10
    r'|loopback(?:\.\d+)?'             # loopback.1 or loopback
    r'|tunnel(?:\.\d+)?'               # tunnel.10 or tunnel
    r'|management'                     # management
    r'|mgmt'                           # mgmt
    r')$', re.IGNORECASE
)

PortSpec = Union[int, Tuple[int, int]]

def _trim_iface_token(tok: str) -> str:
    """Trim common surrounding punctuation around interface tokens from CLI listings."""
    if not tok:
        return tok
    return tok.strip().strip(',:;)]}').lstrip('([{')

# ======================================================================================
# PaloAdapter
# ======================================================================================
class PaloAdapter(FirewallAdapter):
    def __init__(self, logger=None, debug: bool = True):
        super().__init__(logger=logger, debug=debug)
        # Serialize CLI access across threads (Monitor + UI actions)
        self._cli_lock = threading.RLock()
        self._iface_cache: Optional[Set[str]] = None
        self._vr_cache: Optional[List[str]] = None
        # Context
        self.vsys: Optional[str] = None
        # Zones & mapping
        self.zones: List[str] = []
        self.iface_to_zone: Dict[str, str] = {}
        # Environment flags
        self.multi_vsys: Optional[bool] = None
        # Behavior toggles (overridable via settings.json)
        self.prefer_route_for_ingress: bool = True
        self.apply_target_vsys: bool = True
        # NEW toggles / sources
        self.prefer_interface_all_zone_parse: bool = False
        self.prefer_csv_zones: bool = False

        # --- Monitor display toggles (overridden by settings.json) ---
        self.monitor_snapshot_only_raw: bool = True  # Abhishek: RAW-only in Snapshot
        self.monitor_realtime_only_raw: bool = True  # Abhishek: RAW-only in Realtime
        self.monitor_realtime_include_sessions: bool = True  # fallback when logs empty
        self.monitor_snapshot_use_time_filter: bool = True   # Snapshot = historical
        self.monitor_snapshot_max_total_secs: int = 3600     # default 1 hour
        self.monitor_colorize_actions: bool = True           # colorize allow/deny/drop
        self.monitor_color_allow: str = "\u001b[34m"         # blue
        self.monitor_color_deny: str = "\u001b[31m"          # red
        self.monitor_color_reset: str = "\u001b[0m"

        # External configuration (CSV paths/IDs)
        self.firewall_id: Optional[str] = None     # preferred hostname identifier
        self.csv_zones_path: Optional[str] = None  # PA_ZONES.CSV path
        self.firewall_csv_path: Optional[str] = None
        self.rule_anchors_csv_path: Optional[str] = None
        # Logging
        self.log_file_path: str = os.path.join(os.getcwd(), "palo_adapter.log")
        # Optional static VR hint via settings.json (used first if provided)
        self.static_vr: Optional[str] = None
        # Load settings (sets flags/paths before logger init)
        self._load_settings()
        # Auto file-logger if no external logger provided
        if self.logger is None:
            try:
                lg = logging.getLogger("palo_adapter")
                lg.setLevel(logging.DEBUG if debug else logging.INFO)
                has_fh = any(isinstance(h, logging.FileHandler) for h in lg.handlers)
                if not has_fh:
                    try:
                        os.makedirs(os.path.dirname(self.log_file_path), exist_ok=True)
                    except Exception:
                        pass
                    fh = logging.FileHandler(self.log_file_path, mode="w", encoding="utf-8")
                    fh.setLevel(logging.DEBUG if debug else logging.INFO)
                    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
                    fh.setFormatter(fmt)
                    lg.addHandler(fh)
                self.logger = lg
                self._log("info", f"file logging enabled: {self.log_file_path}")
            except Exception:
                pass

    # ---------- Settings ----------
    def _load_settings(self) -> None:
        try:
            path = os.path.join(os.getcwd(), 'settings.json')
            if os.path.isfile(path):
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if isinstance(data.get('prefer_route_for_ingress'), bool):
                    self.prefer_route_for_ingress = data['prefer_route_for_ingress']
                if isinstance(data.get('apply_target_vsys'), bool):
                    self.apply_target_vsys = data['apply_target_vsys']
                if isinstance(data.get('vsys'), str):
                    self.vsys = data['vsys'].strip() or self.vsys
                if isinstance(data.get('virtual_router'), str):
                    self.static_vr = data['virtual_router'].strip() or None
                # CSV / paths
                if isinstance(data.get('prefer_interface_all_zone_parse'), bool):
                    self.prefer_interface_all_zone_parse = data['prefer_interface_all_zone_parse']
                if isinstance(data.get('prefer_csv_zones'), bool):
                    self.prefer_csv_zones = data['prefer_csv_zones']
                if isinstance(data.get('firewall_id'), str):
                    self.firewall_id = data['firewall_id'].strip() or None
                if isinstance(data.get('csv_zones_path'), str):
                    self.csv_zones_path = data['csv_zones_path'].strip() or None
                if isinstance(data.get('firewall_csv_path'), str):
                    self.firewall_csv_path = data['firewall_csv_path'].strip() or None
                if isinstance(data.get('rule_anchors_csv_path'), str):
                    self.rule_anchors_csv_path = data['rule_anchors_csv_path'].strip() or None

                # Monitor toggles
                if isinstance(data.get('monitor_snapshot_only_raw'), bool):
                    self.monitor_snapshot_only_raw = data['monitor_snapshot_only_raw']
                if isinstance(data.get('monitor_realtime_only_raw'), bool):
                    self.monitor_realtime_only_raw = data['monitor_realtime_only_raw']
                if isinstance(data.get('monitor_realtime_include_sessions'), bool):
                    self.monitor_realtime_include_sessions = data['monitor_realtime_include_sessions']
                if isinstance(data.get('monitor_snapshot_use_time_filter'), bool):
                    self.monitor_snapshot_use_time_filter = data['monitor_snapshot_use_time_filter']
                if isinstance(data.get('monitor_snapshot_max_total_secs'), int):
                    self.monitor_snapshot_max_total_secs = data['monitor_snapshot_max_total_secs']
                if isinstance(data.get('monitor_colorize_actions'), bool):
                    self.monitor_colorize_actions = data['monitor_colorize_actions']
                if isinstance(data.get('monitor_color_allow'), str):
                    self.monitor_color_allow = data['monitor_color_allow']
                if isinstance(data.get('monitor_color_deny'), str):
                    self.monitor_color_deny = data['monitor_color_deny']
                if isinstance(data.get('monitor_color_reset'), str):
                    self.monitor_color_reset = data['monitor_color_reset']

                # Log file
                if isinstance(data.get('log_file_path'), str) and data['log_file_path'].strip():
                    self.log_file_path = data['log_file_path'].strip()
                self._log('info',
                          "settings: prefer_route_for_ingress=%s; apply_target_vsys=%s; "
                          "vsys=%s; static_vr=%s; log_file_path=%s; "
                          "prefer_csv_zones=%s; csv_zones_path=%s; firewall_id=%s; "
                          "firewall_csv_path=%s; rule_anchors_csv_path=%s"
                          % (self.prefer_route_for_ingress, self.apply_target_vsys,
                             self.vsys, self.static_vr, self.log_file_path,
                             self.prefer_csv_zones, self.csv_zones_path, self.firewall_id,
                             self.firewall_csv_path, self.rule_anchors_csv_path))
        except Exception as e:
            try:
                self._log('warning', f"settings.json load failed: {e}")
            except Exception:
                pass

    # ---------- Context ----------
    def set_context(self, context: Optional[str]):
        """Set VSYS context explicitly (also used by GUI via firewall.csv 'context')."""
        ctx = (context or '').strip()
        if ctx:
            self.vsys = ctx
            self._log('info', f"PaloAdapter vsys set to: {ctx}")

    def current_context_hint(self) -> Optional[str]:
        return self.vsys

    def attach(self, conn):
        """Attach Netmiko connection and prepare CLI/session."""
        super().attach(conn)
        # CLI hygiene
        try:
            self.conn.send_command_timing("set cli pager off", read_timeout=15)  # type: ignore
        except Exception:
            pass
        # Detect multi-vsys
        self._detect_multi_vsys()
        # Option-1: if VSYS not set, try reading it from firewall.csv automatically
        try:
            if not self.vsys:
                self._try_set_vsys_from_firewall_csv()
        except Exception as e_vs:
            self._log('warning', f"VSYS from firewall.csv load failed: {e_vs}")
        # Apply target-vsys if we have one
        self._maybe_target_vsys()
        # Prefer XML for config-output (used by XML-based zone parse)
        try:
            self.conn.send_command_timing("set cli config-output xml", read_timeout=15)  # type: ignore
        except Exception:
            pass

    # ---------- Internals ----------
    def _log(self, level: str, msg: str) -> None:
        try:
            if self.logger:
                getattr(self.logger, level)(msg)
        except Exception:
            pass

    def _send(self, cmd: str, timeout: int = 40, delay_factor: int = 2) -> str:
        if not getattr(self, "conn", None):
            raise ValueError("PaloAdapter.conn is not set (Netmiko connection required).")
        if self.debug:
            self._log('debug', f"SEND(timing): {cmd}")
        out = ""
        try:
            out = self.conn.send_command_timing(cmd, read_timeout=timeout, delay_factor=delay_factor)  # type: ignore
        except Exception as e:
            self._log('warning', f"SEND error: {e}")
            out = f"[ERROR] send failed: {e}"
        if self.debug:
            self._log('debug', f"RECV({len(out)}) bytes")
        return out

    def _detect_multi_vsys(self) -> None:
        try:
            info = self._send("show system info", timeout=25)
            m = re.search(r"multi-vsys\s*:\s*(on|off)", info, re.IGNORECASE)
            if m:
                self.multi_vsys = (m.group(1).lower() == 'on')
                self._log('info', f"multi-vsys detected: {self.multi_vsys}")
        except Exception as e:
            self._log('warning', f"multi-vsys detection failed: {e}")
            self.multi_vsys = None

    def _maybe_target_vsys(self) -> None:
        """Apply target-vsys when a vsys is set."""
        try:
            if self.vsys:
                self._send(f"set system setting target-vsys {self.vsys}", timeout=10)
                self._log('info', f"target-vsys applied: {self.vsys}")
        except Exception as e:
            self._log('warning', f"target-vsys apply failed: {e}")

    # ---------- Option-1: read VSYS from firewall.csv ----------
    def _try_set_vsys_from_firewall_csv(self) -> Optional[str]:
        """
        Attempt to read VSYS (context) from firewall.csv:
        - If settings.json['firewall_id'] is set: match by hostname == firewall_id
        - Else match by connection host IP (self.conn.host)
        CSV headers required: hostname, ip, platform, mode, context
        """
        csv_path = self.firewall_csv_path or os.path.join(os.getcwd(), "firewall.csv")
        if not os.path.isfile(csv_path):
            self._log('info', f"firewall.csv not found at {csv_path}")
            return None
        try:
            with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                hdrs = {(h or "").strip().lower(): h for h in (reader.fieldnames or [])}
                host_key = hdrs.get("hostname")
                ip_key = hdrs.get("ip")
                plat_key = hdrs.get("platform")
                ctx_key = hdrs.get("context")
                if not (host_key and ip_key and plat_key and ctx_key):
                    self._log('warning', f"firewall.csv missing required headers: {reader.fieldnames}")
                    return None
                conn_host = None
                try:
                    conn_host = getattr(self.conn, "host", None)
                except Exception:
                    conn_host = None
                for row in reader:
                    hostname = (row.get(host_key) or "").strip()
                    ip = (row.get(ip_key) or "").strip()
                    platform = (row.get(plat_key) or "").strip().lower()
                    context = (row.get(ctx_key) or "").strip()
                    if not platform or "palo" not in platform:
                        continue
                    match_hostname = (self.firewall_id and hostname == self.firewall_id)
                    match_ip = (not self.firewall_id and conn_host and ip == conn_host)
                    if match_hostname or match_ip:
                        if context:
                            self.vsys = context
                            self._log('info', f"VSYS loaded from firewall.csv: {self.vsys} (host={hostname or ip})")
                            return self.vsys
                self._log('info', "No matching firewall row found in firewall.csv for VSYS context.")
                return None
        except Exception as e:
            self._log('warning', f"Reading firewall.csv failed: {e}")
            return None

    # ---------- Rule placement anchor loader (Palo only) ----------
    def _resolve_move_rule_from_anchors(self) -> Optional[str]:
        """
        Read PA_RULE_ANCHORS.CSV and return a move_rule string for push_policy:
        'top' / 'bottom' / 'before <rule>' / 'after <rule>'
        CSV headers: Firewall, placement_mode, anchor_rule
        Matching:
        - Prefer settings.json['firewall_id'] (hostname match) if set
        - Else, match by connection host IP (self.conn.host)
        Returns None if CSV is missing, no match, or invalid row.
        """
        try:
            path = self.rule_anchors_csv_path or os.path.join(os.getcwd(), "PA_RULE_ANCHORS.CSV")
            if not os.path.isfile(path):
                self._log('info', f"Anchors CSV not found: {path}")
                return None
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                hdrs = {(h or "").strip().lower(): h for h in (reader.fieldnames or [])}
                fw_key = hdrs.get("firewall") or "Firewall"
                mode_key = hdrs.get("placement_mode") or "placement_mode"
                anc_key = hdrs.get("anchor_rule") or "anchor_rule"
                conn_host = None
                try:
                    conn_host = getattr(self.conn, "host", None)
                except Exception:
                    conn_host = None
                for row in reader:
                    fw_val = (row.get(fw_key) or "").strip()
                    mode_val = (row.get(mode_key) or "").strip().lower()
                    anc_val = (row.get(anc_key) or "").strip()
                    if not fw_val or mode_val not in ("top", "bottom", "before", "after"):
                        continue
                    match_hostname = (self.firewall_id and fw_val == self.firewall_id)
                    match_ip = (not self.firewall_id and conn_host and fw_val == conn_host)
                    if not (match_hostname or match_ip):
                        continue
                    if mode_val in ("before", "after"):
                        if not anc_val:
                            self._log('warning', f"Anchor row for {fw_val} requires anchor_rule; skipping")
                            continue
                        self._log('info', f"Anchor resolved: {mode_val} {anc_val}")
                        return f"{mode_val} {anc_val}"
                    self._log('info', f"Anchor resolved: {mode_val}")
                    return mode_val
            return None
        except Exception as e:
            self._log('warning', f"_resolve_move_rule_from_anchors failed: {e}")
            return None

    # ---------- Interface discovery / helpers ----------
    def _log_interface_hint(self, label: str, text: str, ip: str):
        try:
            hints: List[str] = []
            for ln in text.splitlines():
                low = ln.lower()
                if (ip and ip in ln) or ('interface' in low):
                    hints.append(ln.strip())
                if len(hints) >= 2:
                    break
            if hints:
                self._log('debug', f"{label} hints -> {'\n'.join(hints)}")
        except Exception:
            pass

    def _format_cidr(self, ip_s: str) -> str:
        s = (ip_s or '').strip()
        if not s:
            return s
        if '/' in s:
            return s
        try:
            ipaddress.IPv4Address(s)
            return f"{s}/32"
        except Exception:
            return s

    def _pick_representative_ip(self, item: Optional[str]) -> Optional[str]:
        if not item:
            return None
        s = item.strip()
        if not s:
            return None
        try:
            ipaddress.IPv4Address(s)
            return s
        except Exception:
            pass
        try:
            net = ipaddress.IPv4Network(s, strict=False)
            it = net.hosts()
            try:
                return str(next(it))
            except StopIteration:
                return str(net.network_address)
        except Exception:
            return None

    def _host_only(self, s: str) -> str:
        s = (s or '').strip()
        if not s:
            return s
        if '/' in s:
            return s.split('/', 1)[0].strip()
        return s

    def list_interfaces(self) -> Set[str]:
        if self._iface_cache is not None:
            return self._iface_cache
        ifaces: Set[str] = set()
        try:
            out = self._send("show interface all", timeout=60, delay_factor=3)
            for line in out.splitlines():
                s = line.strip()
                m = re.match(r'^Name:\s+(\S+)\s*$', s, re.IGNORECASE)
                if m:
                    cand = _trim_iface_token(m.group(1))
                    if SAFE_IFACE_RE.match(cand):
                        ifaces.add(cand)
                else:
                    m2 = re.match(r'^(ethernet\d+/\d+(?:\.\d+)?)\b', s, re.IGNORECASE)
                    if m2:
                        cand = _trim_iface_token(m2.group(1))
                        if SAFE_IFACE_RE.match(cand):
                            ifaces.add(cand)
        except Exception as e:
            self._log('warning', f"list_interfaces(all) failed: {e}")
        try:
            outL = self._send("show interface logical", timeout=60, delay_factor=3)
            for line in outL.splitlines():
                s = line.strip()
                m = re.match(r'^Name:\s+(\S+)\s*$', s, re.IGNORECASE)
                if m:
                    cand = _trim_iface_token(m.group(1))
                    if SAFE_IFACE_RE.match(cand):
                        ifaces.add(cand)
        except Exception as e:
            self._log('warning', f"list_interfaces(logical) failed: {e}")
        self._iface_cache = ifaces
        self._log('info', f"Interfaces discovered: {sorted(ifaces)}")
        return ifaces

    def interfaces_with_networks(self) -> List[Tuple[str, str, str, ipaddress.IPv4Network]]:
        results: List[Tuple[str, str, str, ipaddress.IPv4Network]] = []

        def parse_blocks(raw: str):
            chunks = re.split(r'(?m)^\s*Name:\s+', raw)
            for ch in chunks:
                ch = ch.strip()
                if not ch:
                    continue
                first = ch.splitlines()[0].strip()
                m_name = re.match(r'^([\w\-./]+)\s*$', first)
                name = _trim_iface_token(m_name.group(1)) if m_name else None
                if not name or not SAFE_IFACE_RE.match(name):
                    continue
                ip = None
                mask = None
                for line in ch.splitlines():
                    s = line.strip()
                    m_ip = re.match(
                        r'^(?:IP address|Primary IP address):\s+(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2}))?\s*$',
                        s, re.IGNORECASE)
                    if m_ip:
                        ip = m_ip.group(1)
                        if m_ip.group(2):
                            try:
                                mask = str(ipaddress.IPv4Network(f"{ip}/{m_ip.group(2)}", strict=False).netmask)
                            except Exception:
                                mask = None
                        continue
                    m_mask = re.match(
                        r'^(?:Netmask|Subnet mask):\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$',
                        s, re.IGNORECASE)
                    if m_mask:
                        mask = m_mask.group(1)
                        continue
                if name and ip and mask:
                    try:
                        net = ipaddress.IPv4Network(f"{ip}/{mask}", strict=False)
                        results.append((name, ip, mask, net))
                    except Exception:
                        pass

        out_all = self._send("show interface all", timeout=60, delay_factor=3)
        parse_blocks(out_all)
        out_log = self._send("show interface logical", timeout=60, delay_factor=3)
        parse_blocks(out_log)
        unique: Dict[str, Tuple[str, str, str, ipaddress.IPv4Network]] = {}
        for name, ip, mask, net in results:
            unique[name] = (name, ip, mask, net)
        return list(unique.values())

    # ---------- VR discovery ----------
    def _list_virtual_routers(self) -> List[str]:
        if self._vr_cache is not None:
            return self._vr_cache
        vr_names: List[str] = []
        try:
            out = self._send("show routing route", timeout=40)
            for line in out.splitlines():
                m = re.match(r'^\s*VIRTUAL\s+ROUTER:\s+(\S+)\s+\(id\s+\d+\)\s*$', line.strip(), re.IGNORECASE)
                if m:
                    vr_names.append(m.group(1))
        except Exception as e:
            self._log('warning', f"VR list from 'show routing route' failed: {e}")
        if self.static_vr:
            vr_names.append(self.static_vr)
        self._vr_cache = list(dict.fromkeys(vr_names))
        self._log('info', f"VRs discovered: {self._vr_cache}")
        return self._vr_cache

    # ---------- Route-first ingress ----------
    def _route_ingress_interface(self, src_ip: str) -> Optional[str]:
        self._maybe_target_vsys()
        for vr in (self._list_virtual_routers() or [None]):
            try:
                ip_host = self._host_only(src_ip)
                fib_cmd = (f"test routing fib-lookup virtual-router {vr} ip {ip_host}"
                           if vr else f"test routing fib-lookup ip {ip_host}")
                out = self._send(fib_cmd, timeout=55, delay_factor=3)
                self._log('debug', f"[INGRESS] FIB branch cmd: {fib_cmd}")
                self._log_interface_hint(f"FIB({vr or 'implicit'})", out, ip_host)
                cand = self._parse_interface_from_text(out)
                if cand:
                    self._log('info', f"[INGRESS] FIB resolved interface: {cand}")
                    return cand
                cidr = self._format_cidr(src_ip)
                route_cmd = (f"show routing route destination {cidr} virtual-router {vr}"
                             if vr else f"show routing route destination {cidr}")
                out2 = self._send(route_cmd, timeout=50, delay_factor=3)
                self._log('debug', f"[INGRESS] ROUTE fallback cmd: {route_cmd}")
                self._log_interface_hint(f"ROUTE({vr or 'implicit'})", out2, src_ip)
                cand2 = self._parse_interface_from_text(out2)
                if cand2:
                    self._log('info', f"[INGRESS] ROUTE resolved interface: {cand2}")
                    return cand2
            except Exception as e:
                self._log('warning', f"route-ingress failed on VR {vr}: {e}")
        # ARP global fallback
        try:
            out = self._send("show arp all", timeout=35)
            for line in out.splitlines():
                s = line.strip()
                if src_ip in s:
                    parts = s.split()
                    for tok in reversed(parts):
                        cand = _trim_iface_token(tok)
                        if SAFE_IFACE_RE.match(cand):
                            return cand
        except Exception as e:
            self._log('warning', f"Global ARP failed: {e}")
        return self.match_ingress_by_network(src_ip)

    def _parse_interface_from_text(self, text: str) -> Optional[str]:
        patterns = [
            r'(?:egress\s+interface|Egress\s+Interface)\s*:\s*([\w\-./]+)',
            r'(?:outgoing\s+interface|Outgoing\s+interface)\s*:\s*([\w\-./]+)',
            r'(?:next\s+hop\s+interface|Next\s+hop\s+interface)\s*:\s*([\w\-./]+)',
            r'(?:interface|Interface)\s*:\s*([\w\-./]+)',
            r'(?:Interface\s*\(egress\))\s*:\s*([\w\-./]+)',
            r'(?:Egress\s*If)\s*:\s*([\w\-./]+)',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                cand = _trim_iface_token(m.group(1).strip())
                if SAFE_IFACE_RE.match(cand):
                    return cand
        for ln in text.splitlines():
            cols = ln.split()
            if cols and re.match(r'\d{1,3}(?:\.\d{1,3}){3}/\d{1,2}$', cols[0]):
                for tok in reversed(cols):
                    cand = _trim_iface_token(tok)
                    if SAFE_IFACE_RE.match(cand):
                        return cand
        try:
            m = re.search(r'\binterface\s+([\w\-./]+)\b', text, re.IGNORECASE)
            if m:
                cand = _trim_iface_token(m.group(1).strip())
                if SAFE_IFACE_RE.match(cand):
                    return cand
        except Exception:
            pass
        return None

    def match_ingress_by_network(self, src_ip: str) -> Optional[str]:
        try:
            addr = ipaddress.IPv4Address(src_ip)
        except Exception:
            return None
        for (iface, _ip, _mask, net) in self.interfaces_with_networks():
            try:
                if addr in net:
                    return iface
            except Exception:
                continue
        return None

    def _fib_egress_interface(self, dst_ip: str) -> Optional[str]:
        self._maybe_target_vsys()
        for vr in (self._list_virtual_routers() or [None]):
            try:
                ip_host = self._host_only(dst_ip)
                fib_cmd = (f"test routing fib-lookup virtual-router {vr} ip {ip_host}"
                           if vr else f"test routing fib-lookup ip {ip_host}")
                out = self._send(fib_cmd, timeout=55, delay_factor=3)
                self._log('debug', f"[EGRESS] FIB branch cmd: {fib_cmd}")
                self._log_interface_hint(f"FIB({vr or 'implicit'})", out, ip_host)
                cand = self._parse_interface_from_text(out)
                if cand:
                    self._log('info', f"[EGRESS] FIB resolved interface: {cand}")
                    return cand
                cidr = self._format_cidr(dst_ip)
                route_cmd = (f"show routing route destination {cidr} virtual-router {vr}"
                             if vr else f"show routing route destination {cidr}")
                out2 = self._send(route_cmd, timeout=50, delay_factor=3)
                self._log('debug', f"[EGRESS] ROUTE fallback cmd: {route_cmd}")
                self._log_interface_hint(f"ROUTE({vr or 'implicit'})", out2, dst_ip)
                cand2 = self._parse_interface_from_text(out2)
                if cand2:
                    self._log('info', f"[EGRESS] ROUTE resolved interface: {cand2}")
                    return cand2
            except Exception as e:
                self._log('warning', f"egress lookup failed on VR {vr}: {e}")
        return None

    def detect_interfaces(self, src_ip: Optional[str], dst_ip: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        self._log('debug', f"detect_interfaces: received src_ip={src_ip!r}, dst_ip={dst_ip!r}")
        if not src_ip and not dst_ip:
            self._log('warning', "detect_interfaces: both src_ip and dst_ip are None; nothing to detect")
            return None, None
        src_if = None
        dst_if = None
        if src_ip:
            src_ip = self._pick_representative_ip(src_ip) or src_ip
            if self.prefer_route_for_ingress:
                self._log('debug', f"detect_interfaces: route-first ingress for src_ip={src_ip}")
                src_if = self._route_ingress_interface(src_ip)
            if not src_if:
                self._log('debug', "detect_interfaces: ARP fallback for ingress")
                try:
                    out = self._send("show arp all", timeout=35)
                    for line in out.splitlines():
                        s = line.strip()
                        if src_ip in s:
                            parts = s.split()
                            for tok in reversed(parts):
                                cand = _trim_iface_token(tok)
                                if SAFE_IFACE_RE.match(cand):
                                    src_if = cand
                                    break
                        if src_if:
                            break
                except Exception as e:
                    self._log('warning', f"Global ARP failed: {e}")
            if not src_if:
                self._log('debug', "detect_interfaces: subnet membership fallback for ingress")
                src_if = self.match_ingress_by_network(src_ip)
        if dst_ip:
            dst_ip = self._pick_representative_ip(dst_ip) or dst_ip
            self._log('debug', f"detect_interfaces: egress route lookup for dst_ip={dst_ip}")
            dst_if = self._fib_egress_interface(dst_ip)
            if dst_ip and not dst_if:
                try:
                    vr_list = (self._list_virtual_routers() or [None])
                    for vr in vr_list:
                        ip_host = self._host_only(dst_ip)
                        fib_cmd = (f"test routing fib-lookup virtual-router {vr} ip {ip_host}"
                                   if vr else f"test routing fib-lookup ip {ip_host}")
                        out_fib = self._send(fib_cmd, timeout=55, delay_factor=3)
                        route_cmd = (f"show routing route destination {self._format_cidr(dst_ip)} virtual-router {vr}"
                                     if vr else f"show routing route destination {self._format_cidr(dst_ip)}")
                        out_route = self._send(route_cmd, timeout=50, delay_factor=3)
                        self._log('debug', f"=== VR={vr or 'implicit'} ===[FIB] {out_fib} [ROUTE] {out_route}")
                except Exception:
                    pass
        return src_if, dst_if

    def route_out_interface(self, dst_ip: Optional[str]) -> Optional[str]:
        if not dst_ip:
            return None
        dst_ip = self._pick_representative_ip(dst_ip) or dst_ip
        return self._fib_egress_interface(dst_ip)

    # ---------- CSV Zones loader ----------
    def load_zones_from_csv(self, path: Optional[str] = None, firewall_id: Optional[str] = None) -> bool:
        """
        Load interface->zone mapping from a CSV with headers: Firewall, name, zone (case-insensitive).
        Filters by firewall_id if provided. Returns True if at least one mapping was loaded.
        """
        try:
            csv_path = (path or self.csv_zones_path or os.path.join(os.getcwd(), "PA_ZONES.CSV"))
            if not os.path.isfile(csv_path):
                self._log('info', f"CSV not found: {csv_path}")
                return False
            count = 0
            with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                hdrs = {(h or "").strip().lower(): h for h in (reader.fieldnames or [])}
                fw_key = hdrs.get("firewall")
                name_key = hdrs.get("name")
                zone_key = hdrs.get("zone") or hdrs.get("zones")  # allow 'zones'
                if not (fw_key and name_key and zone_key):
                    self._log('warning', f"CSV missing required headers. Got: {reader.fieldnames}")
                    return False
                for row in reader:
                    fw_val = (row.get(fw_key) or "").strip()
                    if firewall_id and fw_val != firewall_id:
                        continue
                    iface_raw = (row.get(name_key) or "").strip()
                    zone_raw = (row.get(zone_key) or "").strip()
                    if not iface_raw or not zone_raw:
                        continue
                    cand = _trim_iface_token(iface_raw)
                    if SAFE_IFACE_RE.match(cand):
                        self.iface_to_zone[cand] = zone_raw
                        if zone_raw not in self.zones:
                            self.zones.append(zone_raw)
                        count += 1
                    else:
                        self._log('debug', f"CSV skip non-PAN iface token: {iface_raw!r}")
            self._log('info', f"Loaded {count} iface->zone mappings from {csv_path} (firewall_id={firewall_id or 'ANY'})")
            return count > 0
        except Exception as e:
            self._log('warning', f"load_zones_from_csv failed: {e}")
            return False

    # ---------- NEW: Zones via `show interface logical` ----------
    def _load_zones_via_show_interface_logical(self) -> bool:
        """
        Parse `show interface logical` to build iface->zone mapping.
        Works for both physical and subinterfaces and is robust across PAN-OS versions.
        Expected table contains headers like:
            name  id  vsys  zone  forwarding  tag  address
        We detect the header row to locate the 'zone' column index dynamically.
        """
        try:
            out = self._send("show interface logical", timeout=60, delay_factor=3)
            if not out or not out.strip():
                return False

            lines = [ln.rstrip("\r") for ln in out.splitlines() if ln.strip()]
            header_idx = -1
            headers: List[str] = []
            name_i: Optional[int] = None
            zone_i: Optional[int] = None

            # Try to locate a header row. Some builds have single space between 'vsys' and 'zone'.
            for i, ln in enumerate(lines[:20]):
                low = ln.lower()
                if "name" in low and "zone" in low and "address" in low:
                    # Split header generously (tabs OR any spaces), then normalize tokens
                    headers_raw = re.split(r"\t+|\s+", ln.strip())
                    headers = [h.strip() for h in headers_raw if h.strip()]
                    header_idx = i
                    break

            # Default data start (skip dashed separator if present)
            start = header_idx + 1 if header_idx >= 0 else 0
            if start < len(lines) and re.match(r"^-{3,}\s*$", lines[start]):
                start += 1

            # Try mapping by names
            if headers:
                hdr_map = {h.lower(): n for n, h in enumerate(headers)}
                name_i = hdr_map.get("name")
                zone_i = hdr_map.get("zone")

            # Fallback: positional indices if not found
            if name_i is None:
                name_i = 0
            if zone_i is None:
                zone_i = 3

            loaded = 0
            for ln in lines[start:]:
                lnl = ln.lower()
                if lnl.startswith("name ") or lnl.startswith("---"):
                    continue

                # Prefer >=2 spaces or tabs (typical table alignment)
                parts = re.split(r"\s{2,}|\t+", ln.strip())
                if len(parts) <= max(name_i, zone_i):
                    # Fallback to any whitespace split
                    parts = re.split(r"\s+|\t+", ln.strip())
                if len(parts) <= max(name_i, zone_i):
                    continue

                iface = parts[name_i].strip()
                zone = parts[zone_i].strip()

                if not iface or not zone or zone.lower() in ("n/a", "na", "none", "-"):
                    continue
                if SAFE_IFACE_RE.match(iface):
                    self.iface_to_zone[iface] = zone
                    if zone not in self.zones:
                        self.zones.append(zone)
                    loaded += 1

            if loaded > 0:
                self._log('info', f"Loaded {loaded} iface->zone mappings from 'show interface logical'")
                return True
            return False
        except Exception as e:
            self._log('warning', f"_load_zones_via_show_interface_logical failed: {e}")
            return False

    def refresh_zones_and_interfaces(self):
        """Populate zones and iface_to_zone mapping (CSV-first if enabled; else device parse)."""
        self.zones = []
        self.iface_to_zone = {}
        if self.prefer_csv_zones:
            used_csv = self.load_zones_from_csv(path=self.csv_zones_path, firewall_id=self.firewall_id)
            if used_csv:
                self._log('info', "Using zones from CSV; skipping device discovery.")
                return
        # Device discovery fallback
        self._maybe_target_vsys()  # ensure correct VSYS before reading config

        # STEP-1 (NEW authoritative): `show interface logical`
        try:
            if self._load_zones_via_show_interface_logical():
                self._log('info', "Zones populated via 'show interface logical'; skipping XML/text parsing.")
                return
        except Exception as e:
            self._log('warning', f"'show interface logical' parsing error (non-fatal): {e}")

        # STEP-2: XML parse as a secondary option
        try:
            self._send("set cli config-output xml", timeout=10)
            cfg = self._send("show config running", timeout=60)
            zone_blocks = re.split(r'\<zone\>', cfg)
            for blk in zone_blocks[1:]:
                name_m = re.search(r'\<name\>([^\<]+)\</name\>', blk)
                if not name_m:
                    continue
                zname = name_m.group(1).strip()
                if zname and zname not in self.zones:
                    self.zones.append(zname)
                for mem in re.findall(r'\<member\>\s*([^\s\<]+)\s*\</member\>', blk):
                    cand = _trim_iface_token(mem)
                    if SAFE_IFACE_RE.match(cand):
                        self.iface_to_zone[cand] = zname
            if not self.iface_to_zone:
                self._log('warning', "XML zone parse yielded no members; using text fallback")
                self._fallback_parse_zones_text()
            self._log('info', f"zones={self.zones}; iface_to_zone size={len(self.iface_to_zone)}")
        except Exception as e:
            self._log('warning', f"refresh_zones_and_interfaces failed: {e}")
            self._fallback_parse_zones_text()

    def _zone_for_iface_via_xml_search(self, iface: str) -> Optional[str]:
        """Reverse-lookup zone by scanning running-config XML for <member>iface</member> and extracting the nearest enclosing <zone><entry name="...">."""
        self._maybe_target_vsys()
        try:
            self._send('set cli config-output xml', timeout=10)
            cfg = self._send('show config running', timeout=60)
            pat_member = re.compile(r'\<member\>\s*' + re.escape(iface) + r'\s*\</member\>', re.IGNORECASE)
            for m in pat_member.finditer(cfg):
                window_start = max(0, m.start() - 50000)
                window = cfg[window_start:m.start()]
                if re.search(r'\<zone\>', window, re.IGNORECASE):
                    m_entry = re.search(r'\<entry\s+name="([^"]+)"\s*\>', window, re.IGNORECASE)
                    if m_entry:
                        zname = m_entry.group(1).strip()
                        if zname:
                            self.iface_to_zone[iface] = zname
                            if zname not in self.zones:
                                self.zones.append(zname)
                            return zname
            return None
        except Exception as e:
            self._log('warning', f"_zone_for_iface_via_xml_search failed: {e}")
            return None

    # ---------- NEW: Per‑interface fallback via `show interface <iface>` ----------
    def _zone_for_iface_via_interface_detail(self, iface: str) -> Optional[str]:
        try:
            out = self._send(f"show interface {iface}", timeout=20)
            m = re.search(r"(?im)^\s*Zone:\s*([A-Za-z0-9_.\-]+)\s*$", out)
            if m:
                z = m.group(1).strip()
                if z:
                    self.iface_to_zone[iface] = z
                    if z not in self.zones:
                        self.zones.append(z)
                    return z
        except Exception as e:
            self._log('warning', f"_zone_for_iface_via_interface_detail failed: {e}")
        return None

    def zone_for_iface(self, iface: Optional[str]) -> Optional[str]:
        if not iface:
            return None
        # Prefer CSV mapping if available and requested
        if self.prefer_csv_zones and not self.iface_to_zone:
            self.zones = []
            self.iface_to_zone = {}
            self.load_zones_from_csv(path=self.csv_zones_path, firewall_id=self.firewall_id)
        # Ensure we have some mapping
        if not self.iface_to_zone:
            self._maybe_target_vsys()
            self.refresh_zones_and_interfaces()
        z = self.iface_to_zone.get(iface)
        if z:
            return z

        # Live text fallback: `show zone`
        self._maybe_target_vsys()
        try:
            out = self._send("show zone", timeout=40)
            current_zone: Optional[str] = None
            for ln in out.splitlines():
                s = ln.strip()
                m_zone = re.match(r'^Zone\s+([\w\-.:]+)\s*$', s, re.IGNORECASE)
                if m_zone:
                    current_zone = m_zone.group(1)
                    continue
                if current_zone and s:
                    for tok in re.split(r'[\s,;]+', s):
                        cand = _trim_iface_token(tok)
                        if cand and SAFE_IFACE_RE.match(cand):
                            self.iface_to_zone[cand] = current_zone
                            if cand == iface:
                                return current_zone
        except Exception as e:
            self._log('warning', f"zone_for_iface live-fallback failed: {e}")

        # Final fallbacks: direct interface detail, then XML reverse lookup
        z = self._zone_for_iface_via_interface_detail(iface)
        if z:
            return z
        z = self._zone_for_iface_via_xml_search(iface)
        if z:
            return z
        return None

    def _fallback_parse_zones_text(self):
        self._maybe_target_vsys()
        try:
            out = self._send("show zone", timeout=40)
            current_zone: Optional[str] = None
            for ln in out.splitlines():
                s = ln.strip()
                m_zone = re.match(r'^Zone\s+([\w\-.:]+)\s*$', s, re.IGNORECASE)
                if m_zone:
                    current_zone = m_zone.group(1)
                    if current_zone and current_zone not in self.zones:
                        self.zones.append(current_zone)
                    continue
                if current_zone and s:
                    for tok in re.split(r'[\s,;]+', s):
                        cand = _trim_iface_token(tok)
                        if cand and SAFE_IFACE_RE.match(cand):
                            self.iface_to_zone[cand] = current_zone
        except Exception as e:
            self._log('warning', f"fallback parse zones failed: {e}")

    def _zone_from_source_ip(self, src_ip: Optional[str]) -> Optional[str]:
        if not src_ip:
            return None
        try:
            addr = ipaddress.IPv4Address(src_ip)
        except Exception:
            return None
        if not self.iface_to_zone:
            self.refresh_zones_and_interfaces()
        for (iface, _ip, _mask, net) in self.interfaces_with_networks():
            try:
                if addr in net:
                    return self.zone_for_iface(iface)
            except Exception:
                continue
        return None

    def zones_for_flow(self, src_iface: Optional[str], dst_ip: Optional[str], src_ip: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
        self._log('debug', f"zones_for_flow: received src_iface={src_iface!r}, src_ip={src_ip!r}, dst_ip={dst_ip!r}")
        if not src_iface and not src_ip and not dst_ip:
            self._log('warning', "zones_for_flow: missing src_iface/src_ip and dst_ip; cannot infer zones")
            return None, None
        from_zone = self.zone_for_iface(src_iface)
        if (from_zone is None) and src_ip:
            self._log('debug', f"zones_for_flow: derive from_zone from src_ip={src_ip}")
            from_zone = self._zone_from_source_ip(src_ip)
        if from_zone is None and self.prefer_route_for_ingress and src_ip:
            try:
                ing_if = self._route_ingress_interface(src_ip)
                if ing_if:
                    from_zone = self.zone_for_iface(ing_if)
                    self._log('debug', f"zones_for_flow: from_zone via ingress iface={ing_if} -> {from_zone}")
            except Exception as e:
                self._log('warning', f"zones_for_flow: ingress detect from src_ip failed: {e}")
        to_zone = None
        egress = self.route_out_interface(dst_ip) if dst_ip else None
        if egress:
            self._log('debug', f"zones_for_flow: derive to_zone from egress iface={egress}")
            to_zone = self.zone_for_iface(egress)
        return from_zone, to_zone

    # ---------- Diagnostics ----------
    def diagnose_egress(self, dst_ip: str, vr: Optional[str] = None, include_route: bool = True) -> Dict[str, str]:
        report: Dict[str, str] = {}
        vr_list: List[Optional[str]] = [vr] if vr else (self._list_virtual_routers() or [None])
        for cur_vr in vr_list:
            ip_host = self._host_only(dst_ip)
            fib_cmd = (f"test routing fib-lookup virtual-router {cur_vr} ip {ip_host}"
                       if cur_vr else f"test routing fib-lookup ip {ip_host}")
            fib_out = self._send(fib_cmd, timeout=55, delay_factor=3)
            fib_if = self._parse_interface_from_text(fib_out)
            route_cmd = route_out = route_if = None
            if include_route:
                cidr = self._format_cidr(dst_ip)
                route_cmd = (f"show routing route destination {cidr} virtual-router {cur_vr}" if cur_vr
                             else f"show routing route destination {cidr}")
                route_out = self._send(route_cmd, timeout=50, delay_factor=3)
                route_if = self._parse_interface_from_text(route_out)
            egress_if = fib_if or route_if
            egress_zone = self.zone_for_iface(egress_if) if egress_if else None
            self._log('debug', f"[DIAG] VR={cur_vr or 'implicit'} FIB_CMD={fib_cmd}\n{fib_out}")
            if include_route and route_cmd:
                self._log('debug', f"[DIAG] VR={cur_vr or 'implicit'} ROUTE_CMD={route_cmd}\n{route_out}")
            report.update({
                'vr': str(cur_vr) if cur_vr is not None else 'implicit',
                'fib_cmd': fib_cmd,
                'fib_out': fib_out,
                'fib_iface': fib_if or '',
                'route_cmd': route_cmd or '',
                'route_out': route_out or '',
                'route_iface': route_if or '',
                'egress_iface': egress_if or '',
                'egress_zone': egress_zone or ''
            })
            if egress_if:
                return report
        return report

    def diagnose_zones(self) -> str:
        try:
            self.refresh_zones_and_interfaces()
        except Exception:
            pass
        lines: List[str] = []
        lines.append("[ZONES] " + (", ".join(self.zones) if self.zones else "(none)"))
        if not self.iface_to_zone:
            lines.append("[IFACE->ZONE] (empty)")
        else:
            items = list(self.iface_to_zone.items())
            for iface, z in items[:30]:
                lines.append(f"{iface} -> {z}")
            if len(items) > 30:
                lines.append(f"... ({len(items)-30} more)")
        return "\n".join(lines)

    # ---------- Status ----------
    def ha_state(self) -> str:
        try:
            out = self._send("show high-availability state", timeout=40)
            low = out.lower()
            if "state: active" in low or "state:\tactive" in low:
                return "active"
            if "state: passive" in low or "state:\tpassive" in low:
                return "passive"
        except Exception:
            pass
        try:
            sys = self._send("show system info", timeout=25)
            if "operational-mode: normal" in sys:
                return "active"
        except Exception:
            pass
        return "unknown"

    def check_status(self) -> Tuple[str, str]:
        st = self.ha_state()
        if st == "active":
            return ("Firewall ACTIVE", "green")
        if st in ("passive", "standby"):
            return ("Firewall PASSIVE - select ACTIVE firewall", "red")
        return ("HA state UNKNOWN - verify", "orange")

    # ---------- Policy generation / push ----------
    def generate_policy_snippet(
        self,
        src_ips: List[str],
        dst_ips: List[str],
        ports: List[PortSpec],
        from_zone: str,
        to_zone: str,
        vsys: Optional[str] = None,
        service_protocol: str = "tcp",
        rule_name: Optional[str] = None
    ) -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        rn = rule_name or f"TEMP-ALLOW-{ts}"
        cmds: List[str] = []
        if (vsys or self.vsys):
            cmds.append(f"set system setting target-vsys {vsys or self.vsys}")
        for ip in src_ips:
            cmds.append(f"set address SRC-{ip} ip-netmask {ip}/32")
        for ip in dst_ips:
            cmds.append(f"set address DST-{ip} ip-netmask {ip}/32")
        use_tcp = service_protocol in ("tcp", "both")
        use_udp = service_protocol in ("udp", "both")
        tcp_services: List[str] = []
        udp_services: List[str] = []
        for p in ports:
            if isinstance(p, int):
                if use_tcp:
                    name = f"SVC-TCP-{p}"
                    cmds.append(f"set service {name} protocol tcp port {p}")
                    tcp_services.append(name)
                if use_udp:
                    name = f"SVC-UDP-{p}"
                    cmds.append(f"set service {name} protocol udp port {p}")
                    udp_services.append(name)
            else:
                a, b = p
                if use_tcp:
                    name = f"SVC-TCP-{a}-{b}"
                    cmds.append(f"set service {name} protocol tcp port {a}-{b}")
                    tcp_services.append(name)
                if use_udp:
                    name = f"SVC-UDP-{a}-{b}"
                    cmds.append(f"set service {name} protocol udp port {a}-{b}")
                    udp_services.append(name)
        svc_list = tcp_services + udp_services
        src_list = " ".join([f"SRC-{ip}" for ip in src_ips]) if src_ips else "any"
        dst_list = " ".join([f"DST-{ip}" for ip in dst_ips]) if dst_ips else "any"
        svc_clause = f"[ {' '.join(svc_list)} ]" if svc_list else "any"
        cmds.append(f"set rulebase security rules {rn} from {from_zone}")
        cmds.append(f"set rulebase security rules {rn} to {to_zone}")
        cmds.append(f"set rulebase security rules {rn} source [ {src_list} ]")
        cmds.append(f"set rulebase security rules {rn} destination [ {dst_list} ]")
        cmds.append(f"set rulebase security rules {rn} application any")
        cmds.append(f"set rulebase security rules {rn} service {svc_clause}")
        cmds.append(f"set rulebase security rules {rn} action allow")
        cmds.append(f"set rulebase security rules {rn} log-setting default")
        return "\n".join(cmds)

    def push_policy(
        self,
        src_ips: List[str],
        dst_ips: List[str],
        ports: List[PortSpec],
        from_zone: str,
        to_zone: str,
        vsys: Optional[str] = None,
        rule_name: Optional[str] = None,
        move_rule: str = "top",
        do_commit: bool = True,
        service_protocol: str = "tcp"
    ) -> Dict[str, str]:
        res: Dict[str, str] = {"config": "", "move": "", "commit": ""}
        state = self.ha_state()
        if state in ("passive", "unknown", "standby"):
            raise RuntimeError(f"HA state not ACTIVE ({state}); abort push.")
        self._maybe_target_vsys()
        ok = self._enter_config()
        if not ok:
            raise RuntimeError("Failed to enter config mode")
        try:
            self._maybe_target_vsys_config()
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            rn = rule_name or f"TEMP-ALLOW-{ts}"
            lines: List[str] = []
            for ip in src_ips:
                lines.append(f"set address SRC-{ip} ip-netmask {ip}/32")
            for ip in dst_ips:
                lines.append(f"set address DST-{ip} ip-netmask {ip}/32")
            use_tcp = service_protocol in ("tcp", "both")
            use_udp = service_protocol in ("udp", "both")
            tcp_services: List[str] = []
            udp_services: List[str] = []
            for p in ports:
                if isinstance(p, int):
                    if use_tcp:
                        nm = f"SVC-TCP-{p}"
                        lines.append(f"set service {nm} protocol tcp port {p}")
                        tcp_services.append(nm)
                    if use_udp:
                        nm = f"SVC-UDP-{p}"
                        lines.append(f"set service {nm} protocol udp port {p}")
                        udp_services.append(nm)
                else:
                    a, b = p
                    if use_tcp:
                        nm = f"SVC-TCP-{a}-{b}"
                        lines.append(f"set service {nm} protocol tcp port {a}-{b}")
                        tcp_services.append(nm)
                    if use_udp:
                        nm = f"SVC-UDP-{a}-{b}"
                        lines.append(f"set service {nm} protocol udp port {a}-{b}")
                        udp_services.append(nm)
            svc_list = tcp_services + udp_services
            src_list = " ".join([f"SRC-{ip}" for ip in src_ips]) if src_ips else "any"
            dst_list = " ".join([f"DST-{ip}" for ip in dst_ips]) if dst_ips else "any"
            svc_clause = f"[ {' '.join(svc_list)} ]" if svc_list else "any"
            lines.append(f"set rulebase security rules {rn} from {from_zone}")
            lines.append(f"set rulebase security rules {rn} to {to_zone}")
            lines.append(f"set rulebase security rules {rn} source [ {src_list} ]")
            lines.append(f"set rulebase security rules {rn} destination [ {dst_list} ]")
            lines.append(f"set rulebase security rules {rn} application any")
            lines.append(f"set rulebase security rules {rn} service {svc_clause}")
            lines.append(f"set rulebase security rules {rn} action allow")
            lines.append(f"set rulebase security rules {rn} log-setting default")
            out_cfg: List[str] = []
            for cmd in lines:
                out_cfg.append(self._send(cmd, timeout=20))
            res["config"] = "".join(out_cfg)
            # Resolve placement
            effective_move = move_rule or "top"
            try:
                if effective_move == "top":
                    anchor_move = self._resolve_move_rule_from_anchors()
                    if anchor_move:
                        self._log('info', f"Using anchor-based placement: {anchor_move}")
                        effective_move = anchor_move
            except Exception as e_mv:
                self._log('warning', f"Placement resolution failed; defaulting to '{effective_move}': {e_mv}")
            mv_out = ""
            if effective_move == "top":
                mv_out = self._send(f"move rulebase security rules {rn} top", timeout=15)
            elif effective_move == "bottom":
                mv_out = self._send(f"move rulebase security rules {rn} bottom", timeout=15)
            elif effective_move.startswith("before "):
                ref = effective_move.split(" ", 1)[1].strip()
                mv_out = self._send(f"move rulebase security rules {rn} before {ref}", timeout=15)
            elif effective_move.startswith("after "):
                ref = effective_move.split(" ", 1)[1].strip()
                mv_out = self._send(f"move rulebase security rules {rn} after {ref}", timeout=15)
            res["move"] = mv_out
            if do_commit:
                res["commit"] = self._send("commit", timeout=120, delay_factor=2)
            return res
        finally:
            self._exit_config()

    def _enter_config(self) -> bool:
        try:
            self._send("configure", timeout=10)
            return True
        except Exception as e:
            self._log('warning', f"configure failed: {e}")
            return False

    def _exit_config(self) -> None:
        try:
            self._send("exit", timeout=10)
        except Exception:
            pass

    def _maybe_target_vsys_config(self) -> None:
        try:
            if self.vsys:
                self._send(f"set system setting target-vsys {self.vsys}", timeout=10)
        except Exception:
            pass

    # ---------- PAN‑OS single‑test verification ----------
    def packet_tracer(self, inif: str, proto: str, sip: str, sport: int,
                      dip: str, dport: int, timeout: int = 120, delay_factor: int = 2) -> str:
        """
        Emulate 'packet-tracer' for PAN‑OS using:
        test security-policy-match from <zone> to <zone> source <ip> destination <ip>
        protocol <1-255> destination-port <port> [source-port <port>]
        """
        try:
            # 0) Always apply vsys if provided (prevents 'target-vsys is none')
            try:
                if self.vsys:
                    self._send(f"set system setting target-vsys {self.vsys}", timeout=10)
                    self._log('info', f"[PA TEST] target-vsys applied: {self.vsys}")
            except Exception as e_tv:
                self._log('warning', f"[PA TEST] target-vsys apply failed (non-fatal): {e_tv}")

            # 1) Protocol number (TCP=6 / UDP=17)
            proto_norm = (proto or "tcp").strip().lower()
            proto_num = 17 if proto_norm == "udp" else 6

            # 2) Resolve zones
            try:
                from_zone, to_zone = self.zones_for_flow(inif, dip, sip)
            except Exception as _e_z:
                self._log('warning', f"zones_for_flow failed in packet_tracer: {_e_z}")
                from_zone, to_zone = None, None

            # Refresh cache, validate zone names
            try:
                if not self.zones or not self.iface_to_zone:
                    self.refresh_zones_and_interfaces()
            except Exception as e_r:
                self._log('warning', f"refresh_zones_and_interfaces in packet_tracer failed: {e_r}")

            def _valid_zone(z: Optional[str]) -> bool:
                return bool(z) and (z in (self.zones or []))

            if not _valid_zone(from_zone):
                self._log('warning', f"[PA TEST] from-zone '{from_zone}' not valid in current vsys; using 'any'")
                from_zone = "any"
            if not _valid_zone(to_zone):
                self._log('warning', f"[PA TEST] to-zone '{to_zone}' not valid in current vsys; using 'any'")
                to_zone = "any"

            # 3) Normalize IPs (CIDR → host)
            src_ip = self._pick_representative_ip(sip) or (sip or "").strip()
            dst_ip = self._pick_representative_ip(dip) or (dip or "").strip()
            if not src_ip or not dst_ip:
                return "[ERROR] policy-match failed: source or destination IP missing after normalization"

            # 4) Build command (so we can retry without 'from' if needed)
            def _build_cmd(_from: Optional[str], _to: Optional[str]) -> str:
                base = (
                    "test security-policy-match "
                    f"source {src_ip} destination {dst_ip} "
                    f"protocol {int(proto_num)} destination-port {int(dport)}"
                )
                if _from and _from != "any":
                    base = "test security-policy-match from " + _from + " " + base[len("test security-policy-match "):]
                if _to and _to != "any":
                    base = base.replace(" source ", f" to {_to} source ", 1)
                return base

            cmd = _build_cmd(from_zone, to_zone)
            try:
                if sport and int(sport) > 0:
                    cmd += f" source-port {int(sport)}"
            except Exception:
                pass

            self._log('debug', f"[PA TEST] CMD={cmd}")
            out = self._send(cmd, timeout=timeout, delay_factor=delay_factor)

            # 5) Defensive retry if PAN‑OS complains that 'from' is invalid.
            low = (out or "").lower()
            if " from is invalid" in low or " is invalid from" in low:
                self._log('warning', "[PA TEST] 'from' rejected by device; retrying WITHOUT 'from' (keeping 'to' if valid)")
                cmd2 = _build_cmd(None, to_zone if to_zone and to_zone != "any" else None)
                try:
                    if sport and int(sport) > 0:
                        cmd2 += f" source-port {int(sport)}"
                except Exception:
                    pass
                self._log('debug', f"[PA TEST][RETRY] CMD={cmd2}")
                out2 = self._send(cmd2, timeout=timeout, delay_factor=delay_factor)
                return out2
            return out
        except Exception as e:
            return f"[ERROR] policy-match failed: {e}"

    def summarize_verdict(self, text: str) -> bool:
        """
        Summarize PAN‑OS policy test output.
        Returns True when output clearly indicates allow; False otherwise.
        Heuristics:
        - 'action: allow' → True
        - 'action: deny' or 'action: drop' → False
        - If a 'matched rule' line exists and contains 'allow', treat as True.
        """
        try:
            low = (text or "").lower()
            if "action: allow" in low:
                return True
            if "action: deny" in low or "action: drop" in low:
                return False
            if "matched rule" in low and "allow" in low:
                return True
        except Exception:
            pass
        return False

    # ---------- Traffic Capture (PAN‑OS only) ----------
    def clear_capture_filters(self) -> str:
        """Turn capture OFF (if on) and clear packet‑diag filters and stages."""
        try:
            out1 = self._send("debug dataplane packet-diag set capture off", timeout=15)
            out2 = self._send("debug dataplane packet-diag clear filter", timeout=15)
            out3 = self._send("debug dataplane packet-diag clear stage", timeout=15)
            return f"{out1}\n{out2}\n{out3}"
        except Exception as e:
            return f"[ERROR] clear_capture_filters failed: {e}"

    def _build_packet_diag_filter(self,
                                  src_ip: Optional[str] = None,
                                  dst_ip: Optional[str] = None,
                                  proto: Optional[str] = None,
                                  src_port: Optional[int] = None,
                                  dst_port: Optional[int] = None) -> List[str]:
        """
        Build packet‑diag filter commands based on provided selectors.
        All params are optional; at least one is recommended to limit capture scope.
        HARDENING:
        - Clear all packet‑diag state + unmark sessions.
        - Define ONE filter: source/destination/protocol NUMBER (tcp=6, udp=17, icmp=1).
        - Enable filter (set filter on).
        - Do NOT add sport/dport here; try opportunistically later.
        """
        cmds: List[str] = []
        # Hard reset to avoid 'All filters are already defined!' and stale indices
        cmds.append("debug dataplane packet-diag clear all")
        cmds.append("debug dataplane packet-diag clear filter-marked-session all")
        # Protocol (IP number: tcp=6, udp=17, icmp=1)
        if proto:
            p = (proto or "").strip().lower()
            pmap = {"tcp": 6, "udp": 17, "icmp": 1}
            if p in pmap:
                cmds.append(f"debug dataplane packet-diag set filter match protocol {pmap[p]}")
        # Source / destination IPs
        if src_ip:
            sip = self._pick_representative_ip(src_ip) or src_ip
            cmds.append(f"debug dataplane packet-diag set filter match source {sip}")
        if dst_ip:
            dip = self._pick_representative_ip(dst_ip) or dst_ip
            cmds.append(f"debug dataplane packet-diag set filter match destination {dip}")
        # Enable the filter so new sessions are marked
        cmds.append("debug dataplane packet-diag set filter on")
        return cmds

    def start_capture(self,
                      src_ip: Optional[str] = None,
                      dst_ip: Optional[str] = None,
                      proto: Optional[str] = None,
                      src_port: Optional[int] = None,
                      dst_port: Optional[int] = None,
                      stages: Optional[List[str]] = None) -> str:
        """
        Start PAN‑OS dataplane packet capture:
        - Clears state, sets filter (source/destination/proto number), enables filter.
        - Opportunistically adds sport/dport (skips if device rejects).
        - Sets capture stages (one or more of: 'receive', 'firewall', 'transmit').
        - Turns capture ON.
        NOTE: Packet capture can impact performance; keep capture windows short.
        """
        try:
            # Ensure VSYS context is applied
            try:
                if self.vsys:
                    self._send(f"set system setting target-vsys {self.vsys}", timeout=10)
            except Exception:
                pass
            # Build and apply filter (reset + single filter + enable)
            cmds = self._build_packet_diag_filter(src_ip, dst_ip, proto, src_port, dst_port)
            outs: List[str] = []
            for c in cmds:
                outs.append(self._send(c, timeout=15))
            # Opportunistically add ports (skip on invalid syntax/server error)
            def _try_port_cmd(cmd: str):
                out = self._send(cmd, timeout=10)
                low = (out or "").lower()
                if ("invalid syntax" in low) or ("server error" in low):
                    self._log('warning', f"[CAPTURE] Port match rejected; skipping: {cmd}")
                    return None
                return out
            if src_port and isinstance(src_port, int) and src_port > 0:
                o1 = _try_port_cmd(f"debug dataplane packet-diag set filter match sport {src_port}")
                if o1: outs.append(o1)
            if dst_port and isinstance(dst_port, int) and dst_port > 0:
                o2 = _try_port_cmd(f"debug dataplane packet-diag set filter match dport {dst_port}")
                if o2: outs.append(o2)
            # Stages: default to 'firewall' if not specified
            stages = stages or ["firewall"]
            # Clear any previous stage selection
            outs.append(self._send("debug dataplane packet-diag clear stage", timeout=10))
            # Set requested stages
            valid = {"receive", "firewall", "transmit"}
            for st in stages:
                s = (st or "").strip().lower()
                if s in valid:
                    outs.append(self._send(f"debug dataplane packet-diag set capture stage {s}", timeout=10))
            # Turn capture ON
            outs.append(self._send("debug dataplane packet-diag set capture on", timeout=15))
            return "\n".join(outs)
        except Exception as e:
            return f"[ERROR] start_capture failed: {e}"

    def stop_capture(self) -> str:
        """Stop PAN‑OS dataplane packet capture (does NOT clear filters/stages)."""
        try:
            return self._send("debug dataplane packet-diag set capture off", timeout=15)
        except Exception as e:
            return f"[ERROR] stop_capture failed: {e}"

    def capture_status(self) -> str:
        """Show current packet‑diag settings; useful to confirm filters/stages/capture state."""
        try:
            return self._send("debug dataplane packet-diag show setting", timeout=20)
        except Exception as e:
            return f"[ERROR] capture_status failed: {e}"

    # ---------- Monitor / Sessions (PAN‑OS) ----------
    def _tail_traffic_logs(
        self,
        src_ip: Optional[str],
        dst_ip: Optional[str],
        app: Optional[str],
        max_rows: int = 20,
        timeout: int = 45
    ) -> str:
        """Return recent traffic log lines filtered by src/dst/app using 'show log traffic'.
        Updated per Abhishek's format preference:
        `show log traffic direction equal backward query equal "(...)"`
        with graceful fallbacks when syntax is rejected by device.
        """
        self._maybe_target_vsys()
        parts = []
        if src_ip:
            parts.append(f"(addr.src in {self._host_only(src_ip)})")
        if dst_ip:
            parts.append(f"(addr.dst in {self._host_only(dst_ip)})")
        if app:
            parts.append(f"(app eq {app})")
        query = " and ".join(parts) if parts else ""

        # Preferred (newest-first): direction equal backward BEFORE query
        cmd1 = "show log traffic direction equal backward"
        if query:
            cmd1 += f' query equal "{query}"'
        out1 = self._send(cmd1, timeout=timeout, delay_factor=2)
        low = (out1 or '').lower()
        if ("invalid syntax" in low) or ("server error" in low):
            # Fallback #1: legacy wording without 'equal' before backward
            cmd2 = "show log traffic direction backward"
            if query:
                cmd2 += f' query equal "{query}"'
            out2 = self._send(cmd2, timeout=timeout, delay_factor=2)
            low2 = (out2 or '').lower()
            if ("invalid syntax" in low2) or ("server error" in low2):
                # Fallback #2: omit direction—device default ordering
                cmd3 = "show log traffic"
                if query:
                    cmd3 += f' query equal "{query}"'
                out3 = self._send(cmd3, timeout=timeout, delay_factor=2)
                return out3 or ""
            return out2 or ""
        return out1 or ""

    def _extract_kv(self, text: str, key: str) -> Optional[str]:
        """Best-effort 'key: value' extractor (tolerant across PAN‑OS variants)."""
        m = re.search(rf'\b{re.escape(key)}\s*:\s*([^\s,]+)', text, re.IGNORECASE)
        return m.group(1) if m else None

    def _colorize_actions(self, text: str) -> str:
        """Color 'allow' (blue) and 'deny'/'drop' (red) using ANSI, when enabled."""
        try:
            if not text or not getattr(self, 'monitor_colorize_actions', False):
                return text or ""
            import re as _re
            def repl_allow(m):
                return f"{self.monitor_color_allow}{m.group(0)}{self.monitor_color_reset}"
            def repl_deny(m):
                return f"{self.monitor_color_deny}{m.group(0)}{self.monitor_color_reset}"
            text = _re.sub(r"(?i)\ballow\b", repl_allow, text)
            text = _re.sub(r"(?i)\b(deny|drop)\b", repl_deny, text)
            return text
        except Exception:
            return text or ""

    # ---------- PATCHED: multi-format traffic-log parser ----------
    def parse_traffic_log_lines(self, raw: str, top_n: int = 20) -> List[Dict[str, str]]:
        """
        Parse 'show log traffic' output into dicts with keys:
        time, src, sport, dst, dport, app, rule, action, from_zone, to_zone,
        vsys (if present), session_id (Rule_UUid in block layout), src_user, dst_user, end_reason.

        Supports:
          1) PAN-OS multi-line block format (4 stacked lines per row) — the format you shared.
          2) CSV/tabular one-line rows (header + rows).
          3) Single-line 'key:value' tokens.
        """
        rows: List[Dict[str, str]] = []
        text = (raw or "").strip()
        if not text:
            return rows

        lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
        if not lines:
            return rows

        # --- Detect multi-line block header (4 lines + separator of '=')
        def _hmatch(a: str, b: str) -> bool:
            return a.strip().lower() == b.strip().lower()

        if len(lines) >= 6:
            h1 = lines[0]
            h2 = lines[1]
            h3 = lines[2]
            h4 = lines[3]
            sep = lines[4]
            if (
                _hmatch(h1, "Time App From Src Port Source")
                and _hmatch(h2, "Rule Action To Dst Port Destination")
                and ("end reason" in h3.lower())
                and ("rule_uuid" in h4.lower())
                and (set(sep) == {"="})
            ):
                # ----- Multi-line block layout detected -----
                i = 5
                count = 0
                while (i + 3) < len(lines) and count < top_n:
                    l1 = lines[i].rstrip()
                    l2 = lines[i + 1].rstrip()
                    l3 = lines[i + 2].rstrip()
                    l4 = lines[i + 3].rstrip()
                    i += 4
                    count += 1

                    # Split columns by >=2 spaces to tolerate varying alignment
                    import re as _re
                    cols1 = [c for c in _re.split(r"\s{2,}", l1.strip()) if c]
                    cols2 = [c for c in _re.split(r"\s{2,}", l2.strip()) if c]
                    cols3 = [c for c in _re.split(r"\s{2,}", l3.strip()) if c]

                    # Expected columns:
                    # l1: time, app, from_zone, sport, src
                    # l2: rule, action, to_zone, dport, dst
                    # l3: src_user, dst_user, end_reason
                    d: Dict[str, str] = {
                        "time":       cols1[0] if len(cols1) >= 1 else "",
                        "app":        cols1[1] if len(cols1) >= 2 else "",
                        "from_zone":  cols1[2] if len(cols1) >= 3 else "",
                        "sport":      cols1[3] if len(cols1) >= 4 else "",
                        "src":        cols1[4] if len(cols1) >= 5 else "",
                        "rule":       cols2[0] if len(cols2) >= 1 else "",
                        "action":     cols2[1] if len(cols2) >= 2 else "",
                        "to_zone":    cols2[2] if len(cols2) >= 3 else "",
                        "dport":      cols2[3] if len(cols2) >= 4 else "",
                        "dst":        cols2[4] if len(cols2) >= 5 else "",
                        "src_user":   cols3[0] if len(cols3) >= 1 else "",
                        "dst_user":   cols3[1] if len(cols3) >= 2 else "",
                        "end_reason": cols3[2] if len(cols3) >= 3 else "",
                        # Line 4 is Rule_UUid; expose it as session_id for downstream use
                        "session_id": l4.strip(),
                    }
                    if d.get("rule") or d.get("action") or d.get("app"):
                        rows.append(d)

                if rows:
                    return rows
                # If header matched but parsing yielded empty, fall through to other parsers.

        # --- CSV/tabular fallback ---
        try:
            import csv as _csv
            hdr_idx = -1
            hdr: List[str] = []
            for j, ln in enumerate(lines[:8]):
                if ln.count(",") >= 3:
                    hdr_idx = j
                    hdr = next(_csv.reader([ln], skipinitialspace=True))
                    break
            if hdr_idx >= 0 and hdr:
                canon = [h.strip().lower() for h in hdr]
                idx = {k: n for n, k in enumerate(canon)}

                def _get(rec: List[str], k: str) -> str:
                    n = idx.get(k)
                    return (rec[n].strip() if (n is not None and n < len(rec)) else "")

                cnt = 0
                for ln in lines[hdr_idx + 1:]:
                    rec = next(_csv.reader([ln], skipinitialspace=True))
                    d = {
                        "time": _get(rec, "receive time") or _get(rec, "time"),
                        "src": _get(rec, "source") or _get(rec, "src"),
                        "dst": _get(rec, "destination") or _get(rec, "dst"),
                        "sport": _get(rec, "source port") or _get(rec, "sport"),
                        "dport": _get(rec, "destination port") or _get(rec, "dport"),
                        "app": _get(rec, "application") or _get(rec, "app"),
                        "rule": _get(rec, "rule name") or _get(rec, "rule"),
                        "action": _get(rec, "action"),
                        "from_zone": _get(rec, "source zone"),
                        "to_zone": _get(rec, "destination zone"),
                        "vsys": _get(rec, "virtual system") or _get(rec, "vsys"),
                        "session_id": _get(rec, "session id"),
                    }
                    if any(d.get(k) for k in ("rule", "action", "app")):
                        rows.append(d)
                        cnt += 1
                        if cnt >= top_n:
                            break
                if rows:
                    return rows
        except Exception:
            # swallow and continue to key:value fallback
            pass

        # --- Single-line key:value fallback ---
        import re as _re

        def _kv(s: str, key: str) -> str:
            m = _re.search(rf'\b{_re.escape(key)}\s*[:=]\s*([^\s,|]+)', s, _re.IGNORECASE)
            return m.group(1) if m else ""

        for ln in lines[: max(top_n, 50)]:
            s = ln.strip()
            d = {
                "time": _kv(s, "Receive Time") or _kv(s, "Time"),
                "src": _kv(s, "Source") or _kv(s, "src"),
                "dst": _kv(s, "Destination") or _kv(s, "dst"),
                "sport": _kv(s, "Source Port") or _kv(s, "sport"),
                "dport": _kv(s, "Destination Port") or _kv(s, "dport"),
                "app": _kv(s, "Application") or _kv(s, "app"),
                "rule": _kv(s, "Rule Name") or _kv(s, "rule"),
                "action": _kv(s, "Action") or _kv(s, "action"),
                "from_zone": _kv(s, "Source Zone"),
                "to_zone": _kv(s, "Destination Zone"),
                "vsys": _kv(s, "Virtual System") or _kv(s, "vsys"),
                "session_id": _kv(s, "Session ID"),
            }
            if d["rule"] or d["action"] or d["app"]:
                rows.append(d)

        return rows

    def _augment_sessions_with_rule(self, raw: str, max_ids: int = 12) -> List[Dict[str,str]]:
        """
        Fallback path: parse 'show session all filter ...' for IDs and run
        'show session id <ID>' to pull 'rule :' and key details for active flows.
        """
        entries: List[Dict[str,str]] = []
        ids = []
        for ln in (raw or "").splitlines():
            m = re.search(r'^\s*(\d+)(?:/\S+)?\s', ln)  # first token is ID[/vsys]
            if m:
                ids.append(m.group(1))
            if len(ids) >= max_ids:
                break
        for sid in ids:
            det = self._send(f"show session id {sid}", timeout=30, delay_factor=2)
            rule = self._extract_kv(det, "rule") or ""
            app = self._extract_kv(det, "application") or ""
            src = self._extract_kv(det, "source") or ""
            dst = self._extract_kv(det, "dst") or ""
            sport= self._extract_kv(det, "sport") or ""
            dport= self._extract_kv(det, "dport") or ""
            vsys = self._extract_kv(det, "vsys") or ""
            action = "allow"  # live session => allowed; deny/drop appear in Traffic logs
            entries.append({
                "time": "",
                "src": src, "sport": sport,
                "dst": dst, "dport": dport,
                "app": app, "rule": rule, "action": action,
                "from_zone": "", "to_zone": "", "vsys": vsys,
                "session_id": sid
            })
        return entries

    def _format_items_summary(self, items: List[Dict[str,str]]) -> str:
        """Render a human‑readable summary (single‑line per flow with rule+action) suitable for GUI‑neutral display."""
        if not items:
            return "[MONITOR] No matching entries."
        lines = []
        lines.append("Time \n src:port -> dst:port \n app \n rule \n action \n zones")
        lines.append("-"*96)
        for it in items:
            tm = it.get("time","")
            sp = f"{it.get('src','')}:{it.get('sport','')}" if it.get("src") else ""
            dp = f"{it.get('dst','')}:{it.get('dport','')}" if it.get("dst") else ""
            app = it.get("app","")
            rule = it.get("rule","")
            act = it.get("action","")
            zones = f"{it.get('from_zone','')}-{ '>' if it.get('to_zone') else '' }{it.get('to_zone','')}".strip("->")
            lines.append(f"{tm}\n {sp} -> {dp}\n {app}\n {rule}\n {act}\n {zones}")
        return "\n".join(lines)

    def show_sessions(self,
                      src_ip: Optional[str] = None,
                      dst_ip: Optional[str] = None,
                      app: Optional[str] = None,
                      limit: int = 200,
                      timeout: int = 45) -> str:
        """Return 'show session all filter ...' output."""
        try:
            self._maybe_target_vsys()
            flt_parts: List[str] = []
            if src_ip:
                sip = self._pick_representative_ip(src_ip) or src_ip
                flt_parts += ["source", sip]
            if dst_ip:
                dip = self._pick_representative_ip(dst_ip) or dst_ip
                flt_parts += ["destination", dip]
            if app:
                flt_parts += ["application", app.strip()]
            cmd = "show session all"
            if flt_parts:
                cmd += " filter " + " ".join(flt_parts)
            out = self._send(cmd, timeout=timeout, delay_factor=2)
            return out
        except Exception as e:
            return f"[ERROR] show_sessions failed: {e}"

    def monitor_supported(self) -> bool:
        """Neutral capability flag for GUI (Palo supported)."""
        return True

    def monitor_snapshot(
        self,
        src_ip: Optional[str] = None,
        dst_ip: Optional[str] = None,
        app: Optional[str] = None,
        limit: int = 200,
        timeout: int = 45
    ) -> Dict[str, str]:
        """
        Neutral monitor API used by GUI. Returns only RAW traffic (tabular) and timestamp.
        Prefers Traffic logs; falls back to sessions.
        """
        # Prefer Traffic Logs (contain Rule Name + Action)
        try:
            t_raw = self._tail_traffic_logs(src_ip, dst_ip, app, max_rows=limit, timeout=timeout)
            return {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "raw": t_raw or ""
            }
        except Exception as e:
            self._log('warning', f"[MONITOR] traffic log path failed: {e}")

        # Fallback: live sessions (RAW-only)
        try:
            s_raw = self.show_sessions(src_ip=src_ip, dst_ip=dst_ip, app=app, limit=limit, timeout=timeout)
            return {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "raw": s_raw or ""
            }
        except Exception as e:
            return {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "raw": f"[MONITOR] Error: {e}"
            }

    def summarize_sessions(self, text: str, top_n: int = 10) -> str:
        """Best-effort summary of sessions: total, top apps, top rules."""
        try:
            low = (text or "").strip()
            if not low:
                return "[MONITOR] No session data."
            import re
            from collections import Counter
            apps = re.findall(r"(?im)\bapplication\s*[:=]\s*([A-Za-z0-9._\-]+)", text)
            rules = re.findall(r"(?im)\brule\s*[:=]\s*([^\s,]+)", text)
            total = max(len(apps), len(rules))
            app_top = Counter(apps).most_common(top_n)
            rule_top = Counter(rules).most_common(top_n)
            lines = []
            lines.append(f"[MONITOR] Estimated sessions: {total}")
            if app_top:
                lines.append("[MONITOR] Top applications:")
                for name, cnt in app_top:
                    lines.append(f" - {name}: {cnt}")
            if rule_top:
                lines.append("[MONITOR] Top rules:")
                for name, cnt in rule_top:
                    lines.append(f" - {name}: {cnt}")
            return "\n".join(lines)
        except Exception:
            return "[MONITOR] Summary unavailable (parse error)."

    def export_capture(self,
                       remote_host: str,
                       username: str,
                       remote_path: str,
                       file_hint: Optional[str] = None) -> str:
        """
        Export the capture file via SCP to a remote server.
        PAN‑OS stores packet-diag pcaps under /var/log/pan/; filename varies by version.
        Strategy:
        - Inspect 'debug dataplane packet-diag show setting' for a pcap filename (best-effort).
        - Fallback to a common default 'packet-diag.pcap' if none found.
        - Run: scp export <file> to <user>@<host>:<path>
        """
        try:
            pcap_file = (file_hint or "").strip()
            if not pcap_file:
                # Try to parse status output for a filename hint
                status = self.capture_status()
                m = re.search(r'(?i)\bpcap\b.*\bfile\b.*?:\s*(\S+)', status)
                if m:
                    pcap_file = m.group(1).strip()
                if not pcap_file:
                    # Conservative fallback — common default in many builds
                    pcap_file = "/var/log/pan/packet-diag.pcap"
            cmd = f"scp export {pcap_file} to {username}@{remote_host}:{remote_path}"
            out = self._send(cmd, timeout=120, delay_factor=2)
            return out
        except Exception as e:
            return f"[ERROR] export_capture failed: {e}"

    # ===============================
    # Real‑time Monitor (polling loop)
    # ===============================
    def _now_str(self) -> str:
        # PAN‑OS traffic log Receive Time format usually "YYYY/MM/DD HH:MM:SS"
        return datetime.now().strftime("%Y/%m/%d %H:%M:%S")

    def _fmt_time_for_query(self, dt: datetime) -> str:
        # Format for traffic‑log query 'receive_time geq'
        return dt.strftime("%Y/%m/%d %H:%M:%S")

    def _build_traffic_query(self,
                             src_ip: Optional[str],
                             dst_ip: Optional[str],
                             app: Optional[str],
                             since_dt: Optional[datetime]) -> str:
        parts: List[str] = []
        if src_ip:
            parts.append(f"(addr.src in {self._host_only(src_ip)})")
        if dst_ip:
            parts.append(f"(addr.dst in {self._host_only(dst_ip)})")
        if app:
            parts.append(f"(app eq {app})")
        if since_dt:
            parts.append(f"(receive_time geq '{self._fmt_time_for_query(since_dt)}')")
        return " and ".join(parts)

    def _tail_traffic_logs_since(self,
                                 src_ip: Optional[str],
                                 dst_ip: Optional[str],
                                 app: Optional[str],
                                 since_dt: Optional[datetime],
                                 timeout: int = 30) -> Tuple[List[Dict[str, str]], str]:
        self._maybe_target_vsys()
        query = self._build_traffic_query(src_ip, dst_ip, app, since_dt)
        cmd = 'show log traffic'
        if query:
            cmd += f' query equal "{query}"'
        with self._cli_lock:
            raw = self._send(cmd, timeout=timeout, delay_factor=2)
            rows = self.parse_traffic_log_lines(raw, top_n=50)
        def parse_ts(r):
            t = r.get('time', '')
            for fmt in ('%Y/%m/%d %H:%M:%S','%Y-%m-%d %H:%M:%S','%Y-%m-%dT%H:%M:%S','%m/%d/%Y %H:%M:%S'):
                try:
                    tt = t.replace('-', '/') if fmt == '%Y/%m/%d %H:%M:%S' else t
                    return datetime.strptime(tt, fmt)
                except Exception:
                    continue
            return None
        rows_sorted = sorted(rows, key=lambda r: parse_ts(r) or datetime.min)
        return rows_sorted, (raw or '')


def _monitor_worker(
    self,
    stop_event: threading.Event,
    on_update,
    src_ip: Optional[str],
    dst_ip: Optional[str],
    app: Optional[str],
    poll_interval: float,
    lookback_secs: int,
    limit_per_tick: int,
    timeout: int
) -> None:
    """
    Live stream only: poll new logs since last timestamp and emit RAW-only payloads.
    Fallback to sessions when configured.
    """
    last_ts: Optional[datetime] = None

    while not stop_event.is_set():
        try:
            since = None
            if last_ts:
                since = last_ts - timedelta(seconds=lookback_secs)

            items, raw = self._tail_traffic_logs_since(
                src_ip, dst_ip, app, since_dt=since, timeout=timeout
            )

            if items:
                # advance last_ts
                for it in items:
                    t_str = (it.get('time') or '').replace('-', '/')
                    try:
                        cur = datetime.strptime(t_str, '%Y/%m/%d %H:%M:%S')
                        if (last_ts is None) or (cur > last_ts):
                            last_ts = cur
                    except Exception:
                        pass

                payload = {
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'summary': '',
                    'raw': self._colorize_actions(raw or '')
                }
                try:
                    on_update(payload)
                except Exception as cb_err:
                    self._log('warning', f"[MONITOR] on_update callback error: {cb_err}")
            else:
                if getattr(self, 'monitor_realtime_include_sessions', True):
                    try:
                        with self._cli_lock:
                            s_raw = self.show_sessions(
                                src_ip=src_ip, dst_ip=dst_ip, app=app, limit=100, timeout=timeout
                            )
                        if s_raw and s_raw.strip():
                            payload = {
                                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'summary': '',
                                'raw': self._colorize_actions(s_raw)
                            }
                            on_update(payload)
                    except Exception:
                        pass
        except Exception as e:
            self._log('warning', f"[MONITOR] worker tick failed: {e}")

        stop_event.wait(timeout=poll_interval)

def start_monitor(self,
                  on_update,
                  src_ip: Optional[str] = None,
                  dst_ip: Optional[str] = None,
                  app: Optional[str] = None,
                  poll_interval: float = 2.0,
                  lookback_secs: int = 2,
                  limit_per_tick: int = 20,
                  timeout: int = 30) -> bool:
    """Start real‑time monitor."""
    if getattr(self, "_monitor_thread", None) and self._monitor_thread.is_alive():
        self._log('info', "[MONITOR] already running")
        return False
    self._monitor_stop = threading.Event()
    self._monitor_thread = threading.Thread(
        target=self._monitor_worker,
        name="PaloMonitorWorker",
        args=(self._monitor_stop, on_update, src_ip, dst_ip, app, poll_interval, lookback_secs, limit_per_tick, timeout,),
        daemon=True
    )
    self._monitor_thread.start()
    self._log('info', "[MONITOR] started")
    return True

def stop_monitor(self) -> bool:
    """Stop the real‑time monitor and wait for the worker to exit."""
    thr = getattr(self, "_monitor_thread", None)
    ev = getattr(self, "_monitor_stop", None)
    if thr and ev and thr.is_alive():
        ev.set()
        try:
            thr.join(timeout=5.0)
        except Exception:
            pass
        self._log('info', "[MONITOR] stopped")
        return True
    self._log('info', "[MONITOR] not running")
    return False

# Bind monitor functions to PaloAdapter (module-scope -> class methods)
for _name in (
    "_now_str",
    "_fmt_time_for_query",
    "_build_traffic_query",
    "_tail_traffic_logs_since",
    "_monitor_worker",
    "start_monitor",
    "stop_monitor",
):
    try:
        setattr(PaloAdapter, _name, globals()[_name])
    except Exception:
        pass