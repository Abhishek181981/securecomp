import re
from .models import PolicyRule

def parse_acls(rows):
    out = []
    groups = {}
    for r in rows:
        key = ((r.get('hostname') or '').strip(), (r.get('context') or '').strip(), (r.get('platform') or '').strip().lower())
        groups.setdefault(key, []).append((r.get('line') or '').rstrip())

    for (host, ctx, plat), lines in groups.items():
        if not host:
            continue

        # SRX: accumulate policy blocks to extract name + action + evidence (Level-1)
        if 'srx' in plat or 'juniper' in plat or 'junos' in plat:
            from_zone = None
            to_zone = None
            pol_name = None
            evidence = []
            action = None

            def flush():
                nonlocal pol_name, evidence, action
                if pol_name:
                    out.append(PolicyRule(host, ctx, plat, pol_name, from_zone, to_zone, [], [], [], action or 'unknown', evidence[:]))
                pol_name = None
                evidence.clear()
                action = None

            for ln in lines:
                mz = re.search(r'From zone:\s*([^,\"]+),\s*To zone:\s*([^\"]+)', ln, re.IGNORECASE)
                if mz:
                    from_zone = mz.group(1).strip().strip('"')
                    to_zone = mz.group(2).strip().strip('"')
                    continue

                mp = re.search(r'Policy:\s*([^,\"]+)', ln, re.IGNORECASE)
                if mp:
                    flush()
                    pol_name = mp.group(1).strip().strip('"')
                    evidence.append(ln)
                    continue

                if pol_name:
                    evidence.append(ln)
                    if re.search(r'Action:\s*permit', ln, re.IGNORECASE):
                        action = 'permit'
                    elif re.search(r'Action:\s*deny', ln, re.IGNORECASE):
                        action = 'deny'

            flush()
            continue

        # ASA: any access-list line containing permit/deny becomes a rule record
        if 'asa' in plat:
            for ln in lines:
                low = ln.lower()
                if 'permit' in low or 'deny' in low:
                    act = 'permit' if 'permit' in low else 'deny'
                    mname = re.match(r'^access-list\s+(\S+)', ln, re.IGNORECASE)
                    name = mname.group(1) if mname else 'ASA-ACL'
                    out.append(PolicyRule(host, ctx, plat, name, None, None, [], [], [], act, [ln]))
            continue

        # Palo Alto: any line containing allow/deny
        if 'palo' in plat or 'pan' in plat:
            for ln in lines:
                low = ln.lower()
                if 'allow' in low or 'deny' in low:
                    act = 'permit' if 'allow' in low else 'deny'
                    out.append(PolicyRule(host, ctx, plat, 'PA-POLICY', None, None, [], [], [], act, [ln]))
            continue

    return out
