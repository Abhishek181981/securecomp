import re
from .models import InterfaceEntry

def _norm_platform(p: str) -> str:
    return (p or '').strip().lower()

def parse_ips(rows):
    out = []
    for r in rows:
        host = (r.get('hostname') or '').strip()
        ctx = (r.get('context') or '').strip()
        plat = _norm_platform(r.get('platform') or '')
        line = (r.get('line') or '').strip()
        if not host or not line:
            continue

        # SRX: '<if> ... inet <ip>/<plen>'
        if 'srx' in plat or 'juniper' in plat or 'junos' in plat:
            m = re.search(r'^(\S+)\s+\S+\s+\S+\s+inet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)', line)
            if m:
                out.append(InterfaceEntry(host, ctx, plat, m.group(1), m.group(2), int(m.group(3)), None))
                continue

        # ASA: 'Ethernet1/4.239 23.91.239.126 YES ...' (skip unassigned)
        if 'asa' in plat:
            m = re.search(r'^(\S+)\s+(\d+\.\d+\.\d+\.\d+)\s+YES\s+', line, re.IGNORECASE)
            if m:
                out.append(InterfaceEntry(host, ctx, plat, m.group(1), m.group(2), 32, None))
                continue

        # Palo Alto: logical interface table includes '<if> ... <ip>/<plen>'
        if 'palo' in plat or 'pan' in plat:
            m = re.search(r'^(ethernet\d+/\d+(?:\.\d+)?)\s+\d+\s+\d+\s+\S+\s+\S+\s+\d+\s+(\d+\.\d+\.\d+\.\d+)/(\d+)', line, re.IGNORECASE)
            if m:
                out.append(InterfaceEntry(host, ctx, plat, m.group(1), m.group(2), int(m.group(3)), None))
                continue

    # Dedup
    seen = set(); dedup = []
    for it in out:
        k = (it.hostname, it.context, it.iface, it.ip, it.prefixlen)
        if k not in seen:
            seen.add(k)
            dedup.append(it)
    return dedup
