# platforms/palo_collector.py (v6.1.6)
# Final merge with ACL action index:
# - Force operational mode (exit config '#') before 'show' commands.
# - Parse 'service' and 'application' from 'show running security-policy'.
# - Include service/application in raw_ace for audit/search.
# - Risk model = ANY + BROAD (BROAD if CIDR mask <= /16; applies to RFC1918 and public),
#   with combinations: any_src, any_dst, any_any, broad_src, broad_dst, broad_both,
#   any_to_broad, broad_to_any, broad_to_host.
# - Risky ports (secondary): {80, 21} (HTTP, FTP), detected via names and numbers.
# - Write 'risk' & 'risk_description' ONLY in risky_acl.csv.
# - NEW: ACL action index allows zero-hit rows (including unmatched fallback) to pick action
#        from ACL context instead of hard-coding.

from __future__ import annotations
import re, os, traceback, hashlib
from datetime import datetime

# ---- Normalizer -----------------------------------------------------------------
try:
    from modular_collector.normalize import normalize_cli
except Exception:
    try:
        from normalize import normalize_cli
    except Exception:
        def normalize_cli(s: str) -> str:
            return s or ""

# ---- FS helpers -----------------------------------------------------------------
def _ensure_dir(p: str) -> None:
    try: os.makedirs(p, exist_ok=True)
    except Exception: pass

def _abs_dir_from_hostmeta(hostmeta, default: str = "reports/latest/logs") -> str:
    if isinstance(hostmeta, dict):
        for k in ("latest_dir","log_dir","run_dir","workdir"):
            if hostmeta.get(k): return os.path.abspath(str(hostmeta[k]))
    return os.path.abspath(default)

def _write_text(path: str, body: str) -> None:
    _ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8", errors="replace") as f:
        f.write(body or "")

# ---- CLI helpers ----------------------------------------------------------------
def _safe_prompt(conn) -> str:
    try:
        p=(conn.find_prompt() or "").strip()
        return re.escape(p)+r"\s*$" if p else r"[>#]\s*$"
    except Exception:
        return r"[>#]\s*$"

def _is_config_mode_prompt(p: str) -> bool:
    p=(p or '').lower()
    return "(config" in p or p.strip().endswith("#")

def _run(conn, cmd: str, timeout: int = 240) -> str:
    """Run command; auto 'run ' if in config mode."""
    try: prompt_str=(conn.find_prompt() or "").strip()
    except Exception: prompt_str=""
    prompt=_safe_prompt(conn)
    op_cmd = cmd if (not _is_config_mode_prompt(prompt_str) or cmd.lstrip().startswith("run ")) \
                else ("run " + cmd.lstrip())
    try:
        out=conn.send_command(op_cmd, expect_string=prompt, read_timeout=timeout)
        if out and out.strip(): return normalize_cli(out)
    except Exception: pass
    try:
        out=conn.send_command_timing(op_cmd)
        return normalize_cli(out or "")
    except Exception:
        return ""

# ---- Regex primitives -----------------------------------------------------------
IP_CIDR_RE = re.compile(r"(?P<ip>\d{1,3}(?:\.\d{1,3}){3})/(?P<mask>\d{1,2})")
IP_RE      = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")
PREFIX_RE  = re.compile(r"^\s*(?P<prefix>\d{1,3}(?:\.\d{1,3}){3}/\d{1,2})")
VSYS_RE    = re.compile(r"^vsys\s+(?P<name>\S+)\b", re.IGNORECASE)

# ---- Parsers: IPs & routes ------------------------------------------------------
def _parse_ips_palo(txt: str):
    rows=[]
    for raw in (txt or '').splitlines():
        line=raw.strip()
        if not line or line.lower().startswith(("name","---")): continue
        parts=line.split()
        iface=parts[0] if parts else ""
        m=IP_CIDR_RE.search(line)
        if iface and m:
            rows.append({"interface":iface,"ip":m.group("ip"),"mask":m.group("mask")})
    return rows

def _parse_routes_palo(txt: str):
    rows=[]; vrf="default"
    for raw in (txt or '').splitlines():
        line=raw.strip()
        if not line: continue
        low=line.lower()
        if low.startswith("virtual router:"):
            vrf=line.split(":",1)[1].strip() or "default"; continue
        m=PREFIX_RE.match(line)
        if not m: continue
        prefix=m.group("prefix"); next_hop=""
        if "connected" not in low and "direct" not in low:
            ips=IP_RE.findall(line[m.end():])
            if ips: next_hop=ips[0]
        rows.append({"vrf":vrf,"prefix":prefix,"next_hop":next_hop})
    return rows

# ---- Policy parser (RUN output) -------------------------------------------------
KV_RE = {
    'from':         re.compile(r"\bfrom\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'to':           re.compile(r"\bto\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'source':       re.compile(r"\bsource\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'destination':  re.compile(r"\bdestination\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'action':       re.compile(r"\baction\s*:?\s+(?P<val>\w+)", re.IGNORECASE),
    'name':         re.compile(r"\bname\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'service':      re.compile(r"\bservice\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'application':  re.compile(r"\bapplication\s*:?\s+(?P<val>[^;,\s]+)", re.IGNORECASE),
    'disabled':     re.compile(r"\b(disabled|state\s*disabled|\(disabled\))\b", re.IGNORECASE),
}
RULE_SPLIT_RE = re.compile(r"^rule\s+\S+\s*$", re.IGNORECASE)

def _parse_policies_palo(txt: str):
    rows=[]; rule_id=0
    cur={'from':'','to':'','source':'any','destination':'any','action':None,'name':'',
         'inactive':False,'service':'','application':''}

    def emit():
        nonlocal rule_id
        if cur['action']:
            rule_id+=1
            rows.append({
                'rule_id':str(rule_id),
                'from_zone':cur['from'],'to_zone':cur['to'],
                'src':cur['source'],'dst':cur['destination'],
                'action':cur['action'].lower(),'name':cur['name'],
                'inactive':cur['inactive'],
                'service':cur.get('service',''),'application':cur.get('application',''),
            })
        cur.update({'from':'','to':'','source':'any','destination':'any','action':None,'name':'',
                    'inactive':False,'service':'','application':''})

    for raw in (txt or '').splitlines():
        line=raw.strip()
        if not line: emit(); continue
        if RULE_SPLIT_RE.match(line): emit(); continue
        m_hdr=re.match(r"^rule\s+(?P<n>.+?)\s*$", line, re.IGNORECASE)
        if m_hdr: emit(); cur['name']=m_hdr.group('n').strip(); continue
        for key,rgx in KV_RE.items():
            m=rgx.search(line)
            if m:
                if key=='disabled':       cur['inactive']=True
                elif key=='action':       cur['action']=m.group('val')
                elif key=='name':         cur['name']=m.group('val')
                elif key=='service':      cur['service']=m.group('val')
                elif key=='application':  cur['application']=m.group('val')
                else:                     cur[key]=m.group('val')
    emit()
    return rows

# ---- VSYS helper ----------------------------------------------------------------
def _list_vsys(conn):
    txt=_run(conn,"show vsys") or ""; vsys=[]
    for raw in txt.splitlines():
        line=raw.strip(); m=VSYS_RE.match(line)
        if m: vsys.append(m.group("name"))
    return (vsys or ["vsys1"]), txt

# ---- Rule-use hit-count parser --------------------------------------------------
RULEUSE_KV = re.compile(r"name\s*:\s*(?P<name>.+?)\s+(?:hit|hit\s*count|hit-count|hits?)\s*:?[\s]*(?P<h>\d+)\b", re.IGNORECASE)
RULEUSE_TAB_ROW = re.compile(r"^(?P<name>.+?)\s{2,}(?P<h>\d+)\s{2,}(?P<ts>[-0-9: /]+)?\s*$")
HEADER_HINTS=("rule name","hit count","timestamp")
SECTION_HINTS=("slot","dp ")
def _parse_ruleuse_hitcounts(txt: str):
    hits={}
    if not txt: return hits
    lines=[ln.rstrip() for ln in txt.splitlines() if ln.strip()]
    for ln in lines:
        low=ln.lower()
        if any(h in low for h in HEADER_HINTS): continue
        if any(low.startswith(h) for h in SECTION_HINTS): continue
        if set(ln.strip())<=set("-_"): continue
        m=RULEUSE_KV.search(ln)
        if m:
            name=m.group('name').strip().strip('"')
            try: hits[name]=int(m.group('h'))
            except: pass
            continue
        m2=RULEUSE_TAB_ROW.match(ln)
        if m2:
            name=m2.group('name').strip().strip('"')
            try: hits[name]=int(m2.group('h'))
            except: pass
            continue
        parts=ln.split()
        if parts and parts[-1].isdigit():
            name=ln[:ln.rfind(parts[-1])].rstrip().strip('"')
            try: hits.setdefault(name,int(parts[-1]))
            except: pass
    return hits

# ---- Risk model: ANY + BROAD + selected ports -----------------------------------
ANY_TOKENS = {'any','any4','any-ip','0.0.0.0/0'}

# Configurable risky ports: HTTP(80), FTP(21)
SENSITIVE_PORTS = {80, 21}
PORT_TOKENS = {
    80: {'http','tcp/80','udp/80',':80'},
    21: {'ftp','tcp/21','udp/21',':21'},
}

def _is_any(v: str) -> bool:
    return str(v or '').strip().lower() in ANY_TOKENS

def _cidr_mask(v: str):
    m = IP_CIDR_RE.match(str(v or '').strip())
    if not m: return None
    try: return int(m.group('mask'))
    except: return None

def _is_broad(v: str) -> bool:
    """
    BROAD if CIDR mask <= /16 (applies to RFC1918 and public).
    Ranges or single IPs without '/mask' are not treated as 'broad' here.
    """
    mask = _cidr_mask(v)
    if mask is None: return False
    return mask <= 16

def _mentions_port(text: str, port: int) -> bool:
    t = str(text or '').lower()
    if any(tok in t for tok in PORT_TOKENS[port]): return True
    # match raw ":80" or "/80" with word boundaries
    return bool(re.search(rf'(?<!\d)(?:/|:)\s*{port}(?!\d)', t))

def _risk_reasons(action: str,
                  src: str, dst: str,
                  from_zone: str, to_zone: str,
                  remark: str, service: str, application: str) -> list[str]:
    """
    Final risk logic (your definition):
    - ANY in src/dst/both
    - BROAD (mask <= /16) in src/dst/both
    - ANY<->BROAD or BROAD<->host combinations
    - risky ports (80,21) are secondary
    """
    a = (action or '').lower()
    if a not in {'permit','allow'}: return []

    reasons = []

    any_s = _is_any(src)
    any_d = _is_any(dst)
    br_s  = _is_broad(src)
    br_d  = _is_broad(dst)

    # ANY categories
    if any_s: reasons.append('any_src')
    if any_d: reasons.append('any_dst')
    if any_s and any_d: reasons.append('any_any')

    # BROAD categories
    if br_s: reasons.append('broad_src')
    if br_d: reasons.append('broad_dst')
    if br_s and br_d: reasons.append('broad_both')

    # Combinations
    if any_s and br_d: reasons.append('any_to_broad')
    if br_s and any_d: reasons.append('broad_to_any')
    if br_s and not br_d: reasons.append('broad_to_host')
    # (Optionally add: if br_d and not br_s: reasons.append('host_to_broad'))

    # Sensitive ports (secondary)
    port_ctx = ' '.join([
        str(remark or ''), str(src or ''), str(dst or ''),
        str(from_zone or ''), str(to_zone or ''), str(service or ''), str(application or '')
    ])
    for p in SENSITIVE_PORTS:
        if _mentions_port(port_ctx, p):
            reasons.append(f'port={p}')

    # De-duplicate while preserving order
    seen=set(); dedup=[]
    for r in reasons:
        if r not in seen:
            seen.add(r); dedup.append(r)
    return dedup

# ---- Name normalization + ACL Action Index --------------------------------------
def _norm_name(s: str) -> str:
    """Normalize rule names for relaxed matching across sources."""
    return re.sub(r'[\s_\-]+', '', (s or '').strip().lower())

class _AclActionIndex:
    """
    Minimal in-memory index to recover 'action' for zero-hit rows from ACL rows
    written earlier in the same run. Avoids file reads/locks.
    """
    def __init__(self):
        self.by_name = {}   # normalized name -> action
        self.by_hash = {}   # ace_hash -> action (optional use)
    def add(self, name: str, action: str, ace_hash: str = ""):
        act=(action or '').strip().lower()
        if name:
            self.by_name[_norm_name(name)] = act
        if ace_hash:
            self.by_hash[ace_hash] = act
    def get_by_name(self, name: str) -> str:
        return self.by_name.get(_norm_name(name), "")
    def get_by_hash(self, h: str) -> str:
        return self.by_hash.get(h, "")

# ---- Entry point ----------------------------------------------------------------
def collect(session, hostmeta, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky):
    hostname=(hostmeta.get("hostname") or hostmeta.get("ip") or "palo") if isinstance(hostmeta, dict) else "palo"
    platform_for_csv="Palo Alto"; platform_tag="palo"
    latest_dir=_abs_dir_from_hostmeta(hostmeta,"reports/latest/logs")
    ts=datetime.now().strftime("%Y%m%d-%H%M%S")
    log_path=os.path.join(latest_dir, f"{hostname}_{platform_tag}_{ts}.log")
    dump_path=os.path.join(latest_dir, f"{hostname}_{platform_tag}_{ts}_ruleuse_dump.txt")
    log_lines=[f"==== START {datetime.now().isoformat()} ====\n",
               f"HOST={hostname} PLATFORM={platform_tag}\n",
               f"LOG_PATH={log_path}\n\n"]

    # Ensure operational mode ('>')
    try:
        p=session.find_prompt().strip()
        if p.endswith("#"):
            session.send_command("exit", expect_string=r"[>#]\s*$")
    except: pass

    # Counters & Action index
    acl_written = 0
    risky_written = 0
    zero_written = 0
    zero_emit_total = 0
    acl_index = _AclActionIndex()

    try:
        ips_txt=_run(session,"show interface all")
        routes_txt=_run(session,"show routing route")
        vsys_list,_=_list_vsys(session)

        for v in vsys_list:
            _run(session, f"set system setting target-vsys {v}")
            a_txt=_run(session, "show running security-policy")

            # rule-use across bases
            ru_maps={}; ru_total=0; dump_buf=[]
            for rb in ("security","pre-rulebase","post-rulebase"):
                cmd=f"show running rule-use hit-count rules all vsys {v} rule-base {rb}"
                ru_txt=_run(session, cmd)
                dump_buf.append(f"\n#### {cmd}\n{ru_txt or ''}\n")
                m=_parse_ruleuse_hitcounts(ru_txt)
                if m: ru_maps[rb]=m; ru_total+=len(m)
            _write_text(dump_path, "".join(dump_buf))
            log_lines.append(
                f"VSYS {v}: ruleuse_maps={','.join([f'{k}:{len(ru_maps[k])}' for k in ru_maps])} total={ru_total}\n"
            )

            parsed=_parse_policies_palo(a_txt or "")

            # merge hits (case-insensitive names)
            ru_all={}
            for _rb,m in ru_maps.items():
                for name,hc in m.items():
                    ru_all[(name or '').strip().strip('"').lower()]=hc

            # policy name -> record
            pol_by_name={}
            for r in parsed:
                nm=(r.get('name') or '').strip().strip('"')
                if nm: pol_by_name[nm.lower()]=r

            zero_emit_vsys=0
            for r in parsed:
                name_key=(r.get('name') or '').strip().strip('"').lower()
                hc=ru_all.get(name_key)
                if hc is None:
                    nk2=re.sub(r"[\s\-]+","", name_key)
                    for k,v_h in ru_all.items():
                        if re.sub(r"[\s\-]+","", k)==nk2:
                            hc=v_h; break
                hit_str=str(hc) if isinstance(hc,int) else ""

                action=(r.get('action') or '').lower().strip()
                if action not in ('permit','allow'): continue
                if bool(r.get('inactive', False)): continue

                z=f"from {r.get('from_zone','')} to {r.get('to_zone','')}".strip()
                remark_parts=[]
                if hit_str: remark_parts.append(f"hit_count={hit_str}")
                if z and z!="from to": remark_parts.append(z)
                remark="; ".join(remark_parts)

                svc=(r.get('service') or '').strip()
                app=(r.get('application') or '').strip()

                raw_ace=(
                    f"set rulebase security rules {r.get('name') or r.get('rule_id','rule')} "
                    f"from {r.get('from_zone','any')} to {r.get('to_zone','any')} "
                    f"source {r.get('src','any')} destination {r.get('dst','any')} "
                    f"action {action}"
                    + (f" service {svc}" if svc else "")
                    + (f" application {app}" if app else "")
                ).strip()

                ace_hash=hashlib.md5(raw_ace.encode('utf-8')).hexdigest()

                # ACL row
                writer_acls.writerow({
                    "hostname":hostname,"platform":platform_for_csv,
                    "rule_id":r["rule_id"],"action":action,"src":r["src"],"dst":r["dst"],
                    "hit_count":hit_str,"ace_hash":ace_hash,"remark":remark,"raw_ace":raw_ace
                })
                acl_written += 1

                # Index action by name/hash for zero-hit recovery
                acl_index.add(r.get('name') or r.get('rule_id',''), action, ace_hash)

                # Risky row
                reasons=_risk_reasons(
                    action, r.get('src',''), r.get('dst',''),
                    r.get('from_zone',''), r.get('to_zone',''),
                    remark, svc, app
                )
                if reasons:
                    risk_remark = remark + ("; " if remark else "") + "risk=" + ",".join(reasons)
                    writer_risky.writerow({
                        "hostname":hostname,"platform":platform_for_csv,"rule_id":r["rule_id"],
                        "action":action,"src":r["src"],"dst":r["dst"],"hit_count":hit_str,
                        "ace_hash":ace_hash,"remark":risk_remark,"raw_ace":raw_ace,
                        "risk":",".join(reasons),"risk_description":" | ".join(reasons),
                    })
                    risky_written += 1

            # ZERO-HIT rows from rule-use
            for k,hc in ru_all.items():
                if hc!=0: continue
                rr=pol_by_name.get(k)
                if not rr:
                    key2=re.sub(r"[\s\-]+","", k)
                    for kk,pp in pol_by_name.items():
                        if re.sub(r"[\s\-]+","", kk)==key2:
                            rr=pp; break

                if rr:
                    action=(rr.get('action') or '').lower().strip()
                    inactive=bool(rr.get('inactive', False))
                    if action not in ('permit','allow') or inactive: continue
                    src=rr.get('src','any'); dst=rr.get('dst','any')
                    remark=f"from {rr.get('from_zone','')} to {rr.get('to_zone','')}".strip()
                    raw_ace=(
                        f"set rulebase security rules {rr.get('name') or rr.get('rule_id','rule')} "
                        f"from {rr.get('from_zone','any')} to {rr.get('to_zone','any')} "
                        f"source {src} destination {dst} action {action}"
                    ).strip()
                    ace_hash=hashlib.md5(raw_ace.encode('utf-8')).hexdigest()
                    writer_zero.writerow({
                        "hostname":hostname,"platform":platform_for_csv,"rule_id":rr.get('name') or k,
                        "action":action,"src":src,"dst":dst,"hit_count":"0",
                        "ace_hash":ace_hash,"remark":remark,"raw_ace":raw_ace
                    })
                    zero_written += 1
                    zero_emit_vsys+=1
                else:
                    # Unmatched rule-use entry:
                    # Try to recover 'action' from ACL index by relaxed name matching.
                    rec_action = acl_index.get_by_name(k)
                    writer_zero.writerow({
                        "hostname":hostname,"platform":platform_for_csv,"rule_id":k,
                        "action":rec_action,  # blank if not found; no hard-coding
                        "src":"any","dst":"any","hit_count":"0","ace_hash":"",
                        "remark": f"vsys={v} (unmatched rule-use; action recovered from ACLs)" if rec_action else f"vsys={v} (unmatched rule-use)",
                        "raw_ace":""
                    })
                    zero_written += 1
                    zero_emit_vsys+=1

            log_lines.append(f"VSYS {v}: zero_hit_emitted={zero_emit_vsys}\n")
            zero_emit_total += zero_emit_vsys
            _run(session, "set system setting target-vsys none")

        # IPs & Routes
        for r in _parse_ips_palo(ips_txt or ""):
            writer_ips.writerow({
                "hostname":hostname,"platform":platform_for_csv,
                "interface":r["interface"],"ip":r["ip"],"mask":r["mask"]
            })
        for r in _parse_routes_palo(routes_txt or ""):
            writer_routes.writerow({
                "hostname":hostname,"platform":platform_for_csv,
                "vrf":r["vrf"],"route":r["prefix"],"nexthop":r["next_hop"]
            })

        # Final counters in log
        log_lines.append(f"ZERO_HIT_TOTAL={zero_emit_total}\n")
        log_lines.append(f"ACL_WRITTEN={acl_written} RISKY_WRITTEN={risky_written} ZERO_WRITTEN={zero_written}\n")
        _write_text(log_path, "".join(log_lines))
        return routes_txt or "", ips_txt or "", ""

    except Exception:
        tb = traceback.format_exc()
        log_lines.append("\n[ERROR]\n"+tb)
        _write_text(log_path, "".join(log_lines))
        return "","",""