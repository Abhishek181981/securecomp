#!/usr/bin/env python3
"""
Fixed + DIAG patcher for gui_factory_ready13_secure.py
- Shows `remark` column in Risky Rules UI
- Derives `risk_tags` from `remark` (risk=source, risk=destination, etc.)
- Adds filter tokens `risk:` and `remark:`; also includes both in free-text search
- Creates <file>.bak backup and writes patched file atomically (no partial writes)

Usage:
    python patch_risky_gui_FIXED_DIAG_v2.py /path/to/gui_factory_ready13_secure.py
"""
import sys, re, os
from pathlib import Path

def _replace_once(text: str, pattern: str, repl: str, *, flags=0, label: str) -> str:
    new_text, n = re.subn(pattern, repl, text, flags)
    if n == 0:
        raise RuntimeError(f"Patch chunk not found: {label}")
    return new_text

def main():
    # --- DIAGNOSTIC BANNER ---
    print("=== PATCHER RUN DIAG ===")
    print("This script file:", os.path.abspath(__file__))  # <-- shows which file actually ran
    print("CWD:", os.path.abspath(os.getcwd()))
    print("========================")

    if len(sys.argv) != 2:
        print("Usage: python patch_risky_gui_FIXED_DIAG_v2.py /path/to/gui_factory_ready13_secure.py")
        sys.exit(2)

    target_path = Path(sys.argv[1]).resolve()
    if not target_path.is_file():
        print(f"File not found: {target_path}")
        sys.exit(2)

    original = target_path.read_text(encoding='utf-8')
    patched = original

    # ---------------- Patch 1: _load_all_risky_rows -> enrich with remark/risk_tags and rule_id->line
    pat1 = (
        r"(def\s+_load_all_risky_rows\(self\):[\s\S]*?for\s+r\s+in\s+dr:\n\s*)"
        r"self\.risky_rows\.append\(dict\(r\)\)"
    )
    repl1 = (
        r"\1# --- PATCH: normalize aliases and enrich ---\n"
        r"            norm = dict(r)\n\n"
        r"            # alias: rule_id -> line (so 'line' shows up for datasets with rule_id only)\n"
        r"            if ('line' not in norm) and ('rule_id' in norm):\n"
        r"                norm['line'] = norm.get('rule_id')\n\n"
        r"            # optional: parse risk tokens from remark into 'risk_tags'\n"
        r"            remark_val = (norm.get('remark') or '').strip()\n"
        r"            if remark_val:\n"
        r"                toks = []\n"
        r"                for part in remark_val.split(','):\n"
        r"                    p = part.strip()\n"
        r"                    if p.lower().startswith('risk='):\n"
        r"                        toks.append(p[len('risk='):].strip())\n"
        r"                if toks:\n"
        r"                    norm['risk_tags'] = '; '.join(toks)\n\n"
        r"            self.risky_rows.append(norm)"
    )
    patched = _replace_once(patched, pat1, repl1, flags=re.MULTILINE, label="_load_all_risky_rows loop")

    # ---------------- Patch 2: _risky__preferred_columns -> include risk_tags and push 'remark' to end
    pat2 = r"def\s+_risky__preferred_columns\(self,\s*rows\):[\s\S]*?\n\s*return\s+cols\n"
    repl2 = (
        "def _risky__preferred_columns(self, rows):\n"
        "    \"\"\"\n"
        "    Build an adaptive header:\n"
        "    1) Start with a known useful order.\n"
        "    2) Add any extra fields present in the file (e.g., rule_id, remark, category).\n"
        "    3) Place 'remark' last for readability.\n"
        "    \"\"\"\n"
        "    base_pref = [\n"
        "        'hostname', 'device', 'platform',\n"
        "        'acl', 'line', 'rule_id',\n"
        "        'action', 'src', 'dst',\n"
        "        'apps', 'hits', 'score',\n"
        "        'risk_tags'\n"
        "    ]\n\n"
        "    present = set(rows[0].keys()) if rows else set()\n"
        "    cols = [c for c in base_pref if c in present]\n\n"
        "    # Append any remaining columns in file order (so we don't hide new fields)\n"
        "    for k in rows[0].keys() if rows else []:\n"
        "        if k not in cols:\n"
        "            cols.append(k)\n\n"
        "    # Prefer to show 'remark' at the end (keeps table readable)\n"
        "    if 'remark' in cols:\n"
        "        cols = [c for c in cols if c != 'remark'] + ['remark']\n\n"
        "    if not cols and rows:\n"
        "        cols = list(rows[0].keys())\n"
        "    return cols\n"
    )
    patched = _replace_once(patched, pat2, repl2, flags=re.MULTILINE, label="_risky__preferred_columns body")

    # ---------------- Patch 3A/3B: extend _matches_risky_filter with risk/remark in haystack
    pat3a = (
        r"(def\s+_matches_risky_filter\(self,\s*rec,\s*query:str\)\s*->\s*bool:[\s\S]*?\n\s*"
        r"plat_val\s*=\s*str\(rec\.get\('platform'\)\s*or\s*''\)\s*\n\s*"
        r"host_val\s*=\s*str\(rec\.get\('hostname'\)\s*or\s*rec\.get\('device'\)\s*or\s*''\)\s*\n)"
        r"(\s*hay\s*=\s*'\s*'\.join\(\[\s*\n[\s\S]*?\]\)\.lower\(\)\s*\n)"
    )
    repl3a = (
        r"\1"
        r"    # --- PATCH: include risk and remark fields in filterable content ---\n"
        r"    risk_val = str(rec.get('risk_tags') or '')\n"
        r"    remark_val = str(rec.get('remark') or '')\n\n"
        r"    hay = ' '.join([\n"
        r"        host_val, plat_val,\n"
        r"        str(rec.get('acl') or ''), str(rec.get('name') or ''),\n"
        r"        str(rec.get('action') or ''), src_val, dst_val, apps_val,\n"
        r"        risk_val, remark_val\n"
        r"    ]).lower()\n"
    )
    patched = _replace_once(patched, pat3a, repl3a, flags=re.MULTILINE, label="_matches_risky_filter locals+haystack")

    # ---------------- Patch 3C: add token handlers for risk: and remark:
    pat3c = (
        r"(elif\s+tl\.startswith\('acl:'\):\n\s*sub\s*=\s*tl\.split\(':',1\)\[1\]\n\s*"
        r"if\s+sub\s+not\s+in\s+str\(rec\.get\('acl'\)\s*or\s*''\)\.lower\(\):\n\s*return\s+False\n)\s*else:"
    )
    repl3c = (
        r"\1"
        r"        elif tl.startswith('risk:'):\n"
        r"            sub = tl.split(':', 1)[1]\n"
        r"            if sub not in risk_val.lower():\n"
        r"                return False\n"
        r"        elif tl.startswith('remark:'):\n"
        r"            sub = tl.split(':', 1)[1]\n"
        r"            if sub not in remark_val.lower():\n"
        r"                return False\n"
        r"        else:"
    )
    patched = _replace_once(patched, pat3c, repl3c, flags=re.MULTILINE, label="_matches_risky_filter token handlers")

    # ---- Write backup and patched target safely
    backup_path = target_path.with_suffix(target_path.suffix + '.bak')
    backup_path.write_text(original, encoding='utf-8')
    target_path.write_text(patched, encoding='utf-8')

    print("Patched successfully. Backup created:", backup_path)

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print("ERROR:", e)
        sys.exit(1)