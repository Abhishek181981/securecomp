import pandas as pd
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
from tkinter import Tk, Label, Button, filedialog, simpledialog, messagebox
import threading
import csv
from datetime import datetime
import smtplib
from email.mime.text import MIMEText

FW_CSV = "firewalls.csv"
IOC_CSV = "ioc_list.csv"
MASTER_IOC = "master_ioc.csv"


# === Email notification ===
def send_email(recipients):
    msg = MIMEText("IOC addition process has completed successfully.")
    msg["Subject"] = "✅ IOC Addition Completed"
    msg["From"] = "noreply@yourdomain.com"
    msg["To"] = ", ".join(recipients)

    try:
        with smtplib.SMTP("smtp.example.com", 587) as server:
            server.starttls()
            server.login("noreply@yourdomain.com", "yourpassword")
            server.send_message(msg)
        print("📧 Email notification sent.")
    except Exception as e:
        print(f"⚠️ Email failed: {str(e)}")


# === Core IOC push function ===
def push_ioc(fw_user, fw_pass, enable_pass):
    try:
        df_fw = pd.read_csv(FW_CSV)
        try:
            ioc_df = pd.read_csv(IOC_CSV)
        except pd.errors.EmptyDataError:
            ioc_df = pd.DataFrame(columns=["ioc_ip"])

        if "ioc_ip" not in ioc_df.columns:
            messagebox.showerror("Error", f"'ioc_ip' column not found in {IOC_CSV}")
            return

        ioc_ips = [str(ip).strip() for ip in ioc_df["ioc_ip"]
                   if ip and str(ip).strip() != "0.0.0.0" and str(ip).replace(".", "").isdigit()]

        if not ioc_ips:
            messagebox.showwarning("Warning", "No valid IOC IPs found.")
            return

        for _, fw_row in df_fw.iterrows():
            fw_name = str(fw_row["firewall_name"]).strip()
            fw_ip = str(fw_row["ip"]).strip()
            platform = str(fw_row["platform"]).strip().lower()

            print(f"\n✅ Pushing IOC to {fw_name} ({fw_ip})")

            try:
                device = {
                    "device_type": "cisco_asa" if platform == "asa" else "juniper_junos",
                    "ip": fw_ip,
                    "username": fw_user,
                    "password": fw_pass,
                    "secret": enable_pass,
                }

                net_connect = ConnectHandler(**device)

                if platform == "asa":
                    if not net_connect.check_enable_mode():
                        net_connect.enable()
                    for ip in ioc_ips:
                        cmd = f"object-group network GENERAL_IOC\n network-object host {ip}"
                        net_connect.send_config_set(cmd.splitlines())

                elif platform == "srx":
                    net_connect.config_mode()
                    for ip in ioc_ips:
                        cmd = f"set security address-book global address IOC_{ip.replace('.', '_')} {ip}"
                        net_connect.send_command(cmd)
                        cmd2 = f"set security address-book global address-set GENERAL_IOC address IOC_{ip.replace('.', '_')}"
                        net_connect.send_command(cmd2)
                    net_connect.commit()

                df_fw.loc[df_fw["ip"] == fw_ip, "status"] = "Success"
                net_connect.disconnect()
                print(f"✅ IOC pushed successfully to {fw_name} ({fw_ip})")

            except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
                print(f"❌ Connection failed for {fw_name} ({fw_ip}): {str(e)}")
                df_fw.loc[df_fw["ip"] == fw_ip, "status"] = "Failed"
            except Exception as e:
                print(f"❌ Error with {fw_name} ({fw_ip}): {str(e)}")
                df_fw.loc[df_fw["ip"] == fw_ip, "status"] = "Failed"

        df_fw.to_csv(FW_CSV, index=False)
        print("\n✅ IOC push completed. Status updated in firewalls.csv")

        # === Append IOC to master log ===
        with open(MASTER_IOC, mode="a", newline="") as f:
            writer = csv.writer(f)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for ip in ioc_ips:
                writer.writerow([timestamp, ip])

        print("✅ IOC entries appended to master_ioc.csv")

        # === Send Email ===
        send_email(["admin1@example.com", "admin2@example.com"])

    except Exception as e:
        messagebox.showerror("Error", f"Unexpected error: {str(e)}")


# === GUI Layer ===
def start_push():
    fw_user = simpledialog.askstring("Credentials", "Enter firewall username:")
    fw_pass = simpledialog.askstring("Credentials", "Enter firewall password:", show="*")
    enable_pass = simpledialog.askstring("Credentials", "Enter enable password:", show="*")

    if not fw_user or not fw_pass:
        messagebox.showwarning("Warning", "Credentials not entered.")
        return

    threading.Thread(target=push_ioc, args=(fw_user, fw_pass, enable_pass), daemon=True).start()


# === GUI Setup ===
root = Tk()
root.title("IOC Blocker")
root.geometry("400x200")

Label(root, text="IOC Blocker Automation", font=("Arial", 14, "bold")).pack(pady=10)
Button(root, text="Push IOC to Firewalls", command=start_push, width=25, height=2, bg="green", fg="white").pack(pady=20)

root.mainloop()
