# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# Adds the "Remediate…" button and Sprint-1 helper methods into an existing gui_remediate.py.
# Safe to run multiple times; it won't duplicate code.

import os
import re
import sys

HELPERS_SNIPPET = r'''
    # ---------------- Remediation (Thin-UI, Sprint 1: Plan-only, Dry-run) ----------------
    def _open_remediate_dialog(self):
        import tkinter as tk
        from tkinter import ttk, messagebox
        top = tk.Toplevel(self.root)
        top.title("Remediate Zero-hit ACLs")
        top.transient(self.root)
        top.grab_set()
        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        for c in range(2): frm.columnconfigure(c, weight=1)
        self._rm_dry = tk.BooleanVar(value=True)
        self._rm_backup = tk.BooleanVar(value=True)
        self._rm_ticket = tk.StringVar(value='')
        self._rm_confirm = tk.IntVar(value=5)
        self._rm_panorama = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text="Dry-run (no device changes)", variable=self._rm_dry).grid(row=0, column=0, columnspan=2, sticky='w')
        ttk.Checkbutton(frm, text="Backup before change (future exec only)", variable=self._rm_backup).grid(row=1, column=0, columnspan=2, sticky='w')
        ttk.Label(frm, text="Ticket ID (optional):").grid(row=2, column=0, sticky='w', pady=(6,0))
        ttk.Entry(frm, textvariable=self._rm_ticket).grid(row=2, column=1, sticky='ew', pady=(6,0))
        ttk.Label(frm, text="SRX commit-confirm (minutes):").grid(row=3, column=0, sticky='w', pady=(6,0))
        ttk.Spinbox(frm, from_=1, to=60, textvariable=self._rm_confirm, width=6).grid(row=3, column=1, sticky='w', pady=(6,0))
        ttk.Checkbutton(frm, text="Panorama-aware mode (experimental)", variable=self._rm_panorama).grid(row=4, column=0, columnspan=2, sticky='w')
        btns = ttk.Frame(frm); btns.grid(row=5, column=0, columnspan=2, sticky='e', pady=(10,0))
        ttk.Button(btns, text="Cancel", command=top.destroy).grid(row=0, column=0, padx=(0,6))
        ttk.Button(btns, text="Generate Plan", command=lambda: [self._generate_remediation_plan(), top.destroy()]).grid(row=0, column=1)

    def _collect_zero_selection_rows(self):
        header = getattr(self, '_zero_last_header', None)
        rows   = getattr(self, '_zero_last_rows', None) or []
        tv     = getattr(self, 'console_tree_zero', None)
        if not header or not rows: return []
        dict_rows = []
        for r in rows:
            if isinstance(r, dict):
                dict_rows.append(dict(r))
            else:
                d = {}
                for i, col in enumerate(header):
                    d[col] = ('' if col == '#' else (r[i-1] if 0 <= i-1 < len(r) else ''))
                dict_rows.append(d)
        try: sel = tv.selection()
        except Exception: sel = []
        if sel:
            selected = set()
            for iid in sel:
                vals = tv.item(iid, 'values')
                selected.add('\x01'.join([str(v) for v in vals]))
            filtered = []
            for d in dict_rows:
                fp = []
                for c in header:
                    fp.append(str(d.get('#','')) if c=='#' else str(d.get(c,'')))
                if '\x01'.join(fp) in selected:
                    filtered.append(d)
            return filtered
        return dict_rows

    def _generate_remediation_plan(self):
        import os, json, datetime
        from tkinter import messagebox
        rows = self._collect_zero_selection_rows()
        if not rows:
            try: messagebox.showinfo('Remediate', 'No rows to remediate. Load a Zero-hit page and select rows (or leave unselected to include the page).')
            except Exception: pass
            return
        targets = {}
        for r in rows:
            device   = (r.get('hostname') or r.get('device') or '').strip() or '(unknown)'
            platform = (r.get('platform') or '').strip() or '(unknown)'
            key = (device, platform)
            if key not in targets:
                targets[key] = {'device': device, 'platform': platform, 'auth_ref': 'global', 'rules': []}
            rule = {
                'source_row_key': 'zero',
                'rule_name': r.get('rule_name') or r.get('name') or '',
                'policy': r.get('policy') or r.get('acl') or '',
                'acl': r.get('acl') or '',
                'line': r.get('line') or r.get('rule_id') or '',
                'src': r.get('src') or '',
                'dst': r.get('dst') or '',
                'apps': r.get('apps') or r.get('application') or '',
                'service': r.get('service') or '',
                'action': r.get('action') or '',
                'zones': r.get('zones') or r.get('from_to') or '',
                'category': r.get('category') or '',
                'remark': r.get('remark') or ''
            }
            targets[key]['rules'].append(rule)
        run_id = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        opts = {
            'dry_run': bool(getattr(self, '_rm_dry', None).get() if getattr(self, '_rm_dry', None) else True),
            'backup': bool(getattr(self, '_rm_backup', None).get() if getattr(self, '_rm_backup', None) else True),
            'ticket_id': (getattr(self, '_rm_ticket', None).get() if getattr(self, '_rm_ticket', None) else ''),
            'srx_commit_confirm_minutes': int(getattr(self, '_rm_confirm', None).get() if getattr(self, '_rm_confirm', None) else 5),
            'panorama_mode': bool(getattr(self, '_rm_panorama', None).get() if getattr(self, '_rm_panorama', None) else False)
        }
        plan = {'run_id': run_id, 'options': opts, 'targets': list(targets.values())}
        try:
            base_dir = os.path.dirname(os.path.abspath(self.risk_path_var.get() or 'dashboard.csv')) or '.'
        except Exception:
            base_dir = '.'
        rep_dir = os.path.join(base_dir, 'remediation', run_id)
        try: os.makedirs(rep_dir, exist_ok=True)
        except Exception: pass
        plan_path = os.path.join(rep_dir, 'plan.json')
        try:
            with open(plan_path, 'w', encoding='utf-8') as f:
                json.dump(plan, f, indent=2)
            self._append_ctx(f"[REMED] Plan written -> {plan_path}\n", ctx='logs')
        except Exception as e:
            self._append_ctx(f"[REMED] Failed to write plan: {e}\n", ctx='logs')
            return
        self._run_remediator(plan_path)

    def _run_remediator(self, plan_path:str):
        import os, subprocess, sys
        from tkinter import messagebox
        rem_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools', 'remediator.py')
        if not os.path.isfile(rem_path):
            self._append_ctx(f"[REMED] remediator not found at: {rem_path}\n", ctx='logs')
            try: messagebox.showerror('Remediate', 'remediator.py not found in tools/.')
            except Exception: pass
            return
        try:
            proc = subprocess.run([sys.executable, rem_path, '--plan', plan_path], capture_output=True, text=True, timeout=300)
            out = proc.stdout or ''
            err = proc.stderr or ''
            rc  = proc.returncode
            if out: self._append_ctx(out + ('' if out.endswith('\n') else '\n'), ctx='logs')
            if err: self._append_ctx('[stderr]\n' + err + ('' if err.endswith('\n') else '\n'), ctx='logs')
            self._append_ctx(f"[REMED] remediator exit code: {rc}\n", ctx='logs')
        except Exception as e:
            self._append_ctx(f"[REMED] Failed to run remediator: {e}\n", ctx='logs')
'''

def main():
    if len(sys.argv) < 2:
        print("Usage: python inject_remediate_button.py <path-to-gui_remediate.py>")
        sys.exit(2)
    path = sys.argv[1]
    if not os.path.isfile(path):
        print(f"[inject] File not found: {path}")
        sys.exit(2)

    with open(path, 'r', encoding='utf-8') as f:
        src = f.read()

    # 1) Ensure helpers exist
    if '_generate_remediation_plan' not in src:
        marker = '# ---------------- Logs & Reports TAB ----------------'
        if marker in src:
            idx = src.find(marker)
            src = src[:idx] + HELPERS_SNIPPET + '\n' + src[idx:]
            print("[inject] Added helper methods before Logs section.")
        else:
            src = src + '\n' + HELPERS_SNIPPET + '\n'
            print("[inject] Added helper methods at file end (fallback).")
    else:
        print("[inject] Helper methods already present (skipping).")

    # 2) Add “Remediate…” button into Zero-hit toolbar (zc_btns frame)
    # Try bump columns 5 -> 6
    changed_cols = False
    src2 = re.sub(r'(for c in range\()\s*5(\s*\)\s*:\s*zc_btns\.columnconfigure\(\s*c\s*,\s*weight\s*=\s*1\s*\))',
                  r'\g<1>6\2', src)
    if src2 != src:
        changed_cols = True
        src = src2

    # Insert button after Console
    console_btn_regex = r'(ttk\.Button\(zc_btns,\s*text=(?:\'▼ Console\'|"▼ Console"|\'Console ▼\'|"Console ▼"),\s*command=.*?\)\.grid\(row=0,\s*column=)\d(.*?\))'
    m = re.search(console_btn_regex, src, flags=re.S)
    if m:
        # Keep console at col=4; Remediate at col=5
        full = m.group(0)
        inject = '\n        ttk.Button(zc_btns, text="Remediate…", command=self._open_remediate_dialog).grid(row=0, column=5, sticky=\'ew\')'
        src = src.replace(full, full + inject)
        print("[inject] Added Remediate… button after Console button.")
    else:
        # Fallback: insert after Export button (col=3)
        export_btn_regex = r'(ttk\.Button\(zc_btns,\s*text=(?:\'Export Zero[\u2011-\-]hit to Excel\'|"Export Zero[\u2011-\-]hit to Excel"),\s*command=.*?\)\.grid\(row=0,\s*column=)\d(.*?\))'
        m2 = re.search(export_btn_regex, src, flags=re.S)
        if m2:
            full = m2.group(0)
            inject = '\n        ttk.Button(zc_btns, text="Remediate…", command=self._open_remediate_dialog).grid(row=0, column=4, sticky=\'ew\')'
            src = src.replace(full, full + inject)
            # Best-effort: shift Console to column 5 if present
            src = re.sub(r'(ttk\.Button\(zc_btns,\s*text=(?:\'▼ Console\'|"▼ Console"|\'Console ▼\'|"Console ▼"),\s*command=.*?\.grid\(row=0,\s*column=)\d',
                         r'\g<1>5', src, flags=re.S)
            print("[inject] Added Remediate… button after Export button (fallback).")
        else:
            print("[inject] ERROR: Could not locate Zero-hit toolbar to add Remediate… button.")
            sys.exit(3)

    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)

    print(f"[inject] Patched in-place: {path}")
    print("[inject] Next: run `python gui_remediate.py`, go to Zero-hit tab, look at the top-right for “Remediate…”.")
    print("[inject] If it still doesn’t show, paste the Zero-hit toolbar code block and I’ll tailor an exact drop-in.")

if __name__ == '__main__':
    main()