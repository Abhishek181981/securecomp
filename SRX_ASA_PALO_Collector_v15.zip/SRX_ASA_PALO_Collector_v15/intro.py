# -*- coding: utf-8 -*-
"""intro.py (requested name: into.py)

Splash/login launcher for the Firewall ACL Automation GUI.

Fix: ttk.LabelFrame does NOT support a 'state' option on Windows/Tk 8.6+, so we
enable/disable child widgets instead.

Features
- Modern-looking Tkinter splash screen.
- Login via Email OTP using a company SMTP relay by IP (no username/password).
- Launches the target GUI script in a separate Python process.

Config via settings.json (optional):
  - smtp_relay_ip (str)
  - smtp_relay_port (int)
  - smtp_from (str)
  - allowed_email_domain (str)  # optional
  - otp_ttl_seconds (int)       # default 300
  - target_gui (str)            # GUI python file name

"""

import os
import sys
import json
import time
import random
import threading
import subprocess
import smtplib
from email.message import EmailMessage

import tkinter as tk
from tkinter import ttk, messagebox

# ============================
# CONFIG (defaults)
# ============================
DEFAULT_TARGET_GUI = "gui_factory_ready13_fullpatched.py"  # change if your GUI file differs
DEFAULT_SMTP_RELAY_IP = "127.0.0.1"                        # <-- set your relay IP
DEFAULT_SMTP_RELAY_PORT = 25
DEFAULT_SMTP_FROM = "noreply@company.com"                  # <-- set a valid From for your relay
DEFAULT_ALLOWED_DOMAIN = ""                                # e.g. "company.com" or "" to allow any
DEFAULT_OTP_TTL = 300                                       # seconds

APP_TITLE = "Firewall ACL Automation Tool"
APP_SUBTITLE = "Secure Launcher"

# Optional password mode (disabled unless env var set)
ENV_PASSWORD = os.environ.get("INTRO_APP_PASSWORD", "").strip()


def load_settings(path: str = "settings.json") -> dict:
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f) if f else {}
    except Exception:
        pass
    return {}


class OTPManager:
    def __init__(self, ttl_seconds: int = DEFAULT_OTP_TTL):
        self.ttl_seconds = ttl_seconds
        self._otp = None
        self._issued_at = None
        self._email = None

    def issue(self, email: str) -> str:
        otp = f"{random.randint(0, 999999):06d}"
        self._otp = otp
        self._issued_at = time.time()
        self._email = email
        return otp

    def valid_for(self, email: str, otp: str) -> bool:
        if not self._otp or not self._issued_at or not self._email:
            return False
        if email.strip().lower() != self._email.strip().lower():
            return False
        if (time.time() - self._issued_at) > self.ttl_seconds:
            return False
        return otp.strip() == self._otp

    def seconds_left(self) -> int:
        if not self._issued_at:
            return 0
        left = int(self.ttl_seconds - (time.time() - self._issued_at))
        return max(0, left)


def send_otp_email(relay_ip: str, relay_port: int, mail_from: str, mail_to: str, otp: str, timeout: int = 20) -> None:
    """Send OTP via unauthenticated SMTP relay (IP only, no auth)."""
    msg = EmailMessage()
    msg["Subject"] = "Your OTP for Firewall ACL Automation Tool"
    msg["From"] = mail_from
    msg["To"] = mail_to
    msg.set_content(
        "Hello,\n\n"
        f"Your one-time password (OTP) is: {otp}\n"
        "It is valid for a limited time.\n\n"
        "If you did not request this, you can ignore this email.\n"
    )

    with smtplib.SMTP(relay_ip, int(relay_port), timeout=timeout) as s:
        # If your relay requires STARTTLS (still no auth), uncomment:
        # s.starttls()
        s.send_message(msg)


class SplashLoginApp:
    def __init__(self, root: tk.Tk, cfg: dict):
        self.root = root
        self.cfg = cfg

        self.target_gui = cfg.get("target_gui") or DEFAULT_TARGET_GUI
        self.smtp_ip = cfg.get("smtp_relay_ip") or DEFAULT_SMTP_RELAY_IP
        self.smtp_port = int(cfg.get("smtp_relay_port") or DEFAULT_SMTP_RELAY_PORT)
        self.smtp_from = cfg.get("smtp_from") or DEFAULT_SMTP_FROM
        self.allowed_domain = (cfg.get("allowed_email_domain") or DEFAULT_ALLOWED_DOMAIN).strip().lower()
        self.otp_ttl = int(cfg.get("otp_ttl_seconds") or DEFAULT_OTP_TTL)

        self.otp = OTPManager(ttl_seconds=self.otp_ttl)

        self.mode = tk.StringVar(value="otp")  # otp | password
        self.status_var = tk.StringVar(value="Ready")
        self.timer_var = tk.StringVar(value="")

        self._build_ui()
        self._tick_timer()

    def _set_children_state(self, parent, state: str):
        """ttk.LabelFrame doesn't support -state; toggle its children."""
        try:
            for child in parent.winfo_children():
                try:
                    child.configure(state=state)
                except Exception:
                    pass
        except Exception:
            pass

    # ---------------- UI ----------------
    def _build_ui(self):
        self.root.title(f"{APP_TITLE} — {APP_SUBTITLE}")
        self.root.geometry("520x360")
        self.root.resizable(False, False)

        style = ttk.Style()
        try:
            if "vista" in style.theme_names():
                style.theme_use("vista")
            elif "clam" in style.theme_names():
                style.theme_use("clam")
        except Exception:
            pass

        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"))
        style.configure("SubHeader.TLabel", font=("Segoe UI", 10))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))

        canvas = tk.Canvas(self.root, width=520, height=360, highlightthickness=0)
        canvas.place(x=0, y=0)
        for i in range(0, 360, 4):
            r = int(230 + (25 * i / 360))
            g = int(245 + (10 * i / 360))
            b = 255
            color = f"#{r:02x}{g:02x}{b:02x}"
            canvas.create_rectangle(0, i, 520, i + 4, outline=color, fill=color)

        frame = ttk.Frame(self.root, padding=16)
        frame.place(x=0, y=0, width=520, height=360)

        ttk.Label(frame, text=APP_TITLE, style="Header.TLabel").pack(anchor="w")
        ttk.Label(frame, text="Welcome! Please authenticate to continue.", style="SubHeader.TLabel").pack(anchor="w", pady=(2, 12))

        mode_row = ttk.Frame(frame)
        mode_row.pack(fill="x")

        self.otp_rb = ttk.Radiobutton(mode_row, text="Email OTP", variable=self.mode, value="otp", command=self._refresh_mode)
        self.otp_rb.pack(side="left")

        self.pwd_rb = ttk.Radiobutton(mode_row, text="Password", variable=self.mode, value="password", command=self._refresh_mode)
        self.pwd_rb.pack(side="left", padx=(12, 0))

        if not ENV_PASSWORD:
            self.pwd_rb.configure(state="disabled")
            self.mode.set("otp")

        ttk.Separator(frame).pack(fill="x", pady=12)

        self.content = ttk.Frame(frame)
        self.content.pack(fill="both", expand=True)

        self.otp_box = ttk.LabelFrame(self.content, text="Email OTP")
        self.otp_box.pack(fill="x")

        self.email_var = tk.StringVar(value="")
        self.otp_var = tk.StringVar(value="")

        row1 = ttk.Frame(self.otp_box)
        row1.pack(fill="x", pady=(8, 4), padx=8)
        ttk.Label(row1, text="Email:").pack(side="left")
        self.email_entry = ttk.Entry(row1, textvariable=self.email_var)
        self.email_entry.pack(side="left", fill="x", expand=True, padx=(8, 0))

        row2 = ttk.Frame(self.otp_box)
        row2.pack(fill="x", pady=4, padx=8)
        ttk.Label(row2, text="OTP:").pack(side="left")
        self.otp_entry = ttk.Entry(row2, textvariable=self.otp_var)
        self.otp_entry.pack(side="left", fill="x", expand=True, padx=(8, 0))

        row3 = ttk.Frame(self.otp_box)
        row3.pack(fill="x", pady=(6, 8), padx=8)
        self.send_btn = ttk.Button(row3, text="Send OTP", command=self._send_otp_clicked)
        self.send_btn.pack(side="left")
        ttk.Label(row3, textvariable=self.timer_var, foreground="#0066cc").pack(side="left", padx=(10, 0))

        self.pwd_box = ttk.LabelFrame(self.content, text="Password")
        self.pwd_box.pack(fill="x", pady=(12, 0))

        self.pwd_var = tk.StringVar(value="")
        prow = ttk.Frame(self.pwd_box)
        prow.pack(fill="x", pady=10, padx=8)
        ttk.Label(prow, text="Password:").pack(side="left")
        self.pwd_entry = ttk.Entry(prow, textvariable=self.pwd_var, show="*")
        self.pwd_entry.pack(side="left", fill="x", expand=True, padx=(8, 0))

        action = ttk.Frame(frame)
        action.pack(fill="x", pady=(10, 0))
        ttk.Label(action, textvariable=self.status_var, foreground="#444").pack(side="left")
        self.login_btn = ttk.Button(action, text="Login & Launch", style="Accent.TButton", command=self._login_clicked)
        self.login_btn.pack(side="right")

        footer = ttk.Label(frame, text="Tip: Use your company email address. OTP expires automatically.", foreground="#555")
        footer.pack(anchor="w", pady=(10, 0))

        self._refresh_mode()
        self.email_entry.focus_set()

    def _refresh_mode(self):
        mode = self.mode.get()
        if mode == "otp":
            self._set_children_state(self.otp_box, "normal")
            try:
                self.pwd_entry.configure(state="disabled")
            except Exception:
                pass
            self.status_var.set("Ready for OTP login")
        else:
            self._set_children_state(self.otp_box, "disabled")
            try:
                self.pwd_entry.configure(state="normal")
            except Exception:
                pass
            self.status_var.set("Ready for password login")

    # ---------------- Actions ----------------
    def _send_otp_clicked(self):
        email = (self.email_var.get() or "").strip()
        if not email or "@" not in email:
            messagebox.showerror("OTP", "Please enter a valid email address.")
            return
        if self.allowed_domain:
            dom = email.split("@", 1)[-1].strip().lower()
            if dom != self.allowed_domain:
                messagebox.showerror("OTP", f"Email must be in domain: {self.allowed_domain}")
                return

        otp = self.otp.issue(email)
        self.status_var.set("Sending OTP...")
        self.send_btn.configure(state="disabled")

        def worker():
            try:
                send_otp_email(self.smtp_ip, self.smtp_port, self.smtp_from, email, otp)
                self.root.after(0, lambda: self.status_var.set("OTP sent. Check your inbox."))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror(
                    "OTP",
                    f"Failed to send OTP via relay {self.smtp_ip}:{self.smtp_port}\n\n{e}"
                ))
                self.root.after(0, lambda: self.status_var.set("OTP send failed"))
            finally:
                self.root.after(0, lambda: self.send_btn.configure(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    def _login_clicked(self):
        mode = self.mode.get()
        if mode == "otp":
            email = (self.email_var.get() or "").strip()
            otp = (self.otp_var.get() or "").strip()
            if not email or not otp:
                messagebox.showerror("Login", "Enter email and OTP.")
                return
            if not self.otp.valid_for(email, otp):
                left = self.otp.seconds_left()
                if left <= 0:
                    messagebox.showerror("Login", "OTP expired. Please click 'Send OTP' again.")
                else:
                    messagebox.showerror("Login", "Invalid OTP. Please try again.")
                return
        else:
            if not ENV_PASSWORD:
                messagebox.showerror("Login", "Password mode is not enabled on this machine.")
                return
            if (self.pwd_var.get() or "").strip() != ENV_PASSWORD:
                messagebox.showerror("Login", "Invalid password.")
                return

        self.status_var.set("Launching GUI...")
        ok = self._launch_gui()
        if ok:
            self.root.destroy()

    def _launch_gui(self) -> bool:
        target = self.target_gui
        if not os.path.isfile(target):
            base = os.path.dirname(os.path.abspath(__file__))
            candidate = os.path.join(base, target)
            if os.path.isfile(candidate):
                target = candidate
            else:
                messagebox.showerror(
                    "Launch",
                    f"GUI file not found: {self.target_gui}\n\nPlace it next to into.py/intro.py or update target_gui in settings.json"
                )
                self.status_var.set("Launch failed")
                return False

        try:
            cmd = [sys.executable, target]
            kwargs = {}
            if sys.platform.startswith("win"):
                kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
            subprocess.Popen(cmd, cwd=os.path.dirname(os.path.abspath(target)) or None, **kwargs)
            return True
        except Exception as e:
            messagebox.showerror("Launch", f"Failed to start GUI: {e}")
            self.status_var.set("Launch failed")
            return False

    def _tick_timer(self):
        left = self.otp.seconds_left()
        self.timer_var.set(f"OTP expires in {left}s" if left > 0 else "")
        self.root.after(1000, self._tick_timer)


def main():
    cfg = load_settings("settings.json")
    cfg.setdefault("target_gui", os.environ.get("INTRO_TARGET_GUI", "") or cfg.get("target_gui") or DEFAULT_TARGET_GUI)
    cfg.setdefault("smtp_relay_ip", os.environ.get("INTRO_SMTP_RELAY", "") or cfg.get("smtp_relay_ip") or DEFAULT_SMTP_RELAY_IP)

    root = tk.Tk()
    SplashLoginApp(root, cfg)
    root.mainloop()


if __name__ == "__main__":
    main()
