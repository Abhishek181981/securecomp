
# -*- coding: utf-8 -*-
"""
Reporting & Logging utilities for ASA ACL tool
- Creates per-run report folders with timestamps
- Writes text, JSON, and CSV reports
- Provides a simple logger with rotating global log and per-run activity logs
"""

import os
import csv
import json
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime


DEFAULT_SETTINGS = {
    "reports_base_dir": "reports",
    "global_log_file": "acl_tool.log",
    "global_log_max_mb": 5,
    "global_log_backup_count": 3,
    "debug_enabled": True,
}

_settings_cache = None
_global_logger = None


def load_settings(path="settings.json"):
    """
    Load settings.json and merge with defaults.
    Return a dict with keys present in DEFAULT_SETTINGS only.
    """
    global _settings_cache
    if _settings_cache is not None:
        return _settings_cache
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Merge defaults with provided keys
        out = dict(DEFAULT_SETTINGS)
        out.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
        _settings_cache = out
        return out
    except Exception:
        _settings_cache = dict(DEFAULT_SETTINGS)
        return _settings_cache


def get_global_logger():
    """
    Return a rotating global logger configured from settings.
    Ensures only one handler is attached to avoid duplicate logs.
    """
    global _global_logger
    if _global_logger:
        return _global_logger

    cfg = load_settings()
    logger = logging.getLogger("acl_tool")
    logger.setLevel(logging.DEBUG if cfg.get("debug_enabled") else logging.INFO)

    # Avoid duplicate handlers across re-imports/runs
    if not logger.handlers:
        log_path = cfg.get("global_log_file", "acl_tool.log")
        handler = RotatingFileHandler(
            log_path,
            maxBytes=cfg.get("global_log_max_mb", 5) * 1024 * 1024,
            backupCount=cfg.get("global_log_backup_count", 3),
            encoding="utf-8",
        )
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    _global_logger = logger
    return _global_logger


def make_run_dir(base_dir=None):
    """
    Create a timestamped report directory under base_dir (default: reports/).
    Returns the run directory path.
    """
    cfg = load_settings()
    base = base_dir or cfg.get("reports_base_dir", "reports")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(base, ts)
    os.makedirs(run_dir, exist_ok=True)
    return run_dir


def write_text(run_dir, filename, text):
    """
    Write a plain text file under run_dir.
    """
    path = os.path.join(run_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text if text is not None else "")
    return path


def write_json(run_dir, filename, data_dict):
    """
    Write a JSON file under run_dir.
    """
    path = os.path.join(run_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data_dict or {}, f, indent=2)
    return path


def append_csv(run_dir, filename, headers, row):
    """
    Append a row to CSV (creates with headers if not exists).
    """
    path = os.path.join(run_dir, filename)
    exists = os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        if not exists:
            writer.writeheader()
        writer.writerow(row)
    return path


def get_run_logger(run_dir):
    """
    Create/return a per-run logger writing to run_dir/activity.log.
    Ensures only one handler is attached for the run.
    """
    logger_name = f"run_{os.path.basename(run_dir)}"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        path = os.path.join(run_dir, "activity.log")
        handler = logging.FileHandler(path, encoding="utf-8")
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


def write_error(run_dir, message):
    """
    Append an error/warning line to errors.txt with timestamp.
    """
    path = os.path.join(run_dir, "errors.txt")
    with open(path, "a", encoding="utf-8") as f:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{ts}] {message}\n")
