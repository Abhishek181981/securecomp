# -*- coding: utf-8 -*-
"""into.py / intro.py

Secure launcher with Email OTP via SMTP relay (no auth) + audit logging.
- Restricts email domain to @colt.net
- Uses SMTP relay: 10.100.5.12:25
- From address: CyberSecurityOperationsCentre@colt.net
- Writes a short-lived auth token consumed by the GUI (single-use)

Files written by launcher:
- Audit log: %LOCALAPPDATA%\AclToolAuth\otp_audit.log  (Windows) or ~/.AclToolAuth/otp_audit.log
- Auth token: %LOCALAPPDATA%\AclToolAuth\auth_token.json

NOTE: The GUI must be the *secure* version (default target_gui below).
"""

import os
import sys
import json
import time
import random
import threading
import subprocess
import smtplib
from email.message import EmailMessage

import tkinter as tk
from tkinter import ttk, messagebox

# ============================
# HARD-CODED SECURITY CONFIG
# ============================
TARGET_GUI = "gui_remediate.py"  # secure GUI with token check
SMTP_RELAY_IP = "10.100.5.12"
SMTP_RELAY_PORT = 25
SMTP_FROM = "CyberSecurityOperationsCentre@colt.net"
ALLOWED_DOMAIN = "colt.net"
OTP_TTL_SECONDS = 300
TOKEN_TTL_SECONDS = 600  # GUI must be launched within this window

APP_TITLE = "Firewall ACL Automation Tool"
APP_SUBTITLE = "Secure Launcher"


def _storage_dir():
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    folder = os.path.join(base, 'AclToolAuth')
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception:
        pass
    return folder


def audit_log(event: str, email: str = "", status: str = "", detail: str = ""):
    """Append an audit log line."""
    try:
        folder = _storage_dir()
        path = os.path.join(folder, 'otp_audit.log')
        user = os.environ.get('USERNAME') or os.environ.get('USER') or ''
        host = os.environ.get('COMPUTERNAME') or os.uname().nodename if hasattr(os, 'uname') else ''
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
        # mask email for logs? keep full for SOC audits; adjust if needed
        line = f"{ts}\t{event}\t{email}\t{status}\t{user}\t{host}\t{detail}\n"
        with open(path, 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass


def auth_token_path():
    return os.path.join(_storage_dir(), 'auth_token.json')


def write_auth_token(email: str):
    tok = f"{random.randint(0, 2**63-1):016x}{random.randint(0, 2**63-1):016x}"
    now = time.time()
    data = {
        'token': tok,
        'email': email.strip(),
        'issued_at': now,
        'expires_at': now + TOKEN_TTL_SECONDS,
        'pid': os.getpid(),
    }
    path = auth_token_path()
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f)


def send_otp_email(mail_to: str, otp: str):
    msg = EmailMessage()
    msg['Subject'] = 'Your OTP for Firewall ACL Automation Tool'
    msg['From'] = SMTP_FROM
    msg['To'] = mail_to
    msg.set_content(
        "Hello,\n\n"
        f"Your one-time password (OTP) is: {otp}\n"
        f"It is valid for {OTP_TTL_SECONDS} seconds.\n\n"
        "If you did not request this, ignore this message.\n"
    )
    with smtplib.SMTP(SMTP_RELAY_IP, SMTP_RELAY_PORT, timeout=20) as s:
        s.send_message(msg)


class OTPManager:
    def __init__(self, ttl_seconds: int):
        self.ttl_seconds = ttl_seconds
        self._otp = None
        self._issued_at = None
        self._email = None

    def issue(self, email: str) -> str:
        otp = f"{random.randint(0, 999999):06d}"
        self._otp = otp
        self._issued_at = time.time()
        self._email = email
        return otp

    def valid_for(self, email: str, otp: str) -> bool:
        if not self._otp or not self._issued_at or not self._email:
            return False
        if email.strip().lower() != self._email.strip().lower():
            return False
        if (time.time() - self._issued_at) > self.ttl_seconds:
            return False
        return otp.strip() == self._otp

    def seconds_left(self) -> int:
        if not self._issued_at:
            return 0
        return max(0, int(self.ttl_seconds - (time.time() - self._issued_at)))


class SplashLoginApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.otp = OTPManager(OTP_TTL_SECONDS)
        self.status_var = tk.StringVar(value='Ready')
        self.timer_var = tk.StringVar(value='')
        self.email_var = tk.StringVar(value='')
        self.otp_var = tk.StringVar(value='')
        self._build_ui()
        self._tick_timer()

    def _set_children_state(self, parent, state: str):
        try:
            for child in parent.winfo_children():
                try:
                    child.configure(state=state)
                except Exception:
                    pass
        except Exception:
            pass

    def _build_ui(self):
        self.root.title(f"{APP_TITLE} — {APP_SUBTITLE}")
        self.root.geometry('520x340')
        self.root.resizable(False, False)

        style = ttk.Style()
        try:
            if 'vista' in style.theme_names():
                style.theme_use('vista')
            elif 'clam' in style.theme_names():
                style.theme_use('clam')
        except Exception:
            pass
        style.configure('Header.TLabel', font=('Segoe UI', 16, 'bold'))
        style.configure('SubHeader.TLabel', font=('Segoe UI', 10))
        style.configure('Accent.TButton', font=('Segoe UI', 10, 'bold'))

        frame = ttk.Frame(self.root, padding=16)
        frame.pack(fill='both', expand=True)

        ttk.Label(frame, text=APP_TITLE, style='Header.TLabel').pack(anchor='w')
        ttk.Label(frame, text='Email OTP required (@colt.net) to continue.', style='SubHeader.TLabel').pack(anchor='w', pady=(2, 12))

        box = ttk.LabelFrame(frame, text='Email OTP')
        box.pack(fill='x')

        r1 = ttk.Frame(box)
        r1.pack(fill='x', padx=8, pady=(10, 4))
        ttk.Label(r1, text='Email:').pack(side='left')
        self.email_entry = ttk.Entry(r1, textvariable=self.email_var)
        self.email_entry.pack(side='left', fill='x', expand=True, padx=(8, 0))

        r2 = ttk.Frame(box)
        r2.pack(fill='x', padx=8, pady=4)
        ttk.Label(r2, text='OTP:').pack(side='left')
        self.otp_entry = ttk.Entry(r2, textvariable=self.otp_var)
        self.otp_entry.pack(side='left', fill='x', expand=True, padx=(8, 0))

        r3 = ttk.Frame(box)
        r3.pack(fill='x', padx=8, pady=(6, 10))
        self.send_btn = ttk.Button(r3, text='Send OTP', command=self._send_clicked)
        self.send_btn.pack(side='left')
        ttk.Label(r3, textvariable=self.timer_var, foreground='#0066cc').pack(side='left', padx=(10, 0))

        action = ttk.Frame(frame)
        action.pack(fill='x', pady=(12, 0))
        ttk.Label(action, textvariable=self.status_var, foreground='#444').pack(side='left')
        ttk.Button(action, text='Login & Launch', style='Accent.TButton', command=self._login_clicked).pack(side='right')

        ttk.Label(frame, text=f"SMTP Relay: {SMTP_RELAY_IP}:{SMTP_RELAY_PORT}", foreground='#666').pack(anchor='w', pady=(10, 0))

        self.email_entry.focus_set()

    def _send_clicked(self):
        email = (self.email_var.get() or '').strip()
        if not email or '@' not in email:
            messagebox.showerror('OTP', 'Please enter a valid email address.')
            return
        dom = email.split('@', 1)[-1].strip().lower()
        if dom != ALLOWED_DOMAIN:
            messagebox.showerror('OTP', f'Email must be in domain: {ALLOWED_DOMAIN}')
            audit_log('otp_send', email, 'rejected', 'domain_mismatch')
            return

        otp = self.otp.issue(email)
        self.status_var.set('Sending OTP...')
        self.send_btn.configure(state='disabled')
        audit_log('otp_send', email, 'started', '')

        def worker():
            try:
                send_otp_email(email, otp)
                audit_log('otp_send', email, 'sent', '')
                self.root.after(0, lambda: self.status_var.set('OTP sent. Check your inbox.'))
            except Exception as e:
                audit_log('otp_send', email, 'failed', str(e))
                self.root.after(0, lambda: messagebox.showerror('OTP', f'Failed to send OTP via relay {SMTP_RELAY_IP}:{SMTP_RELAY_PORT}\n\n{e}'))
                self.root.after(0, lambda: self.status_var.set('OTP send failed'))
            finally:
                self.root.after(0, lambda: self.send_btn.configure(state='normal'))

        threading.Thread(target=worker, daemon=True).start()

    def _login_clicked(self):
        email = (self.email_var.get() or '').strip()
        otp = (self.otp_var.get() or '').strip()
        if not email or not otp:
            messagebox.showerror('Login', 'Enter email and OTP.')
            return
        if not self.otp.valid_for(email, otp):
            left = self.otp.seconds_left()
            audit_log('otp_login', email, 'failed', 'invalid_or_expired')
            if left <= 0:
                messagebox.showerror('Login', 'OTP expired. Please click Send OTP again.')
            else:
                messagebox.showerror('Login', 'Invalid OTP. Please try again.')
            return

        # success
        audit_log('otp_login', email, 'success', '')
        try:
            write_auth_token(email)
        except Exception as e:
            audit_log('auth_token', email, 'failed', str(e))
            messagebox.showerror('Launch', f'Failed to create auth token: {e}')
            return

        self.status_var.set('Launching GUI...')
        if self._launch_gui():
            self.root.destroy()

    def _launch_gui(self) -> bool:
        target = TARGET_GUI
        if not os.path.isfile(target):
            base = os.path.dirname(os.path.abspath(__file__))
            cand = os.path.join(base, target)
            if os.path.isfile(cand):
                target = cand
            else:
                messagebox.showerror('Launch', f'GUI file not found: {TARGET_GUI}')
                audit_log('launch', '', 'failed', 'gui_not_found')
                return False

        try:
            cmd = [sys.executable, target]
            kwargs = {}
            if sys.platform.startswith('win'):
                kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
            subprocess.Popen(cmd, cwd=os.path.dirname(os.path.abspath(target)) or None, **kwargs)
            audit_log('launch', '', 'started', os.path.basename(target))
            return True
        except Exception as e:
            audit_log('launch', '', 'failed', str(e))
            messagebox.showerror('Launch', f'Failed to start GUI: {e}')
            return False

    def _tick_timer(self):
        left = self.otp.seconds_left()
        self.timer_var.set(f"OTP expires in {left}s" if left > 0 else '')
        self.root.after(1000, self._tick_timer)


def main():
    root = tk.Tk()
    SplashLoginApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
