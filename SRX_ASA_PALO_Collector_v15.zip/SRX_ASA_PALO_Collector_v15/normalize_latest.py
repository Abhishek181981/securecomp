# -*- coding: utf-8 -*-
"""
normalize_latest.py — v3.3 (crash-safe, no flow_engine, with console progress)
Additions in v3.3
- Default HA filtering switched to inference (no collector hints needed): --ha-mode infer
- Stronger HA name patterns (-01/-02, -A/-B, -PRIM/-SEC/-STBY/-STD, underscore variants)
- Retains semantic de-duplication, evidence slimming, and ASA regex fix

CLI:
  python3 normalize_latest.py --base reports
Optional:
  --limit N                      Only process first N rows per artifact (testing)
  --progress-width W             Progress bar width (default 40)
  --no-progress                  Disable progress bars (quiet)
  --ha-mode {auto,off,infer}     Default: infer
  --evidence-max-lines N         Default: 3 (0 = keep all)
"""
import argparse
import csv
import json
import re
import time
import os
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# --- JSON dump helper (pretty vs. compact) ---
def _dump_json(obj, outf, *, pretty: bool):
    if pretty:
        json.dump(obj, outf, ensure_ascii=False, indent=2)
    else:
        json.dump(obj, outf, ensure_ascii=False, separators=(",", ":"))


# --------------------- Common schema for CSVs written by collector ---------------------
SCHEMA = ["timestamp","hostname","ip","platform","context","command","line"]
FILES = ["acls","ips","routes"]

# --------------------- ASA / SRX / PAN helpers (patched) ---------------------
SERVICE_PORTS = {
    "ssh": 22, "http": 80, "https": 443, "ldap": 389, "ldaps": 636,
    "domain": 53, "dns": 53, "tacacs": 49, "tacacs-plus": 49, "radius": 1812,
}

# FIXED: use alternation '|' instead of literal newlines
ASA_LINE_RE = re.compile(
    r"""
^access\-list\s+(?P<name>\S+)\s+(?:line\s+(?P<line>\d+)\s+)?extended\s+(?P<action>permit|deny)\s+
(?P<proto>tcp|udp|ip|icmp)\s+
(?: 
  host\s+(?P<src_host>\d+\.\d+\.\d+\.\d+)
 |(?P<src_any>any)
 |object\-group\s+(?P<src_og>\S+)
 |(?P<src_net>\d+\.\d+\.\d+\.\d+)\s+(?P<src_mask>\d+\.\d+\.\d+\.\d+)
)
\s+
(?: 
  host\s+(?P<dst_host>\d+\.\d+\.\d+\.\d+)
 |(?P<dst_any>any)
 |object\-group\s+(?P<dst_og>\S+)
 |(?P<dst_net>\d+\.\d+\.\d+\.\d+)\s+(?P<dst_mask>\d+\.\d+\.\d+\.\d+)
)
(?:\s+eq\s+(?P<dport>\S+))?
""",
    re.IGNORECASE | re.VERBOSE,
)

SRX_POLICY_RE = re.compile(r'^\"?Policy:\s*(?P<name>[^,]+)', re.IGNORECASE)
SRX_FROM_TO_RE = re.compile(
    r'(?:From zone|From zones):\s*(?P<from>[^,]+).*?(?:To zone|To zones):\s*(?P<to>[^\"\n]+)',
    re.IGNORECASE | re.DOTALL
)
SRX_FROM_RE = re.compile(r'(?:From zone|From zones):\s*(?P<from>[^,\" \n]+)', re.IGNORECASE)
SRX_TO_RE   = re.compile(r'(?:To zone|To zones):\s*(?P<to>[^,\" \n]+)', re.IGNORECASE)

# --------------------- Small console progress helper (no external deps) ---------------------
class Progress:
    def __init__(self, title: str, total: int, width: int = 40, enabled: bool = True):
        self.title = title
        self.total = max(0, total)
        self.width = max(10, width)
        self.enabled = enabled
        self.start = time.time()
        self.last_print = 0.0
        self.count = 0
        if self.enabled:
            print(f"{self.title}: 0/{self.total} (0%)")

    def update(self, inc: int = 1, force: bool = False):
        if not self.enabled:
            return
        self.count += inc
        now = time.time()
        # throttle prints to ~10/sec
        if not force and (now - self.last_print) < 0.1:
            return
        self.last_print = now
        done = min(self.count, self.total) if self.total else self.count
        pct = int((done / self.total) * 100) if self.total else 0
        filled = int((pct / 100) * self.width)
        bar = "#" * filled + "-" * (self.width - filled)
        elapsed = now - self.start
        rate = self.count / elapsed if elapsed > 0 else 0.0
        suffix = f" {self.count}/{self.total} ({pct}%) {rate:.1f}/s"
        print(f"\r{self.title}: [{bar}]{suffix}", end="", flush=True)

    def finish(self):
        if not self.enabled:
            return
        self.update(0, force=True)
        print()  # newline

# Fast row counter (without loading into memory)
def count_rows(csv_path: Path) -> int:
    try:
        with csv_path.open("r", encoding="utf-8", newline="") as f:
            r = csv.reader(f)
            # skip header
            header = next(r, None)
            if not header:
                return 0
            n = 0
            for _ in r:
                n += 1
            return n
    except Exception:
        return 0

# --------------------- ASA helpers ---------------------
def _mask_to_prefix(mask_str: str) -> int:
    import ipaddress
    try:
        return ipaddress.IPv4Network(f"0.0.0.0/{mask_str}", strict=False).prefixlen
    except Exception:
        parts = mask_str.split(".")
        if len(parts) != 4:
            raise
        octets = [int(p) for p in parts]
        mask_int = (octets[0]<<24)|(octets[1]<<16)|(octets[2]<<8)|octets[3]
        pref = 0
        for b in range(31,-1,-1):
            if (mask_int>>b)&1: pref += 1
            else: break
        return pref

def _netmask_pair_to_cidr(ip_str: str, mask_str: str) -> str:
    import ipaddress
    plen = _mask_to_prefix(mask_str)
    return str(ipaddress.IPv4Network(f"{ip_str}/{plen}", strict=False))

def parse_asa_evidence_line(line: str) -> Optional[Dict]:
    m = ASA_LINE_RE.search(line)
    if not m: return None
    if m.group("src_host"): src = [m.group("src_host")]
    elif m.group("src_og"): src = [f"object-group:{m.group('src_og')}"]
    elif m.group("src_any"): src = ["any"]
    elif m.group("src_net") and m.group("src_mask"): src = [_netmask_pair_to_cidr(m.group("src_net"), m.group("src_mask"))]
    else: src = []
    if m.group("dst_host"): dst = [m.group("dst_host")]
    elif m.group("dst_og"): dst = [f"object-group:{m.group('dst_og')}"]
    elif m.group("dst_any"): dst = ["any"]
    elif m.group("dst_net") and m.group("dst_mask"): dst = [_netmask_pair_to_cidr(m.group("dst_net"), m.group("dst_mask"))]
    else: dst = []
    proto = (m.group("proto") or "").lower(); dport = (m.group("dport") or "").lower()
    if proto in ("tcp","udp"):
        if dport and dport.isdigit(): apps=[f"{proto}:{dport}"]
        elif dport: apps=[f"{proto}:{SERVICE_PORTS.get(dport)}"] if SERVICE_PORTS.get(dport) else [proto]
        else: apps=[proto]
    elif proto=="icmp": apps=["icmp"]
    else: apps=["ip"]
    return {"name": m.group("name"), "action": (m.group("action") or "").lower(), "src": src, "dst": dst, "apps": apps, "proto": proto}

# PAN-OS set style
def _segment_after(line: str, key: str, next_keys: List[str]) -> str:
    i = line.find(key)
    if i == -1: return ""
    start = i + len(key); end = len(line)
    for nk in next_keys:
        j = line.find(nk, start)
        if j != -1: end = min(end, j)
    return line[start:end].strip()

def _split_items(seg: str) -> List[str]:
    if not seg: return []
    seg = seg.strip()
    if seg.startswith("[") and seg.endswith("]"): seg = seg[1:-1].strip()
    return [t for t in seg.replace("\n"," ").split(" ") if t and t != ","]

def parse_palo_set_line(line: str) -> Optional[Dict]:
    l = line.strip()
    if not l.lower().startswith("set rulebase security rules "): return None
    prefix = "set rulebase security rules "; rest = l[len(prefix):]
    parts = rest.split(" ", 1); name = parts[0]; tail = parts[1] if len(parts)>1 else ""
    from_seg=_segment_after(tail, " from ", [" to "," source "," destination "," application "," service "," action "])
    to_seg  =_segment_after(tail, " to ",   [" source "," destination "," application "," service "," action "])
    src_seg =_segment_after(tail, " source ",[" destination "," application "," service "," action "])
    dst_seg =_segment_after(tail, " destination ",[" application "," service "," action "])
    from_z=from_seg or "any"; to_z=to_seg or "any"
    def map_item(x:str)->Optional[str]:
        x=x.strip()
        if not x: return None
        if x.lower()=="any": return "any"
        if re.match(r"^\d+\.\d+\.\d+\.\d+(?:/\d+)?$", x): return x
        return f"addr-group:{x}"
    src=[t for t in (map_item(x) for x in _split_items(src_seg)) if t]; dst=[t for t in (map_item(x) for x in _split_items(dst_seg)) if t]
    return {"name": name, "from_zone": from_z, "to_zone": to_z, "src": src or ["any"], "dst": dst or ["any"]}

# --------------------- HA helpers & de-dup ---------------------
def load_ha_status(latest_dir: Path) -> Dict[str, str]:
    """
    <base>/latest/ha_status.json (optional)
    { "DEVICE1": "active", "DEVICE2": "standby", ... }
    """
    p = latest_dir / "ha_status.json"
    if not p.is_file():
        return {}
    try:
        with p.open("r", encoding="utf-8") as f:
            data = json.load(f) or {}
        out = {}
        for k, v in data.items():
            role = (str(v) or "").strip().lower()
            if role in ("active","primary"): out[k] = "active"
            elif role in ("standby","passive","secondary"): out[k] = "standby"
            else: out[k] = "unknown"
        return out
    except Exception:
        return {}

def load_ha_pairs(latest_dir: Path) -> Dict[str, Dict[str, str]]:
    """
    <base>/latest/ha_pairs.csv (optional)
    cluster_id,active,standby
    """
    p = latest_dir / "ha_pairs.csv"
    if not p.is_file():
        return {}
    pairs = {}
    try:
        with p.open("r", encoding="utf-8", newline="") as f:
            r = csv.DictReader(f)
            for row in r:
                cid = (row.get("cluster_id") or "").strip()
                act = (row.get("active") or "").strip()
                stb = (row.get("standby") or "").strip()
                if cid and (act or stb):
                    pairs[cid] = {"active": act, "standby": stb}
    except Exception:
        return {}
    return pairs

def infer_cluster_id(host: str) -> str:
    """
    Heuristic: collapse typical HA suffixes into a cluster key.
    Examples handled:
      - ...-01 / ...-02
      - ...-A / ...-B
      - ...-PRIM / ...-SEC / ...-STBY / ...-STD / ...-PASSIVE
      - ..._A / ..._B (underscore variants)
    """
    h = (host or "").strip().lower()

    # Hyphenated suffixes
    m = re.match(r"^(.*?)-(?:0*[12]|a|b|prim|primary|sec|secondary|stb|stby|std|standby|passive)$", h)
    if m:
        return m.group(1)

    # Underscore variants
    m = re.match(r"^(.*?)_(?:0*[12]|a|b|prim|primary|sec|secondary|stb|stby|std|standby|passive)$", h)
    if m:
        return m.group(1)

    # Fallback
    return h

def policy_fingerprint(rec: Dict) -> str:
    """
    Semantic fingerprint across platforms.
    Ignores cosmetic fields (name, evidence, ordering).
    """
    def _norm_list(xs):
        return tuple(sorted(str(x) for x in (xs or [])))
    stable = {
        "platform": (rec.get("platform") or "").lower(),
        "from": (rec.get("from_zone") or "any").lower(),
        "to":   (rec.get("to_zone") or "any").lower(),
        "src":  _norm_list(rec.get("src")),
        "dst":  _norm_list(rec.get("dst")),
        "apps": _norm_list(rec.get("apps")),
        "action": (rec.get("action") or "permit").lower(),
        "scope": str(rec.get("context") or ""),  # vsys/context if present
    }
    return hashlib.sha256(json.dumps(stable, sort_keys=True).encode()).hexdigest()

def dedup_policy_list(lst: List[Dict]) -> Tuple[List[Dict], int]:
    seen, out, drops = set(), [], 0
    for r in lst:
        fp = policy_fingerprint(r)
        if fp in seen:
            drops += 1
            continue
        seen.add(fp)
        out.append(r)
    return out, drops

def choose_active_devices(device_map: Dict[str, List[Dict]],
                          latest_dir: Path,
                          ha_mode: str = "infer") -> Tuple[Dict[str, List[Dict]], int]:
    """
    device_map: {hostname: [policy_recs]}
    Returns filtered_map and number_of_devices_dropped.
    ha_mode:
      - 'auto' : use ha_status.json / ha_pairs.csv if present; else keep all
      - 'off'  : keep all devices
      - 'infer': keep one device per inferred cluster (device with more rules)
    """
    if ha_mode not in ("auto","off","infer"):
        ha_mode = "infer"
    dropped = 0
    if ha_mode == "off":
        return device_map, dropped

    ha_status = load_ha_status(latest_dir) if ha_mode in ("auto","infer") else {}
    ha_pairs  = load_ha_pairs(latest_dir)  if ha_mode in ("auto","infer") else {}

    filtered = dict(device_map)

    # If we have explicit status and we're in auto/infer, drop standby
    if ha_status and ha_mode in ("auto","infer"):
        for dev, role in list(ha_status.items()):
            if role == "standby" and dev in filtered:
                dropped += 1
                filtered.pop(dev, None)

    # If we have explicit pairs, keep 'active' member where available
    if ha_pairs and ha_mode in ("auto","infer"):
        keep = {}
        for cid, pair in ha_pairs.items():
            act = pair.get("active"); stb = pair.get("standby")
            if act and act in filtered:
                keep[act] = filtered[act]
            elif stb and stb in filtered:
                keep[stb] = filtered[stb]
        # include any others not in pairs
        for dev, rules in filtered.items():
            if dev not in keep:
                keep[dev] = rules
        filtered = keep

    # If still multiple per cluster and ha_mode == infer, keep 1 per cluster
    if ha_mode == "infer":
        buckets: Dict[str, List[Tuple[str,int]]] = {}
        for dev, rules in filtered.items():
            cid = infer_cluster_id(dev)
            buckets.setdefault(cid, []).append((dev, len(rules)))
        choose = {}
        for cid, items in buckets.items():
            if len(items) == 1:
                choose[items[0][0]] = filtered[items[0][0]]
            else:
                items.sort(key=lambda t: t[1], reverse=True)
                keep_dev = items[0][0]
                choose[keep_dev] = filtered[keep_dev]
                dropped += (len(items) - 1)
        filtered = choose

    return filtered, dropped

# --------------------- Streamers (JSON) — memory-safe + progress ---------------------
def stream_csv_to_json_array(csv_path: Path, json_path: Path, title: str, limit: int, pbar_width: int, show: bool, pretty: bool = False) -> int:
    total = count_rows(csv_path)
    if limit and total:
        total = min(total, limit)
    p = Progress(title, total, width=pbar_width, enabled=show)
    count = 0
    with json_path.open("w", encoding="utf-8") as outf:
        outf.write("["); first=True
        with csv_path.open("r", encoding="utf-8", newline="") as inf:
            r = csv.DictReader(inf)
            for row in r:
                rec = {k: (row.get(k) or "").rstrip("\r\n") for k in SCHEMA}
                if not any(rec.values()):
                    continue
                if limit and count >= limit:
                    break
                if not first: outf.write(",")
                else: first=False
                _dump_json(rec, outf, pretty=pretty)
                count += 1
                p.update()
        outf.write("]\n")
    p.finish()
    return count

def stream_policies_from_acls(acls_csv: Path, policies_json: Path, title: str,
                              pbar_width: int, show: bool,
                              ha_mode: str = "infer", evidence_max_lines: int = 3) -> int:
    total = count_rows(acls_csv)
    p = Progress(title, total, width=pbar_width, enabled=show)

    last_zones: Dict[Tuple[str,str], Dict[str,str]] = {}
    policies_by_key: Dict[Tuple[str,str,str,str], Dict] = {}

    with acls_csv.open("r", encoding="utf-8", newline="") as f:
        rd = csv.DictReader(f)
        for row in rd:
            hostname=(row.get("hostname") or "").strip()
            platform=(row.get("platform") or "").strip()
            context =(row.get("context") or "").strip()
            line    =(row.get("line") or "").strip()
            if not line:
                p.update(); continue

            # ASA
            if platform.upper()=="ASA" and line.lower().startswith("access-list"):
                parsed = parse_asa_evidence_line(line)
                if not parsed: p.update(); continue
                key=(hostname, context, "ASA", parsed["name"])
                rec=policies_by_key.get(key)
                if not rec:
                    rec={"hostname":hostname, "context":(context or None), "platform":"ASA", "name":parsed["name"],
                         "from_zone":"any","to_zone":"any","src":[],"dst":[],"apps":[],"action":parsed["action"],"evidence":[]}
                    policies_by_key[key]=rec
                for k in ("src","dst"):
                    for v in parsed[k]:
                        if v and v not in rec[k]: rec[k].append(v)
                rec["apps"]=rec.get("apps") or ["any"]
                rec["action"]=rec.get("action") or parsed["action"]
                if line not in rec["evidence"]: rec["evidence"].append(line)

            # PAN-OS
            elif platform.lower() in ("palo alto","paloalto","palo-alto","palo_alto","pa","pan-os","panos"):
                parsed = parse_palo_set_line(line)
                if parsed:
                    key=(hostname, context, "Palo Alto", parsed["name"])
                    rec=policies_by_key.get(key)
                    if not rec:
                        rec={"hostname":hostname, "context":(context or None), "platform":"Palo Alto", "name":parsed["name"],
                             "from_zone":parsed["from_zone"] or "any","to_zone":parsed["to_zone"] or "any",
                             "src":[],"dst":[],"apps":[],"action":"permit","evidence":[]}
                        policies_by_key[key]=rec
                    for v in parsed["src"]:
                        if v and v not in rec["src"]: rec["src"].append(v)
                    for v in parsed["dst"]:
                        if v and v not in rec["dst"]: rec["dst"].append(v)
                    rec["apps"]=rec.get("apps") or ["any"]
                    if line not in rec["evidence"]: rec["evidence"].append(line)

            # SRX
            elif platform.upper()=="SRX":
                m_both=SRX_FROM_TO_RE.search(line)
                if m_both:
                    last_zones[(hostname,context)]={"from":(m_both.group("from") or "any").strip(' "'),
                                                    "to":  (m_both.group("to")   or "any").strip(' "')}
                else:
                    m_from=SRX_FROM_RE.search(line); m_to=SRX_TO_RE.search(line)
                    if m_from or m_to:
                        z=last_zones.get((hostname,context),{"from":"any","to":"any"})
                        if m_from: z["from"]=(m_from.group("from") or "any").strip(' "')
                        if m_to:   z["to"]  =(m_to.group("to")   or "any").strip(' "')
                        last_zones[(hostname,context)]=z
                m_pol=SRX_POLICY_RE.search(line)
                if m_pol:
                    name=m_pol.group("name").strip(' "'); key=(hostname,context,"SRX",name)
                    if key not in policies_by_key:
                        z=last_zones.get((hostname,context),{"from":"any","to":"any"})
                        policies_by_key[key]={"hostname":hostname,"context":(context or None),"platform":"SRX","name":name,
                                              "from_zone":z.get("from") or "any","to_zone":z.get("to") or "any",
                                              "src":[],"dst":[],"apps":[],"action":None,"evidence":[]}
                    policies_by_key[key]["evidence"].append(line)
                else:
                    # attach attributes to last SRX policy
                    srx_keys=[k for k in policies_by_key.keys() if k[0]==hostname and k[1]==context and k[2]=="SRX"]
                    last_key= srx_keys[-1] if srx_keys else None
                    if last_key:
                        rec=policies_by_key[last_key]; rec["evidence"].append(line)
                        if "Source addresses:" in line:
                            toks=line.split(":",1)[1]; items=[t.strip(' "') for t in toks.split(",") if t.strip()]
                            for it in items:
                                if it and it not in rec["src"]: rec["src"].append(it)
                        elif "Destination addresses:" in line:
                            toks=line.split(":",1)[1]; items=[t.strip(' "') for t in toks.split(",") if t.strip()]
                            for it in items:
                                if it and it not in rec["dst"]: rec["dst"].append(it)
                        elif line.lower().startswith("applications:") or "Applications:" in line:
                            if not rec.get("apps"): rec["apps"]=["any"]
                        elif "Action:" in line:
                            act=line.split(":",1)[1].strip().split(",")[0].strip().lower()
                            if act in ("permit","deny","reject","allow"): rec["action"] = "permit" if act in ("permit","allow") else "deny"

            p.update()

    # Aggregate to a list and fill defaults
    out_list=list(policies_by_key.values())
    for rec in out_list:
        rec.setdefault("from_zone","any"); rec.setdefault("to_zone","any")
        rec["src"]=rec.get("src") or ["any"]; rec["dst"]=rec.get("dst") or ["any"]; rec["apps"]=rec.get("apps") or ["any"]
        rec["action"]=rec.get("action") or "permit"

    latest_dir = policies_json.parent

    # ---- HA filtering (devices) ----
    # Map: device -> list of policy records
    dev_map: Dict[str, List[Dict]] = {}
    for r in out_list:
        dev_map.setdefault(r.get("hostname") or "", []).append(r)

    filtered_dev_map, dev_drop = choose_active_devices(dev_map, latest_dir, ha_mode=ha_mode)

    # Flatten back
    filtered_list: List[Dict] = []
    for dev, rules in filtered_dev_map.items():
        filtered_list.extend(rules)

    # ---- De-dup semantics ----
    deduped_list, dup_drop = dedup_policy_list(filtered_list)

    # ---- Evidence slimming ----
    if isinstance(evidence_max_lines, int) and evidence_max_lines >= 0:
        if evidence_max_lines > 0:
            for r in deduped_list:
                ev = r.get("evidence")
                if isinstance(ev, list) and len(ev) > evidence_max_lines:
                    r["evidence"] = ev[:evidence_max_lines]
        # if == 0 keep all

    # Write minimized policies
    with policies_json.open("w", encoding="utf-8") as outf:
        outf.write("["); first=True
        for obj in deduped_list:
            if not first: outf.write(",")
            else: first=False
            json.dump(obj, outf, ensure_ascii=False, separators=(",", ":"))
        outf.write("]\n")
    p.finish()

    # Console summary
    print(f"[SUMMARY] devices_dropped_by_HA={dev_drop}  duplicates_removed={dup_drop}  policies_written={len(deduped_list)}")
    return len(deduped_list)

# --------------------- Main ---------------------
def main():
    ap = argparse.ArgumentParser(description="Normalize reports/latest CSVs to compact JSON (no flow_engine)")
    ap.add_argument("--base", default="reports", help="Reports base directory")
    ap.add_argument("--limit", type=int, default=0, help="Optional row cap per artifact (testing)")
    ap.add_argument("--progress-width", type=int, default=40, help="Progress bar width (chars)")
    ap.add_argument("--no-progress", action="store_true", help="Disable progress bars")
    ap.add_argument(
        "--ha-mode", choices=["auto","off","infer"], default="infer",
        help="HA filtering mode: infer (default)=choose 1 per cluster; auto=use ha_status/pairs if present; off=keep all"
    )
    ap.add_argument("--evidence-max-lines", type=int, default=3,
                    help="Trim evidence lines per rule (0=keep all)")
    args = ap.parse_args()

    base_dir = Path(args.base)
    latest = base_dir / "latest"
    if not latest.is_dir():
        raise FileNotFoundError(f"latest folder not found: {latest}")

    ips_csv = latest / "ips.csv"
    routes_csv = latest / "routes.csv"
    acls_csv = latest / "acls.csv"

    norm_if_json = latest / "normalized_interfaces.json"
    norm_rt_json = latest / "normalized_routes.json"
    norm_pol_json = latest / "normalized_policies.json"
    norm_meta_json = latest / "normalized_meta.json"

    show = (not args.no_progress)

    if ips_csv.exists():
        c_if = stream_csv_to_json_array(ips_csv, norm_if_json, "IPS   ", args.limit, args.progress_width, show, pretty=True)
    else:
        norm_if_json.write_text("[]\n", encoding="utf-8"); c_if = 0

    if routes_csv.exists():
        c_rt = stream_csv_to_json_array(routes_csv, norm_rt_json, "ROUTES", args.limit, args.progress_width, show, pretty=True)
    else:
        norm_rt_json.write_text("[]\n", encoding="utf-8"); c_rt = 0

    if acls_csv.exists():
        c_pol = stream_policies_from_acls(
            acls_csv, norm_pol_json, "POLICY", args.progress_width, show,
            ha_mode=args.ha_mode, evidence_max_lines=args.evidence_max_lines
        )
    else:
        norm_pol_json.write_text("[]\n", encoding="utf-8"); c_pol = 0

    meta = {"counts": {"interfaces": c_if, "routes": c_rt, "policies": c_pol},
            "ha_mode": args.ha_mode, "evidence_max_lines": args.evidence_max_lines}
    norm_meta_json.write_text(json.dumps(meta, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")

    print("[OK] normalized files:")
    print(" - interfaces:", norm_if_json)
    print(" - routes    :", norm_rt_json)
    print(" - policies  :", norm_pol_json)
    print(" - meta      :", norm_meta_json)

if __name__ == "__main__":
    main()