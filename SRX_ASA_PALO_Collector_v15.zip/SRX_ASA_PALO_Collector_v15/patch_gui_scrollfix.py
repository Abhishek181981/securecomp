# -*- coding: utf-8 -*-
# patch_gui_scrollfix.py
# Usage: python patch_gui_scrollfix.py gui_factory_ready13_secure.py
import sys, re, shutil, os

def main():
    if len(sys.argv) < 2:
        print("Usage: python patch_gui_scrollfix.py <path-to-gui_factory_ready13_secure.py>")
        sys.exit(2)

    path = sys.argv[1]
    if not os.path.isfile(path):
        print(f"ERROR: File not found: {path}")
        sys.exit(2)

    with open(path, "r", encoding="utf-8") as f:
        orig = f.read()

    # 1) Backup
    bak = path + ".bak"
    shutil.copy(path, bak)

    text = orig

    # 2) Fix small typo: elf.fw_filter -> self.fw_filter (present in your file)
    text, n_typo = re.subn(r'\belf\.fw_filter\b', 'self.fw_filter', text)

    # 3) Locate the slice to replace
    # Start: the "Open dashboard.html" button line under Risk & Compliance
    start_pat = r'(?m)^\s*ttk\.Button\(rc_btns,\s*text="Open dashboard\.html".*$'
    m_start = re.search(start_pat, text)
    if not m_start:
        print("ERROR: Could not find the 'Open dashboard.html' button line. Aborting.")
        sys.exit(1)
    start_idx = m_start.end()

    # End: the call that returns focus to ACL tab
    end_pat = r'(?m)^\s*self\.root\.after\(250,\s*lambda:\s*nb\.select\(self\.tab_acl\)\s*\)\s*$'
    m_end = re.search(end_pat, text)
    if not m_end:
        print("ERROR: Could not locate the self.root.after(... nb.select(self.tab_acl)) line. Aborting.")
        sys.exit(1)
    end_idx = m_end.end()

    # 4) Replacement block: single, correct scroll area + helpers, all indented for __init__
    block = """
        # ============================================================
        # NEW: Scrollable Region for Risk & Compliance (Charts + Details)
        # ============================================================

        # Scrollable container
        self.risk_scroll_container = ttk.Frame(self.tab_risk)
        self.risk_scroll_container.grid(row=1, column=0, sticky="nsew", padx=PAD, pady=(0, PAD))

        # Canvas
        self.risk_canvas = tk.Canvas(self.risk_scroll_container, highlightthickness=0)
        self.risk_canvas.pack(side="left", fill="both", expand=True)

        # Scrollbars
        self.risk_vscroll = ttk.Scrollbar(self.risk_scroll_container, orient="vertical",
                                          command=self.risk_canvas.yview)
        self.risk_vscroll.pack(side="right", fill="y")

        self.risk_hscroll = ttk.Scrollbar(self.risk_scroll_container, orient="horizontal",
                                          command=self.risk_canvas.xview)
        self.risk_hscroll.pack(side="bottom", fill="x")

        self.risk_canvas.configure(yscrollcommand=self.risk_vscroll.set)
        self.risk_canvas.configure(xscrollcommand=self.risk_hscroll.set)

        # Internal frame to hold widgets
        self.risk_inner = ttk.Frame(self.risk_canvas)
        self.risk_window = self.risk_canvas.create_window((0, 0), window=self.risk_inner, anchor="nw")

        def _risk_on_config(event):
            self.risk_canvas.configure(scrollregion=self.risk_canvas.bbox("all"))

        self.risk_inner.bind("<Configure>", _risk_on_config)

        # Mouse wheel scroll
        def _risk_mousewheel(event):
            self.risk_canvas.yview_scroll(int(-1*(event.delta/120)), "units")

        self.risk_canvas.bind_all("<MouseWheel>", _risk_mousewheel)

        # Details (dashboard.csv dump)
        rc_details = ttk.LabelFrame(self.risk_inner, text="All Metrics (dashboard.csv)")
        rc_details.grid(row=0, column=0, sticky="nsew", padx=PAD, pady=(0, PAD))
        rc_details.columnconfigure(0, weight=1)

        self.risk_out = scrolledtext.ScrolledText(rc_details, width=100, height=18, font=("Consolas", 10))
        self.risk_out.grid(row=0, column=0, sticky="nsew")
        self.risk_out.configure(state="disabled")

        # Charts
        rc_charts = ttk.LabelFrame(self.risk_inner, text="Charts")
        rc_charts.grid(row=1, column=0, sticky="nsew", padx=PAD, pady=PAD)
        rc_charts.columnconfigure(0, weight=1)
        rc_charts.rowconfigure(0, weight=1)

        if MATPLOT_OK:
            self.rc_fig = Figure(figsize=(9.8, 6.6), dpi=100)
            self.rc_ax_ports = self.rc_fig.add_subplot(2, 2, 1)
            self.rc_ax_cats  = self.rc_fig.add_subplot(2, 2, 2)
            self.rc_ax_score = self.rc_fig.add_subplot(2, 2, 3)
            self.rc_ax_ts    = self.rc_fig.add_subplot(2, 2, 4)
            self.rc_canvas = FigureCanvasTkAgg(self.rc_fig, master=rc_charts)
            self.rc_canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")

        # Zero-Hit Permit Time Series (inside scroll area)
        rc_ts = ttk.LabelFrame(self.risk_inner, text="Zero-Hit Permit Time Series")
        rc_ts.grid(row=2, column=0, sticky="nsew", padx=PAD, pady=PAD)
        rc_ts.columnconfigure(0, weight=1)
        rc_ts.rowconfigure(0, weight=1)

        if MATPLOT_OK:
            self.rc_fig_ts = Figure(figsize=(8.8, 2.8), dpi=100)
            self.rc_ax_ts = self.rc_fig_ts.add_subplot(1, 1, 1)
            self.rc_canvas_ts = FigureCanvasTkAgg(self.rc_fig_ts, master=rc_ts)
            self.rc_canvas_ts.get_tk_widget().grid(row=0, column=0, sticky="nsew")

        # ---- helpers used by Refresh/Runner ----
        def _collect_zero_ts():
            \"\"\"Collect time series (dates, values) of zero-hit permit totals across reports folders.\"\"\"
            import os, datetime, csv as _csv
            path = self.risk_path_var.get() or default_dash
            rep_dir = os.path.dirname(path)  # .../reports/latest
            base_reports = os.path.dirname(rep_dir)  # .../reports
            dates, vals = [], []
            try:
                cand = [rep_dir]
                for d in os.listdir(base_reports):
                    full = os.path.join(base_reports, d)
                    if os.path.isdir(full) and d.lower() != 'latest':
                        cand.append(full)
                seen, uniq = set(), []
                for c in cand:
                    if c not in seen:
                        seen.add(c); uniq.append(c)
                for folder in uniq:
                    csv_path = os.path.join(folder, 'dashboard.csv')
                    if not os.path.isfile(csv_path):
                        continue
                    try:
                        with open(csv_path, 'r', encoding='utf-8', newline='') as f:
                            dr = _csv.DictReader(f)
                            metrics = {(r.get('metric') or '').strip(): (r.get('value') or '').strip() for r in dr}
                            v = int(str(metrics.get('total_zero_hit_permit_rules', '0')).split('.')[0])
                    except Exception:
                        v = 0
                    ts = datetime.datetime.fromtimestamp(os.path.getmtime(csv_path))
                    dates.append(ts); vals.append(v)
                if dates:
                    pairs = sorted(zip(dates, vals), key=lambda t: t[0])
                    dates, vals = [p[0] for p in pairs], [p[1] for p in pairs]
            except Exception:
                pass
            return dates, vals

        def _draw_zero_ts():
            if not MATPLOT_OK or getattr(self, 'rc_canvas_ts', None) is None:
                return
            ax = self.rc_ax_ts
            ax.clear()
            ds, vs = _collect_zero_ts()
            if ds and 'mdates' in globals():
                ax.plot(ds, vs, marker='o', color='#4575b4')
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b %H:%M'))
                ax.set_xlabel('Run time')
            else:
                xs = list(range(1, len(vs)+1))
                ax.plot(xs, vs, marker='o', color='#4575b4')
                ax.set_xlabel('Run #')
            ax.set_ylabel('Zero-hit permit rules')
            ax.set_title('Zero-hit Permits Over Time')
            ax.grid(True, linestyle=':', alpha=0.5)
            if MATPLOT_OK:
                self.rc_fig_ts.tight_layout()
                self.rc_canvas_ts.draw_idle()

        def _draw_compliance_donut(score: int):
            if not MATPLOT_OK or getattr(self, 'rc_canvas', None) is None:
                return
            ax3 = self.rc_ax_score
            ax3.clear()
            vals = [score, max(0, 100-score)]
            colors = ['#66bd63', '#f0f0f0']
            ax3.pie(vals, startangle=90, counterclock=False, colors=colors,
                    wedgeprops=dict(width=0.35, edgecolor='white'))
            ax3.set_title('Compliance Score (donut)')
            ax3.text(0, 0, f"{score}", ha='center', va='center', fontsize=12, color='#225522')
            ax3.set_aspect('equal')
            self.rc_fig.tight_layout()
            self.rc_canvas.draw_idle()

        def _run_dashboard_and_refresh():
            \"\"\"Run dashboard.py, capture output, update UI, and refresh charts.\"\"\"
            import os, sys, subprocess, time
            def _push_diag(lines):
                try:
                    self.risk_out.configure(state="normal")
                    self.risk_out.insert("end", "\\n".join(lines) + "\\n")
                    self.risk_out.configure(state="disabled")
                except Exception:
                    pass

            base = os.path.dirname(os.path.abspath(__file__))
            dash_csv_hint = self.risk_path_var.get() or os.path.normpath(os.path.join('modular_collector','reports','latest','dashboard.csv'))
            candidates = [
                os.path.join(base, 'dashboard.py'),
                os.path.join(base, 'modular_collector', 'dashboard.py'),
                os.path.join(os.path.dirname(base), 'dashboard.py'),
                os.path.join(os.path.dirname(base), 'modular_collector', 'dashboard.py'),
                'dashboard.py',
            ]
            script = None
            diag = []
            diag.append('[DASHBOARD] Searching for dashboard.py in:')
            for c in candidates:
                diag.append(' - ' + os.path.abspath(c))
                if (not script) and os.path.isfile(c):
                    script = c
            if not script:
                diag.append('[ERROR] Could not find dashboard.py in any candidate path.')
                _push_diag(diag)
                self.safe_update_status('Dashboard run failed (script not found)', 'red')
                return

            diag.append('[DASHBOARD] Using: ' + os.path.abspath(script))
            run_cwd = os.path.dirname(os.path.abspath(script)) or base
            cmd = [sys.executable, os.path.basename(script)]
            diag.append(f"[DASHBOARD] cwd={run_cwd}")
            diag.append(f"[DASHBOARD] cmd={' '.join(cmd)}")

            try:
                start_ts = time.time()
                res = subprocess.run(cmd, cwd=run_cwd, capture_output=True, text=True, timeout=900)
                dur = round(time.time() - start_ts, 2)
                rc = res.returncode
                out = (res.stdout or '').strip()
                err = (res.stderr or '').strip()
                diag.append(f"[DASHBOARD] returncode={rc} ({dur}s)")

                rep_dir = os.path.dirname(os.path.abspath(dash_csv_hint))
                try:
                    os.makedirs(rep_dir, exist_ok=True)
                except Exception:
                    pass
                run_report = os.path.join(rep_dir, 'dashboard_run_report.txt')
                try:
                    with open(run_report, 'w', encoding='utf-8') as f:
                        f.write('\\n'.join(diag) + '\\n\\n[stdout]\\n' + out + '\\n\\n[stderr]\\n' + err + '\\n')
                except Exception:
                    pass

                try:
                    self.risk_out.configure(state='normal')
                    self.risk_out.insert('end', '[dashboard.py stdout]\\n' + (out or '<empty>') + '\\n')
                    if err:
                        self.risk_out.insert('end', '[dashboard.py stderr]\\n' + err + '\\n')
                    self.risk_out.insert('end', '[report] wrote ' + str(run_report) + '\\n')
                    self.risk_out.configure(state='disabled')
                except Exception:
                    pass

                csv_ok = os.path.isfile(dash_csv_hint)
                html_path = os.path.join(rep_dir, 'dashboard.html')
                html_ok = os.path.isfile(html_path)

                if rc != 0:
                    self.safe_update_status('Dashboard failed (non-zero exit)', 'red')
                    if not csv_ok:
                        self._append(f"[DASHBOARD] dashboard.csv not found at {dash_csv_hint}\\n")
                    return

                if not csv_ok:
                    self.safe_update_status('Dashboard ran, but dashboard.csv is missing', 'red')
                    self._append(f"[DASHBOARD] Expected: {dash_csv_hint}\\n")
                    self._append(f"[DASHBOARD] See run report: {run_report}\\n")
                    return

                try:
                    if html_ok and self.risk_open_html.get():
                        _open_path_safe(html_path)
                except Exception:
                    pass

                try:
                    _refresh_risk_tab()
                except Exception:
                    pass

                try:
                    if hasattr(self, '_render_top10_right'):
                        self._render_top10_right()
                except Exception:
                    pass

                self.safe_update_status('Dashboard updated', 'green')

            except subprocess.TimeoutExpired:
                self.safe_update_status('Dashboard timeout (900s)', 'red')
                self._append('[DASHBOARD] ERROR: Timeout after 900 seconds\\n')
            except FileNotFoundError as e:
                self.safe_update_status('Python or script not found', 'red')
                self._append(f"[DASHBOARD] ERROR: {e}\\n")
            except Exception as e:
                self.safe_update_status('Dashboard run failed (exception)', 'red')
                self._append(f"[DASHBOARD] ERROR: {e}\\n")

        def _run_dashboard_and_refresh_thread():
            self._run_in_thread(target=_run_dashboard_and_refresh,
                                before=lambda: self.safe_update_status("Generating dashboard...", "orange", True))

        # The last button (runner)
        ttk.Button(rc_btns, text="Generate Dashboard", command=_run_dashboard_and_refresh_thread).grid(row=0, column=3, sticky="ew")

        def _refresh_risk_tab():
            \"\"\"Read dashboard.csv and update metrics/charts.\"\"\"
            import csv
            path = self.risk_path_var.get() or default_dash
            metrics = {}
            try:
                with open(path, 'r', encoding='utf-8', newline='') as f:
                    dr = csv.DictReader(f)
                    for r in dr:
                        k = (r.get('metric') or '').strip()
                        v = (r.get('value') or '').strip()
                        if k:
                            metrics[k] = v
            except Exception as e:
                try:
                    self.risk_out.configure(state="normal")
                    self.risk_out.delete("1.0", "end")
                    self.risk_out.insert("end", f"[ERROR] Failed to read {path}: {e}\\n")
                    self.risk_out.configure(state="disabled")
                except Exception:
                    pass
                metrics = {}

            def _ival(k):
                try:
                    return int(str(metrics.get(k, '0')).split('.')[0])
                except Exception:
                    return 0

            total_risky = _ival('total_risky_rules')
            any_any = _ival('any_any_allow')
            any_to_10 = _ival('any_to_10')
            any_to_priv = _ival('any_to_rfc1918_permit')
            broad_broad = _ival('broad_to_broad')
            p22 = _ival('port22_rules'); p3389 = _ival('port3389_rules')
            p1433 = _ival('port1433_rules'); p1521 = _ival('port1521_rules'); p27017 = _ival('port27017_rules')
            zero_permit = _ival('total_zero_hit_permit_rules')

            self.rc_total_risky.set(str(total_risky))
            self.rc_any_any.set(str(any_any))
            self.rc_any_to_10.set(str(any_to_10))
            self.rc_any_to_priv.set(str(any_to_priv))
            self.rc_broad_broad.set(str(broad_broad))
            self.rc_sensitive.set(f"22:{p22} 3389:{p3389} 1433:{p1433} 1521:{p1521} 27017:{p27017}")
            self.rc_zero_permit.set(str(zero_permit))

            score = 100
            score -= min(any_any*10, 40)
            score -= min(any_to_priv*3, 30)
            score -= min(broad_broad*2, 20)
            score -= min((p22+p3389+p1433+p1521+p27017), 10)
            score = max(0, score)
            self.rc_score.set(str(score))

            try:
                _draw_compliance_donut(score)
            except Exception:
                pass
            try:
                _draw_zero_ts()
            except Exception:
                pass

            try:
                self.risk_out.configure(state="normal")
                self.risk_out.delete("1.0", "end")
                if metrics:
                    width = max((len(k) for k in metrics.keys()), default=12)
                    for k in sorted(metrics.keys()):
                        self.risk_out.insert("end", f"{k:<{width}} : {metrics[k]}\\n")
                else:
                    self.risk_out.insert("end", "No metrics found. Ensure dashboard.csv exists and has 'metric,value' columns.\\n")
                self.risk_out.configure(state="disabled")
            except Exception:
                pass

        self.root.after(250, lambda: nb.select(self.tab_acl))
"""

    # Splice it in
    new_text = text[:start_idx] + block + text[end_idx:]

    with open(path, "w", encoding="utf-8") as f:
        f.write(new_text)

    print(f"Patched: {path}")
    print(f"Backup : {bak}")
    print(f"Fixes  : typo fixes applied = {n_typo}")
    print("Done. Launch the GUI and open 'Risk & Compliance' — the area below the summary now scrolls.")

if __name__ == "__main__":
    main()