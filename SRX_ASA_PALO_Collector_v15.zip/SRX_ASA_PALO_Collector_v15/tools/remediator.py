#!/usr/bin/env python3
import os, sys, json, argparse, time



def main():
    ap = argparse.ArgumentParser(description='Zero-hit ACL Remediator (Sprint 1: dry-run only)')
    ap.add_argument('--plan', required=True, help='Path to plan.json')
    args = ap.parse_args()
    plan_path = os.path.abspath(args.plan)
    if not os.path.isfile(plan_path):
        print(f"[REMED] Plan not found: {plan_path}")
        return 2
    with open(plan_path,'r',encoding='utf-8') as f:
        plan = json.load(f)
    run_id = plan.get('run_id') or time.strftime('%Y%m%d-%H%M%S')
    base_dir = os.path.dirname(plan_path)
    auth_dir = os.path.join(base_dir, 'authority')
    out_dir  = os.path.join(base_dir, 'out')
    os.makedirs(auth_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)
    options = plan.get('options', {})
    print(f"[REMED] Run: {run_id}")
    print(f"[REMED] Options: dry_run={bool(options.get('dry_run', True))}, backup={options.get('backup')}, ticket_id={options.get('ticket_id')}, srx_confirm={options.get('srx_commit_confirm_minutes')}, panorama_mode={options.get('panorama_mode')}")
    targets = plan.get('targets') or []
    total_rules = 0
    for t in targets:
        dev = t.get('device') or '(unknown)'
        plat = t.get('platform') or '(unknown)'
        rules = t.get('rules') or []
        total_rules += len(rules)
        auth = {
            'device': dev,
            'platform': plat,
            'rules_received': rules,
            'resolution': 'deferred',
            'note': 'Sprint 1 dry-run: no device resolution, no changes applied.'
        }
        auth_path = os.path.join(auth_dir, f"{(dev or 'device').replace('\/', '_')}.json")
        try:
            with open(auth_path,'w',encoding='utf-8') as f:
                json.dump(auth, f, indent=2)
        except Exception as e:
            print(f"[REMED] WARN: failed to write authority for {dev}: {e}")
    backout = {'run_id': run_id, 'targets': [], 'note': 'Sprint 1 dry-run: backout will be generated in Sprint 2.'}
    with open(os.path.join(out_dir,'backout_plan.json'),'w',encoding='utf-8') as f:
        json.dump(backout, f, indent=2)
    print(f"[REMED] Targets: {len(targets)}, Rules: {total_rules}")
    print(f"[REMED] Wrote authority packs -> {auth_dir}")
    print(f"[REMED] Wrote backout skeleton -> {os.path.join(out_dir,'backout_plan.json')}")
    print("[REMED] DRY-RUN COMPLETE (no device changes).")
    return 0


if __name__ == '__main__':
    sys.exit(main())
