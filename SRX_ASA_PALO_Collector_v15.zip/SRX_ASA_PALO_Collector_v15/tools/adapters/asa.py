Adapter stub for Sprint 1 (dry-run). Real device logic to be added in Sprint 2.
