﻿
# -*- coding: utf-8 -*-
"""
Firewall ACL Automation Tool – LITE (Tabs, Isolated Consoles) + Collector Tab

CLEAN v3.2 — What’s included
 - Remediation queue exported to <base>/modular_collector/reports/latest (forced)
 - Auto‑move validated disabled ACLs to Inactive (Option‑C)
 - Fallback: if inactive.csv is missing but disable.csv exists, auto‑create inactive.csv from SUCCESS rows
 - NEW (v3.2): After auto‑move, Inactive tab shows **only the moved batch** (not whole inactive.csv);
              Remediation rows are removed immediately.
 - Dashboard & charts (optional), Risk & Compliance, Zero‑hit, Remediation, Inactive, Logs, Collector tabs
"""

import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont
import os, sys, csv, subprocess, time, threading, re
from openpyxl import Workbook

PAD = 8

# Optional charts
MATPLOT_OK = False
try:
    import matplotlib
    matplotlib.use("TkAgg", force=True)
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    MATPLOT_OK = True
except Exception:
    MATPLOT_OK = False

COLORS = {
    "red":        "#c66565",
    "amber":      "#d6a85b",
    "yellow":     "#ffd966",
    "purple":     "#8e7cc3",
    "blue":       "#9fc5e8",
    "blue_alt":   "#a4c2f4",
    "teal":       "#76a5af",
    "green":      "#93c47d",
    "grey":       "#a4a4a4",
    "olive":      "#b7b482",
}

# ---------- Reports path helpers ----------
def _collector_dir_or_here():
    try:
        base = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        base = os.path.abspath(os.getcwd())
    candidates = [
        os.path.join(base, 'collector.py'),
        os.path.join(base, 'modular_collector', 'collector.py'),
        os.path.join(os.path.dirname(base), 'collector.py'),
        os.path.join(os.path.dirname(base), 'modular_collector', 'collector.py'),
        'collector.py',
    ]
    for c in candidates:
        if os.path.isfile(c):
            return os.path.dirname(os.path.abspath(c))
    return base

def _default_reports_latest_dir():
    cdir = _collector_dir_or_here()
    return os.path.join(cdir, 'reports', 'latest')

def _ensure_reports_dir():
    rep_dir = _default_reports_latest_dir()
    try:
        os.makedirs(rep_dir, exist_ok=True)
        _probe = os.path.join(rep_dir, '.write_test')
        with open(_probe, 'w', encoding='utf-8') as f:
            f.write('ok')
        os.remove(_probe)
        return rep_dir, False, f"Using reports dir: {rep_dir}"
    except Exception as e:
        temp_root = os.path.expandvars('%TEMP%') if os.name == 'nt' else (os.getenv('TMPDIR') or '/tmp')
        tmp_base = os.path.join(temp_root, 'acl_tool', 'reports', 'latest')
        try:
            os.makedirs(tmp_base, exist_ok=True)
            _probe = os.path.join(tmp_base, '.write_test')
            with open(_probe, 'w', encoding='utf-8') as f:
                f.write('ok')
            os.remove(_probe)
            return tmp_base, True, f"Default reports dir failed ({e}); falling back to: {tmp_base}"
        except Exception as e2:
            cwd_last = os.path.join(os.path.abspath(os.getcwd()), 'reports_latest_fallback')
            try:
                os.makedirs(cwd_last, exist_ok=True)
                _probe = os.path.join(cwd_last, '.write_test')
                with open(_probe, 'w', encoding='utf-8') as f:
                    f.write('ok')
                os.remove(_probe)
                return cwd_last, True, f"Temp dir failed ({e2}); using cwd fallback: {cwd_last}"
            except Exception as e3:
                return cwd_last, True, f"[WARN] Unable to create any reports dir (last error: {e3}). Console only."

def _open_path(path):
    try:
        if sys.platform.startswith('win'):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == 'darwin':
            subprocess.call(['open', path])
        else:
            subprocess.call(['xdg-open', path])
    except Exception:
        try:
            messagebox.showwarning("Open", f"Unable to open: {path}")
        except Exception:
            pass

# ---------- GUI ----------
class AclToolGUI:
    # ---------------- Internal: adaptive field detection ----------------
    def _detect_acl_field(self, fieldnames):
        if not fieldnames:
            return None
        original = [s for s in fieldnames if s]
        lower_map = {s.lower(): s for s in original}
        prefs = [
            "raw_ace",
            "acl_name", "acl",
            "policy_name", "policy",
            "rule_name", "rule",
            "rulebase",
        ]
        for p in prefs:
            if p in lower_map:
                return lower_map[p]
        return None

    # ---------------- Internal: tiny tooltip for Treeview cells ----------------
    def _attach_treeview_tooltip(self, tree, col_id):
        tip = tk.Toplevel(self.root)
        tip.withdraw()
        tip.overrideredirect(True)
        lbl = ttk.Label(tip, text="", background="#ffffe0", relief="solid", borderwidth=1)
        lbl.pack(ipadx=4, ipy=2)

        def show_tip(event, text):
            try:
                lbl.config(text=text)
                tip.update_idletasks()
                x = event.x_root + 12
                y = event.y_root + 12
                tip.geometry(f"+{x}+{y}")
                tip.deiconify()
            except Exception:
                pass

        def hide_tip(_e=None):
            try:
                tip.withdraw()
            except Exception:
                pass

        def on_motion(e):
            try:
                region = tree.identify("region", e.x, e.y)
                if region != "cell":
                    hide_tip(); return
                col = tree.identify_column(e.x)  # '#1', '#2', ...
                iid = tree.identify_row(e.y)
                if not iid:
                    hide_tip(); return
                if col == "#0":
                    hide_tip(); return
                cols = list(tree.cget("columns") or [])
                try:
                    idx = int(col.replace("#", "")) - 1
                except Exception:
                    hide_tip(); return
                if idx < 0 or idx >= len(cols):
                    hide_tip(); return
                cid = cols[idx]
                if cid != col_id:
                    hide_tip(); return
                vals = tree.item(iid, "values") or ()
                try:
                    pos = cols.index(col_id)
                except ValueError:
                    hide_tip(); return
                text = vals[pos] if pos < len(vals) else ""
                if not text:
                    hide_tip(); return
                show_tip(e, str(text))
            except Exception:
                hide_tip()

        def on_leave(_e): hide_tip()

        def on_dclick(e):
            try:
                region = tree.identify("region", e.x, e.y)
                if region != "cell": return
                col = tree.identify_column(e.x)
                if col == "#0": return
                iid = tree.identify_row(e.y)
                cols = list(tree.cget("columns") or [])
                if not iid or col_id not in cols: return
                pos = cols.index(col_id)
                vals = tree.item(iid, "values") or ()
                text = vals[pos] if pos < len(vals) else ""
                if not text: return
                p = tk.Toplevel(self.root)
                p.title(col_id + " (full)")
                p.transient(self.root); p.grab_set()
                frm = ttk.Frame(p, padding=10); frm.grid(row=0, column=0, sticky="nsew")
                p.columnconfigure(0, weight=1); p.rowconfigure(0, weight=1)
                txt = tk.Text(frm, wrap="word", width=96, height=14)
                txt.grid(row=0, column=0, sticky="nsew")
                ysb = ttk.Scrollbar(frm, orient="vertical", command=txt.yview)
                ysb.grid(row=0, column=1, sticky="ns")
                txt.configure(yscrollcommand=ysb.set)
                txt.insert("end", str(text))
                txt.config(state="disabled")
                ttk.Button(frm, text="Close", command=p.destroy).grid(row=1, column=0, sticky="e", pady=(8,0))
                try:
                    p.update_idletasks()
                    sw, sh = p.winfo_screenwidth(), p.winfo_screenheight()
                    w, h = p.winfo_width(), p.winfo_height()
                    p.geometry(f"+{(sw-w)//2}+{(sh-h)//3}")
                except Exception:
                    pass
            except Exception:
                pass

        tree.bind("<Motion>", on_motion, add="+")
        tree.bind("<Leave>", on_leave, add="+")
        tree.bind("<Double-1>", on_dclick, add="+")
        return tip

    # ---------------- Internal: drag‑and‑drop column reorder (header drag) ----------------
    def _enable_header_drag(self, tree: ttk.Treeview):
        state = {"start_idx": None, "start_col": None, "dragging": False}
        def _get_cols(): return list(tree.cget("columns") or [])
        def _col_from_xy(x, y):
            if tree.identify_region(x, y) != "heading": return (None, None)
            col_token = tree.identify_column(x)
            try: idx = int(col_token.replace("#", "")) - 1
            except Exception: return (None, None)
            cols = _get_cols()
            return (cols[idx], idx) if 0 <= idx < len(cols) else (None, None)
        def _capture_config(cols):
            htxt = {c: tree.heading(c, "text") for c in cols}
            conf = {}
            for c in cols:
                conf[c] = {
                    "width": tree.column(c, "width"),
                    "minwidth": tree.column(c, "minwidth"),
                    "anchor": tree.column(c, "anchor"),
                    "stretch": bool(tree.column(c, "stretch")),
                }
            return htxt, conf
        def _reorder_columns(new_cols):
            old_cols = _get_cols()
            if old_cols == new_cols: return
            htxt, conf = _capture_config(old_cols)
            old_index = {c: i for i, c in enumerate(old_cols)}
            for iid in tree.get_children(""):
                vals = list(tree.item(iid, "values") or [])
                new_vals = []
                for c in new_cols:
                    oi = old_index.get(c, None)
                    new_vals.append(vals[oi] if (oi is not None and oi < len(vals)) else "")
                tree.item(iid, values=tuple(new_vals))
            tree["columns"] = tuple(new_cols)
            for c in new_cols:
                tree.heading(c, text=htxt.get(c, c))
                cc = conf.get(c, {})
                tree.column(c, width=cc.get("width", 120),
                            minwidth=cc.get("minwidth", 20),
                            anchor=cc.get("anchor", "w"),
                            stretch=cc.get("stretch", False))
        def on_press(e):
            col, idx = _col_from_xy(e.x, e.y)
            if col is None: return
            state["start_idx"] = idx; state["start_col"] = col; state["dragging"] = True
            try: tree.configure(cursor="fleur")
            except Exception: pass
        def on_release(e):
            if not state["dragging"]: return
            try: tree.configure(cursor="")
            except Exception: pass
            tgt_col, tgt_idx = _col_from_xy(e.x, e.y)
            start_idx = state["start_idx"]
            state["dragging"] = False
            if tgt_idx is None or start_idx is None or tgt_idx == start_idx: return
            cols = _get_cols()
            moving = cols.pop(start_idx)
            if start_idx < tgt_idx: tgt_idx -= 1
            cols.insert(tgt_idx, moving)
            _reorder_columns(cols)
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(tree, primary_col="hostname",
                                               fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        def on_motion(e): pass
        tree.bind("<ButtonPress-1>", on_press, add="+")
        tree.bind("<ButtonRelease-1>", on_release, add="+")
        tree.bind("<B1-Motion>", on_motion, add="+")

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Firewall ACL Automation Tool – LITE (with Collector) [STABLE]")
        try:
            self.root.geometry("1200x880+80+60")
        except Exception:
            pass
        self.root.minsize(1100, 760)

        # session-only credential memory (not persisted)
        self._mem_user = ""
        self._mem_pass = ""
        self._mem_enable = ""
        self._last_reports_dir = None

        # tabbed UI containers
        self.nb = None

        # charts
        self._chart_canvas = None
        self._chart_canvas2 = None
        self._chart_canvas3 = None
        self.charts_nb = None
        self.chart_tab1 = None
        self.chart_tab2 = None
        self.chart_tab3 = None
        self.chart_tab4 = None  # Top Devices
        self._topdev_tree = None

        # Risk & Compliance
        self.risk_table = None
        self.risk_wrap = None
        self.risk_filter_var = None
        self.risk_category_var = None
        self._risk_rows_cache = []
        self._risk_categories_all = []
        self._risk_selected_categories = set()
        self._risk_field_order = []
        self._risk_acl_field = "raw_ace"
        self._risk_category_field = None

        # Zero‑hit
        self.zero_table = None
        self.zero_wrap = None
        I = None
        self.zero_filter_var = None
        self.zero_category_var = None
        self._zero_rows_cache = []
        self._zero_categories_all = []
        self._zero_selected_categories = set()
        self._zero_field_order = []
        self._zero_acl_field = "raw_ace"
        self._zero_category_field = None
        self.zero_cat_btn = None

        # Remediation
        self.tab_remed = None
        self.remed_wrap = None
        self.remed_table = None
        self._remed_rows = []
        self._remed_field_order = []
        self._remed_seen_keys = set()
        self.remed_dryrun_var = tk.BooleanVar(value=True)
        self.remed_auto_move_var = tk.BooleanVar(value=True)

        # Inactive batch cache (show only current batch automatically)
        self._inactive_batch_rows = []
        self._inactive_batch_cols = []

        self._build_layout()
        self._init_console_state()
        self._init_table_styles()
        self._build_tabs()
        self._status("Idle", "blue")

    # --- Collapsible console ---
    def _init_console_state(self):
        self._console_visible = False
        self._console_frame = None
        self._console_text = None
        self._console_btn = None

    def _toggle_console(self):
        try:
            self._console_visible = not self._console_visible
            self._console_btn.config(text="▼ Hide Console" if self._console_visible else "▶ Show Console")
            if self._console_frame is not None:
                if self._console_visible:
                    self._console_frame.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
                else:
                    self._console_frame.grid_remove()
        except Exception:
            pass

    # --- Table style ---
    def _init_table_styles(self):
        try:
            self._table_styles_ready
            return
        except AttributeError:
            pass
        style = ttk.Style(self.root)
        style.configure("Bordered.Treeview", borderwidth=0, relief="flat", rowheight=22, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 9))
        style.map("Bordered.Treeview", background=[("selected", "#d9ead3")], foreground=[("selected", "#000000")])
        self._table_styles_ready = True

    # ---------- layout ----------
    def _build_layout(self):
        main = ttk.Frame(self.root)
        main.grid(row=0, column=0, sticky='nsew')
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=0)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)
        self.nb = ttk.Notebook(main)
        self.nb.grid(row=0, column=0, sticky='nsew', padx=PAD, pady=PAD)

        # status bar
        status = ttk.Frame(self.root)
        status.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        self.status_label = ttk.Label(status, text="Status: Idle", foreground='blue')
        self.status_label.pack(side='left', padx=5)
        self.progress = ttk.Progressbar(status, mode='indeterminate', length=240)
        self.progress.pack(side='right', padx=5)

    # ---------- tabs ----------
    def _build_tabs(self):
        self._build_dashboard_tab()
        self._build_risk_tab()
        self._build_zero_tab()
        self._build_remed_tab()
        self._build_inactive_tab()
        self._build_logs_tab()
        self._build_collector_tab()
        try:
            self.nb.select(self.tab_dash)
        except Exception:
            pass

        def _on_main_tab_changed(_e=None):
            try:
                current = self.nb.tab(self.nb.select(), "text")
                if current == "Risk & Compliance":
                    if self.risk_table is not None and not self.risk_table.get_children():
                        self._risk_load_csv_clicked()
                elif current == "Zero‑hit ACL":
                    if self.zero_table is not None and not self.zero_table.get_children():
                        self._zero_load_csv_clicked()
            except Exception:
                pass
        self.nb.bind("<<NotebookTabChanged>>", _on_main_tab_changed)

    # ---------------- Dashboard ----------------
    def _build_dashboard_tab(self):
        self.tab_dash = ttk.Frame(self.nb)
        self.nb.add(self.tab_dash, text="Dashboard")
        self.tab_dash.columnconfigure(0, weight=1)
        self.tab_dash.rowconfigure(2, weight=1)
        self.tab_dash.rowconfigure(3, weight=1)

        btns = ttk.Frame(self.tab_dash)
        btns.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
        for c in range(6): btns.columnconfigure(c, weight=1)
        ttk.Button(btns, text="Generate Dashboard", command=self._run_dashboard).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(btns, text="Refresh Summary", command=self._refresh_dashboard_summary).grid(row=0, column=1, sticky='ew')
        ttk.Button(btns, text="Open reports/latest", command=lambda: _open_path(_default_reports_latest_dir())).grid(row=0, column=2, sticky='ew')
        ttk.Button(btns, text="Refresh Charts", command=self._refresh_dashboard_charts).grid(row=0, column=3, sticky='ew')
        ttk.Button(btns, text="Open dashboard.html",
                   command=lambda: _open_path(os.path.join(self._find_reports_latest_for_dashboard(),'dashboard.html'))).grid(row=0, column=4, sticky='ew')

        self._console_btn = ttk.Button(btns, text="▶ Show Console", command=self._toggle_console)
        self._console_btn.grid(row=0, column=5, sticky='e')

        self.dash_summary = ttk.LabelFrame(self.tab_dash, text="KPI Summary")
        self.dash_summary.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(7): self.dash_summary.columnconfigure(c, weight=1)
        self.lbl_total_risky = ttk.Label(self.dash_summary, text="Total risky rules: —", foreground='#3c78d8'); self.lbl_total_risky.grid(row=0, column=0, sticky='w')
        self.lbl_zero = ttk.Label(self.dash_summary, text="Zero‑hit (permit): —", foreground='#6fa8dc'); self.lbl_zero.grid(row=0, column=1, sticky='w')
        self.lbl_any_any = ttk.Label(self.dash_summary, text="ANY→ANY: —", foreground='#c66565'); self.lbl_any_any.grid(row=0, column=2, sticky='w')
        self.lbl_any_priv = ttk.Label(self.dash_summary, text="ANY→RFC1918: —", foreground='#d6a85b'); self.lbl_any_priv.grid(row=0, column=3, sticky='w')
        self.lbl_broad_broad = ttk.Label(self.dash_summary, text="Broad↔Broad: —", foreground='#8e7cc3'); self.lbl_broad_broad.grid(row=0, column=4, sticky='w')
        self.lbl_broad_rfc1918 = ttk.Label(self.dash_summary, text="Broad RFC1918: —", foreground='#b7b482'); self.lbl_broad_rfc1918.grid(row=0, column=5, sticky='w')
        self.lbl_total_acls = ttk.Label(self.dash_summary, text="Total Firewall Rules: —", foreground='#a4a4a4'); self.lbl_total_acls.grid(row=0, column=6, sticky='w')

        self._console_frame = ttk.LabelFrame(self.tab_dash, text="Dashboard Console")
        self._console_frame.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self._console_frame.columnconfigure(0, weight=1)
        self._console_frame.columnconfigure(1, weight=0)
        self._console_frame.rowconfigure(0, weight=1)
        self._console_frame.rowconfigure(1, weight=0)

        self.output_dash = tk.Text(self._console_frame, width=100, height=12, font=("Consolas", 10), wrap='none')
        self.output_dash.grid(row=0, column=0, sticky='nsew')
        ysb = ttk.Scrollbar(self._console_frame, orient='vertical', command=self.output_dash.yview); ysb.grid(row=0, column=1, sticky='ns')
        hsb = ttk.Scrollbar(self._console_frame, orient='horizontal', command=self.output_dash.xview); hsb.grid(row=1, column=0, sticky='ew')
        self.output_dash.configure(yscrollcommand=ysb.set, xscrollcommand=hsb.set)
        self._console_frame.grid_remove()

        self.dash_charts = ttk.LabelFrame(self.tab_dash, text="Charts")
        self.dash_charts.grid(row=3, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.dash_charts.columnconfigure(0, weight=1)
        self.dash_charts.rowconfigure(0, weight=1)
        self._ensure_charts_notebook()

    def _ensure_charts_notebook(self):
        if self.charts_nb and self.charts_nb.winfo_exists(): return
        for child in self.dash_charts.winfo_children():
            try: child.destroy()
            except Exception: pass
        self.charts_nb = ttk.Notebook(self.dash_charts)
        self.charts_nb.grid(row=0, column=0, sticky='nsew')
        self.chart_tab1 = ttk.Frame(self.charts_nb)
        self.chart_tab2 = ttk.Frame(self.charts_nb)
        self.chart_tab3 = ttk.Frame(self.charts_nb)
        self.chart_tab4 = ttk.Frame(self.charts_nb)
        for t in (self.chart_tab1, self.chart_tab2, self.chart_tab3, self.chart_tab4):
            t.columnconfigure(0, weight=1); t.rowconfigure(0, weight=1)
        self.charts_nb.add(self.chart_tab1, text="Hotspots & Pie")
        self.charts_nb.add(self.chart_tab2, text="Top‑10")
        self.charts_nb.add(self.chart_tab3, text="RFC1918")
        self.charts_nb.add(self.chart_tab4, text="Top Devices")
        def _on_tab_changed(_event=None):
            try:
                if self.charts_nb.select() == self.chart_tab4._w and self._topdev_tree:
                    self._autofit_tree_columns(self._topdev_tree, primary_col="#0",
                                               fixed_cols=("platform","risky_rules"),
                                               pad_px=32, min_w=260, max_w=1400)
            except Exception: pass
        self.charts_nb.bind("<<NotebookTabChanged>>", _on_tab_changed)

    def _append_dash(self, text: str):
        try:
            self.output_dash.config(state='normal')
            self.output_dash.insert('end', text)
        except Exception: pass
        try:
            self.output_dash.see('end')
            self.output_dash.config(state='disabled')
        except Exception: pass

    def _find_dashboard_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'dashboard.py'),
            os.path.join(base, 'modular_collector', 'dashboard.py'),
            os.path.join(os.path.dirname(base), 'dashboard.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'dashboard.py'),
            'dashboard.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _find_remediation_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'remediation.py'),
            os.path.join(base, 'modular_collector', 'remediation.py'),
            os.path.join(os.path.dirname(base), 'remediation.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'remediation.py'),
            'remediation.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _find_reports_latest_for_dashboard(self) -> str:
        candidates = []
        try:
            script = self._find_dashboard_script()
        except Exception:
            script = None
        if script:
            dash_dir = os.path.dirname(os.path.abspath(script))
            candidates.append(os.path.join(dash_dir, 'reports', 'latest'))
        try:
            candidates.append(os.path.join(_collector_dir_or_here(), 'reports', 'latest'))
        except Exception:
            pass
        try:
            gui_base = os.path.dirname(os.path.abspath(__file__))
            candidates.append(os.path.join(gui_base, 'reports', 'latest'))
        except Exception:
            pass
        try:
            rep_dir, _, _ = _ensure_reports_dir()
            candidates.append(rep_dir)
        except Exception:
            pass
        for d in candidates:
            if d and os.path.isdir(d): return d
        return candidates[0] if candidates else os.path.join(os.getcwd(), 'reports', 'latest')

    def _get_reports_dir(self) -> str:
        try:
            if self._last_reports_dir and os.path.isdir(self._last_reports_dir):
                return self._last_reports_dir
        except Exception:
            pass
        return self._find_reports_latest_for_dashboard()

    # NEW: Always use <base>/modular_collector/reports/latest for Remediation
    def _ensure_modcol_reports_dir(self) -> str:
        try:
            base = os.path.dirname(os.path.abspath(__file__))
        except Exception:
            base = os.path.abspath(os.getcwd())
        target = os.path.join(base, 'modular_collector', 'reports', 'latest')
        try:
            os.makedirs(target, exist_ok=True)
            test = os.path.join(target, '.write_test')
            with open(test, 'w', encoding='utf-8') as f:
                f.write('ok')
            os.remove(test)
        except Exception:
            pass
        return target

    def _count_total_acls(self, rep_dir: str) -> int:
        path = os.path.join(rep_dir, 'acls.csv')
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                return sum(1 for _ in csv.DictReader(f))
        except Exception as e:
            self._append_dash(f"[WARN] Could not read total ACL count from {path}: {e}\n")
            return 0

    def _run_dashboard(self):
        script = self._find_dashboard_script()
        if not script:
            self._status('dashboard.py not found', 'red')
            self._append_dash('[ERROR] Could not find dashboard.py\n')
            return
        run_cwd = os.path.dirname(os.path.abspath(script))
        cmd = [sys.executable, os.path.basename(script)]
        rep_dir = self._find_reports_latest_for_dashboard()
        run_report = os.path.join(rep_dir, 'dashboard_run_report.txt')

        try:
            self.output_dash.config(state='normal'); self.output_dash.delete('1.0', 'end'); self.output_dash.config(state='disabled')
        except Exception: pass

        self._status("Generating dashboard...", "orange")
        try: self.progress.start(10)
        except Exception: pass
        def worker():
            try:
                start = time.time()
                res = subprocess.run(cmd, cwd=run_cwd, capture_output=True, text=True, timeout=900)
                dur = round(time.time() - start, 2)
                out = (res.stdout or '').strip(); err = (res.stderr or '').strip()
                with open(run_report, 'w', encoding='utf-8') as f:
                    f.write(f"[cmd] {' '.join(cmd)}\n[rc] {res.returncode} ({dur}s)\n\n[stdout]\n{out}\n\n[stderr]\n{err}\n")
                self.root.after(0, self._append_dash, f"[stdout]\n{out}\n")
                if err: self.root.after(0, self._append_dash, f"[stderr]\n{err}\n")
                if res.returncode == 0:
                    self.root.after(0, self._status, "Dashboard updated", "green")
                    self.root.after(0, self._refresh_dashboard_summary)
                    self.root.after(0, self._refresh_dashboard_charts)
                else:
                    self.root.after(0, self._status, f"Dashboard failed (exit={res.returncode})", "red")
                self.root.after(0, self._append_dash, f"\n[REPORT] {run_report}\n")
            except subprocess.TimeoutExpired:
                self.root.after(0, self._status, "Dashboard timeout (900s)", "red")
                self.root.after(0, self._append_dash, "[ERROR] Timeout after 900 seconds\n")
            except FileNotFoundError as e:
                self.root.after(0, self._status, "Python or script not found", "red")
                self.root.after(0, self._append_dash, f"[ERROR] {e}\n")
            except Exception as e:
                self.root.after(0, self._status, "Dashboard run failed", "red")
                self.root.after(0, self._append_dash, f"[ERROR] {e}\n")
            finally:
                try: self.root.after(0, self.progress.stop)
                except Exception: pass
        threading.Thread(target=worker, daemon=True).start()

    def _refresh_dashboard_summary(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path_csv = os.path.join(rep_dir, 'dashboard.csv')
        path_cav = os.path.join(rep_dir, 'dashboard.cav')

        if os.path.exists(path_csv):
            path = path_csv
        elif os.path.exists(path_cav):
            path = path_cav
        else:
            self._append_dash("[ERROR] Could not find dashboard.csv or dashboard.cav in any known reports path.\n"
                              f" Tried: {path_csv} and {path_cav}\n")
            return

        metrics = {}
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    k = (r.get('metric') or '').strip()
                    v = (r.get('value') or '').strip()
                    if k: metrics[k] = v
        except Exception as e:
            self._append_dash(f"[ERROR] Failed to read dashboard metrics file: {e}\n")
            metrics = {}
        def _ival(k, default=0):
            try: return int(float(str(metrics.get(k, default)).split()[0]))
            except Exception: return default
        total_risky = _ival('total_risky_rules')
        zero_hit = _ival('total_zero_hit_permit_rules')
        any_any = _ival('any_any_allow')
        any_priv = _ival('any_to_rfc1918_permit')
        broad_broad = _ival('broad_to_broad')
        broad_rfc1918 = _ival('broad_rfc1918', 0)
        total_acls = self._count_total_acls(rep_dir)

        self.lbl_total_risky.config(text=f"Total risky rules: {total_risky}")
        self.lbl_zero.config(text=f"Zero‑hit (permit): {zero_hit}")
        self.lbl_any_any.config(text=f"ANY→ANY: {any_any}")
        self.lbl_any_priv.config(text=f"ANY→RFC1918: {any_priv}")
        self.lbl_broad_broad.config(text=f"Broad↔Broad: {broad_broad}")
        self.lbl_broad_rfc1918.config(text=f"Broad RFC1918: {broad_rfc1918}")
        self.lbl_total_acls.config(text=f"Total Firewall Rules: {total_acls}")
        self._status("Dashboard summary refreshed", "blue")

    def _show_charts_placeholder(self, message: str):
        try:
            for child in self.dash_charts.winfo_children(): child.destroy()
        except Exception: pass
        ph = ttk.Label(self.dash_charts, text=message, foreground='gray', anchor='center', justify='center')
        ph.grid(row=0, column=0, sticky='nsew', padx=8, pady=8)

    def _clear_charts_tabs(self):
        if not (self.charts_nb and self.chart_tab1 and self.chart_tab2 and self.chart_tab3 and self.chart_tab4): return
        for tab in (self.chart_tab1, self.chart_tab2, self.chart_tab3, self.chart_tab4):
            for child in tab.winfo_children():
                try: child.destroy()
                except Exception: pass
        self._chart_canvas = None; self._chart_canvas2 = None; self._chart_canvas3 = None; self._topdev_tree = None

    # ---------- Charts ----------
    def _refresh_dashboard_charts(self):
        if not MATPLOT_OK:
            self._append_dash("[INFO] Matplotlib not available. Charts are disabled in this build.\n")
            self._show_charts_placeholder("Charts disabled: matplotlib / Tk backend not available.")
            return

        rep_dir = self._find_reports_latest_for_dashboard()
        path_csv = os.path.join(rep_dir, 'dashboard.csv')
        path_cav = os.path.join(rep_dir, 'dashboard.cav')

        if os.path.exists(path_csv):
            path = path_csv
        elif os.path.exists(path_cav):
            path = path_cav
        else:
            self._append_dash("[ERROR] Could not find dashboard.csv or dashboard.cav in any known reports path.\n"
                              f" Tried: {path_csv} and {path_cav}\n")
            self._show_charts_placeholder("No dashboard.csv/.cav found.\nGenerate Dashboard and try again.")
            return

        self._ensure_charts_notebook()
        self._clear_charts_tabs()

        try:
            metrics = {}
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    k = (r.get('metric') or '').strip()
                    v = (r.get('value') or '').strip()
                    if k: metrics[k] = v
            def _ival(name, default=0):
                try: return int(float(str(metrics.get(name, default)).split()[0]))
                except Exception: return default
            total_risky = _ival('total_risky_rules')
            total_zero_hit = _ival('total_zero_hit_permit_rules')
            risky_minus_zero = max(0, total_risky - total_zero_hit)
            any_any = _ival('any_any_allow')
            any_priv = _ival('any_to_rfc1918_permit')
            broad_broad = _ival('broad_to_broad')
            zero_hit_bar   = total_zero_hit
            total_acls = self._count_total_acls(rep_dir)
            safe = max(0, total_acls - total_risky) if total_acls > 0 else 0

            fig1 = Figure(figsize=(9.0, 4.4), dpi=100, constrained_layout=True)
            ax1 = fig1.add_subplot(1, 2, 1)
            ax2 = fig1.add_subplot(1, 2, 2)

            labels = ["ANY→ANY", "ANY→RFC1918", "Broad↔Broad", "Zero‑hit"]
            values = [any_any, any_priv, broad_broad, zero_hit_bar]
            bar_colors = [COLORS["red"], COLORS["amber"], COLORS["purple"], COLORS["blue"]]
            ax1.bar(labels, values, color=bar_colors)
            ax1.set_title("Risk Hotspots (count)")
            ax1.set_ylabel("Rules")
            ax1.tick_params(axis='x', rotation=12)
            ax1.grid(axis='y', linestyle=':', alpha=0.3)

            if total_acls > 0:
                sizes_p  = [total_zero_hit, risky_minus_zero, safe]
                labels_p = ["Zero‑hit", "Risky", "Safe"]
            else:
                sizes_p  = [max(1, total_zero_hit), max(1, risky_minus_zero), max(1, risky_minus_zero + total_zero_hit)]
                labels_p = ["Zero‑hit", "Risky", "Safe (no acls.csv)"]

            colors_p = [COLORS["blue"], COLORS["red"], COLORS["grey"]]
            ax2.pie(sizes_p, labels=labels_p, colors=colors_p, startangle=90, autopct="%1.0f%%", pctdistance=0.8)
            ax2.set_title("Zero‑hit vs Risky vs Safe (composition)")
            fig1.tight_layout()

            CANDIDATE_KEYS = [
                ("ANY source",          "any_src"),
                ("ANY destination",     "any_dst"),
                ("ANY→ANY",             "any_any_allow"),
                ("ANY→10.0.0.0/8",      "any_to_10"),
                ("ANY→RFC1918",         "any_to_rfc1918_permit"),
                ("Broad↔Broad",         "broad_to_broad"),
                ("Zero‑hit (permit)",   "total_zero_hit_permit_rules"),
                ("Port 22 rules",       "port22_rules"),
                ("Port 3389 rules",     "port3389_rules"),
                ("Port 1433 rules",     "port1433_rules"),
                ("Port 1521 rules",     "port1521_rules"),
                ("Port 27017 rules",    "port27017_rules"),
            ]
            items = []
            for nice, key in CANDIDATE_KEYS:
                val = _ival(key, 0)
                if val is not None and val > 0:
                    items.append((nice, val))
            items.sort(key=lambda x: x[1], reverse=True)
            top_items = items[:10]

            fig2 = Figure(figsize=(9.0, 5.2), dpi=100, constrained_layout=True)
            ax_top = fig2.add_subplot(1, 1, 1)
            if top_items:
                labels2 = [n for n, _ in top_items][::-1]
                values2 = [v for _, v in top_items][::-1]
                ax_top.barh(labels2, values2, color=COLORS["red"])
                ax_top.set_title("Top Risky Categories (Top 10)")
                ax_top.set_xlabel("Rules")
                ax_top.grid(axis='x', linestyle=':', alpha=0.3)
            else:
                ax_top.text(0.5, 0.5, "No non‑zero risky categories found", ha='center', va='center'); ax_top.set_axis_off()
            fig2.tight_layout()

            any_to_rfc1918 = _ival('any_to_rfc1918_permit', 0)
            broad_rfc1918 = _ival('broad_rfc1918', 0)
            any_to_10      = _ival('any_to_10', 0)

            fig3 = Figure(figsize=(9.0, 4.2), dpi=100, constrained_layout=True)
            ax_r = fig3.add_subplot(1, 1, 1)
            labels_r = ["ANY→RFC1918", "Broad RFC1918", "ANY→10/8"]
            values_r = [any_to_rfc1918, broad_rfc1918, any_to_10]
            colors_r = [COLORS["amber"], COLORS["olive"], COLORS["yellow"]]
            ax_r.bar(labels_r, values_r, color=colors_r)
            ax_r.set_title("RFC1918 Exposure (count)")
            ax_r.set_ylabel("Rules")
            ax_r.tick_params(axis='x', rotation=10)
            ax_r.grid(axis='y', linestyle=':', alpha=0.3)
            fig3.tight_layout()

            self._chart_canvas = FigureCanvasTkAgg(fig1, master=self.chart_tab1); self._chart_canvas.draw(); self._chart_canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
            self._chart_canvas2 = FigureCanvasTkAgg(fig2, master=self.chart_tab2); self._chart_canvas2.draw(); self._chart_canvas2.get_tk_widget().grid(row=0, column=0, sticky='nsew')
            self._chart_canvas3 = FigureCanvasTkAgg(fig3, master=self.chart_tab3); self._chart_canvas3.draw(); self._chart_canvas3.get_tk_widget().grid(row=0, column=0, sticky='nsew')

            self._populate_top_devices_table(self._find_reports_latest_for_dashboard())
            self._status("Dashboard charts refreshed", "blue")
        except Exception as e:
            import traceback, io
            sio = io.StringIO(); traceback.print_exc(file=sio)
            if not self._console_visible: self._toggle_console()
            self._append_dash("[ERROR] Chart rendering failed: " + str(e) + "\n"); self._append_dash(sio.getvalue() + "\n")
            self._show_charts_placeholder("Charts failed to render.\nSee console for details.")
            return

    # ---------- Top Devices ----------
    def _top_devices_from_risky(self, rep_dir: str, topn: int = 10):
        path = os.path.join(rep_dir, 'risky_acl.csv')
        rows = []
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr: rows.append({k: (r.get(k, '') or '') for k in (dr.fieldnames or [])})
        except Exception as e: return [], f"[Top Devices] Failed to read {path}: {e}"
        if not rows: return [], f"[Top Devices] No rows found in {path}"
        counts = {}
        for r in rows:
            host = (r.get('hostname') or '').strip(); plat = (r.get('platform') or '').strip()
            counts[(host, plat)] = counts.get((host, plat), 0) + 1
        top = sorted([{'hostname': k[0], 'platform': k[1], 'risky_rules': v} for k, v in counts.items()],
                     key=lambda x: x['risky_rules'], reverse=True)[:topn]
        return top, ""

    def _populate_top_devices_table(self, rep_dir: str):
        for child in self.chart_tab4.winfo_children():
            try: child.destroy()
            except Exception: pass

        data, err = self._top_devices_from_risky(rep_dir, topn=10)
        if err or not data:
            msg = err or "[Top Devices] No risky devices found."
            ttk.Label(self.chart_tab4, text=msg, foreground='gray', anchor='center', justify='center').grid(row=0, column=0, sticky='nsew', padx=8, pady=8)
            return

        header = ttk.Frame(self.chart_tab4); header.grid(row=0, column=0, sticky='ew', padx=(6, 6), pady=(6, 2))
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="Top‑10 Risky Firewalls (by risky ACL count)", font=("Segoe UI Semibold", 10)).grid(row=0, column=0, sticky='w')

        tbl_wrap = ttk.Frame(self.chart_tab4, borderwidth=1, relief="solid"); tbl_wrap.grid(row=1, column=0, sticky='nsew', padx=6, pady=(0, 6))
        self.chart_tab4.rowconfigure(1, weight=1); self.chart_tab4.columnconfigure(0, weight=1)
        tbl_wrap.rowconfigure(0, weight=1); tbl_wrap.columnconfigure(0, weight=1); tbl_wrap.columnconfigure(1, weight=0)

        cols = ("platform", "risky_rules")
        tree = ttk.Treeview(tbl_wrap, columns=cols, show="tree headings", height=12, style="Bordered.Treeview", selectmode="browse")
        tree.heading("#0", text="Hostname"); tree.heading("platform", text="Platform"); tree.heading("risky_rules", text="Risky Rules")
        tree.column("#0", width=480, anchor='w', stretch=True); tree.column("platform", width=140, anchor='center', stretch=False); tree.column("risky_rules", width=120, anchor='e', stretch=False)
        vsb = ttk.Scrollbar(tbl_wrap, orient="vertical", command=tree.yview); hsb = ttk.Scrollbar(tbl_wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        tree.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        tree.tag_configure("odd", background="#f5f5f5"); tree.tag_configure("even", background="#ffffff")
        for i, row in enumerate(data):
            tag = "even" if (i % 2 == 0) else "odd"
            tree.insert("", "end", text=row["hostname"], values=(row["platform"], row["risky_rules"]), tags=(tag,))
        self._autofit_tree_columns(tree, primary_col="#0", fixed_cols=("platform","risky_rules"), pad_px=32, min_w=260, max_w=1400)

    # --- Auto-fit helper ---
    def _autofit_tree_columns(self, tree: ttk.Treeview, primary_col="#0", fixed_cols=("platform",), pad_px=32, min_w=260, max_w=1600):
        try:
            fnt = tkfont.nametofont(tree.cget("font")) if tree.cget("font") else tkfont.nametofont("TkDefaultFont")
        except Exception:
            fnt = tkfont.nametofont("TkDefaultFont")
        try:
            header_text = tree.heading(primary_col).get("text", primary_col)
        except Exception:
            header_text = str(primary_col)
        max_px = fnt.measure(str(header_text))
        for iid in tree.get_children(""):
            txt = tree.item(iid, "text") if primary_col == "#0" else tree.set(iid, primary_col)
            if txt:
                px = fnt.measure(str(txt)); max_px = max(max_px, px)
        measured = max(min_w, min(max_w, max_px + pad_px))
        try: tree.update_idletasks()
        except Exception: pass
        try:
            total_w = tree.winfo_width(); total_w = total_w if total_w > 1 else tree.winfo_reqwidth()
            fixed_sum = 0
            for col in fixed_cols:
                try: fixed_sum += int(tree.column(col, option="width") or 0)
                except Exception: pass
            vscroll_allow = 18
            remaining = max(0, total_w - fixed_sum - vscroll_allow)
            target_w = max(measured, remaining)
        except Exception:
            target_w = measured
        tree.column(primary_col, width=target_w, minwidth=min_w, stretch=True)
        for col in fixed_cols: tree.column(col, stretch=False)

    # ---------------- Risk & Compliance ----------------
    def _build_risk_tab(self):
        self.tab_risk = ttk.Frame(self.nb); self.nb.add(self.tab_risk, text="Risk & Compliance")
        self.tab_risk.columnconfigure(0, weight=1); self.tab_risk.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_risk); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(12): tbar.columnconfigure(c, weight=1)

        ttk.Button(tbar, text="Load risky_acl.csv", command=self._risk_load_csv_clicked).grid(row=0, column=0, sticky='w')

        ttk.Label(tbar, text="Filter (Hostname / tokens)").grid(row=0, column=2, sticky='e')
        self.risk_filter_var = tk.StringVar(value=""); flt = ttk.Entry(tbar, textvariable=self.risk_filter_var, width=28)
        flt.grid(row=0, column=3, sticky='w', padx=(6, 0)); flt.bind("<KeyRelease>", lambda _e: self._risk_apply_filter())

        ttk.Label(tbar, text="Category").grid(row=0, column=4, sticky='e')
        self.risk_category_var = tk.StringVar(value="(All)")
        self.risk_category_combo = ttk.Combobox(tbar, textvariable=self.risk_category_var, values=["(All)"], width=22, state="readonly")
        self.risk_category_combo.grid(row=0, column=5, sticky='w', padx=(6, 0))
        self.risk_category_combo.bind("<<ComboboxSelected>>", lambda _e: self._risk_apply_filter())

        ttk.Button(tbar, text="Categories…", command=self._risk_open_category_picker).grid(row=0, column=6, sticky='w', padx=(6, 0))
        ttk.Button(tbar, text="Export (shown) to CSV",  command=self._risk_export_shown).grid(row=0, column=8, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._risk_export_shown_excel).grid(row=0, column=9, sticky='e', padx=(6, 0))

        self.risk_wrap = ttk.Frame(self.tab_risk, borderwidth=1, relief="solid"); self.risk_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_risk.rowconfigure(2, weight=1); self.tab_risk.columnconfigure(0, weight=1)
        self.risk_wrap.rowconfigure(0, weight=1); self.risk_wrap.columnconfigure(0, weight=1); self.risk_wrap.columnconfigure(1, weight=0)

        self.risk_table = ttk.Treeview(self.risk_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="browse")
        vsb = ttk.Scrollbar(self.risk_wrap, orient="vertical", command=self.risk_table.yview)
        hsb = ttk.Scrollbar(self.risk_wrap, orient="horizontal", command=self.risk_table.xview)
        self.risk_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.risk_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.risk_table.tag_configure("odd", background="#f5f5f5"); self.risk_table.tag_configure("even", background="#ffffff")

        self._enable_header_drag(self.risk_table)
        def _refit(_e=None):
            cols = list(self.risk_table.cget("columns") or [])
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(self.risk_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        self.risk_table.bind("<Map>", _refit); self.risk_table.bind("<Configure>", _refit)

    def _risk_load_csv_clicked(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path = os.path.join(rep_dir, 'risky_acl.csv')

        for iid in self.risk_table.get_children(): self.risk_table.delete(iid)
        self._risk_rows_cache = []; self._risk_categories_all = []; self._risk_selected_categories = set()
        self._risk_field_order = []; self._risk_category_field = None

        if not os.path.exists(path):
            try: messagebox.showwarning("Risky ACL", f"File not found:\n{path}")
            except Exception: pass
            return

        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f); rows = list(dr); fieldnames = list(dr.fieldnames or [])
                self._risk_field_order = fieldnames
                self._risk_acl_field = self._detect_acl_field(fieldnames) or "raw_ace"
                low = {c.lower(): c for c in fieldnames}
                self._risk_category_field = low.get("category") or low.get("risk") or None
        except Exception as e:
            try: messagebox.showerror("Risky ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return

        self._risk_rows_cache = rows

        self.risk_table["columns"] = tuple(self._risk_field_order)
        for col in self._risk_field_order:
            head_text = "ACL" if col == self._risk_acl_field else col
            self.risk_table.heading(col, text=head_text)
            w = 140; anchor = 'w'; stretch = False
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
            if lc in ("raw_ace", self._risk_acl_field.lower()): w, anchor, stretch = max(420, w), 'w', True
            if lc in ("remark", "risk_description"): w, anchor, stretch = max(320, w), 'w', True
            self.risk_table.column(col, width=w, anchor=anchor, stretch=stretch)

        cat_set = set()
        if self._risk_category_field:
            for r in rows:
                val = (r.get(self._risk_category_field) or "").strip()
                if val: cat_set.add(val)
        self._risk_categories_all = sorted(cat_set, key=lambda s: s.lower())
        values = ["(All)"] + self._risk_categories_all if self._risk_categories_all else ["(All)"]
        self.risk_category_combo.configure(values=values, state="readonly" if self._risk_categories_all else "disabled")
        self.risk_category_var.set("(All)")

        for cid in ("hostname", self._risk_acl_field, "remark", "risk_description"):
            if cid in self._risk_field_order:
                try: self._attach_treeview_tooltip(self.risk_table, cid)
                except Exception: pass

        self._risk_apply_filter()

    def _risk_apply_filter(self):
        raw = (self.risk_filter_var.get() or "").strip(); host_token = raw; token_cats = None
        m = re.search(r'(category|risk)\s*:\s*([^\s]+)', raw, flags=re.IGNORECASE)
        if m:
            parts = [p.strip() for p in re.split(r'[;,]', m.group(2)) if p.strip()]
            token_cats = set(p.lower() for p in parts) if parts else None
            host_token = (raw[:m.start()] + raw[m.end():]).strip()
        if self._risk_selected_categories:
            active_categories = set(c.lower() for c in self._risk_selected_categories)
        elif token_cats is not None:
            active_categories = token_cats
        else:
            sel = (self.risk_category_var.get() or "").strip()
            active_categories = {sel.lower()} if (sel and sel != "(All)" and self._risk_category_field) else None

        for iid in self.risk_table.get_children(): self.risk_table.delete(iid)
        def gv(r, k): return (r.get(k, "") or "").strip()

        host_sub = host_token.lower(); out_rows = []
        for r in self._risk_rows_cache:
            if host_sub and "hostname" in self._risk_field_order:
                if host_sub not in gv(r, "hostname").lower(): continue
            if active_categories and self._risk_category_field:
                if gv(r, self._risk_category_field).lower() not in active_categories: continue
            out_rows.append(r)

        cols = list(self._risk_field_order)
        for i, r in enumerate(out_rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [gv(r, c) for c in cols]
            self.risk_table.insert("", "end", values=tuple(vals), tags=(tag,))

        try:
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                self._autofit_tree_columns(self.risk_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
        except Exception: pass

    def _risk_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_acl_filtered.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_acl_filtered.csv")
        cols = list(self._risk_field_order or (self.risk_table.cget("columns") or []))
        if not cols:
            try: messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols); dw.writeheader()
                for iid in self.risk_table.get_children():
                    vals = list(self.risk_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try: messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try: messagebox.showinfo("Export CSV", f"Exported {len(self.risk_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _risk_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_acl_filtered.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_acl_filtered.xlsx")
        cols = list(self._risk_field_order or (self.risk_table.cget("columns") or []))
        if not cols:
            try: messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Risky ACL (filtered)"; ws.append(cols)
            for iid in self.risk_table.get_children():
                vals = list(self.risk_table.item(iid, "values") or []); ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None: continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 120)
            wb.save(out_path)
        except Exception as e:
            try: messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try: messagebox.showinfo("Export Excel", f"Exported {len(self.risk_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _risk_open_category_picker(self):
        if not (self._risk_categories_all and self._risk_category_field):
            try: messagebox.showinfo("Categories", "No categories available. Load risky_acl.csv first.")
            except Exception: pass
            return
        top = tk.Toplevel(self.root); top.title("Select Categories"); top.transient(self.root); top.grab_set()
        try: top.resizable(False, True)
        except Exception: pass
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1); top.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)
        canvas = tk.Canvas(frm, highlightthickness=0); cscroll = ttk.Scrollbar(frm, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas); inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw"); canvas.configure(yscrollcommand=cscroll.set, width=360, height=260)
        canvas.grid(row=0, column=0, sticky='nsew'); cscroll.grid(row=0, column=1, sticky='ns')
        frm.rowconfigure(0, weight=1); frm.columnconfigure(0, weight=1)
        var_map = {}
        for i, cat in enumerate(self._risk_categories_all):
            v = tk.BooleanVar(value=(cat in self._risk_selected_categories))
            ttk.Checkbutton(inner, text=cat, variable=v).grid(row=i, column=0, sticky='w', padx=4, pady=2); var_map[cat] = v
        btns = ttk.Frame(frm); btns.grid(row=1, column=0, columnspan=2, sticky='e', pady=(8, 0))
        def on_ok():
            selected = {c for c, v in var_map.items() if v.get()}
            self._risk_selected_categories = selected
            if selected: self.risk_category_var.set("(All)")
            self._risk_apply_filter(); top.destroy()
        def on_clear():
            for v in var_map.values(): v.set(False)
        ttk.Button(btns, text="Clear", command=on_clear).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)
        try:
            top.update_idletasks()
            w = top.winfo_width(); h = top.winfo_height()
            sw = top.winfo_screenwidth(); sh = top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception: pass

    # ---------------- Zero‑hit ACL ----------------
    def _build_zero_tab(self):
        self.tab_zero = ttk.Frame(self.nb); self.nb.add(self.tab_zero, text="Zero‑hit ACL")
        self.tab_zero.columnconfigure(0, weight=1); self.tab_zero.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_zero); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(14): tbar.columnconfigure(c, weight=1)

        ttk.Button(tbar, text="Load zero_acl.csv", command=self._zero_load_csv_clicked).grid(row=0, column=0, sticky='w')

        ttk.Label(tbar, text="Filter (Hostname / tokens)").grid(row=0, column=2, sticky='e')
        self.zero_filter_var = tk.StringVar(value=""); zflt = ttk.Entry(tbar, textvariable=self.zero_filter_var, width=28)
        zflt.grid(row=0, column=3, sticky='w', padx=(6, 0)); zflt.bind("<KeyRelease>", lambda _e: self._zero_apply_filter())

        ttk.Label(tbar, text="Category").grid(row=0, column=4, sticky='e')
        self.zero_category_var = tk.StringVar(value="(All)")
        self.zero_category_combo = ttk.Combobox(tbar, textvariable=self.zero_category_var, values=["(All)"], width=22, state="disabled")
        self.zero_category_combo.grid(row=0, column=5, sticky='w', padx=(6, 0))
        self.zero_category_combo.bind("<<ComboboxSelected>>", lambda _e: self._zero_apply_filter())

        self.zero_cat_btn = ttk.Button(tbar, text="Categories…", command=self._zero_open_category_picker, state="disabled")
        self.zero_cat_btn.grid(row=0, column=6, sticky='w', padx=(6, 0))

        ttk.Button(tbar, text="Send to Remediation", command=self._zero_send_selected_to_remediation).grid(row=0, column=7, sticky='w', padx=(12, 0))

        ttk.Button(tbar, text="Export (shown) to CSV",  command=self._zero_export_shown).grid(row=0, column=10, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._zero_export_shown_excel).grid(row=0, column=11, sticky='e', padx=(6, 0))

        self.zero_wrap = ttk.Frame(self.tab_zero, borderwidth=1, relief="solid"); self.zero_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_zero.rowconfigure(2, weight=1); self.tab_zero.columnconfigure(0, weight=1)
        self.zero_wrap.rowconfigure(0, weight=1); self.zero_wrap.columnconfigure(0, weight=1); self.zero_wrap.columnconfigure(1, weight=0)

        self.zero_table = ttk.Treeview(self.zero_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        self.zero_table.bind("<Control-a>", lambda e: (self.zero_table.selection_set(self.zero_table.get_children()), "break"))

        vsb = ttk.Scrollbar(self.zero_wrap, orient="vertical", command=self.zero_table.yview)
        hsb = ttk.Scrollbar(self.zero_wrap, orient="horizontal", command=self.zero_table.xview)
        self.zero_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.zero_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.zero_table.tag_configure("odd", background="#f5f5f5"); self.zero_table.tag_configure("even", background="#ffffff")

        self._enable_header_drag(self.zero_table)
        def _refit_zero(_e=None):
            cols = list(self.zero_table.cget("columns") or [])
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(self.zero_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        self.zero_table.bind("<Map>", _refit_zero); self.zero_table.bind("<Configure>", _refit_zero)

    def _zero_load_csv_clicked(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path = os.path.join(rep_dir, 'zero_acl.csv')

        for iid in self.zero_table.get_children(): self.zero_table.delete(iid)
        self._zero_rows_cache = []; self._zero_categories_all = []; self._zero_selected_categories = set()
        self._zero_field_order = []; self._zero_category_field = None

        if not os.path.exists(path):
            try: messagebox.showwarning("Zero‑hit ACL", f"File not found:\n{path}")
            except Exception: pass
            return

        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f); rows = list(dr); fieldnames = list(dr.fieldnames or [])
                self._zero_field_order = fieldnames
                self._zero_acl_field = self._detect_acl_field(fieldnames) or "raw_ace"
                low = {c.lower(): c for c in fieldnames}
                self._zero_category_field = low.get("category") or low.get("risk") or None
        except Exception as e:
            try: messagebox.showerror("Zero‑hit ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return

        self._zero_rows_cache = rows

        self.zero_table["columns"] = tuple(self._zero_field_order)
        for col in self._zero_field_order:
            head_text = "ACL" if col == self._zero_acl_field else col
            self.zero_table.heading(col, text=head_text)
            w = 140; anchor = 'w'; stretch = False
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
            if lc in ("raw_ace", self._zero_acl_field.lower()): w, anchor, stretch = max(420, w), 'w', True
            if lc in ("remark", "risk_description"): w, anchor, stretch = max(320, w), 'w', True
            self.zero_table.column(col, width=w, anchor=anchor, stretch=stretch)

        cat_set = set()
        if self._zero_category_field:
            for r in rows:
                v = (r.get(self._zero_category_field) or "").strip()
                if v: cat_set.add(v)
        self._zero_categories_all = sorted(cat_set, key=lambda s: s.lower())

        values = ["(All)"] + self._zero_categories_all if self._zero_categories_all else ["(All)"]
        self.zero_category_combo.configure(values=values,
                                           state="readonly" if self._zero_categories_all else "disabled")
        self.zero_category_var.set("(All)")

        try:
            self.zero_cat_btn.config(state=("normal" if self._zero_categories_all else "disabled"))
        except Exception:
            pass

        for cid in ("hostname", self._zero_acl_field, "remark", "risk_description"):
            if cid in self._zero_field_order:
                try: self._attach_treeview_tooltip(self.zero_table, cid)
                except Exception: pass

        self._zero_apply_filter()

    def _zero_apply_filter(self):
        raw = (self.zero_filter_var.get() or "").strip(); host_token = raw; token_cats = None
        m = re.search(r'(category|risk)\s*:\s*([^\s]+)', raw, flags=re.IGNORECASE)
        if m:
            parts = [p.strip() for p in re.split(r'[;,]', m.group(2)) if p.strip()]
            token_cats = set(p.lower() for p in parts) if parts else None
            host_token = (raw[:m.start()] + raw[m.end():]).strip()
        if self._zero_selected_categories:
            active_categories = set(c.lower() for c in self._zero_selected_categories)
        elif token_cats is not None:
            active_categories = token_cats
        else:
            sel = (self.zero_category_var.get() or "").strip()
            active_categories = {sel.lower()} if (sel and sel != "(All)" and self._zero_category_field) else None

        for iid in self.zero_table.get_children(): self.zero_table.delete(iid)
        def gv(r, k): return (r.get(k, "") or "").strip()

        host_sub = host_token.lower(); out_rows = []
        for r in self._zero_rows_cache:
            if host_sub and "hostname" in self._zero_field_order:
                if host_sub not in gv(r, "hostname").lower(): continue
            if active_categories and self._zero_category_field:
                if gv(r, self._zero_category_field).lower() not in active_categories: continue
            out_rows.append(r)

        cols = list(self._zero_field_order)
        for i, r in enumerate(out_rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [gv(r, c) for c in cols]
            self.zero_table.insert("", "end", values=tuple(vals), tags=(tag,))

        try:
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                self._autofit_tree_columns(self.zero_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
        except Exception: pass

    def _zero_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "zero_acl_filtered.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "zero_acl_filtered.csv")

        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception:
                pass
            return

        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols)
                dw.writeheader()
                for iid in self.zero_table.get_children():
                    vals = list(self.zero_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception:
                pass
            return

        try:
            messagebox.showinfo("Export CSV", f"Exported {len(self.zero_table.get_children())} rows to:\n{out_path}")
        except Exception:
            pass

    def _zero_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "zero_acl_filtered.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "zero_acl_filtered.xlsx")

        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception:
                pass
            return

        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Zero‑hit ACL (filtered)"

            ws.append(cols)
            for iid in self.zero_table.get_children():
                vals = list(self.zero_table.item(iid, "values") or [])
                ws.append(vals)

            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None:
                        continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 120)

            wb.save(out_path)
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception:
                pass
            return

        try:
            messagebox.showinfo("Export Excel", f"Exported {len(self.zero_table.get_children())} rows to:\n{out_path}")
        except Exception:
            pass

    def _zero_open_category_picker(self):
        if not (self._zero_categories_all and self._zero_category_field):
            try:
                messagebox.showinfo("Categories", "No categories available. Load zero_acl.csv first.")
            except Exception:
                pass
            return

        top = tk.Toplevel(self.root)
        top.title("Select Categories")
        top.transient(self.root)
        top.grab_set()
        try:
            top.resizable(False, True)
        except Exception:
            pass

        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1)
        top.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)

        canvas = tk.Canvas(frm, highlightthickness=0)
        cscroll = ttk.Scrollbar(frm, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=cscroll.set, width=360, height=260)

        canvas.grid(row=0, column=0, sticky='nsew')
        cscroll.grid(row=0, column=1, sticky='ns')
        frm.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)

        var_map = {}
        for i, cat in enumerate(self._zero_categories_all):
            v = tk.BooleanVar(value=(cat in self._zero_selected_categories))
            ttk.Checkbutton(inner, text=cat, variable=v).grid(row=i, column=0, sticky='w', padx=4, pady=2)
            var_map[cat] = v

        btns = ttk.Frame(frm)
        btns.grid(row=1, column=0, columnspan=2, sticky='e', pady=(8, 0))

        def on_ok():
            selected = {c for c, v in var_map.items() if v.get()}
            self._zero_selected_categories = selected
            if selected:
                self.zero_category_var.set("(All)")
            self._zero_apply_filter()
            top.destroy()

        def on_clear():
            for v in var_map.values():
                v.set(False)

        ttk.Button(btns, text="Clear", command=on_clear).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)

        try:
            top.update_idletasks()
            w, h = top.winfo_width(), top.winfo_height()
            sw, sh = top.winfo_screenwidth(), top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception:
            pass

    def _zero_send_selected_to_remediation(self):
        iids = self.zero_table.selection()
        if not iids:
            try: messagebox.showinfo("Send to Remediation", "No rows selected. Use multi‑select or Ctrl+A, then retry.")
            except Exception: pass
            return
        cols = list(self.zero_table.cget("columns") or [])
        rows = []
        for iid in iids:
            vals = list(self.zero_table.item(iid, "values") or [])
            row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
            rows.append(row)
        added = self._remed_add_rows(rows, cols)
        try: messagebox.showinfo("Send to Remediation", f"Sent {added} new row(s) to Remediation.")
        except Exception: pass
        try: self.nb.select(self.tab_remed)
        except Exception: pass

    # ---------------- Remediation ----------------
    def _build_remed_tab(self):
        self.tab_remed = ttk.Frame(self.nb); self.nb.add(self.tab_remed, text="Remediation")
        self.tab_remed.columnconfigure(0, weight=1); self.tab_remed.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_remed); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        ttk.Checkbutton(tbar, text='Auto-move validated to Inactive', variable=self.remed_auto_move_var).grid(row=0, column=3, sticky='w')
        ttk.Checkbutton(tbar, text='Dry-run (no changes)', variable=self.remed_dryrun_var).grid(row=0, column=4, sticky='w')

        for c in range(12): tbar.columnconfigure(c, weight=1)
        ttk.Button(tbar, text="Execute (disable)", command=self._remed_execute).grid(row=0, column=5, sticky='w')
        ttk.Button(tbar, text="Export (shown) to CSV",  command=self._remed_export_shown).grid(row=0, column=6, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._remed_export_shown_excel).grid(row=0, column=7, sticky='e', padx=(6,0))
        ttk.Button(tbar, text="Clear Selected", command=self._remed_clear_selected).grid(row=0, column=8, sticky='e', padx=(12,0))
        ttk.Button(tbar, text="Clear All", command=self._remed_clear_all).grid(row=0, column=9, sticky='e')
        ttk.Button(tbar, text="Sync from inactive.csv (move)", command=lambda: self._manual_sync_inactive()).grid(row=0, column=10, sticky='e')

        self.remed_wrap = ttk.Frame(self.tab_remed, borderwidth=1, relief="solid"); self.remed_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_remed.rowconfigure(2, weight=1); self.tab_remed.columnconfigure(0, weight=1)
        self.remed_wrap.rowconfigure(0, weight=1); self.remed_wrap.columnconfigure(0, weight=1); self.remed_wrap.columnconfigure(1, weight=0)

        self.remed_table = ttk.Treeview(self.remed_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        self.remed_table.bind("<Control-a>", lambda e: (self.remed_table.selection_set(self.remed_table.get_children()), "break"))
        vsb = ttk.Scrollbar(self.remed_wrap, orient="vertical", command=self.remed_table.yview)
        hsb = ttk.Scrollbar(self.remed_wrap, orient="horizontal", command=self.remed_table.xview)
        self.remed_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.remed_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.remed_table.tag_configure("odd", background="#f5f5f5"); self.remed_table.tag_configure("even", background="#ffffff")

        self._enable_header_drag(self.remed_table)
        def _refit_remed(_e=None):
            cols = list(self.remed_table.cget("columns") or [])
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(self.remed_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2400)
                except Exception: pass
        self.remed_table.bind("<Map>", _refit_remed); self.remed_table.bind("<Configure>", _refit_remed)

    def _remed_add_rows(self, rows, field_order):
        new_unique = []
        for r in rows:
            if r.get('ace_hash'):
                key = ('hash', r['ace_hash'])
            else:
                key = ('tuple', r.get('hostname',''), r.get('rule_id',''), r.get('action',''), r.get('src',''), r.get('dst',''))
            if key in self._remed_seen_keys:
                continue
            self._remed_seen_keys.add(key)

            try:
                plat = (r.get('platform') or '').strip().lower()
                rule_id = (r.get('rule_id') or '').strip()
                raw_ace = (r.get('raw_ace') or '').strip()
                if plat in ('srx','palo alto','palo-alto','paloalto','pa') and rule_id:
                    r['policy_name'] = rule_id
                    r['rule_name']   = rule_id
                    r['acl_name']    = rule_id
                if plat == 'srx' and not r.get('policy_name') and rule_id:
                    if (' policy ' + rule_id) in (' ' + raw_ace + ' '):
                        r['policy_name'] = rule_id
            except Exception:
                pass

            new_unique.append(r)

        if not new_unique:
            return 0

        if not self._remed_field_order:
            self._remed_field_order = list(field_order)
            self._remed_configure_columns(self._remed_field_order)
        else:
            merged = list(self._remed_field_order)
            for c in field_order:
                if c not in merged:
                    merged.append(c)
            if merged != self._remed_field_order:
                self._remed_field_order = merged
                self._remed_configure_columns(self._remed_field_order, rebuild=True)

        cols = self._remed_field_order
        for i, r in enumerate(new_unique):
            vals = [(r.get(c, '') or '') for c in cols]
            tag = 'even' if ((len(self._remed_rows) + i) % 2 == 0) else 'odd'
            self.remed_table.insert('', 'end', values=tuple(vals), tags=(tag,))
        self._remed_rows.extend(new_unique)

        for cid in ('hostname', 'raw_ace', 'remark', 'risk_description'):
            if cid in cols:
                try:
                    self._attach_treeview_tooltip(self.remed_table, cid)
                except Exception:
                    pass

        return len(new_unique)

    def _remed_configure_columns(self, cols, rebuild=False):
        if rebuild:
            existing = []
            for iid in self.remed_table.get_children():
                existing.append(self.remed_table.item(iid, "values") or ())
            self.remed_table["columns"] = tuple(cols)
            for col in cols:
                self.remed_table.heading(col, text=col)
                w = 140; anchor = 'w'; stretch = False
                lc = col.lower()
                if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
                if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
                if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
                if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
                if lc in ("raw_ace",): w, anchor, stretch = 560, 'w', True
                if lc in ("remark", "risk_description"): w, anchor, stretch = 360, 'w', True
                self.remed_table.column(col, width=w, anchor=anchor, stretch=stretch)
            for iid in self.remed_table.get_children():
                self.remed_table.delete(iid)
            for i, r in enumerate(self._remed_rows):
                vals = [ (r.get(c,"") or "") for c in cols ]
                tag = "even" if (i % 2 == 0) else "odd"
                self.remed_table.insert("", "end", values=tuple(vals), tags=(tag,))
        else:
            self.remed_table["columns"] = tuple(cols)
            for col in cols:
                self.remed_table.heading(col, text=col)
                w = 140; anchor = 'w'; stretch = False
                lc = col.lower()
                if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
                if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
                if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
                if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
                if lc in ("raw_ace",): w, anchor, stretch = 560, 'w', True
                if lc in ("remark", "risk_description"): w, anchor, stretch = 360, 'w', True
                self.remed_table.column(col, width=w, anchor=anchor, stretch=stretch)

    def _remed_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "remediation_queue.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "remediation_queue.csv")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            try: messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols); dw.writeheader()
                for iid in self.remed_table.get_children():
                    vals = list(self.remed_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try: messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try: messagebox.showinfo("Export CSV", f"Exported {len(self.remed_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _remed_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "remediation_queue.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "remediation_queue.xlsx")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            try: messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Remediation Queue"; ws.append(cols)
            for iid in self.remed_table.get_children():
                vals = list(self.remed_table.item(iid, "values") or []); ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None: continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 140)
            wb.save(out_path)
        except Exception as e:
            try: messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try: messagebox.showinfo("Export Excel", f"Exported {len(self.remed_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    # ---- Helpers for Inactive sync ----
    def _read_csv_rows(self, path):
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                return list(dr), list(dr.fieldnames or [])
        except Exception:
            return [], []

    def _row_key(self, d):
        if d.get('ace_hash'):
            return ('hash', (d.get('ace_hash') or '').strip())
        return (
            'tuple',
            (d.get('hostname') or '').strip(),
            (d.get('rule_id') or '').strip(),
            (d.get('action') or '').strip(),
            (d.get('src') or '').strip(),
            (d.get('dst') or '').strip(),
        )

    def _ensure_inactive_from_disable(self, rep_dir: str) -> bool:
        """
        If inactive.csv is missing but disable.csv exists, create inactive.csv
        from SUCCESS rows in disable.csv. Returns True if file was created.
        """
        inactive_path = os.path.join(rep_dir, 'inactive.csv')
        if os.path.exists(inactive_path):
            return False
        disable_path = os.path.join(rep_dir, 'disable.csv')
        if not os.path.exists(disable_path):
            return False
        rows, cols = self._read_csv_rows(disable_path)
        if not rows:
            return False
        preferred = ['timestamp','hostname','platform','rule_id','rule_name','acl_name','raw_ace','action','status','message','command_preview','src','dst','ace_hash']
        out_cols = [c for c in preferred if c in cols] or cols
        out = []
        for r in rows:
            st = (r.get('status') or '').strip().upper()
            if st == 'SUCCESS':
                out.append(r)
        if not out:
            return False
        try:
            with open(inactive_path, 'w', encoding='utf-8', newline='') as f:
                dw = csv.DictWriter(f, fieldnames=out_cols)
                dw.writeheader()
                for r in out:
                    dw.writerow({k: (r.get(k,'') or '') for k in out_cols})
            return True
        except Exception:
            return False

    def _inactive_show_rows(self, rows, cols):
        """Render the given rows/cols in the Inactive table (batch view)."""
        try:
            for iid in self.inactive_table.get_children():
                self.inactive_table.delete(iid)
        except Exception:
            pass
        if not rows:
            return
        try:
            self.inactive_table["columns"] = tuple(cols)
            for col in cols:
                w, anchor, stretch = 140, 'w', True
                lc = col.lower()
                if lc in ("platform", "action", "service"):
                    w, anchor, stretch = 110, 'center', False
                if lc in ("rule_id", "hit_count"):
                    w, anchor, stretch = 90, 'center', False
                if lc in ("hostname",):
                    w, anchor, stretch = 320, 'w', True
                if lc in ("src", "dst"):
                    w, anchor, stretch = 220, 'w', True
                if lc in ("raw_ace", "remark", "risk_description"):
                    w, anchor, stretch = 560, 'w', True
                self.inactive_table.heading(col, text=col)
                self.inactive_table.column(col, width=w, anchor=anchor, stretch=stretch)
            for i, r in enumerate(rows):
                tag = 'even' if (i % 2 == 0) else 'odd'
                vals = [(r.get(c, '') or '') for c in cols]
                self.inactive_table.insert('', 'end', values=tuple(vals), tags=(tag,))
        except Exception:
            pass

    def _sync_move_via_inactive(self, rep_dir: str):
        """
        Loads inactive.csv from rep_dir, compares against Remediation table,
        removes any matching rows from Remediation, and updates Inactive tab
        to show ONLY the moved rows for this batch (not the whole file).
        """
        path_inactive = os.path.join(rep_dir, 'inactive.csv')
        rows_inactive, cols_inactive = self._read_csv_rows(path_inactive)
        if not rows_inactive:
            return 0
        inactive_map = {}
        for r in rows_inactive:
            inactive_map[self._row_key(r)] = r
        inactive_keys = set(inactive_map.keys())

        cols = list(self._remed_field_order or (self.remed_table.cget('columns') or []))
        def row_dict_from_vals(vals):
            return {cols[i]: (vals[i] if i < len(cols) else '') for i in range(len(cols))}
        def row_key_from_vals(vals):
            d = row_dict_from_vals(vals)
            return self._row_key(d)

        to_delete = []
        batch_rows = []
        for iid in self.remed_table.get_children():
            vals = list(self.remed_table.item(iid, 'values') or [])
            key = row_key_from_vals(vals)
            if key in inactive_keys:
                to_delete.append(iid)
                batch_rows.append(inactive_map.get(key) or row_dict_from_vals(vals))

        for iid in to_delete:
            vals = list(self.remed_table.item(iid, 'values') or [])
            d = row_dict_from_vals(vals)
            key = self._row_key(d)
            if key in self._remed_seen_keys:
                self._remed_seen_keys.discard(key)
            self.remed_table.delete(iid)

        if to_delete:
            remaining = []
            for iid in self.remed_table.get_children():
                vals = list(self.remed_table.item(iid, 'values') or [])
                remaining.append(row_dict_from_vals(vals))
            self._remed_rows = remaining

            # Update Inactive tab with only this batch
            self._inactive_batch_rows = batch_rows
            self._inactive_batch_cols = list(cols_inactive or (batch_rows[0].keys() if batch_rows else []))
            try:
                self._inactive_show_rows(self._inactive_batch_rows, self._inactive_batch_cols)
            except Exception:
                pass
        return len(to_delete)

    def _manual_sync_inactive(self):
        rep_dir = self._ensure_modcol_reports_dir()
        moved = self._sync_move_via_inactive(rep_dir)
        try:
            if moved:
                messagebox.showinfo('Inactive Sync', f'Moved {moved} row(s) to Inactive (validated).')
            else:
                messagebox.showinfo('Inactive Sync', 'No validated rows found in inactive.csv.')
        except Exception:
            pass

    def _remed_export_queue_to_dir(self, rep_dir: str) -> str:
        out_path = os.path.join(rep_dir, "remediation_queue.csv")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            raise RuntimeError("No remediation rows to export.")
        with open(out_path, "w", encoding="utf-8", newline="") as f:
            dw = csv.DictWriter(f, fieldnames=cols)
            dw.writeheader()
            for iid in self.remed_table.get_children():
                vals = list(self.remed_table.item(iid, "values") or [])
                row = {k: (vals[i] if i < len(cols) else "") for i, k in enumerate(cols)}
                dw.writerow(row)
        return out_path

    def _remed_execute(self):
        row_count = len(self.remed_table.get_children())
        if row_count == 0:
            try: messagebox.showinfo("Execute Remediation", "No rows in the remediation queue.")
            except Exception: pass
            return
        if not self._ask_creds():
            self._status("Remediation cancelled (credentials required)", "orange")
            return

        os.environ["FW_USERNAME"] = self._mem_user
        os.environ["FW_PASSWORD"] = self._mem_pass
        os.environ["FW_ENABLE"]   = self._mem_enable

        if self.remed_dryrun_var.get():
            os.environ.pop("APPLY_CHANGES", None)
        else:
            os.environ["APPLY_CHANGES"] = "1"

        try:
            ok = messagebox.askyesno(
                "Confirm Execute",
                f"This will disable {row_count} rule(s).\n\n"
                "• Queue will be exported to modular_collector/reports/latest/remediation_queue.csv\n"
                "• Script: remediation.py\n"
                "• Expected output: modular_collector/reports/latest/disable.csv\n\n"
                "Proceed?"
            )
        except Exception:
            ok = True
        if not ok:
            self._status("Remediation cancelled", "orange")
            return

        script = self._find_remediation_script()
        if not script:
            self._status("remediation.py not found", "red")
            try: messagebox.showerror("Execute Remediation", "Could not locate remediation.py")
            except Exception: pass
            return
        run_cwd = os.path.dirname(os.path.abspath(script))

        rep_dir = self._ensure_modcol_reports_dir()
        run_report = os.path.join(rep_dir, "remediation_run_report.txt")

        self._last_reports_dir = rep_dir
        try:
            _ = self._remed_export_queue_to_dir(rep_dir)
        except Exception as e:
            self._status("Failed to export remediation queue", "red")
            try:
                messagebox.showerror(
                    "Execute Remediation",
                    f"Cannot export remediation queue:\n{e}"
                )
            except Exception:
                pass
            return

        try:
            self.output_dash.config(state='normal'); self.output_dash.delete('1.0', 'end'); self.output_dash.config(state='disabled')
        except Exception:
            pass

        self._status("Executing remediation...", "orange")
        try: self.progress.start(10)
        except Exception: pass

        cmd = [sys.executable, os.path.basename(script)]
        def append_console(s: str):
            try:
                self.output_dash.config(state='normal')
                self.output_dash.insert('end', s)
                self.output_dash.see('end')
                self.output_dash.config(state='disabled')
            except Exception:
                pass
        def worker():
            try:
                start = time.time()
                env = os.environ.copy()
                env["PYTHONUNBUFFERED"] = "1"
                env["REPORTS_DIR"] = rep_dir

                res = subprocess.run(
                    cmd, cwd=run_cwd, capture_output=True, text=True, timeout=1800, env=env
                )
                dur = round(time.time() - start, 2)
                out = (res.stdout or '').strip()
                err = (res.stderr or '').strip()

                try:
                    with open(run_report, 'w', encoding='utf-8') as f:
                        f.write(f"[cmd] {' '.join(cmd)}\n[rc] {res.returncode} ({dur}s)\n\n[stdout]\n{out}\n\n[stderr]\n{err}\n")
                except Exception:
                    pass

                if out:
                    self.root.after(0, append_console, f"[stdout]\n{out}\n")
                if err:
                    self.root.after(0, append_console, f"[stderr]\n{err}\n")

                if res.returncode == 0:
                    self.root.after(0, self._status, "Remediation completed. Check disable.csv", "green")
                    # Fallback: if inactive.csv missing but disable.csv exists, create it
                    try:
                        if self.remed_auto_move_var.get():
                            try:
                                created = self._ensure_inactive_from_disable(rep_dir)
                                if created:
                                    self.root.after(0, append_console, '[INFO] Created inactive.csv from disable.csv (fallback)\n')
                            except Exception:
                                pass
                            moved = self._sync_move_via_inactive(rep_dir)
                            if moved:
                                self.root.after(0, append_console, f"[INFO] Moved {moved} row(s) from Remediation to Inactive (validated).\n")
                    except Exception as _e:
                        self.root.after(0, append_console, f"[WARN] Auto-move to Inactive failed: {_e}\n")
                    self.root.after(0, append_console, f"\n[REPORT] {run_report}\n")
                else:
                    self.root.after(0, self._status, f"Remediation failed (exit={res.returncode})", "red")
                    self.root.after(0, append_console, f"\n[REPORT] {run_report}\n")
            except subprocess.TimeoutExpired:
                self.root.after(0, self._status, "Remediation timeout (1800s)", "red")
                self.root.after(0, append_console, "[ERROR] Timeout after 1800 seconds\n")
            except FileNotFoundError as e:
                self.root.after(0, self._status, "Python or remediation.py not found", "red")
                self.root.after(0, append_console, f"[ERROR] {e}\n")
            except Exception as e:
                self.root.after(0, self._status, "Remediation run failed", "red")
                self.root.after(0, append_console, f"[ERROR] {e}\n")
            finally:
                try: self.root.after(0, self.progress.stop)
                except Exception: pass

        threading.Thread(target=worker, daemon=True).start()

    def _remed_clear_selected(self):
        iids = self.remed_table.selection()
        if not iids:
            try: messagebox.showinfo("Remediation", "No rows selected.")
            except Exception: pass
            return
        cols = list(self._remed_field_order)
        def row_key_from_vals(vals):
            d = {cols[i]: (vals[i] if i < len(cols) else "") for i in range(len(cols))}
            if d.get('ace_hash'): return ('hash', d['ace_hash'])
            return ('tuple', d.get('hostname',''), d.get('rule_id',''), d.get('action',''), d.get('src',''), d.get('dst',''))
        for iid in iids:
            vals = list(self.remed_table.item(iid, "values") or [])
            key = row_key_from_vals(vals)
            if key in self._remed_seen_keys:
                self._remed_seen_keys.discard(key)
            self.remed_table.delete(iid)
        remain = []
        for iid in self.remed_table.get_children():
            vals = list(self.remed_table.item(iid, "values") or [])
            d = {cols[i]: (vals[i] if i < len(vals) else "") for i in range(len(cols))}
            remain.append(d)
        self._remed_rows = remain

    def _remed_clear_all(self):
        for iid in self.remed_table.get_children(): self.remed_table.delete(iid)
        self._remed_rows = []; self._remed_field_order = []; self._remed_seen_keys = set()

    # ---------------- Inactive ACL Tab (viewer) ----------------
    def _build_inactive_tab(self):
        self.tab_inactive = ttk.Frame(self.nb)
        self.nb.add(self.tab_inactive, text="Inactive ACL")
        self.tab_inactive.columnconfigure(0, weight=1)
        self.tab_inactive.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_inactive)
        tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(8): tbar.columnconfigure(c, weight=1)
        ttk.Button(tbar, text="Reload from inactive.csv", command=self._inactive_reload_from_csv).grid(row=0, column=0, sticky='w')
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._inactive_export_to_csv).grid(row=0, column=1, sticky='w', padx=(6, 0))
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._inactive_export_to_xlsx).grid(row=0, column=2, sticky='w', padx=(6, 0))

        wrap = ttk.Frame(self.tab_inactive, borderwidth=1, relief="solid")
        wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_inactive.rowconfigure(2, weight=1)
        self.tab_inactive.columnconfigure(0, weight=1)
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)
        wrap.columnconfigure(1, weight=0)

        self.inactive_table = ttk.Treeview(wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.inactive_table.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self.inactive_table.xview)
        self.inactive_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.inactive_table.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        self.inactive_table.tag_configure("odd", background="#f5f5f5")
        self.inactive_table.tag_configure("even", background="#ffffff")
        self._inactive_field_order = []
        self._enable_header_drag(self.inactive_table)

    def _inactive_reload_from_csv(self):
        rep_dir = self._get_reports_dir()
        path = os.path.join(rep_dir, "inactive.csv")
        for iid in self.inactive_table.get_children(): self.inactive_table.delete(iid)
        self._inactive_field_order = []
        if not os.path.exists(path):
            try: messagebox.showwarning("Inactive ACL", f"File not found:\n{path}")
            except Exception: pass
            return
        try:
            with open(path, "r", encoding="utf-8", newline="") as f:
                dr = csv.DictReader(f); rows = list(dr); cols = list(dr.fieldnames or [])
        except Exception as e:
            try: messagebox.showerror("Inactive ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return
        self._inactive_field_order = cols
        self.inactive_table["columns"] = tuple(cols)
        for col in cols:
            w, anchor, stretch = 140, 'w', True
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', True
            if lc in ("raw_ace", "remark", "risk_description"): w, anchor, stretch = 560, 'w', True
            self.inactive_table.heading(col, text=col)
            self.inactive_table.column(col, width=w, anchor=anchor, stretch=stretch)
        for i, r in enumerate(rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [(r.get(c, "") or "") for c in cols]
            self.inactive_table.insert("", "end", values=tuple(vals), tags=(tag,))

    def _inactive_export_to_csv(self):
        rep_dir = self._get_reports_dir()
        out_path = os.path.join(rep_dir, "inactive.csv")
        cols = list(self.inactive_table.cget("columns") or [])
        if not cols:
            try: messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.writer(f); dw.writerow(cols)
                for iid in self.inactive_table.get_children():
                    vals = list(self.inactive_table.item(iid, "values") or [])
                    dw.writerow(vals)
            try: messagebox.showinfo("Export CSV", f"Exported to:\n{out_path}")
            except Exception: pass
        except Exception as e:
            try: messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass

    def _inactive_export_to_xlsx(self):
        rep_dir = self._get_reports_dir()
        out_path = os.path.join(rep_dir, "inactive.xlsx")
        cols = list(self.inactive_table.cget("columns") or [])
        if not cols:
            try: messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Inactive ACL"; ws.append(cols)
            for iid in self.inactive_table.get_children():
                vals = list(self.inactive_table.item(iid, "values") or [])
                ws.append(vals)
            wb.save(out_path)
            try: messagebox.showinfo("Export Excel", f"Exported to:\n{out_path}")
            except Exception: pass
        except Exception as e:
            try: messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass

    # ---------------- Logs & Reports ----------------
    def _build_logs_tab(self):
        try:
            self.tab_logs = ttk.Frame(self.nb); self.nb.add(self.tab_logs, text="Logs & Reports")
            self.tab_logs.columnconfigure(0, weight=1)
            frame = ttk.LabelFrame(self.tab_logs, text="Location"); frame.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
            for c in range(3): frame.columnconfigure(c, weight=1)
            try: base_dir = os.path.abspath(os.path.join(_collector_dir_or_here(), 'reports'))
            except Exception: base_dir = os.path.join(_collector_dir_or_here(), 'reports')
            self.logs_base_var = tk.StringVar(value=base_dir or '-')
            ttk.Label(frame, text="Reports Dir:").grid(row=0, column=0, sticky='w')
            ttk.Label(frame, textvariable=self.logs_base_var, foreground='blue').grid(row=0, column=1, sticky='w')
            ttk.Button(frame, text="Open", command=lambda: _open_path(self.logs_base_var.get() or '.')).grid(row=0, column=2, sticky='ew')

            lframe = ttk.LabelFrame(self.tab_logs, text="Logs Console"); lframe.grid(row=1, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
            self.tab_logs.rowconfigure(1, weight=1); lframe.columnconfigure(0, weight=1); lframe.rowconfigure(0, weight=1); lframe.rowconfigure(1, weight=0)
            self.output_logs = tk.Text(lframe, width=100, height=24, font=("Consolas", 10), wrap='none'); self.output_logs.grid(row=0, column=0, sticky='nsew')
            hsb = ttk.Scrollbar(lframe, orient='horizontal', command=self.output_logs.xview); self.output_logs.configure(xscrollcommand=hsb.set); hsb.grid(row=1, column=0, sticky='ew')
            try:
                self.output_logs.config(state='normal'); self.output_logs.insert('end', f"[INIT] Logs tab ready. Base dir: {self.logs_base_var.get()}\n"); self.output_logs.config(state='disabled')
            except Exception: pass
        except Exception as e:
            try: print("[INIT] _build_logs_tab failed:", e)
            except Exception: pass
            try:
                placeholder = ttk.Frame(self.nb); self.nb.add(placeholder, text="Logs & Reports")
                ttk.Label(placeholder, text=f"Logs tab failed to initialize: {e}", foreground='red').grid(row=0, column=0, sticky='w', padx=PAD, pady=PAD)
            except Exception: pass

    # ---------------- Collector (NEW TAB) ----------------
    def _build_collector_tab(self):
        self.tab_collect = ttk.Frame(self.nb); self.nb.add(self.tab_collect, text="Collector")
        self.tab_collect.columnconfigure(0, weight=1); self.tab_collect.rowconfigure(2, weight=1)

        cfrm = ttk.LabelFrame(self.tab_collect, text="Run Common Collector"); cfrm.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
        for c in range(10): cfrm.columnconfigure(c, weight=1)
        ttk.Label(cfrm, text="Threads").grid(row=0, column=0, sticky='w'); self.collect_threads_var = tk.StringVar(value='8')
        ttk.Entry(cfrm, textvariable=self.collect_threads_var, width=7).grid(row=0, column=1, sticky='w')
        ttk.Label(cfrm, text="Device Timeout (s)").grid(row=0, column=2, sticky='w'); self.collect_timeout_var = tk.StringVar(value='120')
        ttk.Entry(cfrm, textvariable=self.collect_timeout_var, width=9).grid(row=0, column=3, sticky='w')

        ttk.Label(cfrm, text="Read Timeout (s)").grid(row=1, column=0, sticky='w'); self.collect_read_to_var = tk.StringVar(value='120')
        ttk.Entry(cfrm, textvariable=self.collect_read_to_var, width=9).grid(row=1, column=1, sticky='w')
        ttk.Label(cfrm, text="ACL Timeout (s)").grid(row=1, column=2, sticky='w'); self.collect_acl_to_var = tk.StringVar(value='180')
        ttk.Entry(cfrm, textvariable=self.collect_acl_to_var, width=9).grid(row=1, column=3, sticky='w')
        ttk.Label(cfrm, text="Publish every (s)").grid(row=1, column=4, sticky='w'); self.collect_pubint_var = tk.StringVar(value='10')
        ttk.Entry(cfrm, textvariable=self.collect_pubint_var, width=7).grid(row=1, column=5, sticky='w')
        ttk.Label(cfrm, text="ACL method").grid(row=1, column=6, sticky='w')
        self.collect_acl_method = tk.StringVar(value='adaptive')
        ttk.Combobox(cfrm, textvariable=self.collect_acl_method, width=10, values=['prompt', 'timing', 'adaptive'], state='readonly').grid(row=1, column=7, sticky='w')
        self.collect_asa_allctx = tk.BooleanVar(value=False); ttk.Checkbutton(cfrm, text="ASA: all contexts", variable=self.collect_asa_allctx).grid(row=1, column=8, sticky='w')

        btns = ttk.Frame(cfrm); btns.grid(row=2, column=0, columnspan=10, sticky='ew', pady=(6, 0))
        for c in range(5): btns.columnconfigure(c, weight=1)
        ttk.Button(btns, text="Start Collector", command=self._start_collector).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(btns, text="Stop", command=self._stop_collector).grid(row=0, column=1, sticky='ew')
        ttk.Button(btns, text="Open reports/latest", command=lambda: _open_path(_default_reports_latest_dir())).grid(row=0, column=2, sticky='ew')

        stat = ttk.Frame(self.tab_collect); stat.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        stat.columnconfigure(0, weight=1); stat.columnconfigure(1, weight=0)
        self.collect_status_label = ttk.Label(stat, text="Collector Status: Idle", foreground='blue'); self.collect_status_label.grid(row=0, column=0, sticky='w')
        self.collect_prog = ttk.Progressbar(stat, mode='indeterminate', length=250); self.collect_prog.grid(row=0, column=1, sticky='e')

        cons = ttk.LabelFrame(self.tab_collect, text="Collector Console"); cons.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        cons.columnconfigure(0, weight=1); cons.rowconfigure(0, weight=1); cons.rowconfigure(1, weight=0)
        self.output_collect = tk.Text(cons, width=100, height=24, font=("Consolas", 10), wrap='none'); self.output_collect.grid(row=0, column=0, sticky='nsew')
        hsb = ttk.Scrollbar(cons, orient='horizontal', command=self.output_collect.xview); self.output_collect.configure(xscrollcommand=hsb.set); hsb.grid(row=1, column=0, sticky='ew')

        self.col_proc = None; self.collect_run_report = ''

    # ---------- Collector helpers ----------
    def _find_collector_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'collector.py'),
            os.path.join(base, 'modular_collector', 'collector.py'),
            os.path.join(os.path.dirname(base), 'collector.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'collector.py'),
            'collector.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _collector_status(self, msg, color="blue"):
        try:
            self.collect_status_label.config(text=f"Collector Status: {msg}")
            self.collect_status_label.config(foreground=color)
            self.root.update_idletasks()
        except Exception: pass

    def _append_collect(self, text: str):
        try:
            self.output_collect.config(state='normal'); self.output_collect.insert('end', text); self.output_collect.see('end'); self.output_collect.config(state='disabled')
        except Exception: pass

    def _collector_build_cmd(self, script_path: str):
        cmd = [sys.executable, '-u', os.path.basename(script_path)]
        # Threads
        try:
            th = int(self.collect_threads_var.get() or '0')
            if th > 0: cmd += ['--threads', str(th)]
        except Exception: pass
        # Device timeout
        try:
            dt = int(self.collect_timeout_var.get() or '0')
            if dt > 0: cmd += ['--device-timeout', str(dt)]
        except Exception: pass
        # Inline credentials to avoid interactive prompts (force global creds)
        try:
            if getattr(self, '_mem_user', ''):
                cmd += ['--username', self._mem_user, '--password', self._mem_pass or '']
                cmd += ['--force-global-creds']
                if getattr(self, '_mem_enable', ''):
                    cmd += ['--enable-secret', self._mem_enable]
        except Exception: pass
        return cmd

    def _ask_creds(self) -> bool:
        top = tk.Toplevel(self.root); top.title("Enter credentials for this run"); top.transient(self.root); top.grab_set(); top.resizable(False, False)
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        for c in range(2): frm.columnconfigure(c, weight=1)
        ttk.Label(frm, text="Username").grid(row=0, column=0, sticky='w'); uvar = tk.StringVar(value=self._mem_user)
        ttk.Entry(frm, textvariable=uvar, width=28).grid(row=0, column=1, sticky='ew')
        ttk.Label(frm, text="Password").grid(row=1, column=0, sticky='w', pady=(4, 0)); pvar = tk.StringVar(value=self._mem_pass)
        ttk.Entry(frm, textvariable=pvar, width=28, show='•').grid(row=1, column=1, sticky='ew', pady=(4, 0))
        ttk.Label(frm, text="ASA Enable Secret (optional)").grid(row=2, column=0, sticky='w', pady=(4, 0)); evar = tk.StringVar(value=self._mem_enable)
        ttk.Entry(frm, textvariable=evar, width=28, show='•').grid(row=2, column=1, sticky='ew', pady=(4, 0))
        remember = tk.BooleanVar(value=True); ttk.Checkbutton(frm, text="Remember in session (memory only)", variable=remember).grid(row=3, column=0, columnspan=2, sticky='w', pady=(6, 0))
        btns = ttk.Frame(frm); btns.grid(row=4, column=0, columnspan=2, sticky='e', pady=(10, 0))
        ok = {'v': False}
        def on_ok():
            if not uvar.get().strip() or not pvar.get().strip():
                try: messagebox.showwarning("Credentials", "Username and Password are required.")
                except Exception: pass
                return
            ok['v'] = True
            if remember.get():
                self._mem_user = uvar.get().strip(); self._mem_pass = pvar.get(); self._mem_enable = evar.get()
            top.destroy()
        def on_cancel(): top.destroy()
        ttk.Button(btns, text="Cancel", command=on_cancel).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)
        try:
            top.update_idletasks()
            w = top.winfo_width(); h = top.winfo_height()
            sw = top.winfo_screenwidth(); sh = top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception: pass
        top.wait_window(); return ok['v']

    def _start_collector(self):
        if getattr(self, 'col_proc', None):
            self._collector_status("Already running", "orange"); return
        if not self._ask_creds():
            self._collector_status("Cancelled (credentials required)", "orange"); return
        script = self._find_collector_script()
        if not script:
            self._collector_status("collector.py not found", "red"); self._append_collect("[ERROR] Could not find collector.py\n"); return
        run_cwd = os.path.dirname(os.path.abspath(script))
        cmd = self._collector_build_cmd(script)
        self._append_collect(f"[INFO] Using collector script: {script}\n"); self._append_collect(f"[INFO] Working directory: {run_cwd}\n")
        rep_dir, used_fallback, rep_note = _ensure_reports_dir()
        self.collect_run_report = os.path.join(rep_dir, "collector_run_report.txt")
        try: self._append_collect(f"[PATH] {rep_note}\n[PATH] Run report: {self.collect_run_report}\n")
        except Exception: pass
        try:
            with open(self.collect_run_report, 'w', encoding='utf-8') as rf:
                rf.write("[START] Collector launched\n"); rf.write("[CWD] " + run_cwd + "\n"); rf.write("[CMD] " + " ".join(cmd) + "\n"); rf.flush()
        except Exception as e:
            self._append_collect(f"[ERROR] Cannot open report file for writing: {self.collect_run_report}\n {e}\n Output will be shown in the console only.\n")
        try:
            self.output_collect.config(state='normal'); self.output_collect.delete('1.0','end'); self.output_collect.config(state='disabled')
        except Exception: pass
        self._collector_status("Starting...", "orange")
        try: self.collect_prog['mode'] = 'indeterminate'; self.collect_prog.start(10)
        except Exception: pass

        env = os.environ.copy(); env["PYTHONUNBUFFERED"] = "1";
        env["REPORTS_DIR"] = os.path.join(run_cwd, 'reports', 'latest'); os.makedirs(env["REPORTS_DIR"], exist_ok=True)
        try:
            pypaths = [run_cwd, os.path.join(run_cwd, 'platforms'), os.path.dirname(run_cwd)]
            env['PYTHONPATH'] = os.pathsep.join([os.pathsep.join(pypaths), env.get('PYTHONPATH','')])
        except Exception: pass
        try:
            self.col_proc = subprocess.Popen(cmd, cwd=run_cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                             stdin=subprocess.PIPE, text=True, bufsize=1, universal_newlines=True, env=env)
        except FileNotFoundError as e:
            self._collector_status("Python or collector not found", "red"); self._append_collect(f"[ERROR] {e}\n"); return
        except Exception as e:
            self._collector_status("Failed to start", "red"); self._append_collect(f"[ERROR] {e}\n"); return

        PROMPTS = [
            ("banner",   re.compile(r"Enter credentials.*firewall\.csv\s*$", re.IGNORECASE)),
            ("username", re.compile(r"(?:User(?:name)?|Login)\s*:?\s*$", re.IGNORECASE)),
            ("password", re.compile(r"Password\s*:?\s*$", re.IGNORECASE)),
            ("enable",   re.compile(r"(?:Enable(?:\s+secret)?)\s*:?\s*$", re.IGNORECASE)),
        ]
        NL = "\r\n" if os.name == 'nt' else "\n"
        def reader():
            try:
                rf = None
                try: rf = open(self.collect_run_report, 'a', encoding='utf-8')
                except Exception as e:
                    self.root.after(0, self._append_collect, f"[WARN] Report file not writable: {self.collect_run_report} ({e})\n[WARN] Continuing with console-only logging.\n")
                buf = ""; line_buf = ""; last_user_sent_ts = 0.0; password_sent = False
                tail_active = {"banner": False, "username": False, "password": False, "enable": False}
                def log_console(s: str):
                    try:
                        if rf: rf.write(s); rf.flush()
                    except Exception: pass
                    self.root.after(0, self._append_collect, s)
                def match_prompt_tail(b: str):
                    for kind, rx in PROMPTS:
                        if rx.search(b): return kind
                    return None
                while True:
                    ch = self.col_proc.stdout.read(1)
                    if ch == "" or ch is None:
                        if line_buf: log_console(line_buf); line_buf = ""
                        break
                    buf += ch; line_buf += ch
                    if ch == "\n":
                        log_console(line_buf); line_buf = ""
                        for k in tail_active.keys(): tail_active[k] = False
                    kind = match_prompt_tail(buf)
                    for k in list(tail_active.keys()):
                        if kind != k and tail_active[k]: tail_active[k] = False
                    if kind is not None and not tail_active[kind]:
                        tail_active[kind] = True
                        if kind == "username":
                            log_console("[INPUT] sending username\n")
                            try: self.col_proc.stdin.write(self._mem_user + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                            last_user_sent_ts = time.time(); password_sent = False
                        elif kind == "password":
                            log_console("[INPUT] sending password\n")
                            try: self.col_proc.stdin.write(self._mem_pass + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                            password_sent = True
                        elif kind == "enable":
                            log_console("[INPUT] sending enable secret\n")
                            try: self.col_proc.stdin.write((self._mem_enable or "") + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                    if (not password_sent) and (last_user_sent_ts > 0) and (time.time() - last_user_sent_ts > 1.2):
                        log_console("[INPUT] (fallback) sending password]\n")
                        try: self.col_proc.stdin.write(self._mem_pass + NL); self.col_proc.stdin.flush()
                        except Exception: pass
                        password_sent = True; last_user_sent_ts = 0.0
                    m = re.search(r"Progress:\s*(\d+)\s*/\s*(\d+)", buf)
                    if m:
                        try:
                            done = int(m.group(1)); total = int(m.group(2))
                            self.root.after(0, self._collector_update_progress, done, total)
                        except Exception: pass
                    if len(buf) > 8192: buf = buf[-4096:]
            except Exception: pass
            finally:
                try:
                    if rf: rf.close()
                except Exception: pass
                rc = self.col_proc.wait() if self.col_proc else -1
                self.col_proc = None
                self.root.after(0, self._collector_finish, rc)
        threading.Thread(target=reader, daemon=True).start()
        self._collector_status(f"Running: {' '.join(cmd)}", "blue")

    def _collector_update_progress(self, done, total):
        try:
            if total and total > 0:
                self.collect_prog.stop(); self.collect_prog['mode'] = 'determinate'
                self.collect_prog['maximum'] = total; self.collect_prog['value'] = done
        except Exception: pass

    def _collector_finish(self, rc: int):
        try:
            self.collect_prog.stop(); self.collect_prog['value'] = 0; self.collect_prog['mode'] = 'indeterminate'
        except Exception: pass
        if rc == 0: self._collector_status("Completed (exit=0). See report.", "green")
        else: self._collector_status(f"Finished with errors (exit={rc}). See report.", "red")
        try: self._append_collect(f"\n[REPORT] {self.collect_run_report}\n")
        except Exception: pass

    def _stop_collector(self):
        p = getattr(self, 'col_proc', None)
        if not p: self._collector_status("No active collector", "orange"); return
        try: p.terminate(); self._collector_status("Terminate signal sent", "orange")
        except Exception as e: self._colector_status(f"Terminate failed: {e}", "red")

    # ---------- status ----------
    def _status(self, message, color="blue"):
        try:
            self.status_label.config(text=f"Status: {message}")
            self.status_label.config(foreground=color)
            self.root.update_idletasks()
        except Exception: pass

if __name__ == '__main__':
    root = tk.Tk()
    app = AclToolGUI(root)
    root.mainloop()
