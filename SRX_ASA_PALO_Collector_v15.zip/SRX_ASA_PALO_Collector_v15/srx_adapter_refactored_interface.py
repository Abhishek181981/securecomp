
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SrxAdapter (file-fallback + diagnostics aligned, read-only)

Compatibility-first SRX adapter that:
• Builds zone_map from proven SRX sources:
  - Operational TEXT: 'show security zones'
  - Config SET: 'show configuration security zones display set'
• Adds file-fallbacks: if CLI fetch returns empty, load from current run folder:
  - zones_oper_raw.txt
  - zones_cfg_set.txt
  - zones_cfg_text.txt (optional)
• Logs compact build metrics to confirm non-zero bindings
• Exposes packet_tracer (zone-aware auto) for ASA-like verification:
  - from-zone/to-zone match if zones are known
  - fallback to global match otherwise

Patched: Accept CIDR subnets for src/dst and normalize to a single representative
host IP (first usable host, else network address) for routing and match-policies.
"""

from __future__ import annotations

import os
import re
import sys
import time
import ipaddress
from typing import Dict, Optional, Tuple, List

try:
    # Only for typing; code works even if import fails at type-check time
    from netmiko import BaseConnection  # type: ignore
except Exception:  # pragma: no cover
    BaseConnection = object  # fallback for typing


BUILD_ID = "SRX-Adapter v2025-12-08r6 (file-fallback+zone-aware-pt+cidr-normalization)"


# ------------------------------ Logging helpers ------------------------------
def ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def log(msg: str, level: str = "DIAG") -> None:
    sys.stdout.write(f"[{level} {ts()}] {msg}\n")
    sys.stdout.flush()


# ---------------------------------- Adapter ----------------------------------
class SrxAdapter:
    """
    SRX adapter with file-fallbacks, diagnostics-aligned methods, and zone-aware
    packet tracer.

    CIDR handling: src/dst IPs may be given as single IPv4 hosts or CIDR subnets.
    The adapter will normalize subnets to a single representative host IP (first
    usable host where possible; otherwise the network address) before routing
    lookups and match-policies commands.
    """

    def __init__(self, logger=None, debug: bool = True) -> None:
        self.conn: Optional[BaseConnection] = None
        self.zone_map: Dict[str, str] = {}
        self.logger = logger
        self.debug = debug

        # Raw caches
        self.op_zones_text: str = ""
        self.text_config_text: str = ""
        self.set_config_text: str = ""

        # Optional logical-system hint
        self.logical_system: Optional[str] = None

        log(f"{BUILD_ID} initialized")

    # ------------------------------- Connection ------------------------------
    def attach(self, connection: BaseConnection) -> None:
        """Attach Netmiko connection and disable paging."""
        self.conn = connection
        try:
            # Junos: disable paging
            self.conn.send_command("set cli screen-length 0", expect_string=r"[\>\#]")  # type: ignore
        except Exception:
            pass
        log(f"{BUILD_ID} attached (paging disabled)")

    # -------------------------- Run-folder + file IO -------------------------
    def _current_run_dir(self) -> Optional[str]:
        """
        Best-effort: find current run folder where GUI/probe writes zones_* files.
        Looks for 'zones_*' or 'detection.json' in likely locations.
        """
        candidates = [
            os.getcwd(),
            os.path.join(os.getcwd(), "runs", "current"),
            os.path.join(os.getcwd(), "current_run"),
        ]
        for base in candidates:
            if os.path.isdir(base):
                names = set(os.listdir(base))
                if any(n.startswith("zones_") for n in names) or ("detection.json" in names):
                    return base
        # Search nested folders if needed
        for root, _dirs, files in os.walk(os.getcwd()):
            if any(n.startswith("zones_") for n in files) or ("detection.json" in files):
                return root
        return None

    def _load_text_file(self, run_dir: str, name: str) -> str:
        path = os.path.join(run_dir, name)
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return ""

    # ------------------------------ CIDR helper ------------------------------
    def _pick_representative_ip(self, item: Optional[str]) -> Optional[str]:
        """
        Normalize an IPv4 input (host or CIDR subnet) to a single host IP string.

        - If item is None/empty -> None
        - If item is a host IP -> return as-is
        - If item is a CIDR subnet -> return first usable host if any; else network address
        """
        if not item:
            return None
        s = item.strip()
        if not s:
            return None

        # Host as-is
        try:
            ipaddress.IPv4Address(s)
            return s
        except Exception:
            pass

        # CIDR -> first usable host or network address
        try:
            net = ipaddress.IPv4Network(s, strict=False)
            hosts_iter = net.hosts()
            try:
                rep = next(hosts_iter)
                return str(rep)
            except StopIteration:
                return str(net.network_address)
        except Exception:
            return None

    # --------------------------------- Fetchers ---------------------------------
    def _fetch_zones_oper_raw(self) -> str:
        """Text output of 'show security zones' (operational)."""
        if self.conn:
            try:
                out = self.conn.send_command(  # type: ignore
                    "show security zones", expect_string=r"[\>\#]", read_timeout=30
                ) or ""
                if out.strip():
                    self.op_zones_text = out.strip()
                    log(f"[DBG] oper_raw len={len(self.op_zones_text)}")
                    return self.op_zones_text
            except Exception:
                pass
            # relaxed fallback (no expect_string)
            try:
                out = self.conn.send_command("show security zones", read_timeout=45) or ""  # type: ignore
                if out.strip():
                    self.op_zones_text = out.strip()
                    log(f"[DBG] oper_raw(fallback) len={len(self.op_zones_text)}")
                    return self.op_zones_text
            except Exception:
                pass

        # File fallback
        run_dir = self._current_run_dir()
        if run_dir:
            txt = self._load_text_file(run_dir, "zones_oper_raw.txt")
            if txt.strip():
                self.op_zones_text = txt.strip()
                log(
                    f"[DBG] oper_raw(file) len={len(self.op_zones_text)} "
                    f"from {run_dir}/zones_oper_raw.txt"
                )
                return self.op_zones_text
        return self.op_zones_text or ""

    def _fetch_zones_cfg_set(self) -> str:
        """'display set' output for security zones."""
        if self.conn:
            try:
                out = self.conn.send_command(  # type: ignore
                    "show configuration security zones display set",
                    expect_string=r"[\>\#]", read_timeout=30
                ) or ""
                if out.strip():
                    self.set_config_text = out.strip()
                    log(f"[DBG] cfg_set len={len(self.set_config_text)}")
                    return self.set_config_text
            except Exception:
                pass
            # relaxed
            try:
                out = self.conn.send_command(  # type: ignore
                    "show configuration security zones display set", read_timeout=45
                ) or ""
                if out.strip():
                    self.set_config_text = out.strip()
                    log(f"[DBG] cfg_set(fallback) len={len(self.set_config_text)}")
                    return self.set_config_text
            except Exception:
                pass

        # File fallback
        run_dir = self._current_run_dir()
        if run_dir:
            txt = self._load_text_file(run_dir, "zones_cfg_set.txt")
            if txt.strip():
                self.set_config_text = txt.strip()
                log(
                    f"[DBG] cfg_set(file) len={len(self.set_config_text)} "
                    f"from {run_dir}/zones_cfg_set.txt"
                )
                return self.set_config_text
        return self.set_config_text or ""

    def _fetch_zones_cfg_text(self) -> str:
        """Hierarchical zones config (optional; harmless if empty)."""
        if self.conn:
            try:
                out = self.conn.send_command(  # type: ignore
                    "show configuration security zones", expect_string=r"[\>\#]", read_timeout=30
                ) or ""
                if out.strip():
                    self.text_config_text = out.strip()
                    log(f"[DBG] cfg_text len={len(self.text_config_text)}")
                    return self.text_config_text
            except Exception:
                pass

        # File fallback
        run_dir = self._current_run_dir()
        if run_dir:
            txt = self._load_text_file(run_dir, "zones_cfg_text.txt")
            if txt.strip():
                self.text_config_text = txt.strip()
                log(
                    f"[DBG] cfg_text(file) len={len(self.text_config_text)} "
                    f"from {run_dir}/zones_cfg_text.txt"
                )
                return self.text_config_text
        return self.text_config_text or ""

    # ---------------------------------- Parsers ----------------------------------
    def _parse_operational_output(self, op_text: str) -> Dict[str, str]:
        """
        Parse 'show security zones' operational TEXT output.

        Example shape:
            Security zone: <ZONE>
            Interfaces:
                ge-0/0/0.0
                - ge-0/0/1.0
        """
        zone_map: Dict[str, str] = {}
        if not op_text:
            return zone_map

        current_zone: Optional[str] = None
        in_if_block: bool = False

        for raw in op_text.splitlines():
            line = raw.strip()

            m_zone = re.match(r"^\s*Security\s+zone:\s+(.+)$", line, flags=re.IGNORECASE)
            if m_zone:
                current_zone = m_zone.group(1).strip()
                in_if_block = False
                continue

            if re.match(r"^\s*Interfaces\s*:?\s*$", line, flags=re.IGNORECASE):
                in_if_block = True
                continue

            if in_if_block and current_zone:
                # plain token line
                m1 = re.match(r"^\s*([A-Za-z0-9._/\-]+)\s*$", raw)
                if m1:
                    zone_map[m1.group(1)] = current_zone
                    continue

                # bullet + token
                m2 = re.match(r"^\s*[-\*]\s*([A-Za-z0-9._/\-]+)\s*$", raw)
                if m2:
                    zone_map[m2.group(1)] = current_zone
                    continue

        return zone_map

    def _parse_set_format(self, set_text: str) -> Dict[str, str]:
        """
        Parse 'display set' lines for zone bindings.

        Examples:
            set security zones security-zone TRUST interfaces reth3.962
            set logical-systems EDGE-LSYS security zones security-zone TRUST interfaces reth3.962
        """
        zone_map: Dict[str, str] = {}
        if not set_text:
            return zone_map

        root_re = re.compile(
            r"^set\s+security\s+zones\s+security-zone\s+(\S+)\s+interfaces\s+(\S+)\b.*$",
            re.IGNORECASE,
        )
        lsys_re = re.compile(
            r"^set\s+logical-systems\s+(\S+)\s+security\s+zones\s+security-zone\s+(\S+)\s+interfaces\s+(\S+)\b.*$",
            re.IGNORECASE,
        )

        for line in set_text.splitlines():
            s = line.strip()
            m = lsys_re.match(s)
            if m:
                _lsys, zone, iface = m.groups()
                zone_map[iface] = zone
                continue
            m = root_re.match(s)
            if m:
                zone, iface = m.groups()
                zone_map[iface] = zone

        return zone_map

    def _parse_hierarchical_text(self, text_conf: str) -> Dict[str, str]:
        """
        Parse hierarchical 'show configuration security zones'.

        Extracts entries where:
          security { zones { security-zone <ZONE> { interfaces { <IFACE>; } } } }
        """
        zone_map: Dict[str, str] = {}
        if not text_conf:
            return zone_map

        # Remove /* ... */ comment blocks (rare in Junos show config output)
        lines = [re.sub(r"\s*/\*.*?\*/\s*", " ", l) for l in text_conf.splitlines()]

        stack: List[Tuple[str, Optional[str]]] = []
        current_zone: Optional[str] = None
        in_if = False

        for raw in lines:
            line = raw.strip()
            if not line:
                continue

            if re.match(r"^security\s*\{", line):
                stack.append(("security", None))
                continue

            if re.match(r"^zones\s*\{", line):
                stack.append(("zones", None))
                continue

            m_z = re.match(r"^security-zone\s+(\S+)\s*\{", line)
            if m_z:
                current_zone = m_z.group(1).strip()
                stack.append(("security-zone", current_zone))
                in_if = False
                continue

            if re.match(r"^interfaces\s*\{", line):
                stack.append(("interfaces", None))
                in_if = True
                continue

            if line == "}":
                btype, _ = stack.pop() if stack else ("", None)
                if btype == "interfaces":
                    in_if = False
                elif btype == "security-zone":
                    current_zone = None
                continue

            if in_if and current_zone:
                m_if = re.match(r"^(\S+)\s*;?$", line)
                if m_if:
                    zone_map[m_if.group(1)] = current_zone

        return zone_map

    # --------------------- Builders & zone_map merge (diagnostic) ---------------------
    def _build_zone_map_best_effort(self) -> Dict[str, str]:
        """Build zone_map from operational + (optional) hierarchical text; keep existing entries."""
        if not hasattr(self, "zone_map"):
            self.zone_map = {}

        op = self.op_zones_text or self._fetch_zones_oper_raw()
        m_op = self._parse_operational_output(op)
        for k, v in m_op.items():
            if k not in self.zone_map:
                self.zone_map[k] = v

        txt = self.text_config_text or self._fetch_zones_cfg_text()
        m_text = self._parse_hierarchical_text(txt) if txt else {}
        for k, v in m_text.items():
            if k not in self.zone_map:
                self.zone_map[k] = v

        log(f"[ADAPTER BUILD] text_op={len(m_op)} text_hier={len(m_text)} total_zone_map={len(self.zone_map)}")

        # Return combined dict for GUI sample logs
        merged = dict(m_text)
        for k, v in m_op.items():
            if k not in merged:
                merged[k] = v
        return merged

    def _build_zone_map_from_text(self) -> Dict[str, str]:
        return self._build_zone_map_best_effort()

    def _build_zone_map_from_set(self) -> Dict[str, str]:
        """Parse set-format and override weaker bindings in self.zone_map; return parsed dict."""
        txt = self.set_config_text or self._fetch_zones_cfg_set()
        m_set = self._parse_set_format(txt)

        if not hasattr(self, "zone_map"):
            self.zone_map = {}
        for k, v in m_set.items():
            self.zone_map[k] = v

        log(f"[ADAPTER BUILD] set={len(m_set)} total_zone_map={len(self.zone_map)}")
        return m_set

    def _build_zone_map_from_xml(self) -> Dict[str, str]:
        """Stub to keep diagnostics consistent (environment uses oper text + set)."""
        return {}

    def _build_zone_map(self) -> Dict[str, str]:
        """Build from text then set-format (set wins)."""
        self._build_zone_map_best_effort()
        self._build_zone_map_from_set()
        log(f"[ADAPTER BUILD] after _build_zone_map: total_zone_map={len(self.zone_map)}")
        return dict(self.zone_map)

    def build_zone_map(self) -> Dict[str, str]:
        return self._build_zone_map()

    def rebuild_zone_map_from_device(self) -> Dict[str, str]:
        """Fetch both sources and rebuild self.zone_map in precedence order."""
        self.zone_map = {}
        try:
            self._build_zone_map_best_effort()
        except Exception:
            pass
        try:
            self._build_zone_map_from_set()
        except Exception:
            pass
        log(f"zone_map built with {len(self.zone_map)} bindings")
        return dict(self.zone_map)

    # ------------------------------- Lookups & flow helpers -------------------------------
    def zone_for_iface(self, iface: Optional[str]) -> Optional[str]:
        z = self.zone_map.get(iface) if iface else None
        log(f"direct zone_for_iface({iface}) => {z}")
        return z

    def route_out_interface(self, dst_ip: Optional[str]) -> Optional[str]:
        """Find egress interface via 'show route <dst_ip> detail'. Accepts host or CIDR."""
        if not self.conn or not dst_ip:
            return None

        norm_dst = self._pick_representative_ip(dst_ip)
        if not norm_dst:
            return None

        try:
            out = self.conn.send_command(  # type: ignore
                f"show route {norm_dst} detail", expect_string=r"[\>\#]", read_timeout=20
            ) or ""
            m1 = re.search(r"\bvia\s+([A-Za-z0-9\-\_\/\.]+)", out)
            m2 = re.search(r"\bInterface:\s+([A-Za-z0-9\-\_\/\.]+)", out)
            return m1.group(1) if m1 else (m2.group(1) if m2 else None)
        except Exception:
            return None

    def zones_for_flow(self, src_iface: Optional[str], dst_ip: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """Return (from_zone, to_zone) using zone_map + routing for dst (host or CIDR)."""
        if not self.zone_map:
            self.rebuild_zone_map_from_device()

        from_zone = self.zone_for_iface(src_iface)
        to_zone = None

        norm_dst = self._pick_representative_ip(dst_ip) if dst_ip else None
        if norm_dst:
            egress_if = self.route_out_interface(norm_dst)
            to_zone = self.zone_for_iface(egress_if)

        log(
            "Zones for flow: "
            f"src_if={src_iface or 'N/A'} -> {from_zone or 'N/A'}; "
            f"dst_ip={norm_dst or dst_ip or 'N/A'} -> {to_zone or 'N/A'}"
        )
        return (from_zone, to_zone)

    def list_manual_interfaces(self) -> List[str]:
        """Return interfaces found in zone_map (legacy GUI manual dropdown)."""
        if not self.zone_map:
            self.rebuild_zone_map_from_device()
        return sorted(self.zone_map.keys())

    def detect_interfaces(self, src_ip: Optional[str], dst_ip: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """Best-effort: infer (src_if, dst_if) via 'show route <ip> detail'. Accepts host or CIDR."""
        src_if: Optional[str] = None
        dst_if: Optional[str] = None

        # dst egress
        if dst_ip:
            dst_if = self.route_out_interface(dst_ip)  # normalization happens inside

        # src ingress (if directly connected)
        norm_src = self._pick_representative_ip(src_ip) if src_ip else None
        if norm_src and self.conn:
            try:
                out = self.conn.send_command(  # type: ignore
                    f"show route {norm_src} detail", expect_string=r"[\>\#]", read_timeout=20
                ) or ""
                m1 = re.search(r"\bInterface:\s+([A-Za-z0-9\-\_\/\.]+)", out)
                m2 = re.search(r"\bvia\s+([A-Za-z0-9\-\_\/\.]+)", out)
                src_if = m1.group(1) if m1 else (m2.group(1) if m2 else None)
            except Exception:
                src_if = None

        log(f"[DIAG] detect_interfaces result: src_if={src_if}, dst_if={dst_if}")
        return (src_if, dst_if)

    # -------------------------------- SRX "packet tracer" --------------------------------
    def _normalize_proto(self, protocol: str) -> str:
        proto = (protocol or "").strip().lower()
        return "udp" if proto == "udp" else "tcp"

    def packet_tracer_global(
        self,
        protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 90,
    ) -> str:
        """Global SRX policy match."""
        if not self.conn:
            return "[ERROR] Not connected"

        proto = self._normalize_proto(protocol)
        cmd = (
            "show security match-policies global "
            f"source-ip {src_ip} destination-ip {dst_ip} "
            f"source-port {src_port} destination-port {dst_port} "
            f"protocol {proto}"
        )
        try:
            out = self.conn.send_command(cmd, expect_string=r"[\>\#]", read_timeout=timeout) or ""  # type: ignore
            return out
        except Exception as e:
            return f"[ERROR] match-policies (global) failed: {e}"

    def packet_tracer_zone(
        self,
        from_zone: str,
        to_zone: str,
        protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 90,
    ) -> str:
        """Zone-scoped SRX policy match."""
        if not self.conn:
            return "[ERROR] Not connected"

        proto = self._normalize_proto(protocol)
        cmd = (
            "show security match-policies "
            f"from-zone {from_zone} to-zone {to_zone} "
            f"source-ip {src_ip} destination-ip {dst_ip} "
            f"source-port {src_port} destination-port {dst_port} "
            f"protocol {proto}"
        )
        try:
            out = self.conn.send_command(cmd, expect_string=r"[\>\#]", read_timeout=timeout) or ""  # type: ignore
            return out
        except Exception as e:
            return f"[ERROR] match-policies (zone) failed: {e}"

    def packet_tracer_lsys_zone(
        self,
        logical_system: str,
        from_zone: str,
        to_zone: str,
        protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 90,
    ) -> str:
        """Logical-system + zone-scoped SRX policy match."""
        if not self.conn:
            return "[ERROR] Not connected"

        proto = self._normalize_proto(protocol)
        cmd = (
            "show security match-policies logical-system "
            f"{logical_system} "
            f"from-zone {from_zone} to-zone {to_zone} "
            f"source-ip {src_ip} destination-ip {dst_ip} "
            f"source-port {src_port} destination-port {dst_port} "
            f"protocol {proto}"
        )
        try:
            out = self.conn.send_command(cmd, expect_string=r"[\>\#]", read_timeout=timeout) or ""  # type: ignore
            return out
        except Exception as e:
            return f"[ERROR] match-policies (lsys+zone) failed: {e}"

    def packet_tracer_auto(
        self,
        interface: str,
        protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 90,
    ) -> str:
        """
        Smart SRX packet tracer wrapper:

        1) Normalize src/dst (host or CIDR) to representative host IPs
        2) Resolve from_zone from the given 'interface' via zone_map
        3) Resolve to_zone via routing to dst_ip, then zone_map
        4) If both zones known:
             - If logical_system hint set, use lsys+zone command
             - Else use from-zone/to-zone command
           Else: fall back to global command
        Returns raw device output string.
        """
        if not self.conn:
            return "[ERROR] Not connected"

        if not self.zone_map:
            try:
                self.rebuild_zone_map_from_device()
            except Exception:
                pass

        # Normalize IPs
        norm_src = self._pick_representative_ip(src_ip) if src_ip else None
        norm_dst = self._pick_representative_ip(dst_ip) if dst_ip else None

        # Resolve zones
        from_zone = self.zone_for_iface(interface) if interface else None
        egress_if = self.route_out_interface(norm_dst or dst_ip) if (norm_dst or dst_ip) else None
        to_zone = self.zone_for_iface(egress_if) if egress_if else None

        log(
            f"[PT] auto: iface={interface} -> from_zone={from_zone}; "
            f"dst={norm_dst or dst_ip} via={egress_if} -> to_zone={to_zone}"
        )

        # Prefer zone-scoped match
        src_arg = norm_src or src_ip
        dst_arg = norm_dst or dst_ip

        if from_zone and to_zone:
            lsys = getattr(self, "logical_system", None)
            if lsys:
                return self.packet_tracer_lsys_zone(
                    lsys, from_zone, to_zone, protocol, src_arg, src_port, dst_arg, dst_port, timeout=timeout
                )
            return self.packet_tracer_zone(
                from_zone, to_zone, protocol, src_arg, src_port, dst_arg, dst_port, timeout=timeout
            )

        # Fallback: global match
        return self.packet_tracer_global(protocol, src_arg, src_port, dst_arg, dst_port, timeout=timeout)

    # Alias for GUI code that calls adapter.packet_tracer(...)
    packet_tracer = packet_tracer_auto

    # ---------------------------------- Status helper ----------------------------------
    def check_status(self) -> Tuple[str, str]:
        """Simple SRX status check for GUI: returns (text, color)."""
        if not self.conn:
            return ("Not connected (SRX)", "red")
        try:
            out = self.conn.send_command("show system uptime", expect_string=r"[\>\#]", read_timeout=15) or ""  # type: ignore
            if out.strip():
                return ("SRX reachable; uptime obtained", "green")
            ver = self.conn.send_command("show version", expect_string=r"[\>\#]", read_timeout=15) or ""  # type: ignore
            if ver.strip():
                return ("SRX reachable; version obtained", "green")
            return ("SRX reachable (no status details)", "green")
        except Exception as e:
            return (f"SRX status error: {e}", "red")


# ------------------------------- Optional CLI harness -------------------------------
if __name__ == "__main__":
    import argparse
    try:
        from netmiko import ConnectHandler  # type: ignore
    except Exception:
        ConnectHandler = None  # type: ignore

    p = argparse.ArgumentParser(description="SrxAdapter file-fallback demo")
    p.add_argument("--host", required=True)
    p.add_argument("--username", required=True)
    p.add_argument("--password", required=True)
    p.add_argument("--src-if", default=None)
    p.add_argument("--dst-ip", default=None)
    p.add_argument("--pt-src", default=None, help="packet-tracer source IP or CIDR")
    p.add_argument("--pt-dst", default=None, help="packet-tracer destination IP or CIDR")
    p.add_argument("--pt-sport", type=int, default=12345, help="packet-tracer source port")
    p.add_argument("--pt-dport", type=int, default=80, help="packet-tracer destination port")
    p.add_argument("--pt-proto", default="tcp", help="packet-tracer protocol (tcp/udp)")
    p.add_argument("--lsys", default=None, help="logical-system name (optional)")
    a = p.parse_args()

    if ConnectHandler is None:
        print("[ERROR] netmiko is not installed")
        sys.exit(2)

    dev = {
        "device_type": "juniper_junos",
        "host": a.host,
        "username": a.username,
        "password": a.password,
    }
    conn = ConnectHandler(**dev)  # type: ignore
    adp = SrxAdapter()
    adp.attach(conn)
    if a.lsys:
        adp.logical_system = a.lsys

    # Build zone-map for quick sanity
    adp.rebuild_zone_map_from_device()

    if a.src_if or a.dst_ip:
        print("zones_for_flow:", adp.zones_for_flow(a.src_if, a.dst_ip))

    if a.pt_src and a.pt_dst:
        print("\n--- match-policies (AUTO: zone if possible else global) ---")
        print(
            adp.packet_tracer(
                interface=a.src_if or "",
                protocol=a.pt_proto,
                src_ip=a.pt_src,
                src_port=a.pt_sport,
                dst_ip=a.pt_dst,
                dst_port=a.pt_dport,
                timeout=90,
            ))
