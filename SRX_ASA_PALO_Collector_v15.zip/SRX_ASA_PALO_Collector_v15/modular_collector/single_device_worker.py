
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Single-device worker process.
Reads an inventory row (JSON) and writes per-device CSVs to an output folder.
This isolates device collection so any crash/exception won't affect other devices.
"""
import argparse
import csv
import json
import os
import sys
import traceback
from pathlib import Path
from typing import Dict

# Import vendor collectors here (process-local)
try:
    from platforms import asa_collector, srx_collector, palo_collector
except Exception as e:
    print(f"[FATAL] Cannot import vendor collectors: {e}")
    sys.exit(2)

ROUTES_HDR = ["hostname", "platform", "vrf", "route", "nexthop"]
IPS_HDR    = ["hostname", "platform", "interface", "ip", "mask"]
ACLS_HDR   = ["hostname", "platform", "rule_id", "action", "src", "dst", "remark"]
OBJECTS_HDR= ["hostname", "platform", "type", "name", "group", "member", "value", "metadata"]
STATUS_HDR = [
    "firewall hostname", "IP status", "Route status", "Acl status",
    "Object group status", "overall-status",
]
ZERO_ACL_HDR  = ["hostname", "platform", "rule_id", "action", "src", "dst", "hit_count", "remark"]
RISKY_ACL_HDR = ACLS_HDR[:]

class FileWriter:
    def __init__(self, path: Path, hdr):
        self.fh = path.open('w', newline='', encoding='utf-8')
        self.w = csv.DictWriter(self.fh, fieldnames=hdr)
        self.w.writeheader()
    def writerow(self, row: Dict[str,str]):
        self.w.writerow(row)
        self.fh.flush()
    def close(self):
        try:
            self.fh.close()
        except Exception:
            pass

def device_type_for(platform: str) -> str:
    p = (platform or '').strip().lower()
    if p in ('asa','cisco asa'): return 'cisco_asa'
    if p in ('srx','juniper srx'): return 'juniper_junos'
    if p in ('palo alto','paloalto','palo-alto','pan-os'): return 'paloalto_panos'
    return ''


def connect(row: Dict[str,str], username: str, password: str, enable_secret: str):
    try:
        from netmiko import ConnectHandler
    except Exception as e:
        raise RuntimeError("Netmiko not installed.") from e
    host = row.get('ip') or row.get('hostname') or row.get('host')
    if not host:
        raise RuntimeError("Missing ip/hostname in row")
    platform = row.get('platform') or ''
    dev_type = device_type_for(platform)
    if not dev_type:
        raise RuntimeError(f"Unsupported platform: {platform}")
    params = {
        'device_type': dev_type,
        'ip': host,
        'username': username,
        'password': password,
        'port': int(row.get('port') or 22),
        'fast_cli': False,
        'session_log': str(Path(os.environ.get('WORKER_LOGDIR','.') )/ f"{host}_session.log"),
    }
    if dev_type == 'cisco_asa' and enable_secret:
        params['secret'] = enable_secret
    if (row.get('transport') or 'ssh').lower() == 'telnet':
        params['device_type'] = dev_type + '_telnet'
    sess = ConnectHandler(**params)
    # expect_string shim
    def _expect_string(_pat, timeout=10):
        return None
    sess.expect_string = _expect_string  # type: ignore[attr-defined]
    return sess


def run_worker(row_path: Path, outdir: Path, username: str, password: str, enable_secret: str, verbose: bool=False) -> int:
    # ensure logdir for session logs
    os.environ['WORKER_LOGDIR'] = str(outdir)

    row = json.loads(row_path.read_text(encoding='utf-8'))
    hostname = (row.get('hostname') or row.get('host') or row.get('ip') or 'device')
    platform = (row.get('platform') or '').strip()

    # Open per-device writers
    w_objs   = FileWriter(outdir/"objects.csv", OBJECTS_HDR)
    w_routes = FileWriter(outdir/"routes.csv", ROUTES_HDR)
    w_ips    = FileWriter(outdir/"ips.csv",    IPS_HDR)
    w_acls   = FileWriter(outdir/"acls.csv",   ACLS_HDR)
    w_status = FileWriter(outdir/"status.csv", STATUS_HDR)
    w_zero   = FileWriter(outdir/"zero_acl.csv", ZERO_ACL_HDR)
    w_risky  = FileWriter(outdir/"risky_acl.csv", RISKY_ACL_HDR)

    status = {
        'firewall hostname': hostname,
        'IP status': 'failed',
        'Route status': 'failed',
        'Acl status': 'failed',
        'Object group status': 'failed',
        'overall-status': 'failed',
    }
    rc = 1

    try:
        if verbose:
            print(f"[WORKER] Connecting to {hostname} [{platform}]...")
        sess = connect(row, username, password, enable_secret)
        if verbose:
            print(f"[WORKER] Collecting from {hostname} [{platform}] ...")
        # dispatch
        p = platform.lower()
        if p in ('asa','cisco asa'):
            routes_txt, ips_txt, acls_txt = asa_collector.collect(sess, row, w_objs, w_routes, w_ips, w_acls, w_zero, w_risky)
            # ASA objects best-effort
            try:
                from platforms.asa_collector import get_asa_objects_text
                objs_txt = get_asa_objects_text(sess)
                if objs_txt and objs_txt.strip():
                    status['Object group status'] = 'success'
            except Exception:
                pass
        elif p in ('srx','juniper srx'):
            routes_txt, ips_txt, acls_txt = srx_collector.collect(sess, row, w_objs, w_routes, w_ips, w_acls, w_zero, w_risky)
        elif p in ('palo alto','paloalto','palo-alto','pan-os'):
            routes_txt, ips_txt, acls_txt = palo_collector.collect(sess, row, w_objs, w_routes, w_ips, w_acls, w_zero, w_risky)
        else:
            raise RuntimeError(f"Unsupported platform: {platform}")

        if routes_txt and str(routes_txt).strip():
            status['Route status'] = 'success'
        if ips_txt and str(ips_txt).strip():
            status['IP status'] = 'success'
        if acls_txt and str(acls_txt).strip():
            status['Acl status'] = 'success'
        if (
            status['IP status']=='success' and status['Route status']=='success' and
            status['Acl status']=='success' and status['Object group status']=='success'
        ):
            status['overall-status'] = 'success'
        else:
            status['overall-status'] = 'failed'
        rc = 0
    except Exception as e:
        # log to file
        with (outdir/"worker_error.txt").open('a', encoding='utf-8') as ef:
            ef.write(f"ERROR for {hostname}:
")
            ef.write(''.join(traceback.format_exception(type(e), e, e.__traceback__)))
        rc = 1
    finally:
        try:
            sess.disconnect()
        except Exception:
            pass
        # write status row
        w_status.writerow(status)
        # close writers
        for w in (w_objs,w_routes,w_ips,w_acls,w_status,w_zero,w_risky):
            w.close()

    return rc


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--row', required=True, help='Path to row.json')
    ap.add_argument('--outdir', required=True, help='Output folder for this device')
    ap.add_argument('--username', required=True)
    ap.add_argument('--password', required=True)
    ap.add_argument('--enable-secret', default='')
    ap.add_argument('--verbose', action='store_true')
    args = ap.parse_args(argv)

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    rc = run_worker(Path(args.row), outdir, args.username, args.password, args.enable_secret, args.verbose)
    return rc

if __name__ == '__main__':
    sys.exit(main())
