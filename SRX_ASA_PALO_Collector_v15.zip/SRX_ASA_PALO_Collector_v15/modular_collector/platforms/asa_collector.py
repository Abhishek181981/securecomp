﻿# -*- coding: utf-8 -*-
"""
ASA vendor collector (prompt-based, ASCII-only, multi-context friendly).

Key points:
- No 'show curpriv' anywhere; we use prompt-based expect('#') for reliability.
- Multi-context aware:
  * CSV: mode=multi and optional context="ctxA,ctxB" to limit contexts
  * Otherwise, enumerates contexts via 'show context'
- Writes using LockedWriter objects passed by collector.py (thread-safe).
- Minimal, resilient parsers (tolerant regex). You can refine to your environment.

Public API (called by collector.py):
  collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky, context_filter=None)
  get_asa_objects_text(session)
"""

from __future__ import annotations
from typing import Optional, List, Tuple, Dict
import re

# Generic ASA enable/context prompt; adjust if you use custom prompt tokens
PROMPT = r"#"
READ_TO = 60  # default read timeout (per-command)

# -----------------------------
# Netmiko helpers (prompt-based)
# -----------------------------

def _sc(session, cmd: str, expect: str = PROMPT, timeout: int = READ_TO) -> str:
    """Send a command and wait for the prompt (not echo text)."""
    return session.send_command(
        cmd,
        expect_string=expect,
        read_timeout=timeout,
        strip_prompt=False,
        strip_command=False,
    )

def _enter_enable(session) -> None:
    """Enter enable mode (ignore if already enabled)."""
    try:
        session.enable()
    except Exception:
        pass

def _is_multi_context(session) -> bool:
    """Detect single vs multiple context (prefers 'show mode')."""
    try:
        out = _sc(session, "show mode", timeout=20)
        return "multiple" in out.lower()
    except Exception:
        # Fallback probe; 'show context' exists only in multiple mode
        try:
            out = _sc(session, "show context", timeout=20)
            return ("Context" in out and "Mode" in out) or ("changeto context" in out.lower())
        except Exception:
            return False

def _list_contexts(session) -> List[str]:
    """
    Enumerate contexts using 'show context'. ASA formats vary; try two patterns:
      1) Table-like rows where the first token is context name (skip headers/separators).
      2) Lines like 'Context Name: <NAME>'.
    """
    out = _sc(session, "show context", timeout=30)
    ctxs: set[str] = set()

    # Pattern 1: table-like
    for line in out.splitlines():
        s = line.strip()
        if not s:
            continue
        lo = s.lower()
        # Skip header-ish and separators
        if lo.startswith(("context", "system", "admin", "status", "mode", "current", "changeto")):
            continue
        if set(s) <= set("- "):
            continue
        parts = s.split()
        if parts and len(parts[0]) > 1 and parts[0][0].isalnum():
            name = parts[0]
            if name.lower() not in ("system", "admin"):
                ctxs.add(name)

    # Pattern 2: 'Context Name: <NAME>'
    for name in re.findall(r"Context\s+Name\s*:\s*([A-Za-z0-9_.-]+)", out, flags=re.IGNORECASE):
        if name.lower() not in ("system", "admin"):
            ctxs.add(name)

    return sorted(ctxs)

def _switch_context(session, ctx: str) -> None:
    """Switch ASA context; wait for prompt."""
    _sc(session, f"changeto context {ctx}", expect=PROMPT, timeout=20)

# -----------------------------
# Parsers (routes, ips, acls)
# -----------------------------

def _mask_to_prefix(mask: str) -> int:
    try:
        parts = [int(x) for x in mask.split(".")]
        bits = "".join(f"{p:08b}" for p in parts)
        return bits.count("1")
    except Exception:
        return 0

def _parse_routes(text: str, hostname: str, platform: str, vrf: str = "") -> List[Dict[str, str]]:
    """
    Tolerant route parser; examples vary widely on ASA:
      'S    0.0.0.0 0.0.0.0 [1/0] via 10.1.1.1, inside'
      'C    10.10.0.0 255.255.0.0 is directly connected, inside'
    """
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        m1 = re.search(r"(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)  # route + mask
        m2 = re.search(r"\bvia\s+(\d+\.\d+\.\d+\.\d+)", s)                  # nexthop (if any)
        if m1:
            route = f"{m1.group(1)}/{_mask_to_prefix(m1.group(2))}"
            nexthop = m2.group(1) if m2 else ""
            rows.append({
                "hostname": hostname,
                "platform": platform,
                "vrf": vrf,
                "route": route,
                "nexthop": nexthop,
            })
    return rows

def _parse_ips_interface_brief(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    """
    Parse 'show interface ip brief' rows like:
      'GigabitEthernet0/0     10.1.1.2     255.255.255.0     OK    ...'
    """
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.lower().startswith(("interface", "nameif", "ip address")):
            continue
        m = re.match(r"^(\S+)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)
        if m:
            rows.append({
                "hostname": hostname,
                "platform": platform,
                "interface": m.group(1),
                "ip": m.group(2),
                "mask": m.group(3),
            })
    return rows

def _parse_ips_show_ip(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    """
    Fallback: parse 'show ip' styles (model/version-dependent); best-effort.
    Looks for lines: 'Interface <X> ... ip address A.B.C.D M.M.M.M'
    """
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        m = re.search(
            r"(?i)interface\s+(\S+).*?\b(ip\s+address\s+|addr\s+)\s*(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)",
            s,
        )
        if m:
            rows.append({
                "hostname": hostname,
                "platform": platform,
                "interface": m.group(1),
                "ip": m.group(3),
                "mask": m.group(4),
            })
    return rows

def _parse_acl_line(line: str) -> Dict[str, str]:
    """
    Parse a single ASA ACL line (loose). Supports:
      access-list <name> line <id> extended permit ... (hitcnt=...) ... 0x<hash>
    """
    d: Dict[str, str] = {
        "rule_id": "",
        "action": "",
        "src": "",
        "dst": "",
        "hit_count": "",
        "ace_hash": "",
        "remark": "",
        "raw_ace": line.strip(),
    }
    s = line.strip()

    # remark content
    mrem = re.search(r"(?i)\bremark\b\s+(.*)$", s)
    if mrem:
        d["remark"] = mrem.group(1).strip()

    # rule_id from 'line <n>'
    mid = re.search(r"(?i)\bline\s+(\d+)\b", s)
    if mid:
        d["rule_id"] = mid.group(1)

    # action
    mact = re.search(r"(?i)\b(permit|deny)\b", s)
    if mact:
        d["action"] = mact.group(1).lower()

    # hit count
    mhit = re.search(r"(?i)hitcnt\s*=\s*(\d+)", s)
    if mhit:
        d["hit_count"] = mhit.group(1)

    # trailing 0x hash
    mhash = re.search(r"(0x[0-9A-Fa-f]+)\s*$", s)
    if mhash:
        d["ace_hash"] = mhash.group(1)

    # naive src/dst extraction
    iptoks = re.findall(r"(\d+\.\d+\.\d+\.\d+)", s)
    if len(iptoks) >= 2:
        d["src"], d["dst"] = iptoks[0], iptoks[1]

    return d

def _parse_acls(text: str, hostname: str, platform: str) -> Tuple[List[Dict[str, str]], List[Dict[str, str]], List[Dict[str, str]]]:
    """
    Parse 'show access-list' output into (acls, zero, risky).
      - zero: entries with hitcnt=0 (or parsed hit_count == "0")
      - risky: simple heuristic for 'permit ... any any'
    """
    acls: List[Dict[str, str]] = []
    zero: List[Dict[str, str]] = []
    risky: List[Dict[str, str]] = []
    auto_rule_id = 0

    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            continue
        # Only consider ACE/remark lines
        if "access-list" not in s.lower() and "remark" not in s.lower():
            continue

        entry = _parse_acl_line(s)
        auto_rule_id += 1
        if not entry["rule_id"]:
            entry["rule_id"] = str(auto_rule_id)

        row = {
            "hostname": hostname,
            "platform": platform,
            "rule_id": entry["rule_id"],
            "action": entry["action"],
            "src": entry["src"],
            "dst": entry["dst"],
            "hit_count": entry["hit_count"],
            "ace_hash": entry["ace_hash"],
            "remark": entry["remark"],
            "raw_ace": entry["raw_ace"],
        }
        acls.append(row)

        # zero-hit
        if (row["hit_count"] == "0") or ("hitcnt=0" in s.lower()):
            zero.append(row.copy())

        # simple risky: permit any any
        sl = s.lower()
        if "permit" in sl and " any any" in sl:
            risky.append(row.copy())

    return acls, zero, risky

# -----------------------------
# Objects (best-effort parsing)
# -----------------------------

def _parse_object_groups(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    """
    Parse 'show running-config object-group':
      object-group network <NAME>
        network-object host 10.1.1.1
        network-object 10.1.0.0 255.255.0.0
      object-group service <NAME> tcp
        port-object eq 443
    Emits: type, name, group, member, value, metadata
    """
    rows: List[Dict[str, str]] = []
    cur_type = ""
    cur_name = ""
    metadata = ""

    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            continue

        mg = re.match(r"(?i)^object-group\s+(network|service|protocol)\s+(\S+)(?:\s+(\S+))?", s)
        if mg:
            cur_type = mg.group(1).lower()
            cur_name = mg.group(2)
            metadata = mg.group(3) or ""
            continue

        if s.lower().startswith(("network-object", "service-object", "group-object", "port-object")):
            rows.append({
                "hostname": hostname,
                "platform": platform,
                "type": cur_type or "",
                "name": cur_name or "",
                "group": cur_name or "",
                "member": s.split()[0].lower(),  # network-object / service-object / group-object / port-object
                "value": " ".join(s.split()[1:]) if len(s.split()) > 1 else "",
                "metadata": metadata,
            })

    return rows

# -----------------------------
# Public API used by collector.py
# -----------------------------

def get_asa_objects_text(session) -> str:
    """Best-effort: return object-group config; empty string if not permitted/available."""
    try:
        return _sc(session, "show running-config object-group", timeout=40)
    except Exception:
        return ""

def _collect_one_context(session, host: str, platform: str,
                         writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky,
                         ctx_name: Optional[str] = None) -> Tuple[str, str, str]:
    """
    Collect within a single context (or current if ctx_name is None).
    Return (routes_txt, ips_txt, acls_txt) for status bookkeeping.
    """

    # 0) privilege probe (simple and universal)
    try:
        _sc(session, "show privilege", timeout=20)
    except Exception:
        pass  # non-fatal

    # 1) routes
    routes_txt = ""
    try:
        routes_txt = _sc(session, "show route", timeout=55)
        for r in _parse_routes(routes_txt, host, platform, vrf=(ctx_name or "")):
            writer_routes.writerow(r)
    except Exception:
        pass

    # 2) IPs
    ips_txt = ""
    try:
        txt = _sc(session, "show interface ip brief", timeout=45)
        rows = _parse_ips_interface_brief(txt, host, platform)
        if not rows:
            txt = _sc(session, "show ip", timeout=45)
            rows = _parse_ips_show_ip(txt, host, platform)
        ips_txt = txt
        for r in rows:
            writer_ips.writerow(r)
    except Exception:
        pass

    # 3) ACLs
    acls_txt = ""
    try:
        acls_txt = _sc(session, "show access-list", timeout=95)
        a_rows, z_rows, rk_rows = _parse_acls(acls_txt, host, platform)
        for r in a_rows:
            writer_acls.writerow(r)
        for r in z_rows:
            writer_zero.writerow(r)
        for r in rk_rows:
            writer_risky.writerow(r)
    except Exception:
        pass

    # 4) Objects (optional)
    try:
        og_txt = get_asa_objects_text(session)
        if og_txt:
            for r in _parse_object_groups(og_txt, host, platform):
                writer_objs.writerow(r)
    except Exception:
        pass

    return routes_txt or "", ips_txt or "", acls_txt or ""

def collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky, context_filter=None):
    """
    Main entry for collector.py:
      - Detect single vs multi context
      - Build context list from CSV ('context' field) or discover with 'show context'
      - Switch context (when needed) and collect
    """
    host = row.get("hostname") or row.get("ip") or "asa"
    platform = row.get("platform") or "ASA"
    _enter_enable(session)

    mode = (row.get("mode") or "").strip().lower()
    explicit_ctx = (row.get("context") or "").strip()
    ctxs: List[Optional[str]] = []

    if mode == "multi":
        if context_filter:
            ctxs = [c.strip() for c in context_filter if c and c.strip()]
        elif explicit_ctx:
            ctxs = [c.strip() for c in explicit_ctx.split(",") if c.strip()]
        else:
            if _is_multi_context(session):
                ctxs = _list_contexts(session)
        if not ctxs:
            ctxs = [None]  # fallback to current context
    else:
        ctxs = [None]      # single-context

    agg_routes = ""
    agg_ips    = ""
    agg_acls   = ""

    for ctx in ctxs:
        try:
            if ctx:
                _switch_context(session, ctx)
            r_txt, i_txt, a_txt = _collect_one_context(
                session, host, platform,
                writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky,
                ctx_name=ctx
            )
            agg_routes += r_txt
            agg_ips    += i_txt
            agg_acls   += a_txt
        except Exception:
            # Continue to next context; orchestrator's Option-A will mark partial-success if any data exists
            continue

    return agg_routes, agg_ips, agg_acls