# platforms/srx_collector.py (v3.5.0)
# Changes for your environment:
# - Permit-only ACL capture to acls.csv (stable, canonical SET-style raw_ace + ace_hash)
# - Risk model aligned with Palo/ASA: ANY + BROAD (BROAD if CIDR mask <= /16; public or RFC1918),
#   combos (any_src, any_dst, any_any, broad_src, broad_dst, broad_both,
#   any_to_broad, broad_to_any, broad_to_host), plus risky ports {80, 21} (secondary)
# - Applications parsed from both 'show security policies' and 'display set' (service-aware risk)
# - risk & risk_description ONLY in risky_acl.csv
# - Zero-hit best effort retained via 'show security policies hit-count'

import re
import hashlib
from datetime import datetime
try:
    from modular_collector.normalize import normalize_cli
except Exception:
    try:
        from normalize import normalize_cli
    except Exception:
        def normalize_cli(s: str) -> str:
            return s or ""

# ----------------- FS Helpers -----------------
def _ensure_dir(p: str) -> None:
    try:
        import os
        os.makedirs(p, exist_ok=True)
    except Exception:
        pass

def _abs_logs_dir_from_hostmeta(hostmeta, default="reports/latest/logs") -> str:
    import os
    if isinstance(hostmeta, dict):
        for k in ("latest_dir", "log_dir", "run_dir", "workdir"):
            if hostmeta.get(k):
                return os.path.abspath(str(hostmeta[k]))
    return os.path.abspath(default)

def _write_text(path: str, body: str) -> None:
    import os
    _ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8", errors="replace") as f:
        f.write(body or "")

# ----------------- CLI Helpers -----------------
def _safe_prompt(conn) -> str:
    try:
        p = (conn.find_prompt() or "").strip()
        return re.escape(p) + r"\s*$" if p else r"[\>#]\s*$"
    except Exception:
        return r"[\>#]\s*$"

def _run(conn, cmd: str, timeout: int = 240) -> str:
    prompt = _safe_prompt(conn)
    try:
        out = conn.send_command(cmd, expect_string=prompt, read_timeout=timeout)
        if out and out.strip():
            return normalize_cli(out)
    except Exception:
        pass
    try:
        out = conn.send_command_timing(cmd)
        return normalize_cli(out or "")
    except Exception:
        return ""

# ----------------- Parsers -----------------
def _parse_ips(txt: str):
    rows = []
    for line in (txt or "").splitlines():
        if " inet " not in f" {line} ":
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        iface = parts[0]
        cidr = parts[-1]
        if "/" not in cidr:
            continue
        ip, mask = cidr.split("/", 1)
        rows.append({"interface": iface, "ip": ip, "mask": mask})
    return rows

def _parse_routes(txt: str):
    rows = []
    for raw in (txt or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            line = line[1:].strip()
        first = (line.split() or [""])[0]
        if "/" not in first:
            continue
        prefix = first
        next_hop = ""
        if " via " in line:
            next_hop = line.split(" via ", 1)[1].split()[0]
        elif " -> " in line or " - " in line:
            # JunOS variants sometimes use ' -> '
            seg = line.replace(" -> ", " via ").split(" via ", 1)
            if len(seg) > 1:
                next_hop = seg[1].split()[0]
        rows.append({"prefix": prefix, "next_hop": next_hop})
    return rows

# ---------- Policy Parsers (SHOW) ----------
SHOW_KV = {
    "policy": re.compile(r"^\s*(?:Policy|Policy name)\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "from":   re.compile(r"^\s*From\s+zone\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "to":     re.compile(r"^\s*To\s+zone\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "src":    re.compile(r"^\s*Source(?:-addresses| addresses)\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "dst":    re.compile(r"^\s*Destination(?:-addresses| addresses)\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "act":    re.compile(r"^\s*Action\s*:\s*(?P<v>\S+)\s*$", re.IGNORECASE),
    # some outputs list Application(s)
    "app":    re.compile(r"^\s*Application(?:s)?\s*:\s*(?P<v>\S.*?)\s*$", re.IGNORECASE),
    "then":   re.compile(r"^\s*then\s+(?P<v>permit|allow|deny)\b", re.IGNORECASE),
}

def _parse_policies_show(txt: str):
    rows = []
    rule_id = 0
    cur = {"name": "", "from": "", "to": "", "src": "any", "dst": "any", "action": None, "inactive": False, "app": ""}

    def emit():
        nonlocal rule_id
        if cur["action"]:
            rule_id += 1
            rows.append({
                "rule_id": str(rule_id),
                "name": cur["name"],
                "from_zone": cur["from"],
                "to_zone": cur["to"],
                "src": cur["src"] or "any",
                "dst": cur["dst"] or "any",
                "application": cur.get("app",""),
                "action": cur["action"].lower(),
                "inactive": bool(cur.get("inactive", False)),
            })
        cur["action"] = None
        cur["inactive"] = False
        cur["app"] = ""

    for raw in (txt or "").splitlines():
        line = raw.strip()
        if not line:
            emit()
            cur = {"name": "", "from": "", "to": "", "src": "any", "dst": "any", "action": None, "inactive": False, "app": ""}
            continue
        if "inactive" in line.lower():
            cur["inactive"] = True
        m = SHOW_KV["policy"].match(line)
        if m:
            emit()
            cur = {"name": m.group("v").strip(), "from": "", "to": "", "src": "any", "dst": "any", "action": None, "inactive": cur.get("inactive", False), "app": ""}
            continue

        updated = False
        for k in ("from", "to", "src", "dst", "act", "app"):
            m = SHOW_KV[k].match(line)
            if m:
                v = (m.group("v") or "").strip()
                if k == "act":
                    cur["action"] = v
                elif k == "app":
                    cur["app"] = v
                else:
                    cur[k if k in ("from","to") else ("src" if k=="src" else "dst")] = v or cur[k]
                updated = True
                break

        if not updated:
            m2 = SHOW_KV["then"].match(line)
            if m2:
                cur["action"] = m2.group("v")
                emit()
    emit()
    return rows

# -------- SET policy parsing ----------
SET_LINE = re.compile(
    r"^\s*(?:inactive:\s*)?set\s+security\s+policies\s+from-zone\s+(?P<from>\S+)\s+to-zone\s+(?P<to>\S+)\s+policy\s+(?P<name>\S+)\s+(?P<tail>.+)$",
    re.IGNORECASE
)
SET_SRC = re.compile(r"\bmatch\s+source-address\s+(?P<v>\S+)", re.IGNORECASE)
SET_DST = re.compile(r"\bmatch\s+destination-address\s+(?P<v>\S+)", re.IGNORECASE)
SET_ACT = re.compile(r"\bthen\s+(?P<v>permit|allow|deny)\b", re.IGNORECASE)
SET_APP = re.compile(r"\bmatch\s+application\s+(?P<v>\S+)", re.IGNORECASE)

DEACTIVATE_LINE = re.compile(
    r'^\s*deactivate\s+security\s+policies\s+from-zone\s+(?P<from>\S+)\s+to-zone\s+(?P<to>\S+)\s+policy\s+(?P<name>\S+)\s*$',
    re.IGNORECASE
)
def _parse_policies_set(txt: str):
    rules = {}
    inactive_by_key = set()
    for raw in (txt or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        # detect explicit deactivation lines
        md = DEACTIVATE_LINE.match(line)
        if md:
            key = (md.group('from'), md.group('to'), md.group('name'))
            inactive_by_key.add(key)
            continue
        if 'set security policies' not in line.lower():
            continue
        m = SET_LINE.match(line)
        if not m:
            continue

        key = (m.group("from"), m.group("to"), m.group("name"))
        if line.lower().startswith("inactive:"):
            inactive_by_key.add(key)
        rec = rules.get(key) or {
            "from": m.group("from"),
            "to": m.group("to"),
            "name": m.group("name"),
            "src": set(),
            "dst": set(),
            "app": set(),
            "action": None,
        }
        tail = m.group("tail")
        ms = SET_SRC.search(tail)
        md = SET_DST.search(tail)
        ma = SET_ACT.search(tail)
        mp = SET_APP.search(tail)
        if ms:
            rec["src"].add(ms.group("v"))
        if md:
            rec["dst"].add(md.group("v"))
        if mp:
            rec["app"].add(mp.group("v"))
        if ma:
            rec["action"] = ma.group("v")
        rules[key] = rec

    rows = []
    rid = 0
    for key, r in rules.items():
        rid += 1
        rows.append({
            "rule_id": str(rid),
            "name": r["name"],
            "from_zone": r["from"],
            "to_zone": r["to"],
            "src": ",".join(sorted(r["src"])) if r["src"] else "any",
            "dst": ",".join(sorted(r["dst"])) if r["dst"] else "any",
            "application": ",".join(sorted(r["app"])) if r["app"] else "",
            "action": (r["action"] or "").lower(),
            "inactive": key in inactive_by_key,
        })
    return rows

# ---------- Address-book ----------
ADDR_ADDR = re.compile(
    r"^set\s+security\s+address-book\s+(?P<scope>\S+)\s+address\s+(?P<name>\S+)\s+(?P<cidr>\d{1,3}(?:\.\d{1,3}){3}/\d{1,2})\s*$",
    re.IGNORECASE
)
ADDR_SET = re.compile(
    r"^set\s+security\s+address-book\s+(?P<scope>\S+)\s+address-set\s+(?P<set>\S+)\s+members\s+(?P<member>\S+)\s*$",
    re.IGNORECASE
)

def _load_address_book(conn):
    txt = _run(conn, "show configuration security address-book | display set")
    addr_map, set_map = {}, {}
    for raw in (txt or "").splitlines():
        line = raw.strip()
        if not line.startswith("set security address-book"):
            continue
        m1 = ADDR_ADDR.match(line)
        if m1:
            addr_map[m1.group("name")] = m1.group("cidr")
            continue
        m2 = ADDR_SET.match(line)
        if m2:
            set_map.setdefault(m2.group("set"), set()).add(m2.group("member"))
    return addr_map, set_map

def _flatten_members(symbols, addr_map, set_map, _seen=None, max_depth=3):
    _seen = _seen or set()
    out = set()
    for sym in symbols:
        if sym in _seen:
            continue
        _seen.add(sym)
        cidr = addr_map.get(sym)
        if cidr:
            out.add(cidr)
            continue
        members = set_map.get(sym)
        if members and max_depth > 0:
            out |= _flatten_members(list(members), addr_map, set_map, _seen, max_depth - 1)
            continue
        out.add(sym)
    return out

# ---------- Hitcount table ----------
_TAB_ROW_RE = re.compile(
    r"""
    ^\s*(?P<idx>\d+)\s+
    (?P<from>\S+)\s+
    (?P<to>\S+)\s+
    (?P<name>\S+)\s+
    (?P<count>\d+)\s*$
""",
    re.IGNORECASE | re.VERBOSE,
)

def _parse_hitcount_table(txt: str):
    rows = []
    for raw in (txt or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("logical system") or set(line) <= set("-_"):
            continue
        if low.startswith("index ") or low.startswith("index\t"):
            continue
        m = _TAB_ROW_RE.match(line)
        if not m:
            continue
        try:
            rows.append({
                "name": m.group("name"),
                "from_zone": m.group("from"),
                "to_zone": m.group("to"),
                "count": int(m.group("count")),
            })
        except Exception:
            continue
    return rows

# ---------- Risk helpers ----------
ANY_TOKENS = {'any','any-ip','any4','0.0.0.0/0'}
_CIDR = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})\b")

PORT_TOKENS = {
    80: {'http','junos-http','tcp/80','udp/80',':80','www'},
    21: {'ftp','junos-ftp','tcp/21','udp/21',':21'},
}

def _anyish_token(v: str) -> bool:
    return (v or "").strip().lower() in ANY_TOKENS

def _cidr_prefix(v: str):
    m = _CIDR.search(v or "")
    if not m:
        return None
    try:
        return int(m.group(2))
    except Exception:
        return None

def _is_broad(v: str) -> bool:
    """
    BROAD if CIDR mask <= /16 (public or RFC1918).
    Non-CIDR tokens (object names) are not considered broad here.
    """
    p = _cidr_prefix(v)
    return (p is not None) and (p <= 16)

def _mentions_port(text: str, port: int) -> bool:
    t = str(text or "").lower()
    if any(tok in t for tok in PORT_TOKENS.get(port, set())):
        return True
    return bool(re.search(rf'(?<!\d)(?:/|:)\s*{port}(?!\d)', t))

def _risk_reasons(action: str, src_syms, dst_syms, app_text: str) -> list[str]:
    a = (action or "").lower()
    if a not in ("permit","allow"):
        return []

    reasons = []
    any_s = any(_anyish_token(s) for s in src_syms)
    any_d = any(_anyish_token(s) for s in dst_syms)
    br_s  = any(_is_broad(s) for s in src_syms)
    br_d  = any(_is_broad(s) for s in dst_syms)

    # ANY categories
    if any_s: reasons.append('any_src')
    if any_d: reasons.append('any_dst')
    if any_s and any_d: reasons.append('any_any')

    # BROAD categories
    if br_s: reasons.append('broad_src')
    if br_d: reasons.append('broad_dst')
    if br_s and br_d: reasons.append('broad_both')

    # Combos
    if any_s and br_d: reasons.append('any_to_broad')
    if br_s and any_d: reasons.append('broad_to_any')
    if br_s and not br_d: reasons.append('broad_to_host')

    # Ports (secondary)
    for p in (80, 21):
        if _mentions_port(app_text, p):
            reasons.append(f'port={p}')

    # dedup, preserve order
    seen = set(); out=[]
    for r in reasons:
        if r not in seen:
            seen.add(r); out.append(r)
    return out

# ----------------- MAIN -----------------
def collect(session, hostmeta, writer_objs, writer_routes, writer_ips,
            writer_acls, writer_zero, writer_risky):
    hostname = (hostmeta.get("hostname") or hostmeta.get("ip") or "srx") if isinstance(hostmeta, dict) else "srx"
    platform = "srx"
    vrf = "inet.0"

    log_dir = _abs_logs_dir_from_hostmeta(hostmeta, "reports/latest/logs")
    dbg_path = f"{log_dir}/{hostname}_srx_risky_debug.log"
    dbg = [f"==== SRX RISKY DEBUG {datetime.now().isoformat()} HOST={hostname} ====\n"]

    # ---- IPS & ROUTES ----
    ips_txt = _run(session, "show interfaces terse | match inet")
    routes_txt = _run(session, f"show route table {vrf}")
    for r in _parse_ips(ips_txt):
        writer_ips.writerow({
            "hostname":hostname, "platform":platform,
            "interface":r["interface"], "ip":r["ip"], "mask":r["mask"]
        })
    for r in _parse_routes(routes_txt):
        writer_routes.writerow({
            "hostname":hostname, "platform":platform,
            "vrf":vrf, "route":r["prefix"], "nexthop":r["next_hop"]
        })

    # ---- Policies ----
    acls_show = _run(session, "show security policies")
    pol_show = _parse_policies_show(acls_show)
    dbg.append(f"SHOW policies parsed: {len(pol_show)}\n")

    pol_set = []
    if not pol_show:
        set_pol_txt = _run(session, "show configuration security policies | display set")
        pol_set = _parse_policies_set(set_pol_txt)
        dbg.append(f"SET policies parsed: {len(pol_set)}\n")

    policies = pol_show if pol_show else pol_set

    # ---- Address book ----
    addr_map, set_map = _load_address_book(session)
    dbg.append(f"ADDR addr_map={len(addr_map)} set_map={len(set_map)}\n")

    def _tokens_to_syms(s: str):
        toks = [p.strip() for p in (s or "").replace(",", " ").split() if p.strip()]
        return toks or ["any"]

    # ---- Hit-count ----
    hit_txt = _run(session, "show security policies hit-count")
    hits_by_name = {}
    try:
        for row in _parse_hitcount_table(hit_txt):
            nm = (row.get("name") or "").strip()
            if nm:
                hits_by_name[nm] = int(row.get("count", 0))
    except Exception:
        pass

    # ---- Emit ACLs (permit-only), Risky, Zero (best-effort) ----
    risky_count = 0
    for r in policies:
        name = (r.get("name") or "").strip()
        from_zone = r.get("from_zone", "")
        to_zone = r.get("to_zone", "")
        src_toks = _tokens_to_syms(r.get("src", "any"))
        dst_toks = _tokens_to_syms(r.get("dst", "any"))
        src_syms = _flatten_members(src_toks, addr_map, set_map)
        dst_syms = _flatten_members(dst_toks, addr_map, set_map)
        action = (r.get("action") or "").lower().strip()
        inactive = bool(r.get("inactive", False))
        app = (r.get("application") or "").strip()

        if action not in ("permit","allow") or inactive:
            continue

        # Canonical, service-aware, stable raw_ace (SET-style)
        raw_ace = (
            f"set security policies from-zone {from_zone or 'NA'} to-zone {to_zone or 'NA'} "
            f"policy {name or r.get('rule_id','rule')} "
            f"match source-address {r.get('src','any')} "
            f"match destination-address {r.get('dst','any')} "
            + (f"match application {app} " if app else "")
            + f"then {action}"
        ).strip()
        ace_hash = hashlib.md5(raw_ace.encode("utf-8")).hexdigest()

        hit_val = hits_by_name.get(name)
        hit_str = str(hit_val) if isinstance(hit_val, int) else ""
        remark = f"from {from_zone} to {to_zone}" if (from_zone or to_zone) else ""

        # Emit ACL row
        writer_acls.writerow({
            "hostname": hostname,
            "platform": platform,
            "rule_id": r.get("rule_id"),
            "action": action,
            "src": r.get("src","any"),
            "dst": r.get("dst","any"),
            "hit_count": hit_str,
            "ace_hash": ace_hash,
            "remark": remark,
            "raw_ace": raw_ace,
        })

        # ---- risk reasons (ANY + BROAD + ports 80/21) ----
        reasons = _risk_reasons(action, src_syms, dst_syms, f"{app} {remark} {r.get('src','')} {r.get('dst','')}")
        if reasons:
            risky_count += 1
            writer_risky.writerow({
                "hostname": hostname,
                "platform": platform,
                "rule_id": r.get("rule_id"),
                "action": action,
                "src": r.get("src","any"),
                "dst": r.get("dst","any"),
                "hit_count": hit_str,
                "ace_hash": ace_hash,
                "remark": remark + ("; " if remark else "") + "risk=" + ",".join(reasons),
                "raw_ace": raw_ace,
                "risk": ",".join(reasons),
                "risk_description": " | ".join(reasons),
            })

    # ---- Zero-hit best effort (unchanged logic) ----
    try:
        emitted = set()
        for tr in _parse_hitcount_table(hit_txt):
            if tr.get("count", 1) != 0:
                continue
            nm = (tr.get("name") or "").strip()
            if not nm or nm in emitted:
                continue
            match = next((p for p in policies if (p.get("name") or "").strip() == nm), None)
            if not match:
                continue
            action = (match.get("action") or "").lower().strip()
            inactive = bool(match.get("inactive", False))
            if action not in ("permit","allow") or inactive:
                continue
            src = match.get("src", "any")
            dst = match.get("dst", "any")
            remark = f"from {tr.get('from_zone','')} to {tr.get('to_zone','')}".strip()
            raw_ace = (
                f"set security policies from-zone {match.get('from_zone','NA')} "
                f"to-zone {match.get('to_zone','NA')} "
                f"policy {nm} match source-address {src} "
                f"match destination-address {dst} then {action}"
            ).strip()
            ace_hash = hashlib.md5(raw_ace.encode("utf-8")).hexdigest()
            writer_zero.writerow({
                "hostname": hostname,
                "platform": platform,
                "rule_id": nm or (match or {}).get("rule_id",""),
                "action": action,
                "src": src,
                "dst": dst,
                "hit_count": "0",
                "ace_hash": ace_hash,
                "remark": remark,
                "raw_ace": raw_ace,
            })
            emitted.add(nm)
    except Exception as e:
        dbg.append(f"[WARN] hit-count parse failed: {e}\n")

    dbg.append(f"Risky emitted: {risky_count}\n")
    _write_text(dbg_path, "".join(dbg))
    return routes_txt, ips_txt, acls_show