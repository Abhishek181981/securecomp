# Firewall Risk & Zero-Hit Dashboard
_Generated: 2026-02-28 19:54:48_

## Risky Rules Summary

- **Total risky rules**: 226
- **ANY in source**: 11
- **ANY in destination**: 26
- **Permit ANY→ANY rules**: 0
- **ANY→10/8 permits**: 0
- **Permit to RFC1918 from ANY**: 0
- **Broad→Broad (CIDR ≤ /16 on both sides)**: 1
- **Sensitive services (22/3389/1433/1521/27017)**: 22=0, 3389=0, 1433=0, 1521=0, 27017=0

### Top Devices by Risky Rule Count

Hostname | Platform | Risky Rules
--|--:|--:
LON300-KJC-INT-FW01-PA | Palo Alto | 157
BLR-EDGE-OUT-FW01 | srx | 69

## Zero Hit Rules Summary (Permits only)

- **Total zero-hit permit rules**: 129

### Top Devices by Zero-Hit Permit Rule Count

Hostname | Platform | Zero-Hit Permit Rules
--|--:|--:
BLR-EDGE-OUT-FW01 | srx | 129

### Top Zero-Hit Permit Rule IDs (Global, Top 15)

Rule ID | Count
--|--:
SCTASK066319-6-1 | 1
SCTASK0663131-2-4 | 1
SCTASK0663131-1-2 | 1
SCTASK0663131-4-4 | 1
SCTASK0663131-6-4 | 1
SCTASK0663131-2-5 | 1
SCTASK0663131-2 | 1
SCTASK0663195_1 | 1
SCTASK0663195_3 | 1
SCTASK0663196-2 | 1
TEAM-SBC-RULE | 1
74 | 1
73 | 1
SIP-TEST | 1
RITM0364924 | 1


_Heuristics: ANY includes 0.0.0.0/0 and synonyms. RFC1918 detection covers 10/8, 172.16/12, 192.168/16. Sensitive ports are matched by numbers and common labels. Broadness uses CIDR parsing when present. Zero-hit counts reflect **permits only**; age buckets require a 'timestamp' or 'ts' column._
