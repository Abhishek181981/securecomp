
# -*- coding: utf-8 -*-
"""
AsaAdapter (ASA-only, GUI-aligned Jan-2026, with robust failover parsing, group fallback, and context guard + debug):
- System-only failover checks using 'show failover state'.
- TTL auto-delete for monitor capture 'cap_nowtime'.
- Hardened existence check; short retry after create.
- Verdicts from capture (TCP handshake, UDP bidirectionality).
- Robust packet-tracer; clear errors; never raises.
- Neutral monitor/session APIs; always return a dict for GUI.
- Context guard guarantees return to original context; prefer 'show context' starred row over prompt for current context.
- Enhanced debug logs with structured tags (enable via debug=True).
"""
from __future__ import annotations
import re
import ipaddress
import threading
import time
from datetime import datetime
from typing import Optional, Tuple, Set, List, Dict, Any

try:
    from base_adapter import FirewallAdapter  # must provide .conn, .logger, .debug
except Exception:
    class FirewallAdapter:  # minimal stub for offline test
        def __init__(self, logger=None, debug: bool = True, **kwargs):
            self.logger = logger
            self.debug = debug
        def _ensure_file_debug(self, path: str) -> None:
            pass
        def _trace(self, *args, **kwargs) -> None:
            pass

__all__ = ["AsaAdapter"]

# ----------------------------- Constants -----------------------------
SAFE_IFACE_RE = re.compile(r'^[A-Za-z][A-Za-z0-9/_\-.]*$')  # fixed: no literal '*'
STRICT_IFACE_VALIDATE = True
STOP_WORDS = {
    "distance", "metric", "is", "connected", "subnetted", "via",
    "table", "subnet", "not", "in", "codes", "gateway", "last",
    "resort", "to", "network", "routing", "route", "candidate", "default",
}
_CAP_ERR_PATTERNS = ("no such capture", "does not exist")  # existence checks

# ----------------------------- Adapter -----------------------------
class AsaAdapter(FirewallAdapter):

    # --- Subnet-preserving helpers for GUI ASA preview/push ---
    def parse_hosts_and_subnets(self, text: str):
        """Parse multiline hosts/CIDRs into (hosts, subnets) where subnets are (network, netmask) tuples."""
        import ipaddress
        items = [ (line or '').strip() for line in (text or '').splitlines() if (line or '').strip() ]
        hosts, subnets = [], []
        seen_h, seen_n = set(), set()
        for s in items:
            try:
                if '/' in s:
                    net = ipaddress.IPv4Network(s, strict=False)
                    key = (str(net.network_address), str(net.netmask))
                    if key not in seen_n:
                        seen_n.add(key)
                        subnets.append(key)
                else:
                    ipaddress.IPv4Address(s)
                    if s not in seen_h:
                        seen_h.add(s)
                        hosts.append(s)
            except Exception:
                raise ValueError(f"Invalid IPv4/CIDR value: {s}")
        return hosts, subnets

    def build_network_object_group(self, name: str, hosts, subnets):
        """Return ASA config lines for a network object-group with hosts and (net,mask) pairs."""
        lines = [f"object-group network {name}"]
        for ip in hosts or []:
            lines.append(f" network-object host {ip}")
        for (net_addr, netmask) in subnets or []:
            lines.append(f" network-object {net_addr} {netmask}")
        lines.append("exit")
        return lines

    def build_service_object_group(self, name: str, ports, proto: str):
        """Return ASA config lines for a service object-group (tcp/udp) with eq/range handling."""
        proto = (proto or 'tcp').strip().lower()
        if proto not in ('tcp', 'udp'):
            proto = 'tcp'
        lines = [f"object-group service {name} {proto}"]
        for p in ports or []:
            if isinstance(p, int):
                lines.append(f" port-object eq {int(p)}")
            else:
                a, b = p
                lines.append(f" port-object range {int(a)} {int(b)}")
        lines.append("exit")
        return lines

    def pick_test_ip(self, hosts, subnets):
        """Pick a representative test host from explicit hosts or from the first subnet."""
        import ipaddress
        if hosts:
            return hosts[0]
        if subnets:
            net_addr, netmask = subnets[0]
            try:
                net = ipaddress.IPv4Network(f"{net_addr}/{netmask}", strict=False)
                try:
                    return str(next(net.hosts()))
                except StopIteration:
                    return str(net.network_address)
            except Exception:
                return net_addr
        return None
    def __init__(self, logger=None, debug: bool = True, log_file_path: str = "debug.text", **kwargs):
        try:
            super().__init__(logger=logger, debug=debug, **kwargs)
        except TypeError:
            self.logger = logger
            self.debug = debug
        try:
            self._ensure_file_debug(log_file_path)
            self._trace('init', debug=debug, log_file=log_file_path)
        except Exception:
            pass
        # Capability flags for GUIs
        self.monitor_supported = True
        self.has_monitor = True
        self.supports_monitor = True
        self.monitor = True
        self.monitoring_enabled = True
        self.supports_monitoring = True
        self.MONITOR_SUPPORTED = True

    def capabilities(self) -> dict:
        return {
            'monitor': True,
            'monitor_supported': getattr(self, 'monitor_supported', True),
            'apis': ['monitor_start', 'monitor_show', 'monitor_stop',
                     'start_monitor', 'show_monitor', 'stop_monitor',
                     'monitor_snapshot', 'show_sessions', 'summarize_sessions',
                     'start_capture', 'stop_capture', 'clear_capture_filters',
                     'packet_tracer'],
        }

    # ----------------------------- Logging -----------------------------
    def _log(self, level: str, msg: str) -> None:
        try:
            import logging
            self._ensure_file_debug('debug.text')
            logger = getattr(self, 'logger', None)
            if logger is None:
                logger = logging.getLogger(self.__class__.__name__)
            logger.setLevel(logging.DEBUG if getattr(self, 'debug', False) else logging.INFO)
            self.logger = logger
            lvl_map = {'debug': logging.DEBUG, 'info': logging.INFO, 'warning': logging.WARNING, 'error': logging.ERROR}
            lvl = lvl_map.get(str(level).lower(), logging.INFO)
            logger.log(lvl, msg)
        except Exception:
            try:
                print(msg)
            except Exception:
                pass

    def _dbg(self, label: str, **fields) -> None:
        """Structured debug helper for consistent, searchable logs."""
        if not getattr(self, 'debug', False):
            return
        kv = " ".join(f"{k}={repr(v)}" for k, v in fields.items())
        self._log('debug', f"[DBG] {label} {kv}")

    # ----------------------------- Send & Sanitize -----------------------------
    def _send(self, cmd: str, timeout: int = 30) -> str:
        """Send a command via self.conn and return SANITIZED text always."""
        if not getattr(self, "conn", None):
            raise ValueError("AsaAdapter.conn is not set (Netmiko connection required).")
        self._dbg('SEND', cmd=cmd, timeout=timeout)
        out = ""
        try:
            out = self.conn.send_command(cmd, expect_string=r'[\>#]', read_timeout=timeout)  # type: ignore[attr-defined]
        except Exception as e:
            self._dbg('send_command-fallback', error=str(e))
            out = self.conn.send_command_timing(cmd, read_timeout=timeout)  # type: ignore[attr-defined]
        out = self._sanitize_cli(out)
        self._dbg('RECV', bytes=len(out), head=out[:200])
        return out

    def _sanitize_cli(self, text: str) -> str:
        """Strip [CTX=...] and route metrics like [110/20]; keep other text intact."""
        if not text:
            return ""
        text = re.sub(r'\[CTX[^\]]*\]', '', text)
        text = re.sub(r'\[\d+/\d+\]', '', text)
        text = re.sub(r'[ \t]+', ' ', text)
        return text.strip()

    def _skip_banner_lines(self, line: str) -> bool:
        t = (line or '').strip().lower()
        return t.startswith('routing table:')

    def _validate_iface(self, cand: Optional[str]) -> Optional[str]:
        if not cand:
            return None
        cand = cand.strip().rstrip(',')
        if any(x in cand for x in ('[', ']', '=')):
            return None
        if not SAFE_IFACE_RE.match(cand):
            return None
        try:
            if cand in self.list_interfaces():
                return cand
        except Exception:
            pass
        return cand if not STRICT_IFACE_VALIDATE else None

    def _pick_representative_ip(self, item: Optional[str]) -> Optional[str]:
        if not item:
            return None
        s = item.strip()
        if not s:
            return None
        try:
            ipaddress.IPv4Address(s)
            return s
        except Exception:
            pass
        try:
            net = ipaddress.IPv4Network(s, strict=False)
            it = net.hosts()
            try:
                return str(next(it))
            except StopIteration:
                return str(net.network_address)
        except Exception:
            return None

    # ----------------------------- Interface discovery -----------------------------
    def list_interfaces(self) -> Set[str]:
        if getattr(self, '_iface_cache', None) is not None:
            return self._iface_cache
        ifaces: Set[str] = set()
        try:
            run_if = self._send("show run interface", timeout=40)
            for line in run_if.splitlines():
                s = line.strip()
                m = re.match(r'^nameif\s+([A-Za-z][A-Za-z0-9/_\-.]*)$', s)
                if m:
                    name = m.group(1)
                    if SAFE_IFACE_RE.match(name):
                        ifaces.add(name)
        except Exception as e:
            self._log('warning', f"list_interfaces 'show run interface' failed: {e}")
        if not ifaces:
            try:
                out = self._send("show interface ip brief", timeout=30)
                for line in out.splitlines():
                    s = line.strip()
                    if not s:
                        continue
                    m = re.match(r'^(\S+)\s', s)
                    if m:
                        cand = m.group(1)
                        if SAFE_IFACE_RE.match(cand):
                            ifaces.add(cand)
            except Exception as e:
                self._log('warning', f"list_interfaces 'show interface ip brief' failed: {e}")
        self._iface_cache = ifaces
        self._log('info', f"Interfaces discovered: {sorted(ifaces)}")
        return ifaces

    def _parse_interface_blocks(self, text: str):
        """Parse 'show run interface' into [{'iface','nameif','ip','mask'}] blocks.
        Supports both 'ip address' and 'ipv4 address'."""
        blocks = []
        current = None
        for line in (text or "").splitlines():
            s = (line or '').strip()
            m_if = re.match(r'^interface\s+(\S+)$', s, flags=re.IGNORECASE)
            if m_if:
                if current:
                    blocks.append(current)
                current = {'iface': m_if.group(1), 'nameif': None, 'ip': None, 'mask': None}
                continue
            if not current:
                continue
            m_nameif = re.match(r'^nameif\s+(\S+)$', s, flags=re.IGNORECASE)
            if m_nameif:
                current['nameif'] = m_nameif.group(1)
                continue
            m_ip = re.match(r'^(?:ip|ipv4)\s+address\s+(\d{1,3}(?:\.\d{1,3}){3})\s+(\d{1,3}(?:\.\d{1,3}){3})$', s, flags=re.IGNORECASE)
            if m_ip:
                current['ip'] = m_ip.group(1)
                current['mask'] = m_ip.group(2)
                continue
        if current:
            blocks.append(current)
        return blocks
    def interfaces_with_networks(self):
        try:
            run_if = self._send("show run interface", timeout=50)
        except Exception:
            run_if = ""
        blocks = self._parse_interface_blocks(run_if)
        out = []
        for b in blocks:
            ip_, mask = b.get('ip'), b.get('mask')
            iface = b.get('nameif') or b.get('iface')
            if iface and ip_ and mask:
                try:
                    net = ipaddress.IPv4Network(f"{ip_}/{mask}", strict=False)
                    out.append((iface, ip_, mask, net))
                except Exception:
                    pass
        return out

    def match_ingress_by_network(self, src_ip: str) -> Optional[str]:
        try:
            addr = ipaddress.IPv4Address(src_ip)
        except Exception:
            return None
        for (iface, _ip, _mask, net) in self.interfaces_with_networks():
            try:
                if addr in net:
                    return iface
            except Exception:
                continue
        return None

    # ----------------------------- Ingress detection -----------------------------
    def detect_best_interface(self, src_ip: Optional[str]) -> Optional[str]:
        try:
            if not src_ip:
                return None
            src_ip = self._pick_representative_ip(src_ip) or src_ip
            try:
                by_net = self.match_ingress_by_network(src_ip)
                if by_net:
                    self._log('info', f"src_if via interface network match: {by_net}")
                    return by_net
            except Exception as e:
                self._log('debug', f"network match failed: {e}")
            route_out = self._send(f"show route {src_ip}", timeout=25)
            low = route_out.lower()
            if '% subnet not in table' in low or 'not in table' in low or low.strip().startswith('%'):
                self._log('info', 'No specific route for src; using default route interface')
                di = self._default_route_interface()
                if di:
                    return di
            m_dc = re.search(r"is\s+directly\s+connected,\s+([A-Za-z0-9/_\-.]+)", route_out, flags=re.IGNORECASE)
            if m_dc:
                cand = self._validate_iface(m_dc.group(1))
                if cand:
                    self._log('info', f"src_if via directly-connected: {cand}")
                    return cand
            via_re = re.compile(r"\bvia\s+(?:\d{1,3}(?:\.\d{1,3}){3}\s*,\s*)?([A-Za-z0-9/_\-.]+)", re.IGNORECASE)
            via_occurs = list(via_re.finditer(route_out))
            if via_occurs:
                cand = self._validate_iface(via_occurs[-1].group(1))
                if cand:
                    self._log('info', f"src_if via last 'via': {cand}")
                    return cand
            for rex in (
                re.compile(r"\begress interface\s+([A-Za-z0-9/_\-.]+)", re.IGNORECASE),
                re.compile(r"\binterface\s+([A-Za-z0-9/_\-.]+)", re.IGNORECASE),
            ):
                m = rex.search(route_out)
                if m:
                    cand = self._validate_iface(m.group(1))
                    if cand:
                        self._log('info', f"src_if via explicit: {cand}")
                        return cand
            for line in route_out.splitlines():
                if self._skip_banner_lines(line):
                    continue
                ls = line.strip()
                if not ls or ls.startswith('%') or 'not in table' in ls.lower():
                    continue
                s = ls.rstrip(',')
                parts = s.split()
                if parts:
                    cand = parts[-1]
                    if cand.lower() in STOP_WORDS:
                        continue
                    valid = self._validate_iface(cand)
                    if valid:
                        self._log('info', f"src_if via trailing token: {valid}")
                        return valid
        except Exception as e:
            self._log('warning', f"detect_best_interface failed: {e}")
        return None

    # ----------------------------- Default route parsing -----------------------------
    def _default_route_interface(self) -> Optional[str]:
        try:
            out = self._send("show route 0.0.0.0 0.0.0.0", timeout=25) or ""
        except Exception as e:
            self._log('warning', f"default route lookup failed: {e}")
            out = ""
        m_desc = re.search(
            r"^\s*\*?\s*\d{1,3}(?:\.\d{1,3}){3},\s+via\s+([A-Za-z0-9/_\-.]+)\s*$",
            out, flags=re.IGNORECASE | re.MULTILINE
        )
        if m_desc:
            cand = self._validate_iface(m_desc.group(1))
            if cand:
                self._log("info", f"dst_if via default route (descriptor): {cand}")
                return cand
        for line in out.splitlines():
            s = line.strip()
            if "0.0.0.0" in s and "via " in s and "," in s:
                iface = s.split(",")[-1].strip()
                valid = self._validate_iface(iface)
                if valid:
                    self._log("info", f"dst_if via default route: {valid}")
                    return valid
        m = re.search(
            r"S\*\s+0\.0\.0\.0\s+0\.0\.0\.0.*?via\s+\d{1,3}(?:\.\d{1,3}){3}\s*,\s*([A-Za-z0-9/_\-.]+)",
            out, flags=re.IGNORECASE | re.DOTALL
        )
        if m:
            cand = self._validate_iface(m.group(1))
            if cand:
                self._log("info", f"dst_if via default (S* route): {cand}")
                return cand
        lines = out.splitlines()
        for i, s in enumerate(lines):
            if "Gateway of last resort" in s:
                for j in range(i + 1, min(i + 7, len(lines))):
                    nxt = lines[j].strip()
                    if "via " in nxt and "," in nxt:
                        iface = nxt.split(",")[-1].strip()
                        valid = self._validate_iface(iface)
                        if valid:
                            self._log("info", f"dst_if via default (gateway block): {valid}")
                            return valid
                break
        m2 = re.search(
            r"0\.0\.0\.0\s+0\.0\.0\.0.*?is\s+directly\s+connected,\s+([A-Za-z0-9/_\-.]+)",
            out, flags=re.IGNORECASE | re.DOTALL
        )
        if m2:
            cand = self._validate_iface(m2.group(1))
            if cand:
                self._log("info", f"dst_if via default (directly connected): {cand}")
                return cand
        return None

    # ----------------------------- Egress detection -----------------------------
    def route_out_interface(self, dst_ip: Optional[str]) -> Optional[str]:
        try:
            if not dst_ip:
                return None
            dst_ip = self._pick_representative_ip(dst_ip) or dst_ip
            out = self._send(f"show route {dst_ip}", timeout=25)
            low = out.lower()
            if '% subnet not in table' in low or 'not in table' in low or low.strip().startswith('%'):
                self._log("info", "No specific route; using default route interface for dst")
                di = self._default_route_interface()
                if di:
                    return di
            m_dc = re.search(r"is\s+directly\s+connected,\s+([A-Za-z0-9/_\-.]+)", out, flags=re.IGNORECASE)
            if m_dc:
                cand = self._validate_iface(m_dc.group(1))
                if cand:
                    self._log('info', f"dst_if via directly-connected: {cand}")
                    return cand
            via_re = re.compile(r"\bvia\s+(?:\d{1,3}(?:\.\d{1,3}){3}\s*,\s*)?([A-Za-z0-9/_\-.]+)", re.IGNORECASE)
            via_occurs = [m.group(1) for m in via_re.finditer(out)]
            if via_occurs:
                cand = self._validate_iface(via_occurs[-1])
                if cand:
                    self._log('info', f"dst_if via last 'via': {cand}")
                    return cand
            for rex in (
                re.compile(r"\begress interface\s+([A-Za-z0-9/_\-.]+)", re.IGNORECASE),
                re.compile(r"\binterface\s+([A-Za-z0-9/_\-.]+)", re.IGNORECASE),
            ):
                m = rex.search(out)
                if m:
                    cand = self._validate_iface(m.group(1))
                    if cand:
                        self._log('info', f"dst_if via explicit: {cand}")
                        return cand
            for line in out.splitlines():
                if self._skip_banner_lines(line):
                    continue
                ls = line.strip()
                if not ls or ls.startswith('%') or 'not in table' in ls.lower():
                    continue
                s = ls.rstrip(',')
                parts = s.split()
                if parts:
                    cand = parts[-1]
                    if cand.lower() in STOP_WORDS:
                        continue
                    valid = self._validate_iface(cand)
                    if valid:
                        self._log('info', f"dst_if via trailing token: {valid}")
                        return valid
            self._log("info", "No specific route found; trying default route")
            di = self._default_route_interface()
            if di:
                return di
        except Exception as e:
            self._log('warning', f"route_out_interface failed: {e}")
        self._log("warning", "Default route not found or unparsable")
        return None

    # ----------------------------- Combined detection wrapper -----------------------------
    def detect_interfaces(self, src_ip: Optional[str], dst_ip: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        try:
            src_norm = self._pick_representative_ip(src_ip) if src_ip else None
            dst_norm = self._pick_representative_ip(dst_ip) if dst_ip else None
            src_if = self.detect_best_interface(src_norm) if src_norm else None
        except Exception as e:
            self._log('warning', f"detect_interfaces: src_if failed: {e}")
            src_if = None
        try:
            dst_if = self.route_out_interface(dst_norm) if dst_norm else None
        except Exception as e:
            self._log('warning', f"detect_interfaces: dst_if failed: {e}")
            dst_if = None
        self._log('info', f"detect_interfaces result: src_if={src_if}, dst_if={dst_if}")
        return src_if, dst_if

    # ----------------------------- Monitor-capture TTL helpers -----------------------------
    def _mc_capture_name(self) -> str:
        return getattr(self, '_mon_cap_name', self._monitor_capture_name())

    def _mc_cancel_timer(self):
        t = getattr(self, '_mon_cap_timer', None)
        if t:
            try:
                t.cancel()
            except Exception:
                pass
        self._mon_cap_timer = None

    def _mc_schedule_auto_stop(self, ttl_seconds: int = 20):
        """Schedule auto-deletion of the monitor capture after ttl_seconds of inactivity."""
        self._mc_cancel_timer()
        def _auto():
            try:
                cap = self._mc_capture_name()
                self._send(f"no capture {cap}", timeout=10)
                self._log('info', f"ASA monitor TTL expired; capture {cap} deleted")
            except Exception as e:
                self._log('debug', f"ASA monitor TTL stop failed: {e}")
        try:
            self._mon_cap_timer = threading.Timer(ttl_seconds, _auto)
            self._mon_cap_timer.daemon = True
            self._mon_cap_timer.start()
        except Exception:
            pass

    def _cap_exists(self, name: str) -> bool:
        """Check capture existence using multiple ASA error signatures."""
        try:
            chk = self._send(f"show capture {name}", timeout=5)
        except Exception:
            return False
        low = (chk or "").lower()
        if any(p in low for p in _CAP_ERR_PATTERNS):
            return False
        return True

    # ----------------------------- Capture analysis helpers -----------------------------
    def _parse_cap_line(self, line: str):
        s = (line or "").strip()
        if not s:
            return None
        low = s.lower()
        m = re.search(r'\b(tcp|udp)\b', low)
        proto = m.group(1) if m else None
        m2 = re.search(r'(\d{1,3}(?:\.\d{1,3}){3}):(\d+)\s*\-\>\s*(\d{1,3}(?:\.\d{1,3}){3}):(\d+)', s)
        if not m2:
            return None
        src_ip, src_port, dst_ip, dst_port = m2.group(1), int(m2.group(2)), m2.group(3), int(m2.group(4))
        return (proto, src_ip, src_port, dst_ip, dst_port, low)

    def _analyze_capture_flows(self, raw: str):
        lines = [l for l in (raw or "").splitlines() if l.strip()]
        if not lines:
            return "No packets captured yet."
        tcp_forward = set()
        tcp_reverse = set()
        tcp_flags = {"syn": False, "synack": False, "ack": False}
        udp_forward = set()
        udp_reverse = set()

        def mark_tcp_flags(low_text: str):
            if "syn-ack" in low_text or re.search(r'\bS\+?A?CK\b', low_text):
                tcp_flags["synack"] = True
            if "syn" in low_text or re.search(r'(^|\W)S(\W|$)', low_text):
                tcp_flags["syn"] = True
            if "ack" in low_text:
                tcp_flags["ack"] = True

        for line in lines:
            parsed = self._parse_cap_line(line)
            if not parsed:
                continue
            proto, sip, sport, dip, dport, low = parsed
            if proto == "tcp":
                tcp_forward.add((sip, sport, dip, dport))
                tcp_reverse.add((dip, dport, sip, sport))
                mark_tcp_flags(low)
            elif proto == "udp":
                udp_forward.add((sip, sport, dip, dport))
                udp_reverse.add((dip, dport, sip, sport))

        verdicts = []
        if tcp_forward or tcp_reverse:
            has_bidir = any(f in tcp_reverse for f in tcp_forward)
            has_handshake = tcp_flags["syn"] and tcp_flags["synack"] and tcp_flags["ack"]
            if has_bidir and has_handshake:
                verdicts.append("Forwarding OK — TCP 3-way handshake observed (SYN, SYN-ACK, ACK) and reverse traffic present.")
            elif has_bidir and not has_handshake:
                verdicts.append("Partial — Reverse traffic present, but TCP handshake incomplete (missing SYN-ACK or ACK).")
            elif not has_bidir and has_handshake:
                verdicts.append("Partial — Handshake tokens seen, but reverse packets not captured; check interface selection/NAT.")
            else:
                verdicts.append("Incomplete — No SYN-ACK observed; check return path / ACL / NAT.")

        if udp_forward or udp_reverse:
            has_bidir_udp = any(f in udp_reverse for f in udp_forward)
            if has_bidir_udp:
                verdicts.append("UDP reverse traffic confirmed (bi-directional packets observed).")
            else:
                verdicts.append("UDP reverse traffic not observed; check return path or interface attachment.")

        if not verdicts:
            verdicts.append("No recognizable TCP/UDP flow pattern detected yet.")
        return " ".join(verdicts)

    # ----------------------------- Monitor / Packet Capture (ASA) -----------------------------
    def _monitor_capture_name(self) -> str:
        return "cap_nowtime"

    def build_capture_command(self, protocol: str, src_ip: str, dst_ip: str, port: int, in_if: str) -> str:
        proto = (protocol or "").strip().lower()
        if proto not in {"tcp", "udp"}:
            raise ValueError("protocol must be 'tcp' or 'udp'")
        if not in_if:
            raise ValueError("in_if (source interface) is required")
        src_host = self._pick_representative_ip(src_ip) or src_ip
        dst_host = self._pick_representative_ip(dst_ip) or dst_ip
        return f"capture {{name}} interface {in_if} match {proto} host {src_host} host {dst_host} eq {int(port)}"

    def start_monitor_capture(self, protocol: str, src_ip: str, dst_ip: str, port: int, overwrite: bool = True) -> tuple[str, str, str]:
        src_if = self.detect_best_interface(src_ip)
        if not src_if:
            raise ValueError("Unable to detect source interface for capture")
        cap_name = self._monitor_capture_name()
        if overwrite:
            try:
                _ = self._send(f"no capture {cap_name}", timeout=10)
            except Exception:
                pass
        cap_cmd_tpl = self.build_capture_command(protocol, src_ip, dst_ip, port, in_if=src_if)
        final_cmd = cap_cmd_tpl.format(name=cap_name)
        out = self._send(final_cmd, timeout=25)
        self._log('info', f"ASA capture started: name={cap_name} interface={src_if} proto={protocol} src={src_ip} dst={dst_ip} port={port}")
        self._dbg('capture-start', cmd=final_cmd, cli_head=out[:160])
        setattr(self, "monitor_supported", True)
        return cap_name, final_cmd, out

    def show_monitor_capture(self, capture_name: str, max_bytes: int = 0) -> str:
        if not capture_name:
            raise ValueError("capture_name required")
        out = self._send(f"show capture {capture_name}", timeout=30)
        return out[:max_bytes] if max_bytes and len(out) > max_bytes else out

    def stop_monitor_capture(self, capture_name: str) -> str:
        if not capture_name:
            raise ValueError("capture_name required")
        try:
            _ = self._send(f"show capture {capture_name}", timeout=10)
        except Exception as e:
            self._dbg('stop-capture-show-failed', err=str(e))
        out = self._send(f"no capture {capture_name}", timeout=20)
        self._log('info', f"ASA capture deleted: {capture_name}")
        try:
            chk = self._send(f"show capture {capture_name}", timeout=10)
            low = (chk or "").lower()
            if not any(p in low for p in _CAP_ERR_PATTERNS):
                self._log('warning', f"Capture {capture_name} may still exist; ASA said:\n{chk}")
        except Exception:
            pass
        return out

    # ----------------------------- Monitor API wrappers (GUI) -----------------------------
    def monitor_start(self, protocol: str, src_ip: str, dst_ip: str, port: int) -> Dict[str, Any]:
        name, cmd, cli_out = self.start_monitor_capture(protocol, src_ip, dst_ip, port)
        return {
            "name": name,
            "interface": self.detect_best_interface(src_ip),
            "protocol": (protocol or "").strip().lower(),
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "port": int(port),
            "command": cmd,
            "cli_output": cli_out,
        }

    def monitor_show(self, capture_name: str, max_bytes: int = 0) -> str:
        return self.show_monitor_capture(capture_name, max_bytes=max_bytes)

    def monitor_stop(self, capture_name: str) -> str:
        return self.stop_monitor_capture(capture_name)

    # Aliases (if GUI probes alternative names)
    def start_monitor(self, protocol: str, src_ip: str, dst_ip: str, port: int) -> Dict[str, Any]:
        return self.monitor_start(protocol, src_ip, dst_ip, port)
    def show_monitor(self, capture_name: str, max_bytes: int = 0) -> str:
        return self.monitor_show(capture_name, max_bytes=max_bytes)
    def stop_monitor(self, capture_name: str) -> str:
        return self.monitor_stop(capture_name)

    # ----------------------------- Neutral snapshot APIs (GUI expects) -----------------------------
    def show_sessions(self, src_ip: Optional[str] = None, dst_ip: Optional[str] = None, app: Optional[str] = None,
                      limit: int = 200, timeout: int = 45) -> str:
        out = self._send("show conn", timeout=timeout)
        lines = [l for l in out.splitlines() if l.strip()]
        if src_ip:
            lines = [l for l in lines if src_ip in l]
        if dst_ip:
            lines = [l for l in lines if dst_ip in l]
        raw = "\n".join(lines[:max(1, min(limit, len(lines)))])
        return raw

    def summarize_sessions(self, raw: str, top_n: int = 10) -> str:
        lines = (raw or "").splitlines()
        count = len(lines)
        head = "\n".join(lines[:min(top_n, count)])
        return f"[ASA] Sessions snapshot: {count} line(s). Showing top {min(top_n, count)}.\n" + head

    def monitor_snapshot(self, src_ip: Optional[str] = None, dst_ip: Optional[str] = None, app: Optional[str] = None,
                         limit: int = 200, timeout: int = 45) -> Dict[str, str]:
        try:
            if src_ip or dst_ip:
                in_if = None
                try:
                    in_if = self.detect_best_interface(src_ip) if src_ip else None
                except Exception as e:
                    self._dbg('mon-detect-interface-failed', err=str(e), src=src_ip)
                if not in_if:
                    try:
                        in_if = self._default_route_interface()
                    except Exception as e:
                        self._dbg('mon-default-if-failed', err=str(e))
                        in_if = None
                self._dbg('mon-in-if', in_if=in_if, src=src_ip, dst=dst_ip)
                if in_if:
                    cap = self._mc_capture_name()
                    if src_ip and dst_ip:
                        match_expr = f"match ip host {src_ip} host {dst_ip}"
                    elif src_ip:
                        match_expr = f"match ip host {src_ip} any"
                    else:
                        match_expr = f"match ip any host {dst_ip}"
                    if not self._cap_exists(cap):
                        try:
                            _ = self._send(f"capture {cap} interface {in_if} {match_expr}", timeout=10)
                            self._log('info', f"MON: started capture {cap} on {in_if} ({match_expr})")
                        except Exception as e:
                            self._dbg('mon-capture-create-failed', err=str(e))
                            raise
                    attempts = 0
                    while attempts < 2:
                        raw = self._send(f"show capture {cap}", timeout=timeout)
                        low = (raw or "").lower()
                        if any(p in low for p in _CAP_ERR_PATTERNS):
                            time.sleep(0.3)
                            attempts += 1
                            continue
                        self._mc_schedule_auto_stop(ttl_seconds=20)
                        verdict = self._analyze_capture_flows(raw or "")
                        summary = f"[ASA] Capture snapshot (IP filter) on interface '{in_if}'; showing most recent buffer.\nVerdict: {verdict}"
                        return {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "summary": summary, "raw": raw or ""}
                    self._dbg('mon-capture-show-missing')
        except Exception as e:
            self._dbg('mon-capture-branch-error', err=str(e))

        try:
            raw = self.show_sessions(src_ip=src_ip, dst_ip=dst_ip, app=app, limit=limit, timeout=timeout)
            summary = self.summarize_sessions(raw, top_n=10)
            return {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "summary": summary, "raw": raw}
        except Exception as e:
            self._dbg('mon-show-sessions-error', err=str(e))
            return {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "summary": "[ASA] Monitor error; no data available.",
                    "raw": ""}

    # ----------------------------- Neutral capture aliases -----------------------------
    def start_capture(self, src_ip: Optional[str] = None, dst_ip: Optional[str] = None, proto: str = "tcp",
                      src_port: int = 12345, dst_port: Optional[int] = None, stages: Optional[List[str]] = None) -> str:
        if dst_port is None:
            raise ValueError("dst_port is required for ASA start_capture")
        _name, _cmd, cli_out = self.start_monitor_capture(proto, src_ip or "0.0.0.0", dst_ip or "0.0.0.0", int(dst_port))
        return cli_out

    def stop_capture(self) -> str:
        return self.stop_monitor_capture(self._monitor_capture_name())

    def clear_capture_filters(self) -> str:
        return "ASA: no separate capture filter state to clear."

    # ----------------------------- Robust Packet Tracer -----------------------------
    def packet_tracer(
        self,
        in_if: Optional[str],
        protocol: str,
        src_ip: str,
        src_port: int,
        dst_ip: str,
        dst_port: int,
        timeout: int = 120,
        delay_factor: int = 2
    ) -> str:
        try:
            if not getattr(self, "conn", None):
                return "[ERROR] ASA connection not attached."
            proto = (protocol or "").strip().lower()
            if proto not in ("tcp", "udp"):
                proto = "tcp"
            if not in_if:
                try:
                    in_if = self.detect_best_interface(src_ip)
                except Exception as e:
                    self._dbg('pt-detect-best-if-failed', err=str(e))
                    in_if = None
            if not in_if:
                try:
                    in_if = self._default_route_interface()
                except Exception as e:
                    self._dbg('pt-default-if-failed', err=str(e))
                    in_if = None
            if not in_if:
                return "[ERROR] Input interface undetermined; run 'Detect Interface' first or check IPs."
            try:
                sport = int(src_port)
            except Exception:
                sport = 12345
            try:
                dport = int(dst_port)
            except Exception:
                return "[ERROR] Destination port invalid; please provide a valid port."
            norm_src = self._pick_representative_ip(src_ip) or src_ip
            norm_dst = self._pick_representative_ip(dst_ip) or dst_ip
            cmd = f"packet-tracer input {in_if} {proto} {norm_src} {sport} {norm_dst} {dport}"
            self._dbg('packet-tracer-cmd', cmd=cmd)

            try:
                self.conn.send_command("terminal pager 0", read_timeout=10)  # type: ignore
            except Exception:
                pass

            out = ""
            try:
                out = self.conn.send_command_timing(cmd, read_timeout=timeout, delay_factor=delay_factor)  # type: ignore
                if not out or out.strip() == "":
                    out = self.conn.send_command(cmd, read_timeout=timeout)  # type: ignore
            except Exception as e1:
                self._dbg('pt-primary-call-failed', err=str(e1))
                try:
                    out = self.conn.send_command(cmd, read_timeout=timeout)  # type: ignore
                except Exception as e2:
                    return f"[ERROR] packet-tracer failed: {e2}\n[CMD] {cmd}"

            self._dbg('packet-tracer-recv', bytes=len(out or ""), head=(out or "")[:200])
            return out or "[WARN] packet-tracer returned empty output.\n[CMD] " + cmd
        except Exception as e:
            return f"[ERROR] packet-tracer internal error: {e}"

    # -------------------- Context helpers (prefer 'show context' starred row) --------------------
    def _current_context_via_show_context(self) -> Optional[str]:
        """Prefer starred row from 'show context' as the current/original context."""
        try:
            out = self._send("show context", timeout=10)
        except Exception:
            return None
        for line in out.splitlines():
            s = line.strip()
            if s.startswith('*'):
                # e.g., '*admin default ...'
                return s.split()[0].lstrip('*')
        return None

    def _get_current_context_hint(self):
        """Infer current context; prefer starred 'show context' row; fallback to last_context; avoid prompt suffix tokens."""
        star = self._current_context_via_show_context()
        if star:
            self._dbg('ctx-hint-star', ctx=star)
            if star != "system":
                setattr(self, "_last_context", star)
            return star
        # Do NOT parse prompt tokens like '/sec/act#' into context names
        last = getattr(self, "_last_context", None)
        self._dbg('ctx-hint-fallback', last_ctx=last)
        return last

    def _changeto_system(self):
        self._dbg('changeto-system')
        try:
            self._send("changeto system", timeout=10)
            return True
        except Exception as e:
            self._dbg('changeto-system-failed', err=str(e))
            return False

    def _changeto_context(self, name: str):
        if not name:
            return False
        self._dbg('changeto-context', name=name)
        try:
            self._send(f"changeto context {name}", timeout=10)
            return True
        except Exception as e:
            self._dbg('changeto-context-failed', name=name, err=str(e))
            return False

    # ---------- Scoped context guard to ensure we return ----------
    class _ContextGuard:
        def __init__(self, adapter: "AsaAdapter", target: str):
            self.adapter = adapter
            self.target = (target or "").strip()
            self.orig = None
            self.switched = False
        def __enter__(self):
            self.orig = self.adapter._get_current_context_hint()
            try:
                if self.target.lower() == "system":
                    if self.orig != "system":
                        self.switched = self.adapter._changeto_system()
                elif self.target.lower().startswith("context "):
                    name = self.target.split(" ", 1)[1]
                    if (self.orig or "").lower() != name.lower():
                        self.switched = self.adapter._changeto_context(name)
            except Exception as e:
                self.adapter._dbg('ctx-guard-enter-ex', err=str(e))
                self.switched = False
            self.adapter._dbg('ctx-guard-enter', target=self.target, orig=self.orig, switched=self.switched)
            return self
        def __exit__(self, exc_type, exc, tb):
            try:
                if self.switched and self.orig:
                    if self.orig == "system":
                        self.adapter._changeto_system()
                    else:
                        self.adapter._changeto_context(self.orig)
            except Exception as e:
                self.adapter._dbg('ctx-guard-exit-restore-failed', err=str(e), orig=self.orig)
                try:
                    last = getattr(self.adapter, "_last_context", None)
                    if last and last != "system":
                        self.adapter._changeto_context(last)
                except Exception:
                    pass
            self.adapter._dbg('ctx-guard-exit', target=self.target, orig=self.orig, switched=self.switched)
            return False

    def _ctx_guard(self, target: str):
        return AsaAdapter._ContextGuard(self, target)

    def _list_contexts(self) -> List[str]:
        """
        Parse 'show context' table: the first column is context name,
        but only accept rows where the second column equals a known Class ('default', 'VPN').
        Reject wrapped interface/continuation lines like 'Ethernet...'.
        """
        try:
            out = self._send("show context", timeout=15)
        except Exception:
            return []
        ctxs: List[str] = []
        for line in (out or "").splitlines():
            s = line.strip()
            if not s or s.lower().startswith('context name class'):
                continue
            parts = s.split()
            if len(parts) < 2:
                continue
            name, cls = parts[0].lstrip('*'), parts[1].lower()
            if name.lower().startswith('ethernet') or '/' in name or name.lower() in {'total'}:
                continue
            if cls not in {'default', 'vpn'}:
                continue
            ctxs.append(name)
        seen = set(); uniq: List[str] = []
        for c in ctxs:
            if c not in seen:
                uniq.append(c); seen.add(c)
        self._dbg('list-contexts-table', count=len(uniq), ctxs=uniq[:10])
        return uniq

    # -------------------- Failover group helpers --------------------
    def _extract_group_roles_from_state(self, text: str) -> Dict[str, Dict[str, str]]:
        """
        Parse 'show failover state' into:
        { 'this': { '1': 'Active'|'Standby ...', ... }, 'other': { '1': 'Standby ...', ... } }
        """
        groups = {'this': {}, 'other': {}}
        side = None
        for line in (text or '').splitlines():
            s = line.strip()
            if not s:
                continue
            if s.lower().startswith('this host'):
                side = 'this'; continue
            if s.lower().startswith('other host'):
                side = 'other'; continue
            # e.g., "Group 1 Active None", "Group 2 Standby Ready Ifc Failure ..."
            m = re.match(r'^Group\s+(\d+)\s+([A-Za-z][A-Za-z ]+?)(?:\s+(None|Ifc Failure|No Link|.*))?$', s, flags=re.IGNORECASE)
            if side and m:
                gid = m.group(1)
                role = m.group(2).strip()          # full words (e.g., "Active", "Standby Ready")
                groups[side][gid] = role
        self._dbg('extract-groups', parsed=groups)
        return groups

    def _list_group_ids_from_state(self, text: str) -> List[int]:
        """Extract group IDs present in 'show failover state' output."""
        ids = sorted({int(m.group(1)) for m in re.finditer(r'Group\s+(\d+)\b', text or '', flags=re.IGNORECASE)})
        self._dbg('groups-from-state', ids=ids)
        return ids

    def parse_failover_group_role(self, show_failover_group_text: str) -> Tuple[str, str]:
        """
        Parse 'show failover group <id>' to determine ACTIVE/STANDBY/DISABLED for this unit.
        Matches 'State: Active' / 'State: Standby ...' under 'This host'.
        """
        txt = (show_failover_group_text or "").strip()
        low = txt.lower()
        if "failover disabled" in low or "failover off" in low:
            self._dbg('parse-group-role', result='disabled')
            return ("disabled", "Failover disabled; standalone")

        # Prefer "This host" section, but match any "State:" line
        m_state = re.search(r'(?mi)^\s*State\s*:\s*([A-Za-z][A-Za-z ]+)\s*$', txt)
        if m_state:
            state = m_state.group(1).strip().lower()
            if "active" in state:
                self._dbg('parse-group-role', result='active')
                return ("active", f"Group page: State={m_state.group(1)}")
            if any(k in state for k in ("standby", "ready", "cold", "failed")):
                self._dbg('parse-group-role', result='standby')
                return ("standby", f"Group page: State={m_state.group(1)}")

        self._dbg('parse-group-role', result='unknown', head=txt[:160])
        return ("unknown", "Failover group role unknown")

    def _probe_groups(self, base_text: str) -> Optional[Tuple[str, str]]:
        """
        From system context, iterate 'show failover group <id>' for all IDs found,
        return ('active'|'standby'|'disabled', why) if any group yields a clear role.
        """
        ids = self._list_group_ids_from_state(base_text)
        for gid in ids:
            try:
                grp = self._send(f"show failover group {gid}", timeout=15)
                role, why = self.parse_failover_group_role(grp)
                self._dbg('probe-group', gid=gid, role=role, why=why, head=grp[:120])
                if role in ("active", "standby", "disabled"):
                    return (role, f"group {gid}: {why}")
            except Exception as e:
                self._dbg('probe-group-ex', gid=gid, err=str(e))
                continue
        return None

    def parse_failover_role(self, show_failover_text: str):
        """
        Tolerant parsing for 'show failover state':
          - 'Failover Off/Disabled' -> DISABLED
          - Canonical 'This host|unit: Primary|Secondary - STATE' (some ASA variants)
          - Derive role from per-group lines under 'This host' (your ASA format)
        """
        txt = (show_failover_text or "").strip()
        low = txt.lower()
        if "failover off" in low or "failover disabled" in low:
            self._dbg('parse-role', path='disabled')
            return ("disabled", "Failover disabled; standalone")

        # Canonical single-line header (some ASA variants)
        m = re.search(r"(?mi)^\s*This\s+(host|unit)\s*:\s*(Primary|Secondary)\s*-\s*([A-Za-z ]+?)\s*$", show_failover_text)
        if m:
            state = (m.group(3) or "").strip().lower()
            if "active" in state:
                self._dbg('parse-role', path='canonical', state='active')
                return ("active", f"This {m.group(1)} is {m.group(2)} - {m.group(3)}")
            if any(k in state for k in ("standby", "ready", "cold", "failed")):
                self._dbg('parse-role', path='canonical', state='standby-ish')
                return ("standby", f"This {m.group(1)} is {m.group(2)} - {m.group(3)}")

        # Group-derived decision (your ASA format)
        groups = self._extract_group_roles_from_state(txt)
        this_roles = " | ".join(groups.get('this', {}).values()).lower()
        other_roles = " | ".join(groups.get('other', {}).values()).lower()
        self._dbg('parse-role-groups', this=this_roles, other=other_roles, groups=groups)

        if "active" in this_roles:
            return ("active", "Group roles: this unit has Active group(s)")
        if any(k in this_roles for k in ("standby", "ready", "cold", "failed")):
            return ("standby", "Group roles: this unit shows only Standby/Ready/Cold")
        if "active" in other_roles:
            return ("standby", "Group roles: other unit shows Active")

        return ("unknown", "Unknown failover state (no clear group role)")

    def _map_failover(self, role: str) -> Tuple[str, str]:
        r = (role or "").strip().lower()
        if r == "active":   return ("Failover: ACTIVE", "green")
        if r == "standby":  return ("Failover: STANDBY", "red")
        if r == "disabled": return ("Failover: DISABLED", "red")
        return ("Failover state UNKNOWN - select ACTIVE firewall", "red")

    def _try_changeto(self, target: str) -> bool:
        if not target:
            return False
        t = target.strip().lower()
        self._dbg('try-changeto', target=t)
        try:
            if t == "system" or t == "context system":
                ok = bool(self._changeto_system())
                self._dbg('try-changeto-result', target=t, ok=ok)
                return ok
            if t.startswith("context "):
                name = target.split(" ", 1)[1]
                ok = bool(self._changeto_context(name))
                self._dbg('try-changeto-result', target=t, ok=ok)
                return ok
        except Exception as e:
            self._dbg('try-changeto-ex', err=str(e))
            return False
        return False

    def _try_failover_in_context(self, ctx: str) -> Tuple[str, str]:
        if not ctx:
            return ("unknown", "")
        with self._ctx_guard(f"context {ctx}"):
            try:
                out = self._send("show failover state", timeout=15)
                role, why = self.parse_failover_role(out)
                self._dbg('ctx-failover-check', ctx=ctx, role=role, why=why, raw_head=out[:120])
                return (role, why or out)
            except Exception as e:
                self._dbg('ctx-failover-check-ex', ctx=ctx, err=str(e))
                return ("unknown", "")

    # ----------------------------- Failover Status -----------------------------
    def check_status(self) -> tuple[str, str]:
        """
        Multi-context safe failover state detection:
        - Try current context (show failover state)
        - Scoped switch to system context
        - Enumerate contexts from system and probe each
        Always restore the original context.
        Returns (text, color)
        """
        try:
            try:
                pre = self.conn.find_prompt()
            except Exception:
                pre = "<unknown>"
            self._dbg('check-status-pre', prompt=pre, ctx=self._get_current_context_hint())

            # 1) Current context (may error on multi-context ASA)
            try:
                out = self._send("show failover state", timeout=15)
                self._dbg('check-current-raw', bytes=len(out), head=out[:160])
                role, why = self.parse_failover_role(out)
                self._dbg('check-current-parse', role=role, why=why)
                if role in ("active", "standby", "disabled"):
                    text, color = self._map_failover(role)
                    self._dbg('check-current-result', text=text, color=color)
                    return text, color
            except Exception as e:
                self._dbg('check-current-ex', err=str(e))

            # 2) Scoped SYSTEM (guard returns to original)
            with self._ctx_guard("system"):
                try:
                    out = self._send("show failover state", timeout=15)
                    self._dbg('check-system-raw', bytes=len(out), head=out[:160])
                    role, why = self.parse_failover_role(out)
                    self._dbg('check-system-parse', role=role, why=why)
                    if role in ("active", "standby", "disabled"):
                        res = self._map_failover(role)
                        self._dbg('check-system-result', text=res[0], color=res[1])
                        return res
                    # Fallback: probe groups with indexes
                    grp_res = self._probe_groups(out)
                    if grp_res:
                        grole, gwhy = grp_res
                        self._dbg('check-system-group', role=grole, why=gwhy)
                        if grole in ("active", "standby", "disabled"):
                            return self._map_failover(grole)
                except Exception as e:
                    self._dbg('check-system-ex', err=str(e))

                # 3) Enumerate contexts (guarded; returns to SYSTEM)
                ctxs = self._list_contexts()
                for ctx in ctxs:
                    with self._ctx_guard(f"context {ctx}"):
                        try:
                            out = self._send("show failover state", timeout=15)
                            role, why = self.parse_failover_role(out)
                            self._dbg('check-ctx-parse', ctx=ctx, role=role, why=why, raw_head=out[:120])
                            if role in ("active", "standby", "disabled"):
                                return self._map_failover(role)
                            grp_res = self._probe_groups(out)
                            if grp_res:
                                grole, gwhy = grp_res
                                self._dbg('check-ctx-group', ctx=ctx, role=grole, why=gwhy)
                                if grole in ("active", "standby", "disabled"):
                                    return self._map_failover(grole)
                        except Exception as e:
                            self._dbg('check-ctx-ex', ctx=ctx, err=str(e))
                            continue

            try:
                post = self.conn.find_prompt()
            except Exception:
                post = "<unknown>"
            self._dbg('check-status-post', prompt=post, ctx=self._get_current_context_hint())

        except Exception as e:
            self._dbg('check-status-top-ex', err=str(e))
        return ("Failover state UNKNOWN - select ACTIVE firewall", "red")

    def __del__(self):
        try:
            self._mc_cancel_timer()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Offline self-test harness (Mock ASA connection)
# ---------------------------------------------------------------------------
class _MockConn:
    """Minimal mock class simulating a Netmiko-like connection for offline ASA adapter testing."""
    def __init__(self):
        self.buffers: Dict[str, str] = {}
        self.cap_exists = False

    def send_command(self, cmd: str, expect_string: str | None = None, read_timeout: int | None = None):
        return self._handle(cmd)

    def send_command_timing(self, cmd: str, read_timeout: int | None = None, delay_factor: int | None = None):
        return self._handle(cmd)

    def find_prompt(self):
        # Simulate context prompt (non-system by default)
        return "FRA-OSS-MX-FW/fw-oss-mplsmgmt/sec/act#"

    def _handle(self, cmd: str) -> str:
        cmd = cmd.strip()
        if cmd == "terminal pager 0":
            return ""
        if cmd.startswith("show run interface"):
            return (
                "interface GigabitEthernet0/0\n"
                " nameif outside\n"
                " ip address 203.0.113.2 255.255.255.0\n"
                "!\n"
                "interface GigabitEthernet0/1\n"
                " nameif inside\n"
                " ip address 10.10.10.1 255.255.255.0\n"
                "!\n"
            )
        if cmd.startswith("show interface ip brief"):
            return (
                "Interface IP-Address OK? Method Status\n"
                "inside 10.10.10.1 255.255.255.0 YES manual up\n"
                "outside 203.0.113.2 255.255.255.0 YES manual up\n"
            )
        if cmd.startswith("show route 0.0.0.0"):
            return (
                "Gateway of last resort is 203.0.113.1 to network 0.0.0.0\n"
                "S* 0.0.0.0 0.0.0.0 [1/0] via 203.0.113.1, outside\n"
            )
        if cmd.startswith("show route "):
            ip = cmd.split()[2]
            if ip.startswith("10.10.10."):
                return "C 10.10.10.0 255.255.255.0 is directly connected, inside\n"
            return f"S {ip} 255.255.255.255 [1/0] via 203.0.113.1, outside\n"
        if cmd.startswith("no capture "):
            name = cmd.split()[2]
            self.buffers.pop(name, None)
            self.cap_exists = False
            return f"Capture {name} removed\n"
        if cmd.startswith("capture "):
            parts = cmd.split()
            name = parts[1] if len(parts) > 1 else "cap_nowtime"
            self.cap_exists = True
            self.buffers[name] = (
                "10:00:00.001 tcp 10.10.10.5:12345 -> 172.16.1.20:443 S\n"
                "10:00:00.003 tcp 172.16.1.20:443 -> 10.10.10.5:12345 S+ACK\n"
                "10:00:00.005 tcp 10.10.10.5:12345 -> 172.16.1.20:443 ack\n"
            )
            return f"Capture {name} created\n"
        if cmd.startswith("show capture "):
            name = cmd.split()[2]
            if not self.cap_exists or name not in self.buffers:
                return "ERROR: Capture <cap_nowtime> does not exist\n"
            return self.buffers[name]
        if cmd.startswith("show conn"):
            return (
                "TCP outside 203.0.113.2:443 inside 10.10.10.5:54321, idle 0:00:21, bytes 100531, flags UIO\n"
                "UDP outside 203.0.113.2:53 inside 10.10.10.5:53000, idle 0:01:38, bytes 616, flags -\n"
                "TCP inside 10.10.10.5:12345 outside 172.16.1.20:443, idle 0:00:05, bytes 178, flags UIO\n"
            )
        if cmd.startswith("packet-tracer "):
            return (
                "Phase: 1\nType: ACCESS-LIST\nResult: ALLOW\n"
                "Phase: 2\nType: ROUTE-LOOKUP\nResult: ALLOW\n"
                "Phase: 3\nType: NAT-LOOKUP\nResult: ALLOW\n"
            )
        if cmd.startswith("show failover group 1"):
            return (
                "Last Failover at: 02:42:06 BST Oct 25 2025\n\n"
                " This host: Secondary\n"
                " State: Active\n"
                " Active time: 6628247 (sec)\n"
            )
        if cmd.startswith("show failover group 2"):
            return (
                "Last Failover at: 02:42:07 BST Oct 25 2025\n\n"
                " This host: Secondary\n"
                " State: Active\n"
                " Active time: 6628246 (sec)\n"
            )
        if cmd.startswith("show failover state") or cmd.startswith("show failover"):
            return (
                "State Last Failure Reason Date/Time\n"
                "This host - Secondary\n"
                " Group 1 Active None\n"
                " Group 2 Active None\n"
                "Other host - Primary\n"
                " Group 1 Standby Ready Ifc Failure 13:33:10 GMT Jan 8 2026\n"
                " fw-oss-infovista OSS-DMZ-INS: No Link\n"
                " fw-oss-internal OSS-EXCHANGE-INS: No Link\n"
                " fw-oss-mspmgmt OSS-DMZ-INS: No Link\n"
                " fw-oss-voice-ims OSS-DMZ-INS: No Link\n"
                " fw-oss-novitasext OSS-DMZ-INS: No Link\n"
                " Group 2 Standby Ready Ifc Failure 13:33:10 GMT Jan 8 2026\n"
                " fw-oss-ext1 OSS-DMZ-INS: No Link\n"
                " fw-oss-dcn OSS-DMZ-INS: No Link\n"
                " fw-oss-mplsmgmt OSS-DMZ-INS: No Link\n"
                " fw-oss-interconnect OSS-DMZ-INS: No Link\n"
                " fw-oss-new-mplsmgmt OSS-DMZ-INS: No Link\n"
                " fw-oss-overture OSS-DMZ-INS: No Link\n"
                " fw-oss-prod-internal OSS-DMZ-INS: No Link\n"
                " fw-oss-advamgmt OSS-DMZ-INS: No Link\n"
                "====Configuration State===\n"
                " Sync Done - STANDBY\n"
                "====Communication State===\n"
                " Mac set\n"
            )
        if cmd.startswith("show context"):
            return (
                "Context Name Class Interfaces Mode URL\n"
                " fw-oss-cus-soc default Ethernet1/3.878, Routed disk0:/fw-oss-cus-soc.cfg\n"
                " Ethernet1/6.879\n"
                " fw-oss-ext1 VPN Ethernet1/3.674-675, Routed disk0:/fw-oss-ext1.cfg\n"
                " Ethernet1/6.545,\n"
                " Ethernet1/7\n"
                " fw-oss-dcn default Ethernet1/3.673, Routed disk0:/fw-oss-dcn.cfg\n"
                " Ethernet1/6.546,\n"
                " Ethernet1/7\n"
                " fw-oss-mplsmgmt default Ethernet1/3.669, Routed disk0:/fw-oss-mplsmgmt.cfg\n"
                " Ethernet1/6.557,\n"
                " Ethernet1/7\n"
                " fw-oss-interconnect default Ethernet1/3.672, Routed disk0:/fw-oss-interconnect.cfg\n"
                " Ethernet1/6.573,\n"
                " Ethernet1/7\n"
                " fw-oss-new-mplsmgmt default Ethernet1/3.670, Routed disk0:/fw-oss-new-mplsmgmt.cfg\n"
                " Ethernet1/6.572,\n"
                " Ethernet1/7\n"
                " fw-oss-overture default Ethernet1/3.665-666, Routed disk0:/fw-oss-overture.cfg\n"
                " 668,Ethernet1/6.559,\n"
                " Ethernet1/7\n"
                " fw-oss-infovista default Ethernet1/3.612, Routed disk0:/fw-oss-infovista.cfg\n"
                " Ethernet1/6.550,\n"
                " Ethernet1/7\n"
                " fw-oss-luc default Ethernet1/1, Routed disk0:/fw-oss-luc.cfg\n"
                " Ethernet1/6.592,\n"
                " Ethernet1/7\n"
                " fw-oss-internal default Ethernet1/4.186, Routed disk0:/fw-oss-internal.cfg\n"
                " Ethernet1/6.131,\n"
                " Ethernet1/7\n"
                " fw-oss-dmz default Ethernet1/4.171, Routed disk0:/fw-oss-dmz.cfg\n"
                " Ethernet1/5.132,\n"
                " Ethernet1/7\n"
                " fw-oss-moss default Ethernet1/3.507-508, Routed disk0:/fw-oss-moss.cfg\n"
                " 660,Ethernet1/6.596,\n"
                " Ethernet1/7\n"
                "*admin default Ethernet1/7 Routed disk0:/admin.cfg\n"
                " fw-oss-mspmgmt default Ethernet1/3.636,639, Routed disk0:/fw-oss-mspmgmt.cfg\n"
                " 663,Ethernet1/6.562,\n"
                " Ethernet1/7\n"
                " fw-oss-prod-internal default Ethernet1/3.661, Routed disk0:/fw-oss-prod-internal.cfg\n"
                " Ethernet1/6.567,\n"
                " Ethernet1/7\n"
                " fw-oss-voice-ims default Ethernet1/3.662, Routed disk0:/fw-oss-voice-ims.cfg\n"
                " Ethernet1/6.556,\n"
                " Ethernet1/7\n"
                " fw-oss-novitasext default Ethernet1/3.664,671, Routed disk0:/fw-oss-novitasext.cfg\n"
                " Ethernet1/6.576,\n"
                " Ethernet1/7\n"
                " fw-oss-advamgmt default Ethernet1/3.667, Routed disk0:/fw-oss-advamgmt.cfg\n"
                " Ethernet1/6.561,\n"
                " Ethernet1/7\n"
                "Total active Security Contexts: 18\n"
            )
        if cmd.startswith("changeto system"):
            return ""
        if cmd.startswith("changeto context "):
            return ""
        return ""

# ---------------------------------------------------------------------------
# Simple CLI self-test
# ---------------------------------------------------------------------------
def _selftest() -> int:
    print("[SELFTEST] Starting ASA adapter self-test...")
    asa = AsaAdapter(debug=True)
    asa.conn = _MockConn()
    ifaces = asa.list_interfaces()
    assert 'inside' in ifaces and 'outside' in ifaces, f"Unexpected interfaces: {ifaces}"
    src_if = asa.detect_best_interface('10.10.10.5')
    dst_if = asa.route_out_interface('172.16.1.20')
    print(f"Detected src_if={src_if}, dst_if={dst_if}")
    assert src_if == 'inside', src_if
    assert dst_if == 'outside', dst_if
    snap = asa.monitor_snapshot(src_ip='10.10.10.5', dst_ip='172.16.1.20')
    assert isinstance(snap, dict) and 'summary' in snap and 'raw' in snap
    print("Snapshot summary:\n", snap['summary'])
    out = asa.start_capture(src_ip='10.10.10.5', dst_ip='172.16.1.20', proto='tcp', src_port=12345, dst_port=443)
    assert 'created' in out.lower()
    stop_out = asa.stop_capture()
    assert 'removed' in stop_out.lower()
    pt = asa.packet_tracer(in_if=None, protocol='tcp', src_ip='10.10.10.5', src_port=12345,
                           dst_ip='172.16.1.20', dst_port=443)
    assert 'Phase:' in pt or '[ERROR]' not in pt
    status, color = asa.check_status()
    print("CHECK_STATUS:", status, color)
    assert color in {"green", "red"}
    print("[SELFTEST] All checks passed.")
    return 0

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        raise SystemExit(_selftest())
    else:
        print("AsaAdapter module. Run with --selftest to execute offline tests.")
