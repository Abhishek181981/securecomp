"""Normalize collector outputs into structured JSON for Network Flow (Level-1).

Reads:
  <reports_base>/latest/ips.csv
  <reports_base>/latest/routes.csv
  <reports_base>/latest/acls.csv

Writes:
  <reports_base>/latest/normalized_interfaces.json
  <reports_base>/latest/normalized_routes.json
  <reports_base>/latest/normalized_policies.json
  <reports_base>/latest/normalized_meta.json

Usage:
  python normalize_latest.py --base reports
"""

import argparse
from flow_engine.loaders import load_latest, dump_normalized_json


def main():
    ap = argparse.ArgumentParser(description='Normalize collector outputs into JSON (Level-1)')
    ap.add_argument('--base', default='reports', help='Reports base directory (same as collector --base)')
    args = ap.parse_args()

    load_latest(args.base)
    out = dump_normalized_json(args.base)

    print('[OK] Wrote normalized JSON:')
    for k, v in out.items():
        print(f'  - {k}: {v}')


if __name__ == '__main__':
    main()
