import ipaddress
from typing import Dict, Any, List, Optional

from .loaders import get_data


def _best_route(routes, hostname: str, dst_ip: str):
    best = None
    best_plen = -1
    dip = ipaddress.ip_address(dst_ip)
    for r in routes:
        if r.hostname != hostname:
            continue
        try:
            net = ipaddress.ip_network(r.prefix, strict=False)
        except Exception:
            continue
        if dip in net and net.prefixlen > best_plen:
            best = r
            best_plen = net.prefixlen
    return best


def _find_start_firewall(interfaces, src_ip: str) -> Optional[str]:
    sip = ipaddress.ip_address(src_ip)
    for it in interfaces:
        try:
            net = ipaddress.ip_network(f"{it.ip}/{it.prefixlen}", strict=False)
        except Exception:
            continue
        if sip in net:
            return it.hostname
    return None


def _fw_by_nexthop(interfaces, nh_ip: str) -> Optional[str]:
    ip = ipaddress.ip_address(nh_ip)
    for it in interfaces:
        try:
            net = ipaddress.ip_network(f"{it.ip}/{it.prefixlen}", strict=False)
        except Exception:
            continue
        if ip in net:
            return it.hostname
    return None


def _match_policy_level1(policies, hostname: str):
    # Level-1: return first known policy on last firewall
    for p in policies:
        if p.hostname == hostname:
            return {
                "hostname": hostname,
                "action": p.action or 'unknown',
                "name": p.name or '',
                "from_zone": p.from_zone,
                "to_zone": p.to_zone,
                "evidence": (p.evidence or [])[:25],
            }
    return None


def find_flow(src_ip: str, dst_ip: str, max_hops: int = 10) -> Dict[str, Any]:
    data = get_data()
    interfaces = data.get('interfaces', [])
    routes = data.get('routes', [])
    policies = data.get('policies', [])

    # validate
    ipaddress.ip_address(src_ip)
    ipaddress.ip_address(dst_ip)

    start = _find_start_firewall(interfaces, src_ip)
    if not start:
        return {"error": "Source IP does not match any firewall interface", "path": []}

    path: List[Dict[str, str]] = []
    visited = set()
    current = start

    for _ in range(max_hops):
        if current in visited:
            break
        visited.add(current)

        r = _best_route(routes, current, dst_ip)
        if not r:
            path.append({"hostname": current, "prefix": "", "nexthop": "[NO ROUTE]", "interface": ""})
            break

        path.append({"hostname": current, "prefix": r.prefix, "nexthop": r.nexthop, "interface": r.interface})

        # If next-hop is destination, stop
        if r.nexthop == dst_ip:
            break

        nxt = _fw_by_nexthop(interfaces, r.nexthop)
        if not nxt or nxt == current:
            break
        current = nxt

    last_fw = path[-1]['hostname'] if path else start
    acl = _match_policy_level1(policies, last_fw)

    return {
        "path": path,
        "firewalls_in_path": [h['hostname'] for h in path],
        "acl": acl,
        "verdict": (acl.get('action') if acl else 'unknown'),
        "meta": data.get('meta', {})
    }
