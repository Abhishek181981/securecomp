﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
remediation.py — v11.3.3-local
Local-style commits:
  SRX/Junos:  configure -> (zones-aware) deactivate -> commit -> run show system commit | last 3 -> exit
  PAN-OS:     configure -> set rule disabled yes -> commit -> exit
  ASA:        send 'no access-list ...' (no commit concept)

Hard-coded paths, robust CSV writer, and per-device session transcripts.
"""

import os
import re
import csv
import time
from typing import List, Dict

import paramiko  # SSH client

# =============================================================================
# HARD-CODED PATHS (NO ENV REQUIRED FOR INVENTORY/REPORTS)
# =============================================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Inventory (hard-coded to singular filename per your request)
# If your file is plural ("firewalls.csv"), change 'firewall.csv' to 'firewalls.csv' here:
FW_CSV_PATH = os.path.join(BASE_DIR, 'modular_collector', 'firewall.csv')

# Reports dir (hard-coded to modular_collector/reports/latest)
REPORTS_DIR = os.path.join(BASE_DIR, 'modular_collector', 'reports', 'latest')
os.makedirs(REPORTS_DIR, exist_ok=True)

QUEUE_PATH   = os.path.join(REPORTS_DIR, 'remediation_queue.csv')
DISABLE_PATH = os.path.join(REPORTS_DIR, 'disable.csv')
RUN_LOG_PATH = os.path.join(REPORTS_DIR, 'remediation_run_report.txt')

# Session logs directory
LOGS_DIR = os.path.join(REPORTS_DIR, 'logs')
os.makedirs(LOGS_DIR, exist_ok=True)

# Credentials & apply switch (GUI sets these when Dry-run is OFF)
USERNAME = os.environ.get('FW_USERNAME', '')
PASSWORD = os.environ.get('FW_PASSWORD', '')
ENABLE   = os.environ.get('FW_ENABLE', '')
APPLY    = (os.environ.get('APPLY_CHANGES', '') == '1')

# =============================================================================
# HELPERS
# =============================================================================

FIELDS: List[str] = [
    'timestamp','hostname','platform','rule_id','rule_name','acl_name',
    'raw_ace','action','status','message','command_preview'
]

def _ts() -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S')

def _write_disable(rows: List[Dict[str, str]]) -> None:
    """Write disable.csv with a fixed schema, ignoring any extra keys present in rows."""
    os.makedirs(os.path.dirname(DISABLE_PATH), exist_ok=True)
    with open(DISABLE_PATH, 'w', encoding='utf-8', newline='') as out:
        dw = csv.DictWriter(out, fieldnames=FIELDS, extrasaction='ignore')
        dw.writeheader()
        for r in rows:
            safe = {k: (r.get(k, '') or '') for k in FIELDS}
            dw.writerow(safe)

def _append_runlog_footer() -> None:
    try:
        with open(RUN_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write('\n[Done] remediation.py completed.\n')
    except Exception:
        pass

def _log_header(fw_csv: str) -> None:
    """Write a diagnostic header into RUN_LOG_PATH showing paths in use."""
    try:
        with open(RUN_LOG_PATH, 'w', encoding='utf-8') as f:
            used = fw_csv if os.path.isfile(fw_csv) else '(not found)'
            f.write('Used firewalls.csv: ' + used + '\n')
            f.write('Queue: ' + QUEUE_PATH + '\n')
            f.write('Output: ' + DISABLE_PATH + '\n')
            f.write('ReportsDir: ' + REPORTS_DIR + '\n')
            f.write('ApplyChanges: ' + ('1' if APPLY else '0') + '\n')
            f.write('SessionLogsDir: ' + LOGS_DIR + '\n')

            # Directory listing to expose typos/placement
            mc_dir = os.path.join(BASE_DIR, 'modular_collector')
            f.write('\n[Dir] ' + mc_dir + ' listing:\n')
            try:
                if os.path.isdir(mc_dir):
                    for name in sorted(os.listdir(mc_dir)):
                        f.write('  - ' + name + '\n')
                else:
                    f.write('  (modular_collector not found)\n')
            except Exception as e:
                f.write('  (listing failed: ' + str(e) + ')\n')
    except Exception:
        pass

# ---------------- SRX full-path deactivate (zones-aware) ----------------

def _srx_deactivate_cmd(rule_id: str, raw_ace: str) -> str:
    """
    If raw_ace contains 'from-zone <FZ> to-zone <TZ>', build a full-path deactivate:
      deactivate security policies from-zone <FZ> to-zone <TZ> policy <rule_id>
    Otherwise, fall back to the short form:
      deactivate security policies policy <rule_id>
    """
    if raw_ace:
        # allow optional quotes around zone names (no spaces assumed in zone names)
        m = re.search(
            r'from-zone\s+("?)([^"\s]+)\1\s+to-zone\s+("?)([^"\s]+)\3',
            raw_ace, re.IGNORECASE
        )
        if m:
            fz, tz = m.group(2), m.group(4)
            return f'deactivate security policies from-zone {fz} to-zone {tz} policy {rule_id}'
    return f'deactivate security policies policy {rule_id}'

# ---------------- Session logging & CLI helpers ----------------

def _safe_name(s: str) -> str:
    s = (s or '').strip()
    return ''.join(c if c.isalnum() or c in ('-', '_', '.') else '_' for c in s) or 'device'

def _open_log(hostname: str):
    """Open a per-device session log file and return (file_handle, path)."""
    log_name = f"{_safe_name(hostname)}_{int(time.time())}.log"
    path = os.path.join(LOGS_DIR, log_name)
    fh = open(path, 'w', encoding='utf-8')
    return fh, path

def _log_write(fh, text: str):
    try:
        fh.write(text)
    except Exception:
        pass

def _drain(chan, fh, wait: float = 0.2):
    time.sleep(wait)
    out = b""
    while chan.recv_ready():
        out += chan.recv(65535)
        time.sleep(0.05)
    if out:
        _log_write(fh, out.decode(errors="ignore"))
    return out

def _send(chan, fh, line: str, wait: float = 0.8):
    """Send a line to the device, log the command and the output."""
    _log_write(fh, f"\n$ {line}\n")
    chan.send(line + '\n')
    _drain(chan, fh, wait)

def _prep_cli(platform: str, chan, fh):
    """
    Normalize terminal to avoid pagination; keep SRX prep minimal & widely accepted.
    We do NOT send 'set cli scripting-mode on' because some platforms reject it.
    """
    p = (platform or '').lower()
    # Flush one newline to get a clean prompt
    chan.send('\n'); _drain(chan, fh, 0.5)
    if ('srx' in p) or ('junos' in p):
        _send(chan, fh, 'cli', 0.6)
        _send(chan, fh, 'set cli screen-length 0', 0.5)
        _send(chan, fh, 'set cli screen-width 0', 0.5)
    elif 'palo' in p:
        _send(chan, fh, 'set cli pager off', 0.5)

# =============================================================================
# MAIN
# =============================================================================

def main() -> int:
    # Header: shows exactly which paths we are using
    _log_header(FW_CSV_PATH)

    # 1) Load queue (soft handling)
    queue_rows: List[Dict[str, str]] = []
    if os.path.isfile(QUEUE_PATH):
        try:
            with open(QUEUE_PATH, 'r', encoding='utf-8') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    queue_rows.append(r)
        except Exception as e:
            _write_disable([{
                'timestamp': _ts(), 'hostname': '', 'platform': '',
                'rule_id': '', 'rule_name': '', 'acl_name': '', 'raw_ace': '',
                'action': 'disable', 'status': 'ERROR',
                'message': 'remediation_queue.csv unreadable: ' + str(e),
                'command_preview': ''
            }])
            _append_runlog_footer()
            return 2
    else:
        _write_disable([{
            'timestamp': _ts(), 'hostname': '', 'platform': '',
            'rule_id': '', 'rule_name': '', 'acl_name': '', 'raw_ace': '',
            'action': 'disable', 'status': 'ERROR',
            'message': 'remediation_queue.csv not found at hard-coded REPORTS_DIR',
            'command_preview': ''
        }])
        _append_runlog_footer()
        return 2

    # 2) Load inventory (hard-coded path). If missing, soft error
    if not os.path.isfile(FW_CSV_PATH):
        out_rows: List[Dict[str, str]] = []
        for row in queue_rows:
            row = dict(row)
            row.update({
                'timestamp': _ts(), 'status': 'ERROR',
                'message': 'firewalls inventory CSV not found at hard-coded path',
                'command_preview': ''
            })
            out_rows.append(row)
        _write_disable(out_rows)
        _append_runlog_footer()
        return 2

    fw_index: Dict[str, Dict[str, str]] = {}
    try:
        with open(FW_CSV_PATH, 'r', encoding='utf-8') as f:
            dr = csv.DictReader(f)
            for r in dr:
                hn = (r.get('hostname') or '').strip().lower()
                if hn:
                    fw_index[hn] = r
    except Exception as e:
        _write_disable([{
            'timestamp': _ts(), 'hostname': '', 'platform': '',
            'rule_id': '', 'rule_name': '', 'acl_name': '',
            'raw_ace': '', 'action': 'disable', 'status': 'ERROR',
            'message': 'unable to read inventory CSV: ' + str(e),
            'command_preview': ''
        }])
        _append_runlog_footer()
        return 3

    # 3) Process each queued row
    out_rows: List[Dict[str, str]] = []
    for row in queue_rows:
        row = dict(row)  # shallow copy
        host = (row.get('hostname') or '').strip()
        ts = _ts()

        if not host:
            row.update({
                'timestamp': ts, 'status': 'ERROR',
                'message': 'hostname missing in queue row',
                'command_preview': ''
            })
            out_rows.append(row)
            continue

        dev = fw_index.get(host.lower())
        if not dev:
            row.update({
                'timestamp': ts, 'status': 'ERROR',
                'message': 'Device not found in inventory CSV',
                'command_preview': ''
            })
            out_rows.append(row)
            continue

        platform = (dev.get('platform') or '').strip().lower()
        ip = dev.get('ip') or dev.get('hostname')
        try:
            port = int(dev.get('port') or 22)
        except Exception:
            port = 22

        rule_id = (row.get('rule_id') or '').strip()

        # If rule_id is empty for SRX/Palo, fail this row early (no-op)
        if (('srx' in platform) or ('junos' in platform) or ('palo' in platform)) and not rule_id:
            row.update({
                'timestamp': ts, 'status': 'ERROR',
                'message': 'rule_id missing for SRX/Palo; cannot build disable command',
                'command_preview': ''
            })
            out_rows.append(row)
            continue

        # Build platform command (preview only; executed in APPLY block)
        if ('srx' in platform) or ('junos' in platform):
            cmd = _srx_deactivate_cmd(rule_id, row.get('raw_ace') or '')
        elif 'palo' in platform:
            cmd = f'set rulebase security rules {rule_id} disabled yes'
        elif 'asa' in platform:
            acl = row.get('acl_name') or ''
            ace = row.get('raw_ace') or ''
            cmd = f'no access-list {acl} extended {ace}'
        else:
            cmd = f'# unsupported platform: {platform}'

        row['command_preview'] = cmd

        # SSH hardened settings + Apply flow (config + commit where required)
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(
                ip, port=port, username=USERNAME, password=PASSWORD,
                allow_agent=False, look_for_keys=False,
                timeout=45, banner_timeout=30, auth_timeout=30
            )

            if APPLY:
                log_fh, log_path = _open_log(host or dev.get('hostname') or 'device')
                try:
                    chan = client.invoke_shell()
                    time.sleep(1)

                    # Prepare prompt / pager settings
                    _prep_cli(platform, chan, log_fh)

                    if ('srx' in platform) or ('junos' in platform):
                        # SRX: enter config, zones-aware deactivate, plain commit, verify, exit
                        _send(chan, log_fh, 'configure', 1.0)
                        _send(chan, log_fh, _srx_deactivate_cmd(rule_id, row.get('raw_ace') or ''), 1.2)
                        _send(chan, log_fh, 'commit', 3.5)
                        _send(chan, log_fh, 'run show system commit | last 3', 1.5)
                        _send(chan, log_fh, 'exit', 0.6)

                    elif 'palo' in platform:
                        # PAN-OS: enter config, disable rule, commit, exit
                        _send(chan, log_fh, 'configure', 1.0)
                        _send(chan, log_fh, f'set rulebase security rules {rule_id} disabled yes', 1.2)
                        _send(chan, log_fh, 'commit', 4.0)
                        time.sleep(3.0); _drain(chan, log_fh, 0.8)
                        _send(chan, log_fh, 'exit', 0.6)

                    else:
                        # ASA / others: no commit concept
                        _send(chan, log_fh, cmd, 1.2)

                finally:
                    try:
                        log_fh.close()
                    except Exception:
                        pass

            client.close()
            row.update({'timestamp': ts, 'status': 'SUCCESS', 'message': ''})
        except Exception as e:
            row.update({'timestamp': ts, 'status': 'ERROR', 'message': str(e)})

        out_rows.append(row)

    _write_disable(out_rows)
    _append_runlog_footer()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())