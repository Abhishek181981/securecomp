from dataclasses import dataclass
from typing import List, Optional, Dict, Any

@dataclass
class InterfaceEntry:
    hostname: str
    context: str
    platform: str
    iface: str
    ip: str
    prefixlen: int
    zone: Optional[str] = None

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> 'InterfaceEntry':
        return InterfaceEntry(
            hostname=d.get('hostname',''),
            context=d.get('context',''),
            platform=d.get('platform',''),
            iface=d.get('iface',''),
            ip=d.get('ip',''),
            prefixlen=int(d.get('prefixlen') or 0),
            zone=d.get('zone')
        )

@dataclass
class RouteEntry:
    hostname: str
    context: str
    platform: str
    prefix: str
    nexthop: str
    interface: str
    protocol: str = ''
    raw: str = ''

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> 'RouteEntry':
        return RouteEntry(
            hostname=d.get('hostname',''),
            context=d.get('context',''),
            platform=d.get('platform',''),
            prefix=d.get('prefix',''),
            nexthop=d.get('nexthop',''),
            interface=d.get('interface',''),
            protocol=d.get('protocol','') or '',
            raw=d.get('raw','') or ''
        )

@dataclass
class PolicyRule:
    hostname: str
    context: str
    platform: str
    name: str
    from_zone: Optional[str]
    to_zone: Optional[str]
    src: List[str]
    dst: List[str]
    apps: List[str]
    action: str  # 'permit'|'deny'|'unknown'
    evidence: List[str]

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> 'PolicyRule':
        return PolicyRule(
            hostname=d.get('hostname',''),
            context=d.get('context',''),
            platform=d.get('platform',''),
            name=d.get('name','') or '',
            from_zone=d.get('from_zone'),
            to_zone=d.get('to_zone'),
            src=list(d.get('src') or []),
            dst=list(d.get('dst') or []),
            apps=list(d.get('apps') or []),
            action=d.get('action','unknown') or 'unknown',
            evidence=list(d.get('evidence') or [])
        )
