# sanity_flow.py
import os, json, ipaddress
from pathlib import Path

print("=== MODULE LOCATIONS ===")
import flow_engine.normalize_routes as nr
import flow_engine.flow_search as fs
print("normalize_routes at:", nr.__file__)
print("flow_search at     :", fs.__file__)

print("\n=== DATA SNAPSHOT ===")
from flow_engine.loaders import get_data
d = get_data()
routes = d.get("routes", [])
interfaces = d.get("interfaces", [])
print(f"routes: {len(routes)}, interfaces: {len(interfaces)}")

# 1) Inspect a few route objects to verify their attribute names/values
def _attrs(obj, keys=("hostname","prefix","nexthop","interface","proto")):
    return {k: getattr(obj, k, None) for k in keys}

for i, r in enumerate(routes[:3], 1):
    print(f"[route {i}] type={type(r)} attrs=", _attrs(r))

# 2) Focus on your firewall
HOST = "BLR-EDGE-OUT-FW01"
C = [r for r in routes if (getattr(r,'hostname','') or '').strip().lower() == HOST.lower()]
print(f"\nRoutes for {HOST}: {len(C)}")

# 3) Look for any prefix that contains 10.91.97.14
dst = ipaddress.ip_address("10.91.97.14")
hits = []
for r in C:
    try:
        net = ipaddress.ip_network(getattr(r,'prefix') or "", strict=False)
        if dst in net:
            hits.append(_attrs(r))
    except Exception:
        pass
print("Matching route objects:", hits)

# 4) If no matches, confirm the raw normalized route line exists
latest = Path("reports") / "latest"
raw = json.loads((latest/"normalized_routes.json").read_text(encoding="utf-8"))
raw_hits = [r for r in raw if (r.get("hostname","").strip().lower() == HOST.lower()
                                and r.get("line","").startswith("10.91.97.14/32"))]
print("\nRaw JSON has SRX line?:", bool(raw_hits))
if raw_hits:
    print("SRX raw line:", raw_hits[0]["line"])