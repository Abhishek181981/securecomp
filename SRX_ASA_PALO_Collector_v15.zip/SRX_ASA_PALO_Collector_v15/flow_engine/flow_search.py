import ipaddress
from typing import Dict, Any, List, Optional

from .loaders import get_data


# --- Helpers ---

def _net_from_interface(it) -> Optional[ipaddress._BaseNetwork]:
    """
    Build an ip_network from an interface record.
    Supports attributes: ip + prefixlen (your InterfaceEntry), or cidr if present.
    """
    try:
        cidr = getattr(it, 'cidr', None)
        if cidr:
            return ipaddress.ip_network(str(cidr), strict=False)
        ip = getattr(it, 'ip', None)
        plen = getattr(it, 'prefixlen', None)
        if ip and (plen is not None):
            return ipaddress.ip_network(f"{ip}/{int(plen)}", strict=False)
    except Exception:
        return None
    return None


def _best_route(routes, hostname: str, dst_ip: str):
    """
    Choose the most-specific route on a given firewall for dst_ip.
    """
    best = None
    best_plen = -1
    dip = ipaddress.ip_address(dst_ip)
    for r in routes:
        # robust hostname compare (trim + case-insensitive)
        if ((getattr(r, 'hostname', '') or '').strip().lower()
                != (hostname or '').strip().lower()):
            continue
        try:
            net = ipaddress.ip_network(getattr(r, 'prefix'), strict=False)
        except Exception:
            continue
        if dip in net and net.prefixlen > best_plen:
            best = r
            best_plen = net.prefixlen
    return best


def _find_start_firewall(interfaces, src_ip: str) -> Optional[str]:
    """
    Return hostname of interface whose network contains src_ip.
    """
    sip = ipaddress.ip_address(src_ip)
    for it in interfaces:
        net = _net_from_interface(it)
        if not net:
            continue
        if sip in net:
            return getattr(it, 'hostname', None)
    return None


def _fw_by_nexthop(interfaces, nh_ip: str) -> Optional[str]:
    """
    Map next-hop IP to a firewall hostname by membership in interface networks.
    """
    ip = ipaddress.ip_address(nh_ip)
    for it in interfaces:
        net = _net_from_interface(it)
        if not net:
            continue
        if ip in net:
            return getattr(it, 'hostname', None)
    return None


def _match_policy_level1(policies, hostname: str):
    # Level-1: return first known policy on last firewall (simple)
    for p in policies:
        if getattr(p, 'hostname', None) == hostname:
            return {
                "hostname": hostname,
                "action": getattr(p, 'action', None) or 'unknown',
                "name": getattr(p, 'name', None) or '',
                "from_zone": getattr(p, 'from_zone', None),
                "to_zone": getattr(p, 'to_zone', None),
                "evidence": (getattr(p, 'evidence', None) or [])[:25],
            }
    return None


def _best_source_cover(routes, src_ip: str):
    """
    Choose starting firewall by most-specific route that contains src_ip.
    Scans all devices' routes; returns the matching route record or None.
    """
    sip = ipaddress.ip_address(src_ip)
    best = None
    best_plen = -1
    for r in routes:
        try:
            net = ipaddress.ip_network(getattr(r, 'prefix'), strict=False)
        except Exception:
            continue
        if sip in net and net.prefixlen > best_plen:
            best = r
            best_plen = net.prefixlen
    return best


def find_flow(src_ip: str, dst_ip: str, max_hops: int = 10) -> Dict[str, Any]:
    data = get_data()
    interfaces = data.get('interfaces', [])
    routes     = data.get('routes', [])
    policies   = data.get('policies', [])

    # validate
    ipaddress.ip_address(src_ip)
    ipaddress.ip_address(dst_ip)

    # Prefer interface membership; else route-based source fallback
    start = _find_start_firewall(interfaces, src_ip)
    if not start:
        src_cover = _best_source_cover(routes, src_ip)
        if src_cover:
            start = getattr(src_cover, 'hostname', None)
    if not start:
        return {"error": "Source IP does not match any firewall interface or route cover", "path": []}

    path: List[Dict[str, str]] = []
    visited = set()
    current = start

    for _ in range(max_hops):
        if current in visited:
            break
        visited.add(current)

        r = _best_route(routes, current, dst_ip)
        if not r:
            path.append({"hostname": current, "prefix": "", "nexthop": "[NO ROUTE]", "interface": ""})
            break

        path.append({
            "hostname": current,
            "prefix":   getattr(r, 'prefix'),
            "nexthop":  getattr(r, 'nexthop'),
            "interface":getattr(r, 'interface')
        })

        # Terminal conditions:
        #   - next-hop equals destination, OR
        #   - local/direct route without explicit next-hop, OR
        #   - protocol in ('local','direct','connected','access')
        if (getattr(r, 'nexthop') == dst_ip) \
           or (not getattr(r, 'nexthop') or not str(getattr(r, 'nexthop')).strip()) \
           or (str(getattr(r, 'protocol', '')).lower() in ('local', 'direct', 'connected', 'access')):
            break

        nxt = _fw_by_nexthop(interfaces, getattr(r, 'nexthop'))
        if not nxt or nxt == current:
            break
        current = nxt

    last_fw = path[-1]['hostname'] if path else start
    acl = _match_policy_level1(policies, last_fw)
    return {
        "path": path,
        "firewalls_in_path": [h['hostname'] for h in path],
        "acl": acl,
        "verdict": (acl.get('action') if acl else 'unknown'),
        "meta": data.get('meta', {}),
    }