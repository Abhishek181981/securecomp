# -*- coding: utf-8 -*-
#!/usr/bin/env python3
"""
Patches gui_remediate.py to:
  1) Generate PERMIT-ONLY plans (skips deny/reject/empty).
  2) Add a "View Last Plan" button + read-only JSON viewer dialog.
  3) Keep focus on Zero-hit tab after plan generation (cosmetic).

Idempotent: uses markers; safe to re-run.
Creates a backup: gui_remediate.py.bak (once).

Usage:
  python patch_gui_permit_and_view_plan_v2.py gui_remediate.py
"""
import io, os, re, sys
from shutil import copyfile

# ---- Markers (idempotency) ----
PERMIT_START = "# PERMIT_ONLY_FILTER_START"
PERMIT_END   = "# PERMIT_ONLY_FILTER_END"
VIEW_BTN_MARKER    = "# VIEW_PLAN_BTN_ADDED"
VIEW_HELPER_MARKER = "# VIEW_PLAN_HELPERS_ADDED"
STAY_ZERO_MARKER   = "# STAY_ON_ZERO_TAB_AFTER_PLAN"

# ---- Snippets to inject (plain strings; no f-strings evaluated here) ----
PERMIT_SNIPPET = """
        {PERMIT_START}
        # Keep only explicit permit/allow actions; drop deny/reject/empty
        filtered = []
        for _r in rows:
            _act = (str(_r.get('action') or '')).strip().lower()
            if _act in ('permit', 'allow'):
                filtered.append(_r)
        if not filtered:
            self._append_ctx("[REMED] No permit rules found in selection/page; skipping plan generation.\\n", ctx='logs')
            try:
                from tkinter import messagebox
                messagebox.showinfo('Remediate', 'No permit rules in the current selection/page.')
            except Exception:
                pass
            return
        rows = filtered
        {PERMIT_END}
""".replace("{PERMIT_START}", PERMIT_START).replace("{PERMIT_END}", PERMIT_END)

STAY_ZERO_SNIPPET = """
        {STAY_ZERO_MARKER}
        # Stay on Zero-hit tab after generating the plan (cosmetic)
        try:
            self.nb.select(self.tab_zero)
        except Exception:
            pass
""".replace("{STAY_ZERO_MARKER}", STAY_ZERO_MARKER)

# Use concatenation in the GUI snippet to avoid an f-string here.
VIEW_HELPERS_SNIPPET = """
    {VIEW_HELPER_MARKER}
    def _find_latest_plan_path(self):
        \"\"\"Return full path to latest remediation/<run_id>/plan.json under the same base as dashboard.csv, else ''\"\"\"
        import os
        try:
            base_dir = os.path.dirname(os.path.abspath(self.risk_path_var.get() or 'dashboard.csv')) or '.'
        except Exception:
            base_dir = '.'
        rem_root = os.path.join(base_dir, 'remediation')
        if not os.path.isdir(rem_root):
            return ''
        runs = [os.path.join(rem_root, d) for d in os.listdir(rem_root) if os.path.isdir(os.path.join(rem_root, d))]
        if not runs:
            return ''
        runs.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        for r in runs:
            plan = os.path.join(r, 'plan.json')
            if os.path.isfile(plan):
                return plan
        return ''

    def _open_plan_viewer(self):
        \"\"\"Open a read-only viewer for the latest plan.json.\"\"\"
        import json, os
        import tkinter as tk
        from tkinter import ttk, messagebox
        plan_path = self._find_latest_plan_path()
        if not plan_path:
            try: messagebox.showinfo("View Last Plan", "No plan.json found yet. Generate a plan first from Remediate…")
            except Exception: pass
            return
        try:
            with open(plan_path, 'r', encoding='utf-8') as f:
                data = f.read()
        except Exception as e:
            try: messagebox.showerror("View Last Plan", "Failed to read plan.json:\\n" + str(e))
            except Exception: pass
            return

        # Simple viewer dialog
        top = tk.Toplevel(self.root)
        top.title("Plan Viewer - " + os.path.basename(os.path.dirname(plan_path)))
        top.geometry("900x600")
        top.transient(self.root)
        frm = ttk.Frame(top, padding=8)
        frm.pack(fill='both', expand=True)
        path_lbl = ttk.Label(frm, text=plan_path, foreground='#555')
        path_lbl.pack(anchor='w', pady=(0,6))
        txt = tk.Text(frm, wrap='none')
        txt.pack(fill='both', expand=True)
        ysb = ttk.Scrollbar(frm, orient='vertical', command=txt.yview)
        xsb = ttk.Scrollbar(frm, orient='horizontal', command=txt.xview)
        txt.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        ysb.place(relx=1.0, rely=0.0, relheight=1.0, anchor='ne')
        xsb.pack(fill='x')
        try:
            obj = json.loads(data)
            from json import dumps
            data = dumps(obj, indent=2)
        except Exception:
            pass
        txt.insert('1.0', data)
        txt.configure(state='disabled')
        ttk.Button(frm, text="Close", command=top.destroy).pack(anchor='e', pady=(6,0))
""".replace("{VIEW_HELPER_MARKER}", VIEW_HELPER_MARKER)

VIEW_BUTTON_SNIPPET = """
        {VIEW_BTN_MARKER}
        ttk.Button(zc_btns, text="View Last Plan", command=self._open_plan_viewer).grid(row=0, column=6, sticky='ew')
""".replace("{VIEW_BTN_MARKER}", VIEW_BTN_MARKER)

def die(msg, code=2):
    print(msg); sys.exit(code)

def patch_file(path):
    with io.open(path, "r", encoding="utf-8") as f:
        src = f.read()

    # Backup once
    bak = path + ".bak"
    if not os.path.exists(bak):
        try:
            copyfile(path, bak)
            print(f"[patch] Backup created: {bak}")
        except Exception as e:
            print(f"[patch] WARN: could not create backup: {e}")

    # ---- 1) Permit-only filter in _generate_remediation_plan ----
    if PERMIT_START in src and PERMIT_END in src:
        print("[patch] Permit-only filter already present (skipping).")
    else:
        # Find function body bounds (robust)
        m = re.search(r"def\s+_generate_remediation_plan\s*\(\s*self\s*\)\s*:", src)
        if not m:
            die("[patch] ERROR: Could not find function _generate_remediation_plan(self).", 3)
        func_start = m.start()
        rest = src[func_start:]
        n = re.search(r"^def\s+\w+\s*\(", rest, flags=re.M)
        func_end = func_start + (n.start() if n else len(rest))
        func_body = src[func_start:func_end]

        # Prefer to insert after the call to _collect_zero_selection_rows
        anchors = [
            r"rows\s*=\s*self\._collect_zero_selection_rows\s*\(\s*\)",  # exact
            r"_collect_zero_selection_rows\s*\(",                         # more relaxed
        ]
        a = None
        for pat in anchors:
            a = re.search(pat, func_body)
            if a: break

        if a:
            insert_pos = a.end()
            # Preserve indentation where the anchor resides
            line_start = func_body.rfind("\n", 0, insert_pos) + 1
            indent = ""
            i = line_start
            while i < len(func_body) and func_body[i] in (" ", "\t"):
                indent += func_body[i]; i += 1
            snippet = "".join(indent + l + ("\n" if not l.endswith("\n") else "")
                              for l in PERMIT_SNIPPET.strip("\n").splitlines())
            func_body_new = func_body[:insert_pos] + "\n" + snippet + func_body[insert_pos:]
        else:
            # Fallback: insert at the top of the function (after the 'def' line)
            after_def = func_body.find("\n", 0) + 1
            indent = ""
            j = after_def
            while j < len(func_body) and func_body[j] in (" ", "\t"):
                indent += func_body[j]; j += 1
            snippet = "".join(indent + l + ("\n" if not l.endswith("\n") else "")
                              for l in PERMIT_SNIPPET.strip("\n").splitlines())
            func_body_new = func_body[:after_def] + snippet + func_body[after_def:]

        # Add "stay on Zero-hit tab" (only once)
        if STAY_ZERO_MARKER not in func_body_new:
            try:
                indent  # noqa
            except NameError:
                indent = " " * 8
            stay_snip = "".join(indent + l + ("\n" if not l.endswith("\n") else "")
                                for l in STAY_ZERO_SNIPPET.strip("\n").splitlines())
            func_body_new = func_body_new + "\n" + stay_snip

        src = src[:func_start] + func_body_new + src[func_end:]
        print("[patch] Added permit-only filter + stay-on-tab tweak.")

    # ---- 2) Plan viewer helpers ----
    if VIEW_HELPER_MARKER in src:
        print("[patch] Plan viewer helpers already present (skipping).")
    else:
        marker = "# ---------------- Logs & Reports TAB ----------------"
        if marker in src:
            idx = src.find(marker)
            src = src[:idx] + VIEW_HELPERS_SNIPPET + "\n" + src[idx:]
            print("[patch] Added plan viewer helpers before Logs section.")
        else:
            src = src + "\n" + VIEW_HELPERS_SNIPPET + "\n"
            print("[patch] Added plan viewer helpers at file end (fallback).")

    # ---- 3) Add "View Last Plan" button on Zero-hit toolbar ----
    if VIEW_BTN_MARKER in src:
        print("[patch] 'View Last Plan' button already present (skipping).")
    else:
        # Bump toolbar columns to >= 7
        src2 = re.sub(
            r"(for\s+c\s+in\s+range\()\s*(\d+)(\)\s*:\s*zc_btns\.columnconfigure\(\s*c\s*,\s*weight\s*=\s*1\s*\))",
            lambda m: m.group(1) + str(max(int(m.group(2)), 7)) + m.group(3),
            src
        )
        if src2 != src:
            src = src2

        # Insert after Console button if possible
        console_regex = r"(ttk\.Button\(zc_btns,\s*text=(?:'▼ Console'|\"▼ Console\"|'Console ▼'|\"Console ▼\"),\s*command=.*?\)\.grid\(row=0,\s*column=\d.*?\))"
        m = re.search(console_regex, src, flags=re.S)
        if m:
            block = m.group(1)
            src = src.replace(block, block + VIEW_BUTTON_SNIPPET)
            print("[patch] Added 'View Last Plan' after Console button.")
        else:
            export_regex = r"(ttk\.Button\(zc_btns,\s*text=(?:'Export Zero[\u2011\-]hit to Excel'|\"Export Zero[\u2011\-]hit to Excel\"),\s*command=.*?\)\.grid\(row=0,\s*column=\d.*?\))"
            m2 = re.search(export_regex, src, flags=re.S)
            if m2:
                block = m2.group(1)
                src = src.replace(block, block + VIEW_BUTTON_SNIPPET)
                print("[patch] Added 'View Last Plan' after Export button (fallback).")
            else:
                print("[patch] WARN: Could not locate Zero-hit toolbar; please add the button manually if needed.")

    with io.open(path, "w", encoding="utf-8", newline="") as f:
        f.write(src)

    print(f"[patch] Patched in-place: {path}")
    print("[patch] Next:")
    print("  1) Run the GUI:  python gui_remediate.py")
    print("  2) Zero-hit → Remediate… → Generate Plan (Dry-run)")
    print("  3) Click 'View Last Plan' to preview the latest plan.json")
    print("  4) Confirm plan.json includes only permit/allow actions.")

def main():
    if len(sys.argv) < 2:
        die("Usage: python patch_gui_permit_and_view_plan_v2.py <path-to-gui_remediate.py>")
    path = sys.argv[1]
    if not os.path.isfile(path):
        die(f"[patch] File not found: {path}")
    patch_file(path)

if __name__ == "__main__":
    main()