# apply_flow_patch.py
# Creates a full, patched copy: gui_factory_ready13_secure_patched.py
# Patches: refresh_flow_db(self), search_flow(self)

from pathlib import Path
import re
import sys

SRC = Path("gui_factory_ready13_secure.py")
DST = Path("gui_factory_ready13_secure_patched.py")

if not SRC.exists():
    print(f"[ERROR] {SRC} not found in current directory.")
    sys.exit(1)

code = SRC.read_text(encoding="utf-8")

# ---------- Patched refresh_flow_db ----------
patched_refresh = r'''
    def refresh_flow_db(self):
        # Load normalized JSON (preferred) from <reports_base>/latest/*.json
        try:
            if load_latest_json is None:
                messagebox.showwarning("Network Flow", "flow_engine package not found. Please add flow_engine folder.")
                return
            base = self.logs_base_var.get()
            try:
                self.flow_output.insert("end", f"[INFO] Loading normalized JSON from: {base}\n", "header")
                self.flow_output.see("end")
            except Exception:
                pass
            load_latest_json(base)

            # === Enhanced normalization (hostname/cidr/prefix) for Flow engine joins ===
            # These helpers are local to this method to keep scope tight.
            def _canon_host(s: str) -> str:
                """
                Canonicalize device/hostname across all normalized_* files so Flow can join.
                - lowercase
                - strip domain suffix
                - collapse spaces
                """
                s = (s or "").strip()
                if not s:
                    return s
                s = s.lower()
                if "." in s:
                    s = s.split(".", 1)[0]
                return " ".join(s.split())

            def _mask_to_plen(mask: str) -> int:
                """Convert dotted-decimal netmask to prefix length. Returns -1 on failure."""
                try:
                    import ipaddress
                    net = ipaddress.IPv4Network(f"0.0.0.0/{mask}", strict=False)
                    return net.prefixlen
                except Exception:
                    return -1

            def _ensure_cidr(rec: dict) -> None:
                """
                Ensure interfaces record has 'cidr' string.
                Accepts any of: (ip,prefixlen) or (ip,mask) or direct 'cidr'.
                """
                if rec.get("cidr"):
                    return
                ip = rec.get("ip") or rec.get("address") or rec.get("addr")
                plen = rec.get("prefixlen") or rec.get("prefix_len") or rec.get("masklen") or rec.get("plen")
                mask = rec.get("mask") or rec.get("netmask")
                if ip and plen is not None:
                    rec["cidr"] = f"{ip}/{int(plen)}"
                    return
                if ip and mask:
                    p = _mask_to_plen(str(mask))
                    if p >= 0:
                        rec["cidr"] = f"{ip}/{p}"

            def _ensure_prefix(route: dict) -> None:
                """
                Ensure routes record has 'prefix' in CIDR. Accepts:
                - route['prefix'] already CIDR
                - (network,mask) or (dest,mask) -> CIDR
                """
                if route.get("prefix"):
                    return
                net = route.get("network") or route.get("dest") or route.get("destination")
                mask = route.get("mask") or route.get("netmask")
                if net and mask:
                    p = _mask_to_plen(str(mask))
                    if p >= 0:
                        route["prefix"] = f"{net}/{p}"

            # -- Interfaces: canonicalize hostname/device + robust CIDR
            try:
                p = os.path.join(base, 'latest', 'normalized_interfaces.json')
                with open(p, 'r', encoding='utf-8') as f:
                    _intfs = json.load(f)
                changed = 0
                for rec in _intfs:
                    h = rec.get('hostname') or rec.get('device') or rec.get('name')
                    if h:
                        canon = _canon_host(h)
                        if rec.get('hostname') != canon:
                            rec['hostname'] = canon; changed += 1
                        if rec.get('device') != canon:
                            rec['device'] = canon; changed += 1
                    # Keep adapter-facing key too
                    if rec.get('iface') and not rec.get('interface'):
                        rec['interface'] = rec['iface']; changed += 1
                    _ensure_cidr(rec)
                if changed:
                    with open(p, 'w', encoding='utf-8') as f:
                        json.dump(_intfs, f, indent=2)
                try:
                    self.flow_output.insert('end', f"Interfaces normalized: {changed} change(s).\n", 'header')
                    self.flow_output.see('end')
                except Exception:
                    pass
            except Exception as _e:
                try:
                    self.flow_output.insert('end', f"[WARN] Interfaces enhanced normalization failed: {_e}\n", 'deny')
                    self.flow_output.see('end')
                except Exception:
                    pass

            # -- Routes: canonicalize hostname/device + ensure 'prefix'
            try:
                prt = os.path.join(base, 'latest', 'normalized_routes.json')
                with open(prt, 'r', encoding='utf-8') as f:
                    _routes = json.load(f)
                changed = 0
                for rec in _routes:
                    h = rec.get('hostname') or rec.get('device') or rec.get('name')
                    if h:
                        canon = _canon_host(h)
                        if rec.get('hostname') != canon:
                            rec['hostname'] = canon; changed += 1
                        if rec.get('device') != canon:
                            rec['device'] = canon; changed += 1
                    _ensure_prefix(rec)
                if changed:
                    with open(prt, 'w', encoding='utf-8') as f:
                        json.dump(_routes, f, indent=2)
                try:
                    self.flow_output.insert('end', f"Routes normalized: {changed} change(s).\n", 'header')
                    self.flow_output.see('end')
                except Exception:
                    pass
            except Exception as _e:
                try:
                    self.flow_output.insert('end', f"[WARN] Routes enhanced normalization failed: {_e}\n", 'deny')
                    self.flow_output.see('end')
                except Exception:
                    pass

            # -- Policies: canonical device on policy bundles and rules
            try:
                ppol = os.path.join(base, 'latest', 'normalized_policies.json')
                with open(ppol, 'r', encoding='utf-8') as f:
                    policies = json.load(f)
                changed = 0
                def _canon_into(obj):
                    nonlocal changed
                    if not isinstance(obj, dict):
                        return
                    h = obj.get('device') or obj.get('hostname') or obj.get('name')
                    if h:
                        canon = _canon_host(h)
                        if obj.get('device') != canon:
                            obj['device'] = canon; changed += 1
                        if obj.get('hostname') != canon:
                            obj['hostname'] = canon; changed += 1
                if isinstance(policies, list):
                    for rec in policies:
                        _canon_into(rec)
                        rules = rec.get('rules') or []
                        if isinstance(rules, list):
                            for r in rules:
                                _canon_into(r)
                elif isinstance(policies, dict):
                    # rare: dict keyed by device -> list[rules]
                    for k in list(policies.keys()):
                        canon = _canon_host(k)
                        if canon != k:
                            policies[canon] = policies.pop(k); changed += 1
                if changed:
                    with open(ppol, 'w', encoding='utf-8') as f:
                        json.dump(policies, f, indent=2)
                try:
                    self.flow_output.insert('end', f"Policies normalized: {changed} change(s).\n", 'header')
                    self.flow_output.see('end')
                except Exception:
                    pass
            except Exception as _e:
                try:
                    self.flow_output.insert('end', f"[WARN] Policies enhanced normalization failed: {_e}\n", 'deny')
                    self.flow_output.see('end')
                except Exception:
                    pass

            # -- LOADED summary from normalized_meta.json (for quick sanity)
            try:
                pmeta = os.path.join(base, 'latest', 'normalized_meta.json')
                with open(pmeta, 'r', encoding='utf-8') as f:
                    meta = json.load(f)
                counts = meta.get('counts') or {}
                red = meta.get('reductions') or {}
                msg = (
                    f"[LOADED] interfaces: {counts.get('interfaces', '?')} (devices: {counts.get('interfaces_devices','?')})\n"
                    f"[LOADED] routes: {counts.get('routes', '?')} (devices: {counts.get('routes_devices','?')})\n"
                    f"[LOADED] policies: {counts.get('policies', '?')} (devices: {counts.get('policies_devices','?')})\n"
                    f"[REDUCTIONS] HA dropped: {red.get('devices_dropped_by_HA', 0)} duplicates removed: {red.get('duplicates_removed', 0)}\n\n"
                )
                self.flow_output.insert('end', msg, 'header')
                self.flow_output.see('end')
            except Exception:
                pass

            # --- (your existing augmentation code remains below; safe to keep) ---

            # -- Augment interfaces JSON so flow_search recognizes 'interface' and 'cidr'
            try:
                p = os.path.join(base, 'latest', 'normalized_interfaces.json')
                with open(p, 'r', encoding='utf-8') as f:
                    _intfs = json.load(f)
                changed = 0
                for rec in _intfs:
                    iface = rec.get('iface')
                    ip = rec.get('ip')
                    plen = rec.get('prefixlen')
                    if iface and not rec.get('interface'):
                        rec['interface'] = iface
                        changed += 1
                    if ip and (plen is not None) and not rec.get('cidr'):
                        rec['cidr'] = str(ip) + '/' + str(plen)
                if changed:
                    with open(p, 'w', encoding='utf-8') as f:
                        json.dump(_intfs, f, indent=2)
                try:
                    self.flow_output.insert('end', f"Augmented interfaces: {changed} record(s) updated.\n", 'header')
                    self.flow_output.see('end')
                except Exception:
                    pass
            except Exception as _e:
                try:
                    self.flow_output.insert('end', f"[WARN] Interfaces augmentation failed: {_e}\n", 'deny')
                    self.flow_output.see('end')
                except Exception:
                    pass

            # -- Augment policies JSON: fill src/dst/apps from ASA evidence; default zones; normalize names
            try:
                ppol = os.path.join(base, 'latest', 'normalized_policies.json')
                with open(ppol, 'r', encoding='utf-8') as f:
                    policies = json.load(f)
                changed = 0
                import re
                rex = re.compile(
                    r"access-list\\s+(?P<name>\\S+)\\s+line\\s+(?P<line>\\d+)\\s+extended\\s+(?P<action>permit|deny)\\s+"
                    r"(?P<proto>tcp|udp|ip)\\s+"
                    r"(?:(?:host\\s+(?P<src_host>\\d+\\.\\d+\\.\\d+\\.\\d+))|(?P<src_any>any)|(?:object-group\\s+(?P<src_og>\\S+)))\\s+"
                    r"(?:(?:host\\s+(?P<dst_host>\\d+\\.\\d+\\.\\d+\\.\\d+))|(?P<dst_any>any)|(?:object-group\\s+(?P<dst_og>\\S+)))"
                    r"(?:\\s+eq\\s+(?P<dport>\\d+))?",
                    re.IGNORECASE
                )
                for rec in policies:
                    plat = (rec.get('platform') or '').lower()
                    if plat != 'asa':
                        continue
                    if rec.get('from_zone') is None:
                        rec['from_zone'] = 'any'
                    if rec.get('to_zone') is None:
                        rec['to_zone'] = 'any'
                    need_src = not rec.get('src')
                    need_dst = not rec.get('dst')
                    need_apps = not rec.get('apps')
                    if (need_src or need_dst or need_apps) and isinstance(rec.get('evidence'), list):
                        for ln in rec['evidence']:
                            m = rex.search(ln)
                            if not m:
                                continue
                            # src
                            if need_src:
                                if m.group('src_host'):
                                    rec['src'] = [m.group('src_host')]
                                elif m.group('src_og'):
                                    rec['src'] = [f"object-group:{m.group('src_og')}"]
                                elif m.group('src_any'):
                                    rec['src'] = ['any']
                            # dst
                            if need_dst:
                                if m.group('dst_host'):
                                    rec['dst'] = [m.group('dst_host')]
                                elif m.group('dst_og'):
                                    rec['dst'] = [f"object-group:{m.group('dst_og')}"]
                                elif m.group('dst_any'):
                                    rec['dst'] = ['any']
                            # apps/services
                            if need_apps:
                                apps = []
                                proto = (m.group('proto') or '').lower()
                                dport = m.group('dport')
                                if dport and proto in ('tcp', 'udp'):
                                    apps.append(f"{proto}:{dport}")
                                elif proto:
                                    apps.append(proto)
                                rec['apps'] = apps or ['any']
                            if (not rec.get('name')) and m.group('name'):
                                rec['name'] = m.group('name')
                            if (not rec.get('action')) and m.group('action'):
                                rec['action'] = m.group('action').lower()
                            changed += 1
                            break
                if changed:
                    with open(ppol, 'w', encoding='utf-8') as f:
                        json.dump(policies, f, indent=2)
                try:
                    self.flow_output.insert('end', f"Augmented policies: {changed} record(s) updated.\n", 'header')
                    self.flow_output.see('end')
                except Exception:
                    pass
            except Exception as _e:
                try:
                    self.flow_output.insert('end', f"[WARN] Policies augmentation failed: {_e}\n", 'deny')
                    self.flow_output.see('end')
                except Exception:
                    pass

            try:
                self.flow_output.insert("end", "? Data loaded.\n\n", "header")
                self.flow_output.see("end")
            except Exception:
                pass
        except Exception as e:
            try:
                self.flow_output.insert("end", f"[ERROR] {e}\n", "deny")
                self.flow_output.see("end")
            except Exception:
                pass
'''.strip("\n")

# ---------- Patched search_flow ----------
patched_search = r'''
    def search_flow(self):
        src = (self.flow_src_entry.get() or "").strip()
        dst = (self.flow_dst_entry.get() or "").strip()
        if not src or not dst:
            messagebox.showwarning("Flow Search", "Please enter both Source and Destination IPs.")
            return
        if find_flow is None:
            messagebox.showwarning("Network Flow", "flow_engine package not found.")
            return
        try:
            self.flow_output.insert("end", f"[FLOW] {src} ? {dst}\n", "header")
            self.flow_output.see("end")
        except Exception:
            pass
        try:
            result = find_flow(src, dst)
            if result.get('error'):
                self.flow_output.insert("end", result['error'] + "\n\n", "deny")
                return
            self.flow_output.insert("end", "---- Routing Path ----\n", "header")
            path = result.get('path', [])
            last = len(path) - 1
            for i, hop in enumerate(path):
