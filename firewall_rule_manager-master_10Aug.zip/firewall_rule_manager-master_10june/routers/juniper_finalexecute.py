import datetime
import logging
import re
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import time
from routers.juniper_address_book import create_address_book

logger = logging.getLogger(__name__)

def failOver_check(firewall_ip, username, password, secret, rule, retries=5, delay=15):  # Increased retries and delay
    """
    Log in to Juniper SRX, create address book entries, and run configuration and show commands using a list.
    Only processes rules with final_status 'Pending' and valid src_address_line/dst_address_line.
    Args:
        firewall_ip (str): IP address of the Juniper SRX firewall.
        username (str): Username for SSH login.
        password (str): Password for SSH login.
        secret (str): Enable password (if required).
        rule: Firewall rule object containing source_zone, dest_zone, and multiple_ports.
        retries (int): Number of retry attempts (default: 5).
        delay (int): Delay between retries in seconds (default: 15).
    Returns:
        str: 'commands_executed' if commands are successful, or 'skipped' if conditions not met.
    Raises:
        Exception: If connection or command execution fails after retries.
    """
    # Check conditions before proceeding
    if rule.final_status != "Pending" or not rule.src_address_line or not rule.dst_address_line:
        logger.warning(f"Skipping rule {rule.itsr_number}: final_status={rule.final_status}, src_address_line={rule.src_address_line}, dst_address_line={rule.dst_address_line}")
        print(f"Skipping rule {rule.itsr_number}: final_status={rule.final_status}, src_address_line={rule.src_address_line}, dst_address_line={rule.dst_address_line}")
        return 'skipped'
    
    device = {
        'device_type': 'juniper_junos',
        'ip': firewall_ip,
        'username': username,
        'password': password,
        'secret': secret,
        'port': 22,
        'timeout': 300,  # Increased timeout
        'banner_timeout': 120  # Increased banner timeout
    }
    
    connection = None
    try:
        # Establish SSH connection with retries
        for attempt in range(1, retries + 1):
            try:
                connection = ConnectHandler(**device)
                print(f"Connection established for rule {rule.itsr_number}")
                logger.info(f"Successfully connected to Juniper firewall: {firewall_ip} for rule {rule.itsr_number}")
                break
            except Exception as e:
                logger.error(f"Attempt {attempt}/{retries}: Failed to connect to {firewall_ip}: {str(e)}")
                print(f"Attempt {attempt}/{retries}: Failed to connect to {firewall_ip}: {str(e)}")
                if attempt == retries:
                    raise Exception(f"Connection failed to {firewall_ip} after {retries} attempts: {str(e)}")
                time.sleep(delay)
        
        creation_time = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        
        # Enter configure mode
        output = connection.send_command("configure", expect_string=r'#')
        logger.info(f"Entered configure mode for rule {rule.itsr_number}, output: {output}")
        print(f"Entered configure mode for rule {rule.itsr_number}, output: {output}")
        
        new_policy_name = f"{rule.itsr_number}_{rule.email}_{creation_time}_{rule.Security_Exception_number}_{rule.Security_Exception_expiry_date}"
        line1 = rule.src_address_line
        line2 = rule.dst_address_line
        src_address = line1.strip().split()[-2] if line1 else rule.source_ip
        dest_address = line2.strip().split()[-2] if line2 else rule.dest_ip
        existing_policy = rule.Reason.split("policy:")[1].split(",")[0] if rule.Reason and "policy:" in rule.Reason else "default_policy"
        
        config_commands = [
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match source-address {src_address}",
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match destination-address {dest_address}",
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match application {rule.check_port}",
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then permit",
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then log session-init",
            f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then log session-close",
            f"insert security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} before policy {existing_policy}",
            "commit",
            "exit"
        ]
        print("+=" * 50)
        print(f"Configuration commands for rule {rule.itsr_number}: {config_commands}")
        print("+=" * 50)
        
        # Execute configuration commands with retries
        for attempt_config in range(1, retries + 1):
            try:
                output = connection.send_config_set(config_commands)
                logger.info(f"Configuration commands executed for rule {rule.itsr_number}: {output}")
                print(f"Configuration output for rule {rule.itsr_number}: {output}")
                break
            except Exception as e:
                logger.error(f"Config attempt {attempt_config}/{retries} for rule {rule.itsr_number}: Failed to configure: {str(e)}")
                print(f"Config attempt {attempt_config}/{retries} for rule {rule.itsr_number}: Failed to configure: {str(e)}")
                if attempt_config == retries:
                    raise Exception(f"Failed to configure for rule {rule.itsr_number} after {retries} attempts: {str(e)}")
                time.sleep(delay)
        
        connection.disconnect()
        print(f"Disconnected from {firewall_ip} for rule {rule.itsr_number}")
        logger.info(f"Disconnected from Juniper firewall: {firewall_ip} for rule {rule.itsr_number}")
        return 'commands_executed'
    
    except Exception as e:
        logger.error(f"Failed to process rule {rule.itsr_number} on {firewall_ip}: {str(e)}")
        print(f"Failed to process rule {rule.itsr_number} on {firewall_ip}: {str(e)}")
        if connection:
            try:
                connection.disconnect()
                print(f"Disconnected from {firewall_ip} due to error for rule {rule.itsr_number}")
            except:
                pass
        raise
    finally:
        if connection and connection.is_alive():
            try:
                connection.disconnect()
                print(f"Finally disconnected from {firewall_ip} for rule {rule.itsr_number}")
                logger.info(f"Finally disconnected from Juniper firewall: {firewall_ip} for rule {rule.itsr_number}")
            except:
                pass