from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import time
import re

def update_firewall_interfaces_for_rule(rule, username, password, secret, retries=5, delay=15):
    """
    Run 'show route' and 'show configuration' to get interfaces and zones.
    """
    device = {
        'device_type': 'juniper_junos',
        'ip': rule.firewallIP,
        'username': username,
        'password': password,
        'secret': secret,
        'port': 22,
        'timeout': 180,
        'banner_timeout': 60
    }
    
    for attempt in range(1, retries + 1):
        try:
            print(f"Attempt {attempt} for {rule.firewallIP}...")
            connection = ConnectHandler(**device)
            print(f"Successfully connected to {rule.firewallIP} for interface lookup")
            
            source_cmd = f"show route {rule.source_ip}"
            source_output = connection.send_command(source_cmd)
            print(f"Source route output: {source_output}")
            source_interface = re.search(r'via\s+(\S+)', source_output).group(1) if re.search(r'via\s+(\S+)', source_output) else None
            
            dest_cmd = f"show route {rule.dest_ip}"
            dest_output = connection.send_command(dest_cmd)
            print(f"Destination route output: {dest_output}")
            dest_interface = re.search(r'via\s+(\S+)', dest_output).group(1) if re.search(r'via\s+(\S+)', dest_output) else None
            
            src_zone = None
            if source_interface:
                zone_cmd = f"show configuration | display set | match {source_interface}"
                zone_output = connection.send_command(zone_cmd)
                print(f"Zone output for {source_interface}: {zone_output}")
                zone_match = re.search(r'set security zones security-zone (\S+) interfaces {}'.format(re.escape(source_interface)), zone_output)
                src_zone = zone_match.group(1) if zone_match else None
            
            dest_zone = None
            if dest_interface:
                zone_cmd = f"show configuration | display set | match {dest_interface}"
                zone_output = connection.send_command(zone_cmd)
                print(f"Zone output for {dest_interface}: {zone_output}")
                zone_match = re.search(r'set security zones security-zone (\S+) interfaces {}'.format(re.escape(dest_interface)), zone_output)
                dest_zone = zone_match.group(1) if zone_match else None
            
            connection.disconnect()
            print(f"Disconnected from {rule.firewallIP}")
            return source_interface, dest_interface, src_zone, dest_zone
            
        except NetmikoTimeoutException:
            print(f"Attempt {attempt}/{retries}: Failed to connect - Timeout")
            if attempt == retries:
                return None, None, None, None
        except NetmikoAuthenticationException:
            print(f"Attempt {attempt}/{retries}: Failed to connect - Authentication failed")
            if attempt == retries:
                return None, None, None, None
        except Exception as e:
            print(f"Attempt {attempt}/{retries} failed: {str(e)}")
            if attempt == retries:
                return None, None, None, None
        
        time.sleep(delay)
    
    return None, None, None, None