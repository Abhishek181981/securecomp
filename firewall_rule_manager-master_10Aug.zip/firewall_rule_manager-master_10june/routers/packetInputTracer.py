from database import get_db
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
from sqlalchemy.orm import Session
from models import FirewallRule
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, filename='app.log', format='%(asctime)s - %(levelname)s - %(name)s')
logger = logging.getLogger(__name__)

def parse_packet_tracer(packet):
    """
    Parse the Packet Tracer output to extract the action and reason.
    - For "allow" action, check if "permit" is in the output.
    - For "drop" action, capture the Drop-reason line.
    """
    lines = packet.strip().splitlines()
    last_four_lines = lines[-4:] if len(lines) >= 4 else lines

    action = "unknown"
    reason = "unknown"

    # Search the last 4 lines for Action
    for line in last_four_lines:
        if "Action:" in line:
            action_part = line.split("Action:")[1].strip()
            action = action_part.lower()
            break  # Action found, no need to check further

    if action == "allow":
        # Search the entire output for "permit"
        for line in lines:
            if "permit" in line:
                reason = line
                break
    elif action == "drop":
        # Search the last 4 lines for Drop-reason
        for line in last_four_lines:
            if "Drop-reason:" in line:
                reason = line.strip()
                break

    return action, reason

def packetInputTracer(ip_rule, username, password, secret, context_name, db: Session):
    """
    Generate Packet Tracer commands for each port in the firewall rule and set src_Action and src_Reason.
    Only runs on source firewall using source interface subnet.
    Uses incremented IPs from rule.source_ip and rule.dest_ip for Scenario 2.
    """
    logger.info(f"Starting packet-tracer for rule {ip_rule.id}")
    src_ip_rule = ip_rule.src_interface
    ip_rulewall_ip = ip_rule.firewallIP
    # Refresh the rule from database
    ip_rule = db.query(FirewallRule).filter_by(id=ip_rule.id).first()
    if not ip_rule:
        logger.error(f"No rule found with ip {ip_rule.id}")
        return

    # Determine protocol and ports
    protocol = ip_rule.protocol.lower() if ip_rule.protocol else "tcp"
    ports = [p.strip() for p in ip_rule.multiple_ports.split(',')] if ip_rule.multiple_ports else ["80"]
    
    # Initialize results tracking
    port_results = []
    all_allowed = True
    all_dropped = True
    detailed_reasons = []

    try:
        # Device configuration for source firewall
        src_ip_device = {
            'device_type': 'cisco_asa',
            'ip': ip_rulewall_ip,
            'username': username,
            'password': password,
            'secret': secret,
            "session_log": f"tracer_interface.log",
        }
        
        if ip_rulewall_ip:
            with ConnectHandler(**src_ip_device) as conn:
                conn.enable()
                
                # Change context if needed
                if context_name is not None:
                    conn.send_command("changeto system", expect_string=(r".+#"))
                    conn.send_command(f"change context {context_name}", expect_string=r".+#")
                
                # Iterate over each port
                for port_ip in ports:
                    # Generate Packet Tracer command for this port
                    command = f"packet-tracer input {src_ip_rule} {protocol} {ip_rule.source_ip} 12345 {ip_rule.dest_ip} {port_ip}"
                    logger.info(f"Executing packet-tracer command for port {port_ip}: {command}")
                    
                    try:
                        # Run packet tracer command
                        packet = output = conn.send_command(command)
                        logger.debug(f"Packet Tracer Output for port {port_ip}: {packet}\n{output}")
                        
                        # Parse output
                        action, reason = parse_packet_tracer(packet)
                        
                        # Create detailed port result
                        ip_result = {
                            "port": port_ip,
                            "action": action,
                            "reason": reason
                        }
                        port_results.append(ip_result)
                        
                        # Track overall actions
                        if action != "allow":
                            all_allowed = False
                        if action != "drop":
                            all_dropped = False
                            
                    except Exception as e:
                        error_message = f"Error executing command: {str(e)}"
                        logger.error(error_message)
                        ip_result = {
                            "port":port_ip,
                            "action": "error",
                            "reason": error_message
                        }
                        port_results.append(ip_result)
                        all_allowed = False
                        all_dropped = False
                
                # Create detailed reason description
                detailed_reason = "\n".join([
                    f"Port {res['port']}: {res['action'].upper()} - {res['reason']}"
                    for res in port_results
                ])
                
                # Determine overall action and reason
                if all_allowed:
                    ip_rule.Action = "Allowed"
                    ip_rule.Reason = f"All ports allowed\n{detailed_reason}"
                elif all_dropped:
                    ip_rule.Action = "Drop"
                    ip_rule.Reason = f"All ports dropped\n{detailed_reason}"
                else:
                    ip_rule.Action = "Mixed"
                    ip_rule.Reason = f"Mixed results\n{detailed_reason}"
                
                logger.info(f"Updated ip rule {ip_rule.id}: Action={ip_rule.Action}, Reason=\n{ip_rule.Reason}")
                db.commit()
        else:
            logger.error("No firewall IP provided")
            
    except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
        error_message = f"Connection error: {str(e)}"
        logger.error(error_message)
        ip_rule.Action = "Connection Error"
        ip_rule.Reason = error_message
        db.commit()
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        logger.error(error_message)
        ip_rule.Action = "Error"
        ip_rule.Reason = error_message
        db.commit()