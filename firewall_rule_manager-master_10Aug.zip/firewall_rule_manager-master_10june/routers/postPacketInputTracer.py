# from database import get_db
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
from sqlalchemy.orm import Session
from models import FirewallRule
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, filename='app.log', format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def parse_packet_tracer_output(output):
    """
    Parse the Packet Tracer output to extract the action and reason.
    - For "allow" action, check if "permit" is in the output.
    - For "drop" action, capture the Drop-reason line.
    """
    lines = output.strip().splitlines()
    last_four_lines = lines[-4:] if len(lines) >= 4 else lines

    action = "unknown"
    reason = "unknown"

    for line in last_four_lines:
        if "Action:" in line:
            action_part = line.split("Action:")[1].strip()
            action = action_part.lower()
            break

    if action == "allow":
        for line in lines:
            if "permit" in line:
                reason = line
                break
    elif action == "drop":
        for line in last_four_lines:
            if "Drop-reason:" in line:
                reason = line.strip()
                break

    return action, reason

def postPacketInputTracer(rule, username, password, secret, db: Session) -> list:
    """
    Generate Packet Tracer commands for firewall rules and set post_action and post_reason.
    Handles multiple ports by testing each port individually.
    Uses incremented IPs from rule.source_ip and rule.dest_ip for Scenario 2.
    Returns a list of tuples: (firewall_ip, command, rule_id).
    """
    firewallIP = rule.firewallIP
    context_name = rule.context
    if not rule:
        logger.error(f"No rule found for src_ip={rule.source_ip} and dst_ip={rule.dest_ip}")
        return []

    protocol = rule.protocol.lower() if rule.protocol else "tcp"
    ports = [p.strip() for p in rule.multiple_ports.split(',')] if rule.multiple_ports else ["80"]
    
    port_results = []
    commands_executed = []
    all_allow = True
    all_drop = True
    detailed_reasons = []

    try:
        src_device = {
            'device_type': 'cisco_asa',
            'ip': firewallIP,
            'username': username,
            'password': password,
            'secret': secret,
            "session_log": f"postPacketInputTracer_{rule.id}.log",
        }
        
        if firewallIP is not None:
            with ConnectHandler(**src_device) as conn:
                conn.enable()
                if context_name is not None:
                    conn.send_command("changeto system", expect_string=r".+#")
                    conn.send_command(f"change context {context_name}", expect_string=r".+#")
                
                source_ip = rule.source_ip
                dest_ip = rule.dest_ip
                if rule.source_subnet:
                    base_ip = rule.source_ip.rsplit('.', 1)[0] + '.' + str(int(rule.source_ip.rsplit('.', 1)[1]) - 1)
                    source_ip = base_ip
                if rule.dest_subnet:
                    base_ip = rule.dest_ip.rsplit('.', 1)[0] + '.' + str(int(rule.dest_ip.rsplit('.', 1)[1]) - 1)
                    dest_ip = base_ip

                for port in ports:
                    command = f"packet-tracer input {rule.src_interface} {protocol} {source_ip} 12345 {dest_ip} {port}"
                    logger.info(f"Executing Packet Tracer command for port {port}: {command}")
                    
                    try:
                        output = conn.send_command(command)
                        logger.debug(f"Output for port {port}:\n{output}")
                        
                        action, reason = parse_packet_tracer_output(output)
                        
                        port_result = {
                            "port": port,
                            "action": action,
                            "reason": reason
                        }
                        port_results.append(port_result)
                        
                        if action != "allow":
                            all_allow = False
                        if action != "drop":
                            all_drop = False
                            
                        commands_executed.append((firewallIP, command, rule.id))
                        
                    except Exception as e:
                        error_msg = f"Error executing command: {str(e)}"
                        logger.error(error_msg)
                        port_result = {
                            "port": port,
                            "action": "error",
                            "reason": error_msg
                        }
                        port_results.append(port_result)
                        all_allow = False
                        all_drop = False
                        commands_executed.append((firewallIP, command, rule.id))
                
                detailed_reason = "\n".join([
                    f"Port {res['port']}: {res['action'].upper()} - {res['reason']}"
                    for res in port_results
                ])
                
                if all_allow:
                    rule.post_action = "Allowed"
                    rule.post_reason = f"All ports allowed\n{detailed_reason}"
                elif all_drop:
                    rule.post_action = "Drop"
                    rule.post_reason = f"All ports dropped\n{detailed_reason}"
                else:
                    rule.post_action = "Mixed"
                    rule.post_reason = f"Mixed results\n{detailed_reason}"
                    
                db.commit()
                logger.info(f"Updated rule {rule.id}: post_action={rule.post_action}, post_reason=\n{rule.post_reason}")
                
        return commands_executed

    except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
        error_msg = f"Connection error: {str(e)}"
        logger.error(error_msg)
        rule.post_action = "Connection Error"
        rule.post_reason = error_msg
        db.commit()
        return commands_executed
    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logger.error(error_msg)
        rule.post_action = "Error"
        rule.post_reason = error_msg
        db.commit()
        return commands_executed