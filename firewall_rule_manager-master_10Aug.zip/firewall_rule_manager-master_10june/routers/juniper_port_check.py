from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
from fastapi import HTTPException
import logging
import re
import time

logger = logging.getLogger(__name__)

def check_ports(rule, username, password, secret, retries=5, delay=15):  # Increased retries and delay
    """
    Check Juniper configuration for applications matching the rule's multiple_ports from UI.
    If no match, run an alternative command, and if still no match, configure a new application.
   
    Args:
        rule: FirewallRule object containing multiple_ports, protocol, firewallIP, and itsr_number
        username: Firewall username
        password: Firewall password
        secret: Enable secret
        retries: Number of retry attempts for connection (default: 5)
        delay: Delay between retries in seconds (default: 15)
   
    Returns:
        dict: Status of operation and list of matching application names
    """
    device = {
        "device_type": "juniper_junos",
        "ip": rule.firewallIP,
        "username": username,
        "password": password,
        "secret": secret,
        "port": 22,
        "timeout": 180,  # Increased timeout
        "banner_timeout": 60  # Increased banner timeout
    }
    connection = None
    try:
        logger.info(f"Connecting to firewall {rule.firewallIP} for rule {rule.itsr_number}")
        print(f"Connecting to firewall {rule.firewallIP} for rule {rule.itsr_number}")
        for attempt in range(1, retries + 1):
            try:
                connection = ConnectHandler(**device)
                print(f"Port check connection established for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}")
                break
            except Exception as e:
                logger.error(f"Attempt {attempt}/{retries}: Failed to connect to {rule.firewallIP}: {str(e)}")
                print(f"Attempt {attempt}/{retries}: Failed to connect to {rule.firewallIP}: {str(e)}")
                if attempt == retries:
                    return {"status": "failed", "error": f"Connection failed after {retries} attempts: {str(e)}"}
                time.sleep(delay)
        # Extract multiple_ports and protocol from rule, handle None or empty
        ports = [p.strip() for p in (rule.multiple_ports or "").split()] if rule.multiple_ports else []
        protocol = rule.protocol.lower() if rule.protocol else "tcp"  # Default to "tcp" if protocol is None
        if not ports:
            logger.warning(f"No ports provided for rule {rule.itsr_number}")
            print(f"No ports provided for rule {rule.itsr_number}")
            return {"status": "failed", "error": "No ports provided"}
        # Validate ports
        try:
            for port in ports:
                port_num = int(port)
                if port_num < 1 or port_num > 65535:
                    raise ValueError(f"Invalid port number: {port}")
        except ValueError as e:
            logger.error(f"Invalid ports for rule {rule.itsr_number}: {str(e)}")
            print(f"Invalid ports for rule {rule.itsr_number}: {str(e)}")
            return {"status": "failed", "error": f"Invalid ports: {str(e)}"}
        # First attempt: Check with show configuration groups junos-defaults applications
        output = connection.send_command("show configuration groups junos-defaults applications")
        logger.debug(f"Command output (junos-defaults): {output}")
        print(f"Command output (junos-defaults): {output}")
        # Split output into blocks more robustly
        blocks = re.split(r'\n(?=\s*(?:#|\n\s*application))', output, flags=re.MULTILINE)
        matching_apps = []
        # Check each block for matching destination-port
        for block in blocks:
            if "destination-port" in block:
                for port in ports:
                    if re.search(rf"destination-port\s+{re.escape(port)}\s*;", block, re.IGNORECASE):
                        app_name_match = re.search(r'application\s+(\S+)', block)
                        if app_name_match:
                            app_name = app_name_match.group(1)
                            matching_apps.append(app_name)
                            logger.info(f"Found matching application: {app_name} for rule {rule.itsr_number}")
                            print(f"Found matching application: {app_name} for rule {rule.itsr_number}")
                        break
        # If no match found, run alternative command
        if not matching_apps:
            alt_command = f"show configuration | display set | match applications | match application | match {rule.multiple_ports or ''}"
            alt_output = connection.send_command(alt_command)
            logger.debug(f"Alternative command output: {alt_output}")
            print(f"Alternative command output: {alt_output}")
            if rule.multiple_ports:
                app_name_match = re.search(r'set applications application (\S+)', alt_output)
                if app_name_match:
                    app_name = app_name_match.group(1)
                    matching_apps.append(app_name)
                    logger.info(f"Found matching application from alt command: {app_name} for rule {rule.itsr_number}")
                    print(f"Found matching application from alt command: {app_name} for rule {rule.itsr_number}")
        # If still no match and ports/protocol are available, configure new application
        if not matching_apps:
            # Check for configuration lock
            lock_check = connection.send_command("show configuration | display set | match lock")
            if "lock" in lock_check:
                logger.error(f"Configuration locked for firewall {rule.firewallIP}")
                print(f"Configuration locked for firewall {rule.firewallIP}")
                return {"status": "failed", "error": "Configuration is locked"}
            # Define the application name and commands
            proto = rule.protocol.lower()
            app_name = f"{proto}-{rule.multiple_ports}"
            config_commands = [
                "configure",
                f"set applications application {app_name} protocol {proto}",
                f"set applications application {app_name} destination-port {rule.multiple_ports}",
                "commit",
                "exit"
            ]
            logger.info(f"Configuring new application for rule {rule.itsr_number}: {config_commands}")
            print(f"Configuring new application for rule {rule.itsr_number}: {config_commands}")
            for attempt_config in range(1, retries + 1):
                try:
                    output = connection.send_config_set(config_commands)
                    logger.info(f"Configuration output: {output}")
                    print(f"Configuration output: {output}")
                    matching_apps.append(app_name)
                    logger.info(f"Created new application: {app_name} for rule {rule.itsr_number}")
                    print(f"Created new application: {app_name} for rule {rule.itsr_number}")
                    break
                except Exception as e:
                    logger.error(f"Config attempt {attempt_config}/{retries}: Failed to configure for rule {rule.itsr_number}: {str(e)}")
                    print(f"Config attempt {attempt_config}/{retries}: Failed to configure for rule {rule.itsr_number}: {str(e)}")
                    # Try to exit configuration mode
                    connection.send_command("exit")
                    if attempt_config == retries:
                        return {"status": "failed", "error": f"Failed to configure after {retries} attempts: {str(e)}"}
                    time.sleep(delay)
        if not matching_apps:
            logger.warning(f"No matching application blocks found for ports {rule.multiple_ports} in rule {rule.itsr_number}")
            print(f"No matching application blocks found for ports {rule.multiple_ports} in rule {rule.itsr_number}")
            return {"status": "success", "app_names": []}
        return {"status": "success", "app_names": matching_apps}
    except Exception as e:
        logger.error(f"Failed to process ports for rule {rule.itsr_number} on {rule.firewallIP}: {str(e)}")
        print(f"Failed to process ports for rule {rule.itsr_number} on {rule.firewallIP}: {str(e)}")
        return {"status": "failed", "error": str(e)}
    finally:
        if connection:
            connection.disconnect()
            logger.info(f"Disconnected from firewall: {rule.firewallIP}")
            print(f"Disconnected from firewall: {rule.firewallIP}")