from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import re
import logging
import time

logger = logging.getLogger(__name__)

def run_packet_tracer(rule, username, password, secret, retries=5, delay=15):
    """
    Run 'show security match-policies' on Juniper SRX to check policy feasibility.
    """
    device = {
        "device_type": "juniper_junos",
        "ip": rule.firewallIP,
        "username": username,
        "password": password,
        "secret": secret,
        "port": 22,
        "timeout": 180,
        "banner_timeout": 60
    }
    
    if not rule.source_zone or not rule.dest_zone:
        logger.warning(f"No source or destination zone for rule {rule.itsr_number}")
        return {"error": "Missing source or destination zone", "matched": False}
    
    destination_port = rule.multiple_ports
    protocol = rule.protocol.lower() if rule.protocol else "tcp"
    
    command = (
        f"show security match-policies from-zone {rule.source_zone} to-zone {rule.dest_zone} source-ip {rule.source_ip} destination-ip {rule.dest_ip} source-port 12345 destination-port {destination_port} protocol {protocol}"
    )
    
    for attempt in range(1, retries + 1):
        try:
            print(f"Attempt {attempt} for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}...")
            logger.info(f"Attempt {attempt}: Connecting to {rule.firewallIP} for policy check")
            connection = ConnectHandler(**device)
            print(f"Connection established for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}")
            
            logger.info(f"Executing command: {command}")
            output = connection.send_command(command)
            logger.info(f"Policy match output: {output}")
            
            policy_result = {"policy_name": None, "action": None, "source_address": None, "destination_address": None, "matched": False}
            policy_match = re.search(
                r"Policy:\s+(\S+),\s+action-type:\s+(\S+).*?"
                r"Source addresses:\s*\n\s+(\S+):\s+(\S+).*?"
                r"Destination addresses:\s*\n\s+(\S+):\s+(\S+)",
                output, re.DOTALL | re.IGNORECASE
            )
            
            if policy_match:
                policy_result["policy_name"] = policy_match.group(1)
                policy_result["action"] = policy_match.group(2)
                policy_result["source_address"] = policy_match.group(4)
                policy_result["destination_address"] = policy_match.group(6)
                policy_result["matched"] = True
                logger.info(f"Policy matched: {policy_result}")
            else:
                logger.warning(f"No policy matched for command: {command}")
            
            connection.disconnect()
            print(f"Disconnected from {rule.firewallIP} for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}")
            return policy_result
       
        except NetmikoTimeoutException:
            print(f"Connection failed for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}: Connection timeout")
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect - Timeout")
            if attempt == retries:
                return {"error": "Connection timeout after retries", "matched": False}
        except NetmikoAuthenticationException:
            print(f"Connection failed for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}: Authentication failed")
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect - Authentication failed")
            if attempt == retries:
                return {"error": "Authentication failed", "matched": False}
        except Exception as e:
            print(f"Connection failed for src={rule.source_ip}, dst={rule.dest_ip}, port={rule.multiple_ports}: {str(e)}")
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect - Error: {str(e)}")
            if attempt == retries:
                return {"error": f"Unexpected error: {str(e)}", "matched": False}
       
        time.sleep(delay)
   
    return {"error": "Failed to connect after retries", "matched": False}