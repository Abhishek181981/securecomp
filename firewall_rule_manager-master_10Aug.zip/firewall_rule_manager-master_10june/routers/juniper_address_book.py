import re
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import logging
import time

logger = logging.getLogger(__name__)

def create_address_book(rule, username, password, secret, retries=5, delay=15, connection=None):
    """
    Create or check address book entries on Juniper SRX.
    """
    if not connection:
        device = {
            "device_type": "juniper_junos",
            "ip": rule.firewallIP,
            "username": username,
            "password": password,
            "secret": secret,
            "port": 22,
            "timeout": 180,
            "banner_timeout": 60
        }
        for attempt in range(1, retries + 1):
            try:
                connection = ConnectHandler(**device)
                break
            except Exception as e:
                logger.error(f"Attempt {attempt}/{retries}: Failed to connect for address book: {str(e)}")
                if attempt == retries:
                    return {"status": "failed", "error": f"Connection failed: {str(e)}"}
                time.sleep(delay)
    
    try:
        print(f"Using connection for rule {rule.itsr_number}, src={rule.source_ip}, dst={rule.dest_ip}")
        src_cmd = f"show configuration security zones security-zone {rule.source_zone} address-book | match {rule.source_ip}"
        dst_cmd = f"show configuration security zones security-zone {rule.dest_zone} address-book | match {rule.dest_ip}"
        src_output = connection.send_command(src_cmd)
        dst_output = connection.send_command(dst_cmd)
        
        src_address_line = re.search(rf"set security zones security-zone {re.escape(rule.source_zone)} address-book address \S+ {re.escape(rule.source_ip)}/\d+", src_output)
        dst_address_line = re.search(rf"set security zones security-zone {re.escape(rule.dest_zone)} address-book address \S+ {re.escape(rule.dest_ip)}/\d+", dst_output)
        
        if src_address_line and dst_address_line:
            return {"status": "passed", "src_address_line": src_address_line.group(0), "dst_address_line": dst_address_line.group(0)}
        else:
            config_commands = [
                "configure",
                f"set security zones security-zone {rule.source_zone} address-book address h_{rule.source_ip} {rule.source_ip}/32",
                f"set security zones security-zone {rule.dest_zone} address-book address h_{rule.dest_ip} {rule.dest_ip}/32",
                "commit",
                "exit"
            ]
            output = connection.send_config_set(config_commands)
            logger.info(f"Address book configured: {output}")
            return {"status": "success", "src_address_line": config_commands[1], "dst_address_line": config_commands[2], "commands": config_commands}
    
    except Exception as e:
        logger.error(f"Failed to create address book for rule {rule.itsr_number}: {str(e)}")
        return {"status": "failed", "error": str(e)}
    finally:
        if connection and not connection.is_alive():
            connection.disconnect()
            print(f"Disconnected from {rule.firewallIP} for address book")