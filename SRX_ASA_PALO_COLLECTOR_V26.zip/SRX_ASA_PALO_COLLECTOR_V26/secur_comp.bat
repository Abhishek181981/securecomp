@echo off
SETLOCAL ENABLEEXTENSIONS

REM === Check if Python executable exists ===
IF NOT EXIST "C:\\Users\\amishra11\\AppData\\Local\\Programs\\Python\\Python312\\python.exe" (
    echo [ERROR] Python executable not found at:
    echo C:\\Users\\amishra11\\AppData\\Local\\Programs\\Python\\Python312\\python.exe
    echo Please verify the path or install Python 3.12.
    pause
    exit /b 1
)

REM === Check if script exists ===
IF NOT EXIST "gui_factory_ready13.py" (
    echo [ERROR] gui_factory_ready13.py not found in the current directory.
    echo Please place this batch file in the same folder as gui_factory_ready13.py.
    pause
    exit /b 1
)

REM === Run the Python script ===
echo Starting Secur Comp using Python 3.12...
"C:\\Users\\amishra11\\AppData\\Local\\Programs\\Python\\Python312\\python.exe" "gui_factory_ready13.py"
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] The script exited with an error.
    echo Check your Python environment and dependencies.
    pause
    exit /b %ERRORLEVEL%
)

ENDLOCAL
