
# Monitoring Test Pack

This pack lets you validate the **Monitoring (Syslog)** features of the GUI without a real syslog server.

## Folder layout
```
monitoring_test_pack/
  syslog/logs/firewalls/
    pa-fw-01/pa-log-1.log
    asa-fw-01/asa-log-1.log
    srx-fw-01/srx-log-1.log
  modular_collector/reports/latest/monitor/
    monitor_status.csv (header only)
```

## How to use
1. **Unzip** this archive anywhere (e.g. `C:\temp\monitoring_test_pack`).
2. In the GUI, open **Risk & Compliance → Monitor (syslog)…**.
3. Set **Syslog root** to the `syslog\logs\firewalls` folder inside the extracted pack, e.g.:
   * `C:\temp\monitoring_test_pack\syslog\logs\firewalls`
4. Enter one of the following **Hostname / Platform / Wide Rule** combinations, then click **Start**:
   - Hostname: `pa-fw-01`, Platform: `Palo Alto`, Wide Rule: `Wide-Any-RFC`
   - Hostname: `asa-fw-01`, Platform: `ASA`,        Wide Rule: `WIDE_ANY_ANY`
   - Hostname: `srx-fw-01`, Platform: `SRX`,        Wide Rule: `Wide-Web-Rule`

When running, the worker will scan the latest log file under the given host folder and pick **allow/permit** hits that match the rule substring. It appends matched flows into `modular_collector/reports/latest/monitor/<host>__<rule>.csv` and updates `monitor_status.csv`. Stopping will generate a snippet and push an entry into the **Remediation** tab.

> Tip: You can edit the log files while monitoring to simulate new hits; the reader tails the last portion of the newest file.
