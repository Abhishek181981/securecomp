@echo off
setlocal
cd /d "%~dp0"
echo.
echo [INFO] Copying patched GUI into current folder...
if exist gui_factory_ready13_secure.py (
  echo [OK] Patched GUI file present in bundle.
) else (
  echo [ERROR] Patched GUI not found.
  pause
  exit /b 1
)
echo.
echo [NEXT] After you run collector, run:
echo   python normalize_latest.py --base reports
echo.
echo [THEN] Run GUI and in Network Flow tab click "Refresh Collector Data".
echo.
pause
