﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Unified remediation.py with SRX / ASA (multi-context) / PAN support.
- Hostname split: DEVICE->CONTEXT (ASA)
- ASA: delete active ACE by line, then insert an identical inactive ACE; changeto context; write mem
- SRX/PAN flows preserved in dedicated handlers
- disable.csv contains ALL processed rows (SUCCESS + ERROR)
- inactive.csv prepended (newest-first) when APPLY=1 and status=SUCCESS
"""
import os
import re
import csv
import time
from typing import List, Dict
import paramiko

# ------------------------------------------------------------
# Paths
# ------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FW_CSV_PATH = os.path.join(BASE_DIR, 'modular_collector', 'firewall.csv')
REPORTS_DIR = os.path.join(BASE_DIR, 'modular_collector', 'reports', 'latest')
os.makedirs(REPORTS_DIR, exist_ok=True)
QUEUE_PATH = os.path.join(REPORTS_DIR, 'remediation_queue.csv')
DISABLE_PATH = os.path.join(REPORTS_DIR, 'disable.csv')
INACTIVE_PATH = os.path.join(REPORTS_DIR, 'inactive.csv')
LOGS_DIR = os.path.join(REPORTS_DIR, 'logs')
os.makedirs(LOGS_DIR, exist_ok=True)

# ------------------------------------------------------------
# Environment
# ------------------------------------------------------------
USERNAME = os.environ.get('FW_USERNAME', '')
PASSWORD = os.environ.get('FW_PASSWORD', '')
ENABLE   = os.environ.get('FW_ENABLE', '')
APPLY    = (os.environ.get('APPLY_CHANGES', '') == '1')

FIELDS: List[str] = [
    'timestamp','hostname','platform','rule_id','rule_name','acl_name',
    'raw_ace','action','status','message','command_preview'
]
INACTIVE_FIELDS: List[str] = [
    'timestamp','hostname','platform','rule_id','rule_name','acl_name',
    'raw_ace','action','status','message','command_source'
]

def _ts() -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S')

# ------------------------------------------------------------
# CSV Helpers
# ------------------------------------------------------------

def _write_disable(rows: List[Dict[str, str]]) -> None:
    with open(DISABLE_PATH, 'w', encoding='utf-8', newline='') as out:
        dw = csv.DictWriter(out, fieldnames=FIELDS, extrasaction='ignore')
        dw.writeheader()
        for r in rows:
            safe = {k: (r.get(k,'') or '') for k in FIELDS}
            dw.writerow(safe)

def _prepend_inactive_row(row: Dict[str, str]) -> None:
    """Prepend SUCCESS row into inactive.csv (newest-first)."""
    norm = {
        'timestamp': row.get('timestamp') or _ts(),
        'hostname': row.get('hostname') or '',
        'platform': row.get('platform') or '',
        'rule_id': row.get('rule_id') or '',
        'rule_name': row.get('rule_name') or '',
        'acl_name': row.get('acl_name') or '',
        'raw_ace': row.get('raw_ace') or '',
        'action': row.get('action') or 'disable',
        'status': row.get('status') or 'SUCCESS',
        'message': row.get('message') or '',
        'command_source': row.get('command_source') or '',
    }
    existing: List[Dict[str,str]] = []
    if os.path.isfile(INACTIVE_PATH):
        try:
            with open(INACTIVE_PATH, 'r', encoding='utf-8') as f:
                dr = csv.DictReader(f)
                existing = list(dr)
        except Exception:
            existing = []
    with open(INACTIVE_PATH, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=INACTIVE_FIELDS, extrasaction='ignore')
        dw.writeheader()
        for r in [norm] + existing:
            safe = {k: (r.get(k,'') or '') for k in INACTIVE_FIELDS}
            dw.writerow(safe)

# ------------------------------------------------------------
# Logging & SSH helpers
# ------------------------------------------------------------

def _safe_name(s: str) -> str:
    s = (s or '').strip()
    return ''.join(c if c.isalnum() or c in ('-','_','.') else '_' for c in s)

def _open_log(hostname: str):
    log_name = f"{_safe_name(hostname)}_{int(time.time())}.log"
    path = os.path.join(LOGS_DIR, log_name)
    fh = open(path, 'w', encoding='utf-8')
    return fh, path

def _log_write(fh, text: str):
    try:
        fh.write(text)
    except Exception:
        pass

def _drain(chan, fh, wait: float = 0.2):
    time.sleep(wait)
    out = b''
    while chan.recv_ready():
        out += chan.recv(65535)
        time.sleep(0.05)
    if out:
        _log_write(fh, out.decode(errors='ignore'))
    return out

# Strip stray unicode spaces (BOM-like spaces that can get pasted)
_SAN_RE = re.compile(r'[﻿   ]')

def _send(chan, fh, line: str, wait: float = 0.8):
    if line is None:
        line = ''
    clean = _SAN_RE.sub('', line)
    _log_write(fh, '>> ' + clean + '')
    chan.send(clean + '')
    _drain(chan, fh, wait)

def _send_get(chan, fh, line: str, wait: float = 0.8) -> str:
    if line is None:
        line = ''
    clean = _SAN_RE.sub('', line)
    _log_write(fh, '>> ' + clean + '')
    chan.send(clean + '')
    out = _drain(chan, fh, wait)
    try:
        return out.decode(errors='ignore') if isinstance(out, (bytes, bytearray)) else str(out)
    except Exception:
        return ''

def _prep_cli(platform: str, chan, fh):
    p = (platform or '').lower()
    chan.send(''); _drain(chan, fh, 0.5)
    if ('srx' in p) or ('junos' in p):
        _send(chan, fh, 'cli', 0.6)
        _send(chan, fh, 'set cli screen-length 0', 0.5)
        _send(chan, fh, 'set cli screen-width 0', 0.5)
    elif 'palo' in p:
        _send(chan, fh, 'set cli pager off', 0.5)
    elif 'asa' in p:
        _send(chan, fh, 'terminal pager 0', 0.3)

# ------------------------------------------------------------
# SRX Handler
# ------------------------------------------------------------
_SRZ = re.compile(r'from-zone\s+(\S+)\s+to-zone\s+(\S+)', re.IGNORECASE)

def _srx_deactivate_cmd(rule_id: str, raw_ace: str) -> str:
    if raw_ace:
        m = _SRZ.search(raw_ace or '')
        if m:
            return f"deactivate security policies from-zone {m.group(1)} to-zone {m.group(2)} policy {rule_id}"
    return f'deactivate security policies policy {rule_id}'

def handle_srx_disable(chan, log_fh, row):
    rule_id = (row.get('rule_id') or '').strip()
    ace = row.get('raw_ace') or ''
    _send(chan, log_fh, 'configure', 1.0)
    _send(chan, log_fh, _srx_deactivate_cmd(rule_id, ace), 1.2)
    _send(chan, log_fh, 'commit', 5.0)
    _send(chan, log_fh, 'exit', 0.6)

# ------------------------------------------------------------
# ASA (Model B: delete + insert inactive)
# ------------------------------------------------------------
_HEX_RE        = re.compile(r"0x[0-9a-fA-F]+")
_LINE_EXT_RE   = re.compile(r"line\s+(?P<ln>\d+)\s+extended\s+(?P<body>.*)", re.IGNORECASE)
_INACTIVE_RE   = re.compile(r"inactive", re.IGNORECASE)

# Normalize ACE body (remove hitcnt/hash/inactive/log/interval)

def _asa_norm_body(s: str) -> str:
    s = re.sub(r"\(hitcnt=.*?\)", '', s, flags=re.IGNORECASE)
    s = re.sub(r"0x[0-9a-fA-F]+", '', s)
    s = re.sub(r"inactive", '', s, flags=re.IGNORECASE)
    s = re.sub(r"log.*?(?=host|object|any|eq|lt|gt|range|$)", '', s, flags=re.IGNORECASE)
    s = re.sub(r"interval\s+\d+", '', s, flags=re.IGNORECASE)
    return ' '.join(s.split())

# Clean body from raw ACE (drop 'line N', take after 'extended')

def _asa_build_body_from_raw(ace_raw: str) -> str:
    no_line = re.sub(r"line\s+\d+", '', ace_raw or '', flags=re.IGNORECASE)
    m = re.search(r"extended\s+(.*)", no_line, flags=re.IGNORECASE)
    body = m.group(1) if m else no_line
    return _asa_norm_body(body)

# Extract 0xHASH

def _asa_extract_hex(ace_raw: str) -> str:
    m = _HEX_RE.search(ace_raw or '')
    return m.group(0) if m else ''

# Resolve active line & body from show access-list

def _asa_find_active_line_and_body(show_out: str, hex_id: str, ace_raw: str):
    lines = (show_out or '').splitlines()
    want = _asa_build_body_from_raw(ace_raw)
    if hex_id:
        for ln in lines:
            if (hex_id in ln) and (not _INACTIVE_RE.search(ln)):
                m = _LINE_EXT_RE.search(ln)
                if m:
                    return m.group('ln'), _asa_norm_body(m.group('body'))
    for ln in lines:
        if (' extended ' in ln.lower()) and (not _INACTIVE_RE.search(ln)):
            m = _LINE_EXT_RE.search(ln)
            if m:
                b = _asa_norm_body(m.group('body'))
                if (b == want) or b.startswith(want) or want.startswith(b):
                    return m.group('ln'), b
    return '', ''

# ------------------------------------------------------------
# ASA Handler (delete + insert inactive)
# ------------------------------------------------------------

def handle_asa_disable(chan, log_fh, row, enable_secret):
    ctx = (row.get('context') or '').strip()
    _send(chan, log_fh, 'enable', 0.6)
    if enable_secret:
        _send(chan, log_fh, enable_secret, 0.6)
    _send(chan, log_fh, 'terminal pager 0', 0.3)
    if ctx:
        _send(chan, log_fh, f'changeto context {ctx}', 1.2)
    _send(chan, log_fh, 'configure terminal', 0.8)

    ace_raw = (row.get('raw_ace') or '').strip()
    # Guarantee ACL name here too
    acl = (row.get('acl_name') or '').strip()
    if not acl and ace_raw:
        m_acl = re.match(r'^access-list\s+(\S+)', ace_raw, flags=re.IGNORECASE)
        if m_acl:
            acl = m_acl.group(1)
            row['acl_name'] = acl

    # Resolve active line
    hex_id = _asa_extract_hex(ace_raw)
    out = _send_get(chan, log_fh, f'show access-list {acl}', 1.2)
    line_no, running_body = _asa_find_active_line_and_body(out, hex_id, ace_raw)

    if line_no and running_body:
        _send(chan, log_fh, f'no access-list {acl} line {line_no} extended {running_body}', 1.0)
        _send(chan, log_fh, f'access-list {acl} extended {running_body} inactive', 1.0)
    else:
        _send(chan, log_fh, '# WARN: active line not resolved; adding inactive only', 0.2)
        fb = _asa_build_body_from_raw(ace_raw)
        _send(chan, log_fh, f'access-list {acl} extended {fb} inactive', 1.0)

    _send(chan, log_fh, 'write memory', 2.0)

    # Verify no active remains
    vout = _send_get(chan, log_fh, f'show access-list {acl}', 1.2)
    if hex_id:
        for ln in (vout or '').splitlines():
            if (hex_id in ln) and (not _INACTIVE_RE.search(ln)):
                raise RuntimeError(f'ASA verify failed: active ACE still present (hex {hex_id}) in {acl}')
    else:
        want_body = _asa_build_body_from_raw(ace_raw)
        for ln in (vout or '').splitlines():
            if (' extended ' in ln.lower()) and (not _INACTIVE_RE.search(ln)):
                m2 = _LINE_EXT_RE.search(ln)
                if m2:
                    body2 = _asa_norm_body(m2.group('body'))
                    if (body2 == want_body) or body2.startswith(want_body) or want_body.startswith(body2):
                        raise RuntimeError(f'ASA verify failed: active ACE still present by content in {acl}')
    _send(chan, log_fh, 'end', 0.4)

# ------------------------------------------------------------
# PAN Handler
# ------------------------------------------------------------

def handle_palo_disable(chan, log_fh, row):
    rule_id = (row.get('rule_id') or '').strip()
    _send(chan, log_fh, 'configure', 1.0)
    _send(chan, log_fh, f'set rulebase security rules {rule_id} disabled yes', 1.2)
    _send(chan, log_fh, 'commit', 4.0)
    time.sleep(0.8)
    _send(chan, log_fh, 'exit', 0.6)

# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

def main() -> int:
    # 1) Load queue
    if not os.path.isfile(QUEUE_PATH):
        _write_disable([{
            'timestamp': _ts(), 'hostname': '', 'platform': '',
            'rule_id': '', 'rule_name': '', 'acl_name': '', 'raw_ace': '',
            'action': 'disable', 'status': 'ERROR',
            'message': 'remediation_queue.csv not found',
            'command_preview': ''
        }])
        return 2
    with open(QUEUE_PATH, 'r', encoding='utf-8') as f:
        dr = csv.DictReader(f)
        queue_rows = list(dr)

    # 2) Load inventory
    if not os.path.isfile(FW_CSV_PATH):
        out_rows = []
        for row in queue_rows:
            row = dict(row)
            row.update({'timestamp': _ts(), 'status': 'ERROR', 'message': 'firewall.csv missing', 'command_preview': ''})
            out_rows.append(row)
        _write_disable(out_rows)
        return 2

    fw_index: Dict[str, Dict[str,str]] = {}
    with open(FW_CSV_PATH, 'r', encoding='utf-8') as f:
        dr = csv.DictReader(f)
        for r in dr:
            hn = (r.get('hostname') or '').strip().lower()
            if hn:
                fw_index[hn] = r

    # 3) Process rows
    out_rows: List[Dict[str,str]] = []
    for row in queue_rows:
        row = dict(row)
        ts = _ts()

        # Split multi-context host: DEV->CTX
        raw_host = (row.get('hostname') or '').strip()
        parts = re.split(r'\s*->\s*', raw_host)
        dev = parts[0].strip() if parts else raw_host
        ctx = parts[1].strip() if len(parts) > 1 else ''
        row['context'] = ctx
        if not dev:
            row.update({'timestamp': ts, 'status': 'ERROR', 'message': 'hostname missing'})
            out_rows.append(row)
            continue

        dev_l = dev.lower()
        dev_rec = fw_index.get(dev_l)
        if not dev_rec:
            row.update({'timestamp': ts, 'status': 'ERROR', 'message': f'Device "{dev}" not found in inventory CSV'})
            out_rows.append(row)
            continue

        platform = (dev_rec.get('platform') or '').strip().lower()
        ip = dev_rec.get('ip') or dev_rec.get('hostname')
        try:
            port = int(dev_rec.get('port') or 22)
        except Exception:
            port = 22

        # Ensure ACL name exists BEFORE preview
        ace_preview = row.get('raw_ace') or ''
        m_prev = re.match(r'^access-list\s+(\S+)', ace_preview, flags=re.IGNORECASE)
        acl_prev = m_prev.group(1) if m_prev else (row.get('acl_name') or '')
        if acl_prev and not row.get('acl_name'):
            row['acl_name'] = acl_prev

        # Build preview for UI/logs
        rule_id = (row.get('rule_id') or '').strip()
        if ('srx' in platform) or ('junos' in platform):
            row['command_preview'] = _srx_deactivate_cmd(rule_id, row.get('raw_ace') or '')
        elif 'palo' in platform:
            row['command_preview'] = f'set rulebase security rules {rule_id} disabled yes'
        elif 'asa' in platform:
            row['command_preview'] = f"access-list {acl_prev} extended {_asa_build_body_from_raw(ace_preview)} inactive"
        else:
            row['command_preview'] = f'# unsupported platform: {platform}'

        # Connect + apply
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip, port=port, username=USERNAME, password=PASSWORD,
                           allow_agent=False, look_for_keys=False,
                           timeout=45, banner_timeout=30, auth_timeout=30)
            if APPLY:
                log_fh, _ = _open_log(dev)
                try:
                    chan = client.invoke_shell()
                    time.sleep(1)
                    _prep_cli(platform, chan, log_fh)
                    if ('srx' in platform) or ('junos' in platform):
                        if not rule_id:
                            raise RuntimeError('rule_id missing for SRX')
                        handle_srx_disable(chan, log_fh, row)
                    elif 'palo' in platform:
                        if not rule_id:
                            raise RuntimeError('rule_id missing for PAN')
                        handle_palo_disable(chan, log_fh, row)
                    elif 'asa' in platform:
                        handle_asa_disable(chan, log_fh, row, ENABLE)
                    else:
                        _send(chan, log_fh, f'# unsupported platform: {platform}', 0.5)
                finally:
                    try:
                        log_fh.close()
                    except Exception:
                        pass
            client.close()
            # SUCCESS row
            row.update({'timestamp': ts, 'status': 'SUCCESS', 'message': ''})
            out_rows.append(row)
            # Append to inactive ledger if APPLY
            if APPLY:
                if ('srx' in platform) or ('junos' in platform):
                    row['command_source'] = 'SRX: deactivate policy'
                elif 'palo' in platform:
                    row['command_source'] = 'PAN: set rule disabled yes'
                elif 'asa' in platform:
                    row['command_source'] = 'ASA: delete+insert inactive'
                _prepend_inactive_row(row)
        except Exception as e:
            # ERROR row
            row.update({'timestamp': ts, 'status': 'ERROR', 'message': str(e)})
            out_rows.append(row)

    _write_disable(out_rows)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
