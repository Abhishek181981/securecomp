
def _collector_register_windows_task(self, task_name, mode, date_txt, time_txt, weekday, run_current_user, account_user):
    """
    Fully patched version – stable PowerShell output.
    Handles quoting, escaping, REPORTS_DIR insertion,
    and ensures all lines break correctly.
    """
    import os, sys, json, subprocess

    try:
        if os.name != 'nt':
            return (False, "", "Not on Windows")

        # Resolve paths
        script = self._find_collector_script()
        if not script:
            return (False, "", "collector.py not found")

        run_cwd = os.path.dirname(os.path.abspath(script))
        try:
            rep_dir, _, _ = _ensure_reports_dir()
        except Exception:
            # Fallback: reports/latest under run_cwd
            rep_dir = os.path.join(run_cwd, 'reports', 'latest')
            os.makedirs(rep_dir, exist_ok=True)

        # Build collector command (same options as Start Collector)
        cmd = self._collector_build_cmd(script)
        args_only = cmd[1:] if len(cmd) > 1 else []

        # Escape helper for PowerShell double-quoted strings
        def psq(v: str) -> str:
            return str(v).replace('`', '``').replace('"', '`"')

        args_quoted = " ".join(f'"{psq(a)}"' for a in args_only)

        # Weekday mapping
        wk_map = {
            "Mon": "Monday", "Tue": "Tuesday", "Wed": "Wednesday",
            "Thu": "Thursday", "Fri": "Friday", "Sat": "Saturday", "Sun": "Sunday"
        }
        ps_weekday = wk_map.get(weekday, "Monday")

        # ----- Trigger -----
        if mode == "once":
            ps_trig = f"$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date '{date_txt} {time_txt}')"
        elif mode == "weekly":
            ps_trig = f"$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek {ps_weekday} -At '{time_txt}'"
        else:
            ps_trig = f"$trigger = New-ScheduledTaskTrigger -Daily -At '{time_txt}'"

        # ----- Command executed inside powershell.exe -Command -----
        # Use the real reports dir and python exe; ensure correct quoting
        ps_cmd = (
            f"$env:REPORTS_DIR = '{rep_dir}'; "
            f"& '{sys.executable}' -u 'collector.py' {args_quoted}; "
        )
        # Escape for embedding into -Command "..."
        ps_cmd_escaped = ps_cmd.replace('`', '``').replace('"', '`"')

        # ----- Action -----
        ps_action = (
            "$action = New-ScheduledTaskAction -Execute 'powershell.exe' "
            f'-Argument "-NoProfile -WindowStyle Hidden -Command `"{ps_cmd_escaped}`"" '
            f"-WorkingDirectory '{run_cwd}'"
        )

        # ----- Settings -----
        ps_settings = "$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable"

        # Combine the PowerShell file
        ps_lines = []
        ps_lines.append("$ErrorActionPreference = 'Stop';
")
        ps_lines.append(ps_trig + "
")
        ps_lines.append(ps_action + "
")
        ps_lines.append(ps_settings + "
")

        # ----- Registration -----
        # Support either current-user registration or explicit domain account
        if run_current_user:
            reg = (
                f"Register-ScheduledTask -TaskName {json.dumps(task_name)} "
                f"-Action $action -Trigger $trigger -Settings $settings "
            )
            ps_lines.append(reg + "
")
        else:
            if not account_user:
                return (False, "", "Account user required when not running as current user")
            # Prepare credential prompt first, then pass to Register-ScheduledTask
            acc_escaped = account_user.replace('`', '``').replace("'", "''")
            ps_lines.append(f"$cred = Get-Credential -UserName '{acc_escaped}' -Message 'Enter password for the scheduled task'
")
            ps_lines.append("if (-not $cred) { throw 'No credentials supplied.' }
")
            reg = (
                f"Register-ScheduledTask -TaskName {json.dumps(task_name)} "
                f"-Action $action -Trigger $trigger -Settings $settings "
                f"-User $cred.UserName -Password ($cred.GetNetworkCredential().Password) "
            )
            ps_lines.append(reg + "
")

        ps1_path = os.path.join(rep_dir, 'register_task.ps1')
        with open(ps1_path, 'w', encoding='utf-8') as f:
            f.write(''.join(ps_lines))

        # Execute the generated PS1 to register the task
        proc = subprocess.run(
            ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps1_path],
            capture_output=True, text=True, cwd=run_cwd, timeout=120
        )
        if proc.returncode == 0:
            return (True, ps1_path, None)
        err = (proc.stdout or '') + "
" + (proc.stderr or '')
        return (False, ps1_path, err.strip())

    except subprocess.TimeoutExpired:
        return (False, "", "PowerShell timed out while registering the task")
    except Exception as e:
        return (False, "", str(e))
