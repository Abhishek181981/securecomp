
import paramiko
class SyslogClient:
    def __init__(self, username: str, password: str, timeout: int = 10):
        self.username = username
        self.password = password
        self.timeout = timeout
    def _connect(self, ip):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, username=self.username, password=self.password, timeout=self.timeout, allow_agent=False, look_for_keys=False)
        return client
    def fetch_hits(self, syslog_ip: str, rule: str):
        if not syslog_ip:
            return []
        try:
            client=self._connect(syslog_ip)
            cmd=f"tail -n 5000 /data/syslog/firewall | grep -i '{rule}' || true"
            stdin,stdout,stderr=client.exec_command(cmd)
            out=stdout.read().decode('utf8','ignore').splitlines()
            client.close()
            return [x for x in out if x.strip()]
        except Exception:
            return []
