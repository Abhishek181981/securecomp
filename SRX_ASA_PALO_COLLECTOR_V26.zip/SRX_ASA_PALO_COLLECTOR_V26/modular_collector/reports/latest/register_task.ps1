$ErrorActionPreference = 'Stop';
$trigger = New-ScheduledTaskTrigger -Daily -At '23:30'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -Command `"$env:REPORTS_DIR = 'C:\Users\amishra11\desktop\newprogres\SRX_ASA_PALO_COLLECTOR_V24\modular_collector\reports\latest'; & 'C:\Users\amishra11\AppData\Local\Programs\Python\Python312\python.exe' -u 'collector.py' `"-u`" `"collector.py`" `"--threads`" `"8`" `"--device-timeout`" `"120`"; `"" -WorkingDirectory 'C:\Users\amishra11\desktop\newprogres\SRX_ASA_PALO_COLLECTOR_V24\modular_collector'
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable
Register-ScheduledTask -TaskName "ACL Collector - Nightlyy" -Action $action -Trigger $trigger -Settings $settings 
