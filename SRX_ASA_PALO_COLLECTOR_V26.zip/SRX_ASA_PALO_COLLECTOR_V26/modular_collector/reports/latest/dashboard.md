# Firewall Risk & Zero-Hit Dashboard
_Generated: 2026-03-02 05:19:06_

## Risky Rules Summary

- **Total risky rules**: 55772
- **ANY in source**: 190
- **ANY in destination**: 279
- **Permit ANY→ANY rules**: 18
- **ANY→10/8 permits**: 43
- **Permit to RFC1918 from ANY**: 43
- **Broad→Broad (CIDR ≤ /16 on both sides)**: 0
- **Sensitive services (22/3389/1433/1521/27017)**: 22=97, 3389=671, 1433=53, 1521=0, 27017=0

### Top Devices by Risky Rule Count

Hostname | Platform | Risky Rules
--|--:|--:
FRA-OSS-MX-FW-fw-oss->fw-oss-dcn | ASA | 13426
FRA-OSS-MX-FW-fw-oss->fw-oss-internal | ASA | 10092
FRA-OSS-MX-FW-fw-oss->fw-oss-mspmgmt | ASA | 8642
FRA-OSS-MX-FW-fw-oss->fw-oss-dmz | ASA | 6031
FRA-OSS-MX-FW-fw-oss->fw-oss-moss | ASA | 5134
FRA-OSS-MX-FW-fw-oss->fw-oss-interconnect | ASA | 3321
FRA-OSS-MX-FW-fw-oss->fw-oss-ext1 | ASA | 3239
FRA-OSS-MX-FW-fw-oss->fw-oss-overture | ASA | 2157
FRA-OSS-MX-FW-fw-oss->fw-oss-cus-soc | ASA | 670
FRA-OSS-MX-FW-fw-oss->fw-oss-prod-internal | ASA | 583

## Zero Hit Rules Summary (Permits only)

- **Total zero-hit permit rules**: 158898

### Top Devices by Zero-Hit Permit Rule Count

Hostname | Platform | Zero-Hit Permit Rules
--|--:|--:
FRA-OSS-MX-FW-fw-oss->fw-oss-dcn | ASA | 41765
FRA-OSS-MX-FW-fw-oss->fw-oss-internal | ASA | 31603
FRA-OSS-MX-FW-fw-oss->fw-oss-dmz | ASA | 22620
FRA-OSS-MX-FW-fw-oss->fw-oss-mspmgmt | ASA | 16918
FRA-OSS-MX-FW-fw-oss->fw-oss-interconnect | ASA | 10803
FRA-OSS-MX-FW-fw-oss->fw-oss-ext1 | ASA | 10144
FRA-OSS-MX-FW-fw-oss->fw-oss-moss | ASA | 9295
FRA-OSS-MX-FW-fw-oss->fw-oss-overture | ASA | 5778
FRA-OSS-MX-FW-fw-oss->fw-oss-cus-soc | ASA | 2567
FRA-OSS-MX-FW-fw-oss->fw-oss-voice-ims | ASA | 1756

### Top Zero-Hit Permit Rule IDs (Global, Top 15)

Rule ID | Count
--|--:
73 | 2923
72 | 1785
241 | 1534
18 | 1511
88 | 1431
19 | 1388
340 | 1213
132 | 1188
220 | 1154
224 | 1149
332 | 1140
89 | 1119
151 | 1000
43 | 975
186 | 946


_Heuristics: ANY includes 0.0.0.0/0 and synonyms. RFC1918 detection covers 10/8, 172.16/12, 192.168/16. Sensitive ports are matched by numbers and common labels. Broadness uses CIDR parsing when present. Zero-hit counts reflect **permits only**; age buckets require a 'timestamp' or 'ts' column._
