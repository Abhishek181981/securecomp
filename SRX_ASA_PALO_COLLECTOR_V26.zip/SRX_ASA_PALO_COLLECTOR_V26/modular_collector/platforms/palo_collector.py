# palo_collector.py – Option-A v4.4 (Multi-Token Rule Names + Table Hit-Count Parser + Hardened Prompt)
# PAN-Only | Pure Data Capture | Writes ONLY allow/permit rules

from __future__ import annotations
import re, os, hashlib, traceback
from datetime import datetime

# ------------------ Normalizer ------------------
def normalize_cli(s: str) -> str:
    return s or ''

# ------------------ FS Helpers ------------------
def _ensure_dir(p: str):
    try: os.makedirs(p, exist_ok=True)
    except: pass

def _abs_dir_from_hostmeta(hostmeta, default='reports/latest/logs'):
    if isinstance(hostmeta, dict):
        for k in ('latest_dir','log_dir','run_dir','workdir'):
            if hostmeta.get(k):
                try: return os.path.abspath(str(hostmeta[k]))
                except: pass
    return os.path.abspath(default)

# ------------------ CLI Helpers (v4 hardened) ------------------
def _safe_prompt(conn):
    try:
        p = (conn.find_prompt() or '').strip()
        if not p:
            return r"[>#]\s*$"
        if p.endswith(">") or p.endswith("#"):
            return re.escape(p) + r"\s*$"
        return r"[>#]\s*$"
    except:
        return r"[>#]\s*$"

def _is_config_mode_prompt(p: str) -> bool:
    p = (p or '').lower()
    return '(config' in p or p.endswith('#')

def _run(conn, cmd: str, timeout: int = 240) -> str:
    try:
        p = (conn.find_prompt() or '').strip()
    except:
        p = ''
    prompt = _safe_prompt(conn)
    op_cmd = cmd if (not _is_config_mode_prompt(p) or cmd.startswith('run ')) else ('run ' + cmd)

    try:
        out = conn.send_command(op_cmd, expect_string=prompt, read_timeout=timeout)
        if out and out.strip():
            return normalize_cli(out)
    except:
        pass

    try:
        out = conn.send_command_timing(op_cmd)
        return normalize_cli(out or '')
    except:
        return ''

# ------------------ Regex Primitives ------------------
IP_CIDR_RE  = re.compile(r"^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$")
IP_RANGE_RE = re.compile(r"^(\d{1,3}(?:\.\d{1,3}){3})-(\d{1,3}(?:\.\d{1,3}){3})$")
VSYS_RE     = re.compile(r"^vsys\s+(\S+)$", re.IGNORECASE)

RULE_HDR_RE = re.compile(r'^\s*"(?P<hdr>[^"\\]+)"\s*\{\s*$')
CLOSE_BRACE = re.compile(r'^\s*\}\s*$')

BRACKET_RE = re.compile(r"^\[(?P<body>.*)\]$")
WS_SPLIT   = re.compile(r"[\s,]+")

def _strip_semi(s: str) -> str:
    return (s or '').rstrip(';').strip()

def split_tokens(v: str):
    v = _strip_semi(v)
    if not v: return []
    m = BRACKET_RE.match(v)
    if m:
        body = (m.group('body') or '').strip()
        return [t for t in WS_SPLIT.split(body) if t]
    return [v]

# ------------------ PAN Object DB ------------------
ADDR_RE       = re.compile(r"\baddress\s+(\S+)\s+(ip-netmask|ip-range|fqdn)\s+(\S+)")
ADDR_GRP_M_RE = re.compile(r"\baddress-group\s+(\S+)\s+.*\[(?P<body>[^\]]+)\]")

SVC_RE        = re.compile(r"\bservice\s+(\S+)\s+protocol\s+(tcp|udp)\s+.*?(?:port|ports)\s+([^\s\]]+)")
SVC_GRP_M_RE  = re.compile(r"\bservice-group\s+(\S+)\s+.*\[(?P<body>[^\]]+)\]")

class PaloObjectDB:
    def __init__(self):
        self.addr = {}
        self.addrgr = {}
        self.svc = {}
        self.svcgr = {}

    def load_address(self, txt: str):
        for ln in (txt or '').splitlines():
            m = ADDR_RE.search(ln)
            if m:
                name, typ, val = m.group(1), m.group(2).lower(), m.group(3)
                self.addr[name] = (typ, val)
        for ln in (txt or '').splitlines():
            m = ADDR_GRP_M_RE.search(ln)
            if m:
                name = m.group(1)
                toks = [t for t in WS_SPLIT.split((m.group('body') or '').strip()) if t]
                if toks:
                    self.addrgr.setdefault(name, set()).update(toks)

    def load_service(self, txt: str):
        for ln in (txt or '').splitlines():
            m = SVC_RE.search(ln)
            if m:
                name, proto, ports = m.group(1), m.group(2).lower(), m.group(3)
                parts = [p for p in WS_SPLIT.split(ports.strip()) if p]
                if parts:
                    self.svc[name] = {f"{proto}/{p}" for p in parts}
        for ln in (txt or '').splitlines():
            m = SVC_GRP_M_RE.search(ln)
            if m:
                name = m.group(1)
                toks = [t for t in WS_SPLIT.split((m.group('body') or '').strip()) if t]
                if toks:
                    self.svcgr.setdefault(name, set()).update(toks)

    # Address expansion
    def _expand_addr_one(self, token: str, seen: set) -> set:
        if token in seen: return set()
        seen.add(token)
        t = token.strip()
        if t.lower() == 'any' or t == '0.0.0.0/0':
            return {'0.0.0.0/0'}
        if IP_CIDR_RE.match(t) or IP_RANGE_RE.match(t):
            return {t}
        if t in self.addr:
            typ, val = self.addr[t]
            if typ in ('ip-netmask','ip-range'):
                return {val}
            return set()
        if t in self.addrgr:
            out = set()
            for m in self.addrgr[t]:
                out |= self._expand_addr_one(m, seen)
            return out
        return set()

    def expand_addr(self, tokens: list[str]) -> list[str]:
        out = set()
        for t in (tokens or []):
            out |= self._expand_addr_one(t, set())
        if not out and tokens:
            for t in tokens:
                if t.lower() == 'any' or t == '0.0.0.0/0':
                    out.add('0.0.0.0/0')
                elif IP_CIDR_RE.match(t) or IP_RANGE_RE.match(t):
                    out.add(t)
        return sorted(out)

    # Service expansion
    def _expand_svc_one(self, token: str, seen: set) -> set:
        if token in seen: return set()
        seen.add(token)
        tl = (token or '').strip().lower()
        if tl in ('any','application-default'):
            return {tl}
        if re.match(r'^(tcp|udp)/[0-9]+(?:-[0-9]+)?$', tl):
            return {tl}
        if token in self.svc:
            return set(self.svc[token])
        if token in self.svcgr:
            out = set()
            for m in self.svcgr[token]:
                out |= self._expand_svc_one(m, seen)
            return out
        if tl.startswith('0:any') or tl == 'any/any/any/any' or tl.endswith('/any/any/any'):
            return {'any'}
        return set()

    def expand_svc(self, tokens: list[str]) -> list[str]:
        out = set()
        for t in (tokens or []):
            out |= self._expand_svc_one(t, set())
        return sorted(out)

# ------------------ VSYS ------------------
def list_vsys(conn):
    txt = _run(conn, 'show vsys') or ''
    out = []
    for ln in txt.splitlines():
        m = VSYS_RE.match(ln.strip())
        if m:
            out.append(m.group(1))
    return out or ['vsys1']

# ------------------ v4.4 HIT-COUNT PARSER ------------------
def parse_hitcount(txt: str) -> dict:
    hits = {}
    lines = (txt or "").splitlines()

    # 1) Detect new table format
    header_idx = None
    for i, ln in enumerate(lines):
        if "Rule Name" in ln and "Hit Count" in ln:
            header_idx = i
            break

    if header_idx is not None:
        # Skip header and separator
        for ln in lines[header_idx+2:]:
            if not ln.strip():
                continue

            parts = ln.split()
            if len(parts) < 4:
                continue

            # Identify VSYS column
            vsys_index = None
            for idx, tok in enumerate(parts):
                if tok.lower().startswith("vsys"):
                    vsys_index = idx
                    break
            if vsys_index is None:
                continue

            # Rule name: everything before VSYS
            rule_tokens = parts[:vsys_index]
            rule = " ".join(rule_tokens).strip()

            # Hit count: token after VSYS
            if vsys_index+1 < len(parts):
                count = parts[vsys_index+1]
                if count.isdigit():
                    hits[rule] = count

    # 2) Legacy fallback
    legacy_re = re.compile(
        r'Rule\s+"(?P<name>[^"]+)"\s+hit-count\s+(?P<count>\d+)',
        re.IGNORECASE
    )
    for ln in lines:
        m = legacy_re.search(ln)
        if m:
            hits[m.group("name")] = m.group("count")

    return hits

# ------------------ Main collect() ------------------
def collect(session, hostmeta, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky):

    hostname = (hostmeta.get('hostname') or hostmeta.get('ip') or 'palo') if isinstance(hostmeta, dict) else 'palo'
    platform = 'Palo Alto'
    latest_dir = _abs_dir_from_hostmeta(hostmeta)
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
    log_path = os.path.join(latest_dir, f"{hostname}_palo_{ts}.log")

    try:
        # leave config mode
        try:
            p = (session.find_prompt() or '').strip()
            if p.endswith('#'):
                session.send_command('exit', expect_string=r"[>#]\s*$")
        except:
            pass

        ips_txt    = _run(session, 'show interface all')
        routes_txt = _run(session, 'show routing route')

        vsys_list = list_vsys(session)

        for v in vsys_list:
            _run(session, f"set system setting target-vsys {v}")

            objdb = PaloObjectDB()
            addr_txt = (_run(session, 'show running address') or '') + '\n' + (_run(session, 'show running address-group') or '')
            svc_txt  = (_run(session, 'show running service') or '') + '\n' + (_run(session, 'show running service-group') or '')

            objdb.load_address(addr_txt)
            objdb.load_service(svc_txt)

            # Correct syntax
            hit_cmd = f"show rule-hit-count vsys vsys-name {v} rule-base security rules all"
            hit_txt = _run(session, hit_cmd) or ""
            hits = parse_hitcount(hit_txt)

            # Parse security policy
            pol_txt = _run(session, 'show running security-policy') or ''
            lines = pol_txt.splitlines()
            i = 0

            while i < len(lines):
                line = lines[i].rstrip()
                m_hdr = RULE_HDR_RE.match(line)
                if not m_hdr:
                    i += 1
                    continue

                hdr = m_hdr.group('hdr').strip()
                rule_name = hdr.split(';', 1)[0].strip().strip('"') or 'rule'

                i += 1
                bloc = []
                brace_found = False
                while i < len(lines):
                    ln = lines[i].rstrip()
                    if CLOSE_BRACE.match(ln):
                        brace_found = True
                        i += 1
                        break
                    bloc.append(ln.strip())
                    i += 1

                if not brace_found:
                    continue

                rec = {
                    'name': rule_name,
                    'from': '',
                    'to': '',
                    'source': 'any',
                    'destination': 'any',
                    'service': '',
                    'action': ''
                }

                for ln in bloc:
                    low = ln.lower()
                    if low.startswith('from '):
                        rec['from'] = _strip_semi(ln.split(None,1)[1])
                    elif low.startswith('to '):
                        rec['to'] = _strip_semi(ln.split(None,1)[1])
                    elif low.startswith('application/service '):
                        val = _strip_semi(ln.split(None,1)[1])
                        rec['service'] = 'any' if val.startswith('0:any') or 'any/any/any/any' in val else val
                    elif low.startswith('service '):
                        rec['service'] = _strip_semi(ln.split(None,1)[1])
                    elif low.startswith('source '):
                        rec['source'] = _strip_semi(ln.split(None,1)[1])
                    elif low.startswith('destination '):
                        rec['destination'] = _strip_semi(ln.split(None,1)[1])
                    elif low.startswith('action '):
                        rec['action'] = _strip_semi(ln.split(None,1)[1]).lower()

                if rec['action'] not in ('allow','permit'):
                    continue

                src_tokens = split_tokens(rec['source'])
                dst_tokens = split_tokens(rec['destination'])
                svc_tokens = split_tokens(rec['service']) if rec.get('service') else []

                exp_src  = objdb.expand_addr(src_tokens)
                exp_dst  = objdb.expand_addr(dst_tokens)

                if svc_tokens:
                    if any(t.lower() in ('any','application-default') for t in svc_tokens):
                        exp_ports = [svc_tokens[0].lower()]
                    else:
                        exp_ports = objdb.expand_svc(svc_tokens)
                else:
                    exp_ports = []

                def join_pipe(vals):
                    safe = [str(v).replace(',', ';') for v in (vals or [])]
                    return '|'.join(safe) if safe else ''

                src_out   = join_pipe(exp_src) if exp_src else (join_pipe(['any']) if any(t.lower()=='any' for t in src_tokens) else join_pipe(src_tokens))
                dst_out   = join_pipe(exp_dst) if exp_dst else (join_pipe(['any']) if any(t.lower()=='any' for t in dst_tokens) else join_pipe(dst_tokens))
                ports_out = join_pipe(exp_ports) if exp_ports else ''

                remark = f"exp_src=[{src_out or 'any'}]; exp_dst=[{dst_out or 'any'}]; exp_ports=[{ports_out}]"

                raw_ace = (
                    f"set rulebase security rules {rec['name']} "
                    f"from {rec['from'] or 'any'} to {rec['to'] or 'any'} "
                    f"source {rec['source'] or 'any'} destination {rec['destination'] or 'any'} "
                    f"action allow" + (f" service {rec['service']}" if rec.get('service') else '')
                ).strip()

                ace_hash = hashlib.md5(raw_ace.encode('utf-8')).hexdigest()

                writer_acls.writerow({
                    'hostname': hostname,
                    'platform': platform,
                    'rule_id': rec['name'],
                    'action': 'allow',
                    'src': src_out or rec['source'],
                    'dst': dst_out or rec['destination'],
                    'hit_count': hits.get(rec['name'], ''),
                    'ace_hash': ace_hash,
                    'remark': remark,
                    'raw_ace': raw_ace,
                })

            _run(session, "set system setting target-vsys none")

        # IPs
        for ln in (ips_txt or '').splitlines():
            ln = ln.strip()
            if not ln or '/' not in ln:
                continue
            parts = ln.split()
            if len(parts) >= 2:
                iface, ipmask = parts[0], parts[1]
                if '/' in ipmask:
                    ip, m = ipmask.split('/',1)
                    writer_ips.writerow({
                        'hostname':hostname,'platform':platform,
                        'interface':iface,'ip':ip,'mask':m
                    })

        # Routes
        for ln in (routes_txt or '').splitlines():
            ln = ln.strip()
            if not ln or '/' not in ln: continue
            parts = ln.split()
            route = parts[0]
            nexthop = parts[1] if len(parts) > 1 else ''
            writer_routes.writerow({
                'hostname':hostname,
                'platform':platform,
                'vrf':'default',
                'route':route,
                'nexthop':nexthop
            })

        return routes_txt or '', ips_txt or '', ''

    except Exception:
        tb = traceback.format_exc()
        _ensure_dir(os.path.dirname(log_path))
        with open(log_path,'w',encoding='utf-8',errors='replace') as f:
            f.write(tb)
        return '', '', ''