﻿# -*- coding: utf-8 -*-
"""
ASA vendor collector — MULTI-CONTEXT + UNIFIED RISK LABELS + CORRECT SUBNET PARSING
+ BACK-COMPAT CATEGORY TOKENS FOR DASHBOARD (graphs) — CATEGORIES v2

Adds 'category:<label>' tokens so existing dashboard charts can see risky categories
without changing the dashboard code. We keep 'risk:<tag>' tokens too.

Categories emitted (examples):
- category:ANY→ANY
- category:ANY source
- category:ANY destination
- category:ANY→RFC1918
- category:ANY→10.0.0.0/8
- category:Port 3389 rules (for detected risky ports)
- category:Broad↔Broad (both src & dst broad /16 or wider)
- category:Broad source (only source broad)
- category:Broad destination (only destination broad)
- category:ICMP rules

Other features preserved:
- Multi-context automation; hostname->context decoration; permit-only (DENY skipped)
- Correct src/dst parsing (any/host/ip+mask/object-group/interface)
- Unified Risk labels: risk:any_src_or_dst, risk:any_any, risk:broad_src, risk:broad_dst, risk:broad_both,
  risk:port:<num>, risk:icmp
Environment knobs:
- ASA_RISKY_PORTS="80,21,22,23,443,445,3389,1433,1521" (override default list)
- (Future) BROAD_PREFIX_MAX (currently fixed at 16 inside function)
"""
from __future__ import annotations
from typing import Optional, List, Tuple, Dict
import os
import re

PROMPT = r"#"
READ_TO = 60
_DEF_PORTS = [80,21,22,23,443,445,3389,1433,1521,5900,25,110,143,53,123,161,162]
_env_ports = os.environ.get('ASA_RISKY_PORTS', '')
try:
    if _env_ports.strip():
        RISKY_PORTS = sorted({int(x.strip()) for x in _env_ports.split(',') if x.strip().isdigit()})
    else:
        RISKY_PORTS = _DEF_PORTS
except Exception:
    RISKY_PORTS = _DEF_PORTS

# ---------------- Netmiko helpers ----------------

def _sc(session, cmd: str, expect: str = PROMPT, timeout: int = READ_TO) -> str:
    return session.send_command(cmd, expect_string=expect, read_timeout=timeout, strip_prompt=False, strip_command=False)

def _enter_enable(session) -> None:
    try:
        session.enable()
    except Exception:
        pass

def _changeto_system(session) -> None:
    try:
        _sc(session, 'changeto system', timeout=20)
    except Exception:
        pass

def _is_multi_context(session) -> bool:
    try:
        out = _sc(session, 'show mode', timeout=20)
        return 'multiple' in out.lower()
    except Exception:
        try:
            out = _sc(session, 'show context', timeout=20)
            return ('Context' in out and 'Mode' in out) or ('changeto context' in out.lower())
        except Exception:
            return False

def _list_contexts(session) -> List[str]:
    _changeto_system(session)
    out = _sc(session, 'show context', timeout=30)
    ctxs: set[str] = set()
    for line in out.splitlines():
        s = line.strip(); lo = s.lower()
        if not s: continue
        if lo.startswith(('context','system','admin','status','mode','current','changeto')): continue
        if set(s) <= set('- '): continue
        parts = s.split()
        if parts and len(parts[0])>1 and parts[0][0].isalnum():
            name = parts[0]
            if name.lower() not in ('system','admin'): ctxs.add(name)
    for name in re.findall(r"Context\s+Name\s*:\s*([A-Za-z0-9_.-]+)", out, flags=re.IGNORECASE):
        if name.lower() not in ('system','admin'): ctxs.add(name)
    return sorted(ctxs)

def _switch_context(session, ctx: str) -> None:
    _sc(session, f'changeto context {ctx}', expect=PROMPT, timeout=20)

# ---------------- Parsers ----------------

def _mask_to_prefix(mask: str) -> int:
    try:
        parts = [int(x) for x in mask.split('.')]
        bits = ''.join(f"{p:08b}" for p in parts)
        return bits.count('1')
    except Exception:
        return 0

def _parse_routes(text: str, hostname: str, platform: str, vrf: str = "") -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s: continue
        m1 = re.search(r"(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)
        m2 = re.search(r"\bvia\s+(\d+\.\d+\.\d+\.\d+)", s)
        if m1:
            route = f"{m1.group(1)}/{_mask_to_prefix(m1.group(2))}"
            nexthop = m2.group(1) if m2 else ''
            rows.append({'hostname': hostname, 'platform': platform, 'vrf': vrf, 'route': route, 'nexthop': nexthop})
    return rows

def _parse_ips_interface_brief(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.lower().startswith(('interface','nameif','ip address')): continue
        m = re.match(r"^(\S+)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)
        if m:
            rows.append({'hostname': hostname, 'platform': platform, 'interface': m.group(1), 'ip': m.group(2), 'mask': m.group(3)})
    return rows

def _parse_ips_show_ip(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for line in text.splitlines():
        s = line.strip()
        m = re.search(r"(?i)interface\s+(\S+).*?\b(ip\s+address\s+|addr\s+)\s*(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)
        if m:
            rows.append({'hostname': hostname, 'platform': platform, 'interface': m.group(1), 'ip': m.group(3), 'mask': m.group(4)})
    return rows

def _parse_acl_line(line: str) -> Dict[str, str]:
    d: Dict[str, str] = {'rule_id':'','action':'','src':'','dst':'','hit_count':'','ace_hash':'','remark':'','raw_ace': line.strip()}
    s = line.strip()
    mrem = re.search(r"(?i)\bremark\b\s+(.*)$", s)
    if mrem: d['remark'] = mrem.group(1).strip()
    mid = re.search(r"(?i)\bline\s+(\d+)\b", s)
    if mid: d['rule_id'] = mid.group(1)
    mact = re.search(r"(?i)\b(permit|deny)\b", s)
    if mact: d['action'] = mact.group(1).lower()
    mhit = re.search(r"(?i)hitcnt\s*=\s*(\d+)", s)
    if mhit: d['hit_count'] = mhit.group(1)
    mhash = re.search(r"(0x[0-9A-Fa-f]+)\s*$", s)
    if mhash: d['ace_hash'] = mhash.group(1)

    def is_ip(tok: str) -> bool:
        return re.match(r"^\d+\.\d+\.\d+\.\d+$", tok or '') is not None

    def parse_addr(tokens, i: int):
        if i >= len(tokens): return '', i
        t = tokens[i].lower()
        if t in ('any','any4','any6'): return 'any', i+1
        if t == 'host' and (i+1)<len(tokens) and is_ip(tokens[i+1]):
            return f"{tokens[i+1]}-255.255.255.255", i+2
        if is_ip(tokens[i]) and (i+1)<len(tokens) and is_ip(tokens[i+1]):
            return f"{tokens[i]}-{tokens[i+1]}", i+2
        if t == 'object-group' and (i+1)<len(tokens):
            return f"og:{tokens[i+1]}", i+2
        if t == 'interface' and (i+1)<len(tokens):
            return f"iface:{tokens[i+1]}", i+2
        return tokens[i], i+1

    tokens = s.split()
    try:
        idx = next(i for i,t in enumerate(tokens) if t.lower() in ('permit','deny'))
        addr_i = idx + 2  # after protocol
        src_val, j = parse_addr(tokens, addr_i)
        dst_val, k = parse_addr(tokens, j)
        if src_val: d['src'] = src_val
        if dst_val: d['dst'] = dst_val
    except Exception:
        pass

    # fallback naive
    if not d['src'] or not d['dst']:
        iptoks = re.findall(r"(\d+\.\d+\.\d+\.\d+)", s)
        if len(iptoks)>=2:
            if not d['src']: d['src'] = iptoks[0]
            if not d['dst']: d['dst'] = iptoks[1]
        elif len(iptoks)==1 and not d['src']:
            d['src'] = iptoks[0]
    return d

# ---- Helpers for category tokens ----

def _is_rfc1918(ip_mask: str) -> bool:
    # match common forms: '10.0.0.0-255.255.0.0', 'og:<name>', 'any' etc.
    if not ip_mask or ip_mask.startswith(('og:','iface:','any')):
        return False
    return (
        ip_mask.startswith('10.') and '-255.0.0.0' in ip_mask or
        ip_mask.startswith('172.16.') and '-255.240.0.0' in ip_mask or
        ip_mask.startswith('192.168.') and '-255.255.0.0' in ip_mask
    )

def _is_any(v: str) -> bool:
    return (v or '').lower() == 'any'

def _dst_specifics(dst: str) -> List[str]:
    cats: List[str] = []
    if dst.startswith('10.0.0.0-255.0.0.0'):
        cats.append('category:ANY→10.0.0.0/8')
    if _is_rfc1918(dst):
        cats.append('category:ANY→RFC1918')
    return cats

# ---------------- ACLs & Risk ----------------

def _parse_acls(text: str, hostname: str, platform: str) -> Tuple[List[Dict[str, str]], List[Dict[str, str]], List[Dict[str, str]]]:
    acls: List[Dict[str, str]] = []
    zero: List[Dict[str, str]] = []
    risky: List[Dict[str, str]] = []
    auto_rule_id = 0

    def _mask_to_prefix_local(mask: str) -> int:
        try:
            parts = [int(x) for x in mask.split('.')]
            bits = ''.join(f"{p:08b}" for p in parts)
            return bits.count('1')
        except Exception:
            return 0

    for raw in text.splitlines():
        s = raw.strip()
        if not s: continue
        if 'access-list' not in s.lower() and 'remark' not in s.lower(): continue
        entry = _parse_acl_line(s)
        if (entry['action'] or '').lower() == 'deny':
            continue  # skip deny entirely
        auto_rule_id += 1
        if not entry['rule_id']: entry['rule_id'] = str(auto_rule_id)
        row = {
            'hostname': hostname,
            'platform': platform,
            'rule_id': entry['rule_id'],
            'action': entry['action'],
            'src': entry['src'],
            'dst': entry['dst'],
            'hit_count': entry['hit_count'],
            'ace_hash': entry['ace_hash'],
            'remark': entry['remark'],
            'raw_ace': entry['raw_ace'],
        }
        acls.append(row)
        if (row['hit_count'] == '0') or ('hitcnt=0' in s.lower()):
            zero.append(row.copy())

        if (entry['action'] or '').lower() == 'permit':
            tags: List[str] = []
            cats: List[str] = []
            sl = s.lower(); padded = ' ' + sl + ' '

            # any-ish / any-any
            any_src = _is_any(entry['src'])
            any_dst = _is_any(entry['dst'])
            any_count = 0
            for tok in (' any ', ' any4 ', ' any6 ', ' any, ', ',any '): any_count += padded.count(tok)
            if '0.0.0.0 0.0.0.0' in sl: any_count += 1
            if any_count >= 1: tags.append('risk:any_src_or_dst')
            if any_count >= 2: tags.append('risk:any_any')
            # categories on ACL rows
            if any_src and any_dst:
                cats.append('category:ANY→ANY')
            else:
                if any_src: cats.append('category:ANY source')
                if any_dst:
                    cats.append('category:ANY destination')
                    cats.extend(_dst_specifics(entry['dst']))

            # broad subnets (use first 2 ip/mask pairs as src/dst approximation)
            pairs = re.findall(r"(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", s)
            broad_src = False; broad_dst = False
            if len(pairs)>=1:
                p1 = _mask_to_prefix_local(pairs[0][1])
                if p1 and p1 <= 16:
                    tags.append('risk:broad_src'); broad_src = True
            if len(pairs)>=2:
                p2 = _mask_to_prefix_local(pairs[1][1])
                if p2 and p2 <= 16:
                    tags.append('risk:broad_dst'); broad_dst = True
            if broad_src and broad_dst:
                tags.append('risk:broad_both')
                cats.append('category:Broad↔Broad')
            else:
                if broad_src: cats.append('category:Broad source')
                if broad_dst: cats.append('category:Broad destination')

            # risky ports
            matched_ports: List[int] = []
            for port in RISKY_PORTS:
                if (f' eq {port}' in sl) or (f' tcp/{port}' in sl) or (f' udp/{port}' in sl):
                    tags.append(f'risk:port:{port}')
                    matched_ports.append(port)
            for p in matched_ports:
                cats.append(f'category:Port {p} rules')

            # icmp
            is_icmp = (' icmp' in padded) or (' protocol icmp' in sl) or (' icmp-type any' in sl)
            if is_icmp:
                tags.append('risk:icmp')
                cats.append('category:ICMP rules')

            if tags or cats:
                # de-duplicate preserving order
                def dedup(seq: List[str]) -> List[str]:
                    seen=set(); out=[]
                    for x in seq:
                        if x not in seen:
                            seen.add(x); out.append(x)
                    return out
                tags = dedup(tags); cats = dedup(cats)

                # risky copy: risk tags + categories in remark (for evidence)
                rrow = row.copy()
                suffix = ' '.join(tags + cats)
                rrow['remark'] = (rrow.get('remark','') + ('; ' if rrow.get('remark') else '') + suffix)
                risky.append(rrow)

                # base ACL row: append ONLY categories (so dashboards scanning ACL remarks can chart)
                if cats:
                    base_suffix = ' '.join(cats)
                    row['remark'] = (row.get('remark','') + ('; ' if row.get('remark') else '') + base_suffix)
                    acls[-1] = row
    return acls, zero, risky

# ---------------- Objects ----------------

def _parse_object_groups(text: str, hostname: str, platform: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    cur_type = ''; cur_name = ''; metadata = ''
    for raw in text.splitlines():
        s = raw.strip()
        if not s: continue
        mg = re.match(r"(?i)^object-group\s+(network|service|protocol)\s+(\S+)(?:\s+(\S+))?", s)
        if mg:
            cur_type = mg.group(1).lower(); cur_name = mg.group(2); metadata = mg.group(3) or ''
            continue
        if s.lower().startswith(('network-object','service-object','group-object','port-object')):
            rows.append({'hostname': hostname,'platform': platform,'type': cur_type or '','name': cur_name or '','group': cur_name or '','member': s.split()[0].lower(),'value': ' '.join(s.split()[1:]) if len(s.split())>1 else '','metadata': metadata})
    return rows

# ---------------- Public API ----------------

def get_asa_objects_text(session) -> str:
    try:
        return _sc(session, 'show running-config object-group', timeout=40)
    except Exception:
        return ''

def _collect_one_context(session, host: str, platform: str,
                         writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky,
                         ctx_name: Optional[str] = None) -> Tuple[str, str, str]:
    try: _sc(session, 'show privilege', timeout=20)
    except Exception: pass

    routes_txt = ''
    try:
        routes_txt = _sc(session, 'show route', timeout=55)
        for r in _parse_routes(routes_txt, host, platform, vrf=(ctx_name or '')): writer_routes.writerow(r)
    except Exception: pass

    ips_txt = ''
    try:
        txt = _sc(session, 'show interface ip brief', timeout=45)
        rows = _parse_ips_interface_brief(txt, host, platform)
        if not rows:
            txt = _sc(session, 'show ip', timeout=45)
            rows = _parse_ips_show_ip(txt, host, platform)
        ips_txt = txt
        for r in rows: writer_ips.writerow(r)
    except Exception: pass

    acls_txt = ''
    try:
        acls_txt = _sc(session, 'show access-list', timeout=95)
        a_rows, z_rows, rk_rows = _parse_acls(acls_txt, host, platform)
        for r in a_rows: writer_acls.writerow(r)
        for r in z_rows: writer_zero.writerow(r)
        for r in rk_rows: writer_risky.writerow(r)
    except Exception: pass

    try:
        og_txt = get_asa_objects_text(session)
        if og_txt:
            for r in _parse_object_groups(og_txt, host, platform): writer_objs.writerow(r)
    except Exception: pass

    return routes_txt or '', ips_txt or '', acls_txt or ''


def collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky, context_filter=None):
    host = row.get('hostname') or row.get('ip') or 'asa'
    platform = row.get('platform') or 'ASA'
    _enter_enable(session)

    mode = (row.get('mode') or '').strip().lower()
    explicit_ctx = (row.get('context') or '').strip()

    ctxs: List[Optional[str]] = []
    auto_multi = False
    try: auto_multi = _is_multi_context(session)
    except Exception: auto_multi = False

    if mode == 'multi' or auto_multi:
        if context_filter:
            ctxs = [c.strip() for c in context_filter if c and c.strip()]
        elif explicit_ctx:
            ctxs = [c.strip() for c in explicit_ctx.split(',') if c.strip()]
        else:
            _changeto_system(session); ctxs = _list_contexts(session)
        if not ctxs: ctxs = [None]
    else:
        ctxs = [None]

    agg_routes = ''; agg_ips = ''; agg_acls = ''
    for ctx in ctxs:
        try:
            host_for_ctx = f"{host}->{ctx}" if ctx else host
            if ctx:
                _switch_context(session, ctx); _enter_enable(session)
            r_txt, i_txt, a_txt = _collect_one_context(session, host_for_ctx, platform, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky, ctx_name=ctx)
            agg_routes += r_txt; agg_ips += i_txt; agg_acls += a_txt
        except Exception:
            continue
    return agg_routes, agg_ips, agg_acls
