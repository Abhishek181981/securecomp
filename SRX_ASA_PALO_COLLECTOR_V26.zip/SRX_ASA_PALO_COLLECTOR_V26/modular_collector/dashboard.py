﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dashboard risky ACL extractor (patched v3 + port alias fix + ANY splits)
- Enrich per-row `risk` with canonical KPI tokens BEFORE writing CSVs
- Adds port alias tokens (port80/p80 and port21/p21) whenever port=80/21 is detected
- Adds explicit `any_to_10` token for ANY→10/8 cases
- Computes dashboard.csv counts STRICTLY from row tokens + hit_count, including used/zero splits for any_src/any_dst/any_to_10
- Prints a concise sanity summary after generation
"""
import os, csv, re, time
from typing import List, Dict

RISKY_EXCLUDES_ZERO = os.environ.get("RISKY_EXCLUDES_ZERO", "true").strip().lower() in ("1","true","yes","on")
REPORTS_DIR_ENV = os.environ.get("REPORTS_DIR", "").strip()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _detect_reports_dir() -> str:
    if REPORTS_DIR_ENV and os.path.isdir(REPORTS_DIR_ENV):
        return os.path.abspath(REPORTS_DIR_ENV)
    candidates = [
        os.path.join(BASE_DIR, 'reports', 'latest'),
        os.path.join(BASE_DIR, 'modular_collector', 'reports', 'latest'),
        os.path.join(os.path.dirname(BASE_DIR), 'modular_collector', 'reports', 'latest'),
    ]
    for d in candidates:
        if os.path.isdir(d):
            return os.path.abspath(d)
    return os.path.abspath(candidates[0])

REPORTS_DIR = _detect_reports_dir()
ACL_PATH   = os.path.join(REPORTS_DIR, 'acls.csv')
RISKY_PATH = os.path.join(REPORTS_DIR, 'risky_acl.csv')
RISKY_ALL  = os.path.join(REPORTS_DIR, 'risky_all.csv')
DASHBOARD_CSV= os.path.join(REPORTS_DIR, 'dashboard.csv')
ZERO_PATH  = os.path.join(REPORTS_DIR, 'zero_acl.csv')
RISKY_ZERO = os.path.join(REPORTS_DIR, 'risky_zero_acl.csv')

ANY_TOKENS = {"0.0.0.0/0", "any", "any-ip", "any4"}
SENSITIVE_PORTS = {80, 21}
SVC_NAME_TO_PORT = {'www': 80, 'http': 80, 'ftp': 21}

FIELDS_IN  = ['hostname','platform','rule_id','action','src','dst','hit_count','ace_hash','remark','raw_ace']
FIELDS_OUT = ['hostname','platform','rule_id','action','src','dst','hit_count','ace_hash','remark','raw_ace','risk','risk_description']

_ts = lambda: time.strftime('%Y-%m-%d %H:%M:%S')

def _split_multi(v: str) -> List[str]:
    v = (v or '').strip()
    if not v: return []
    if '\n' in v: return [t.strip() for t in v.split('\n') if t.strip()]
    if '\r' in v: return [t.strip() for t in v.split('\r') if t.strip()]
    return [v]

def _mask(s: str):
    s = (s or '').strip()
    if '/' in s:
        try: return int(s.split('/')[-1])
        except Exception: return None
    return None

def _is_any(token: str) -> bool:
    return (token or '').strip().lower() in ANY_TOKENS

def _is_broad(token: str) -> bool:
    m = _mask(token)
    return (m is not None) and (m <= 16)

def _is_rfc1918(ip_or_cidr: str) -> bool:
    v = (ip_or_cidr or "").strip().lower()
    if v.startswith("10.") or v.startswith("10/"): return True
    if v.startswith("192.168.") or v.startswith("192.168/"): return True
    if v.startswith("172."):
        try:
            oct2 = int(v.split(".")[1].split("/")[0])
            return 16 <= oct2 <= 31
        except Exception:
            return False
    return False

def _is_10net(ip_or_cidr: str) -> bool:
    v = (ip_or_cidr or '').strip()
    return v.startswith('10.') or v.startswith('10/')

def _hit_count_int(v) -> int:
    try: return int(str(v).strip() or "0")
    except Exception: return 0

def _is_permit_row(r):
    a = (r.get('action','') or '').strip().lower()
    return a.startswith('permit') or a.startswith('allow')

def _reasons_from_categories(remark: str) -> List[str]:
    reasons = []
    r = (remark or '')
    if 'category:ANY→ANY' in r: reasons += ['any_src', 'any_dst', 'any_any']
    if 'category:ANY source' in r: reasons.append('any_src')
    if 'category:ANY destination' in r: reasons.append('any_dst')
    if 'category:Broad↔Broad' in r: reasons += ['broad_src','broad_dst','broad_both']
    if 'category:Broad source' in r: reasons.append('broad_src')
    if 'category:Broad destination' in r: reasons.append('broad_dst')
    out, seen = [], set()
    for t in reasons:
        if t not in seen:
            seen.add(t); out.append(t)
    return out

def _parse_exp_ports_from_remark(remark: str) -> List[str]:
    if not remark: return []
    m = re.search(r'exp_ports=\[(.*?)\]', remark)
    if not m: return []
    inner = m.group(1).strip()
    if not inner: return []
    if '\n' in inner: return [t.strip() for t in inner.split('\n') if t.strip()]
    if '\r' in inner: return [t.strip() for t in inner.split('\r') if t.strip()]
    return [inner]

def _mentions_sensitive_port(remark: str, exp_ports: List[str], raw_ace: str = '') -> List[str]:
    reasons = []
    for p in exp_ports:
        try:
            if '/' in p:
                num = int(p.split('/')[-1])
                if num in SENSITIVE_PORTS:
                    tag = f'port={num}'
                    if tag not in reasons: reasons.append(tag)
        except Exception:
            pass
    low_r = (remark or '').lower()
    for sp in SENSITIVE_PORTS:
        if f":{sp}" in low_r or f"/{sp}" in low_r:
            tag = f'port={sp}'
            if tag not in reasons: reasons.append(tag)
    low_a = (raw_ace or '').lower()
    padded = f" {low_a} "
    for sp in SENSITIVE_PORTS:
        if (f" eq {sp}" in low_a) or (f"/{sp}" in low_a):
            tag = f'port={sp}'
            if tag not in reasons: reasons.append(tag)
    for name, mapped in SVC_NAME_TO_PORT.items():
        if (f" eq {name}" in low_a) or (f"/{name}" in low_a) or (f" {name} " in padded):
            if mapped in SENSITIVE_PORTS:
                tag = f'port={mapped}'
                if tag not in reasons: reasons.append(tag)
    return reasons

def main() -> int:
    print(f"[{_ts()}] Using REPORTS_DIR = {REPORTS_DIR}")
    print(f"[{_ts()}] ACL_PATH = {ACL_PATH}")
    if not os.path.isfile(ACL_PATH):
        print(f"[{_ts()}] acls.csv not found: {ACL_PATH}")
        return 2

    risky_rows: List[Dict[str,str]] = []
    all_acls:   List[Dict[str,str]] = []

    with open(ACL_PATH, 'r', encoding='utf-8') as f:
        dr = csv.DictReader(f)
        for row in dr:
            for k in FIELDS_IN: row.setdefault(k, '')
            all_acls.append(row)
            if not _is_permit_row(row):
                continue

            src_list = _split_multi(row['src'])
            dst_list = _split_multi(row['dst'])
            remark   = row.get('remark','')
            raw_ace  = row.get('raw_ace','')

            tokens: List[str] = []
            if any(_is_any(s) for s in src_list): tokens.append('any_src')
            if any(_is_any(d) for d in dst_list): tokens.append('any_dst')
            if 'any_src' in tokens and 'any_dst' in tokens: tokens.append('any_any')
            broad_s = any(_is_broad(s) for s in src_list)
            broad_d = any(_is_broad(d) for d in dst_list)
            if broad_s: tokens.append('broad_src')
            if broad_d: tokens.append('broad_dst')
            if broad_s and broad_d: tokens.append('broad_both')

            exp_ports = _parse_exp_ports_from_remark(remark)
            tokens += [r for r in _mentions_sensitive_port(remark, exp_ports, raw_ace) if r not in tokens]

            # Port synonyms
            if 'port=80' in tokens:
                for alias in ('port80','p80'):
                    if alias not in tokens: tokens.append(alias)
            if 'port=21' in tokens:
                for alias in ('port21','p21'):
                    if alias not in tokens: tokens.append(alias)

            tokens += [r for r in _reasons_from_categories(remark) if r not in tokens]

            # Safety for names
            if 'http' in tokens and 'port=80' not in tokens:
                tokens.append('port=80')
                for alias in ('port80','p80'):
                    if alias not in tokens: tokens.append(alias)
            if 'ftp' in tokens and 'port=21' not in tokens:
                tokens.append('port=21')
                for alias in ('port21','p21'):
                    if alias not in tokens: tokens.append(alias)

            low_a = (raw_ace or '').lower(); low_r = (remark or '').lower()
            is_icmp = (' icmp' in low_a or 'icmp/' in low_a or ' icmp' in low_r or 'icmp/' in low_r)
            if is_icmp and 'icmp' not in tokens: tokens.append('icmp')

            # RFC1918 / 10/8
            dst_is_rfc = any(_is_rfc1918(d) for d in dst_list)
            dst_is_10  = any(_is_10net(d) for d in dst_list)
            if 'any_src' in tokens and dst_is_rfc and 'any_to_rfc' not in tokens:
                tokens.append('any_to_rfc')
            if 'any_src' in tokens and dst_is_10 and 'any_to_10' not in tokens:
                tokens.append('any_to_10')
            if (broad_s or broad_d) and dst_is_rfc and 'broad_rfc1918' not in tokens:
                tokens.append('broad_rfc1918')

            if 'broad_both' in tokens and 'broad_to_broad' not in tokens:
                tokens.append('broad_to_broad')

            existing = [t.strip() for t in (row.get('risk','') or '').split(',') if t.strip()]
            merged = existing[:]
            for t in tokens:
                if t not in merged: merged.append(t)
            if not merged:
                continue

            out = {k: (row.get(k,'') or '') for k in FIELDS_IN}
            out['risk'] = ','.join(merged)
            out['risk_description'] = ' '.join(merged)
            risky_rows.append(out)

    risky_rows_all = list(risky_rows)
    risky_used_rows: List[Dict[str,str]] = []
    risky_zero_rows: List[Dict[str,str]] = []
    for rr in risky_rows_all:
        if not _is_permit_row(rr):
            continue
        hc = _hit_count_int(rr.get('hit_count',''))
        if hc > 0:
            risky_used_rows.append(rr)
        else:
            toks = [t.strip() for t in (rr.get('risk','') or '').split(',') if t.strip()]
            if 'risky_zero_hit' not in toks:
                toks.append('risky_zero_hit')
                rr['risk'] = ','.join(toks)
                rr['risk_description'] = ' '.join(toks)
            risky_zero_rows.append(rr)

    os.makedirs(REPORTS_DIR, exist_ok=True)
    with open(RISKY_PATH, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=FIELDS_OUT, extrasaction='ignore')
        dw.writeheader()
        use_rows = (risky_used_rows if RISKY_EXCLUDES_ZERO else risky_rows_all)
        for r in use_rows: dw.writerow(r)
    print(f"[{_ts()}] risky_acl.csv written: {len(use_rows)} rows")

    with open(RISKY_ALL, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=FIELDS_OUT, extrasaction='ignore')
        dw.writeheader()
        for r in risky_rows_all: dw.writerow(r)
    print(f"[{_ts()}] risky_all.csv written: {len(risky_rows_all)} rows")

    with open(RISKY_ZERO, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=FIELDS_OUT, extrasaction='ignore')
        dw.writeheader()
        for r in risky_zero_rows: dw.writerow(r)
    print(f"[{_ts()}] risky_zero_acl.csv written: {len(risky_zero_rows)} rows")

    zero_rows = [r for r in all_acls if _is_permit_row(r) and _hit_count_int(r.get('hit_count','')) == 0]
    with open(ZERO_PATH, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=FIELDS_IN, extrasaction='ignore')
        dw.writeheader()
        for r in zero_rows: dw.writerow(r)
    print(f"[{_ts()}] zero_acl.csv written: {len(zero_rows)} rows")

    def _has(rr, tag):
        toks = [t.strip() for t in (rr.get('risk','') or '').split(',') if t.strip()]
        if 'broad_both' in toks and 'broad_to_broad' not in toks:
            toks.append('broad_to_broad')
        return tag in toks
    used = lambda rr: _hit_count_int(rr.get('hit_count','')) > 0
    def split_count(tag):
        u = sum(1 for rr in risky_rows_all if _has(rr, tag) and used(rr))
        z = sum(1 for rr in risky_rows_all if _has(rr, tag) and not used(rr))
        return u, z

    any_any_u, any_any_z = split_count('any_any')
    any_rfc_u, any_rfc_z = split_count('any_to_rfc')
    broad_bb_u, broad_bb_z = split_count('broad_to_broad')
    broad_rfc_u, broad_rfc_z = split_count('broad_rfc1918')
    p80_u, p80_z = split_count('port=80')
    p21_u, p21_z = split_count('port=21')
    icmp_u, icmp_z = split_count('icmp')
    any_src_u, any_src_z = split_count('any_src')
    any_dst_u, any_dst_z = split_count('any_dst')
    any10_u, any10_z     = split_count('any_to_10')

    total_permit   = sum(1 for r in all_acls if _is_permit_row(r))
    zero_hit_permit= sum(1 for r in all_acls if _is_permit_row(r) and _hit_count_int(r.get('hit_count','')) == 0)
    used_permit    = max(0, total_permit - zero_hit_permit)
    total_risky_all= len(risky_rows_all)
    risky_used_count = len(risky_used_rows)
    risky_zero_count = len(risky_zero_rows)
    pie_safe_legacy = total_permit - total_risky_all - zero_hit_permit
    if pie_safe_legacy < 0: pie_safe_legacy = 0

    metrics = {
        'total_risky_rules': int(total_risky_all),
        'total_zero_hit_permit_rules': int(zero_hit_permit),
        'any_src': int(any_src_u + any_src_z),
        'any_dst': int(any_dst_u + any_dst_z),
        'any_any_allow': int(any_any_u + any_any_z),
        'any_to_10': int(any10_u + any10_z),
        'any_to_rfc1918_permit': int(any_rfc_u + any_rfc_z),
        'broad_to_broad': int(broad_bb_u + broad_bb_z),
        'broad_rfc1918': int(broad_rfc_u + broad_rfc_z),
        'port80_rules': int(p80_u + p80_z),
        'port21_rules': int(p21_u + p21_z),
        'icmp_rules': int(icmp_u + icmp_z),
        'any_any_allow_used': int(any_any_u),
        'any_any_allow_zero': int(any_any_z),
        'any_to_rfc1918_permit_used': int(any_rfc_u),
        'any_to_rfc1918_permit_zero': int(any_rfc_z),
        'broad_to_broad_used': int(broad_bb_u),
        'broad_to_broad_zero': int(broad_bb_z),
        'broad_rfc1918_used': int(broad_rfc_u),
        'broad_rfc1918_zero': int(broad_rfc_z),
        'port80_rules_used': int(p80_u),
        'port80_rules_zero': int(p80_z),
        'port21_rules_used': int(p21_u),
        'port21_rules_zero': int(p21_z),
        'icmp_rules_used': int(icmp_u),
        'icmp_rules_zero': int(icmp_z),
        'any_src_used': int(any_src_u),
        'any_src_zero': int(any_src_z),
        'any_dst_used': int(any_dst_u),
        'any_dst_zero': int(any_dst_z),
        'any_to_10_used': int(any10_u),
        'any_to_10_zero': int(any10_z),
        'pie_total_permit_rules': int(total_permit),
        'pie_zero_hit_rules': int(zero_hit_permit),
        'pie_used_permit_rules': int(used_permit),
        'pie_risky_rules': int(total_risky_all),
        'pie_safe_rules': int(pie_safe_legacy),
        'risky_used_rules': int(risky_used_count),
        'risky_zero_hit_rules': int(risky_zero_count),
    }

    keys = [
        'total_risky_rules','total_zero_hit_permit_rules',
        'any_src','any_dst','any_any_allow','any_to_10','any_to_rfc1918_permit',
        'broad_to_broad','broad_rfc1918','port80_rules','port21_rules','icmp_rules',
        'any_any_allow_used','any_any_allow_zero',
        'any_to_rfc1918_permit_used','any_to_rfc1918_permit_zero',
        'broad_to_broad_used','broad_to_broad_zero',
        'broad_rfc1918_used','broad_rfc1918_zero',
        'port80_rules_used','port80_rules_zero',
        'port21_rules_used','port21_rules_zero',
        'icmp_rules_used','icmp_rules_zero',
        'any_src_used','any_src_zero','any_dst_used','any_dst_zero','any_to_10_used','any_to_10_zero',
        'pie_total_permit_rules','pie_zero_hit_rules','pie_used_permit_rules',
        'pie_risky_rules','pie_safe_rules',
        'risky_used_rules','risky_zero_hit_rules'
    ]
    with open(DASHBOARD_CSV, 'w', encoding='utf-8', newline='') as f:
        dw = csv.writer(f)
        dw.writerow(['metric','value'])
        for k in keys:
            dw.writerow([k, metrics.get(k, 0)])
    print(f"[{_ts()}] dashboard.csv written")

    summary = (
        f"any_any used={any_any_u} zero={any_any_z} | "
        f"any_to_rfc used={any_rfc_u} zero={any_rfc_z} | "
        f"broad_to_broad used={broad_bb_u} zero={broad_bb_z} | "
        f"broad_rfc1918 used={broad_rfc_u} zero={broad_rfc_z} | "
        f"port80 used={p80_u} zero={p80_z} | "
        f"port21 used={p21_u} zero={p21_z} | "
        f"icmp used={icmp_u} zero={icmp_z} | "
        f"any_src used={any_src_u} zero={any_src_z} | any_dst used={any_dst_u} zero={any_dst_z} | any_to_10 used={any10_u} zero={any10_z}"
    )
    print(f"[{_ts()}] Summary: {summary}")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
