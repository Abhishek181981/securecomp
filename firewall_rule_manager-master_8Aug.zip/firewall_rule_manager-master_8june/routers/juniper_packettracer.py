from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import re
import logging
import time

logger = logging.getLogger(__name__)

def run_packet_tracer(rule, username, password, secret, retries=3, delay=2):
    """
    Run 'show security match-policies' on Juniper SRX to check policy feasibility.
    Args:
        rule: FirewallRule object with source_ip, dest_ip, protocol, port_range_start, ports, firewallIP, source_zone, dest_zone.
        username (str): SSH username.
        password (str): SSH password.
        secret (str): Enable password.
        retries (int): Number of retry attempts (default: 3).
        delay (int): Delay between retries in seconds (default: 2).
    Returns:
        dict: Policy result with policy_name, action, source_address, destination_address, and matched status.
    """
    device = {
        "device_type": "juniper_junos",
        "ip": rule.firewallIP,
        "username": username,
        "password": password,
        "secret": secret,
        "port": 22
    }
    
    # Validate zones
    if not rule.source_zone or not rule.dest_zone:
        logger.warning(f"No source or destination zone for rule {rule.itsr_number}: src_zone={rule.source_zone}, dst_zone={rule.dest_zone}")
        print(f"No source or destination zone for rule {rule.itsr_number}: src_zone={rule.source_zone}, dst_zone={rule.dest_zone}")
        return {"error": "Missing source or destination zone", "matched": False}
    
    # Use destination port from rule.multiple_ports
    destination_port = rule.multiple_ports
    protocol = rule.protocol
    protocol = protocol.lower()
    
    # Generate command
    command = (
        f"show security match-policies from-zone {rule.source_zone} to-zone {rule.dest_zone} source-ip {rule.source_ip} destination-ip {rule.dest_ip} source-port 12345 destination-port {destination_port} protocol {protocol}"
    )
    
    for attempt in range(1, retries + 1):
        try:
            logger.info(f"Attempt {attempt}: Connecting to Juniper firewall {rule.firewallIP} for policy check")
            print(f"Attempt {attempt}: Connecting to Juniper firewall {rule.firewallIP} for policy check")
            connection = ConnectHandler(**device)
            
            # Execute command
            logger.info(f"Executing policy check command: {command}")
            print("*"*100)
            print(f"Executing policy check command: {command}")
            print("*"*100)
            output = connection.send_command(command)
            logger.info(f"Policy match output: {output}")
            print("*"*50)
            print(f"Policy match output: {output}")
            print("*"*50)
            
            # Parse output
            policy_result = {
                "policy_name": None,
                "action": None,
                "source_address": None,
                "destination_address": None,
                "matched": False
            }
            
            # Parse policy name, action, source address, and destination address
            policy_match = re.search(
            r"Policy:\s+(\S+),\s+action-type:\s+(\S+).*?"
            r"Source addresses:\s*\n\s+(\S+):\s+(\S+).*?"
            r"Destination addresses:\s*\n\s+(\S+):\s+(\S+)",
            output,
            re.DOTALL | re.IGNORECASE
        )

            
            if policy_match:
                policy_result["policy_name"] = policy_match.group(1)
                policy_result["action"] = policy_match.group(2)
                policy_result["source_address"] = policy_match.group(4)  # IP (not name)
                policy_result["destination_address"] = policy_match.group(6)  # IP (not name)
                policy_result["matched"] = True
                logger.info(
                    f"Policy matched: {policy_result['policy_name']}, "
                    f"Action: {policy_result['action']}, "
                    f"Source Address: {policy_result['source_address']}, "
                    f"Destination Address: {policy_result['destination_address']}"
                )
                print("-"*100)
                print(
                    f"Policy matched: {policy_result['policy_name']}, "
                    f"Action: {policy_result['action']}, "
                    f"Source Address: {policy_result['source_address']}, "
                    f"Destination Address: {policy_result['destination_address']}"
                )
                print("-"*100)
            else:
                logger.warning(f"No policy matched for command: {command}")
                print(f"No policy matched for command: {command}")
            
            connection.disconnect()
            return policy_result
        
        except NetmikoTimeoutException:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Connection timeout")
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Connection timeout")
            if attempt == retries:
                logger.error(f"Policy check failed for {rule.firewallIP} after {retries} attempts")
                print(f"Policy check failed for {rule.firewallIP} after {retries} attempts")
                return {"error": "Connection timeout after retries", "matched": False}
        except NetmikoAuthenticationException:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Authentication failed")
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Authentication failed")
            if attempt == retries:
                logger.error(f"Policy check failed for {rule.firewallIP} - Authentication failed")
                print(f"Policy check failed for {rule.firewallIP} - Authentication failed")
                return {"error": "Authentication failed", "matched": False}
        except Exception as e:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Error: {str(e)}")
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Error: {str(e)}")
            if attempt == retries:
                logger.error(f"Policy check failed for {rule.firewallIP} - Error: {str(e)}")
                print(f"Policy check failed for {rule.firewallIP} - Error: {str(e)}")
                return {"error": f"Unexpected error: {str(e)}", "matched": False}
        
        if attempt < retries:
            logger.info(f"Retrying connection to {rule.firewallIP} in {delay} seconds...")
            print(f"Retrying connection to {rule.firewallIP} in {delay} seconds...")
            time.sleep(delay)
    
    return {"error": "Failed to connect after retries", "matched": False}











