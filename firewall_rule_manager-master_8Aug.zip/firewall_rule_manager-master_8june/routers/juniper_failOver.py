from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import time

def failOver(firewall_ip, username, password, secret, retries=3, delay=2):
    """
    Log in to Juniper SRX to verify connectivity with retries and print status.
    Args:
        firewall_ip (str): IP address of the Juniper SRX firewall.
        username (str): Username for SSH login.
        password (str): Password for SSH login.
        secret (str): Enable password (if required).
        retries (int): Number of retry attempts (default: 3).
        delay (int): Delay between retries in seconds (default: 2).
    Returns:
        str: 'connected' if login is successful.
    Raises:
        Exception: If connection or authentication fails after retries.
    """
    device = {
        'device_type': 'juniper_junos',
        'ip': firewall_ip,
        'username': username,
        'password': password,
        'secret': secret,
        'port': 22
    }
    
    for attempt in range(1, retries + 1):
        try:
            # Establish SSH connection
            connection = ConnectHandler(**device)
            
            # Print success message
            print(f"Successfully connected to Juniper firewall: {firewall_ip}")
            
            # Disconnect immediately
            connection.disconnect()
            
            return 'connected'
            
        except NetmikoTimeoutException:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Connection timeout")
            if attempt == retries:
                raise Exception(f"Connection timeout to {firewall_ip} after {retries} attempts")
        except NetmikoAuthenticationException:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Authentication failed")
            if attempt == retries:
                raise Exception(f"Authentication failed for {firewall_ip}")
        except Exception as e:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Error: {str(e)}")
            if attempt == retries:
                raise Exception(f"Failed to connect: {str(e)}")
        
        # Wait before retrying
        if attempt < retries:
            print(f"Retrying connection to {firewall_ip} in {delay} seconds...")
            time.sleep(delay)