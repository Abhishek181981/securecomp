import datetime
import logging
import re
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import time
from routers.juniper_address_book import create_address_book

logger = logging.getLogger(__name__)

def failOver_check(firewall_ip, username, password, secret, rule, retries=3, delay=10):
    """
    Log in to Juniper SRX, create address book entries, and run configuration and show commands using a list.
    Args:
        firewall_ip (str): IP address of the Juniper SRX firewall.
        username (str): Username for SSH login.
        password (str): Password for SSH login.
        secret (str): Enable password (if required).
        rule: Firewall rule object containing source_zone, dest_zone, and multiple_ports.
        retries (int): Number of retry attempts (default: 3).
        delay (int): Delay between retries in seconds (default: 2).
    Returns:
        str: 'commands_executed' if commands are successful.
    Raises:
        Exception: If connection or command execution fails after retries.
    """
    device = {
        'device_type': 'juniper_junos',
        'ip': firewall_ip,
        'username': username,
        'password': password,
        'secret': secret,
        'port': 22,
        'timeout': 120  # Increased timeout to handle slow responses
    }
    
    for attempt in range(1, retries + 1):
        try:
            # Establish SSH connection
            connection = ConnectHandler(**device)
            logger.info(f"Successfully connected to Juniper firewall: {firewall_ip}")
            print(f"Successfully connected to Juniper firewall: {firewall_ip}")
            creation_time = datetime.datetime.utcnow().strftime("%Y-%m-%d")
            
            # Enter configure mode
            output = connection.send_command("configure", expect_string=r'#')  # Wait for prompt
            logger.info(f"Entered configure mode, output: {output}")
            print(f"Entered configure mode, output: {output}")
            
            # Show existing policies
            show_command = "run show configuration | display set | match policy"
            show_output = connection.send_command(show_command)
            print(f"Show command output: {show_output}")
            
            # Parse 10th line to get existing policy name
            lines = show_output.strip().split('\n')
            existing_policy = "default_policy"  # Fallback
            if len(lines) >= 10:
                tenth_line = lines[9].strip()  # 10th line (0-based index 9)
                policy_name = re.search(r'policy\s+(\w+)\s+match', tenth_line)
                if policy_name:
                    existing_policy = policy_name.group(1)
                    print(f"Extracted policy name from 10th line: {existing_policy}")
                else:
                    print(f"No policy name found in 10th line, using default: {existing_policy}")
            else:
                print(f"Less than 10 lines, using default: {existing_policy}")
            
            new_policy_name = f"{rule.itsr_number}_{rule.email}_{creation_time}_{rule.Security_Exception_number}_{rule.Security_Exception_expiry_date}"
            line1=rule.src_address_line
            src_address = line1.strip().split()[-2]
            line2=rule.dst_address_line
            dest_address=line2.strip().split()[-2]


            config_commands = [
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match source-address {src_address}",
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match destination-address {dest_address}",
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} match application {rule.check_port}",
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then permit",
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then log session-init",
                f"set security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} then log session-close",
                f"insert security policies from-zone {rule.source_zone} to-zone {rule.dest_zone} policy {new_policy_name} before policy {existing_policy}",
                
                "commit",      # Commit changes
                "exit"         # Exit configure mode
            ]
            print("+=" * 50)
            # print("src_address_line",src_address_line)
            print("Configuration commands:", config_commands)
            print("+=" * 50)
            
            # Execute configuration commands with retries
            for attempt_config in range(1, retries + 1):
                try:
                    output = connection.send_config_set(config_commands)
                    logger.info(f"Configuration commands executed: {output}")
                    print(f"Configuration output: {output}")
                    break
                except Exception as e:
                    logger.error(f"Config attempt {attempt_config}: Failed to configure: {str(e)}")
                    print(f"Config attempt {attempt_config}: Failed to configure: {str(e)}")
                    if attempt_config == retries:
                        raise Exception(f"Failed to configure after {retries} attempts: {str(e)}")
                    time.sleep(delay)
            
            # Disconnect
            connection.disconnect()
            logger.info(f"Disconnected from Juniper firewall: {firewall_ip}")
            
            return 'commands_executed'
            
        except NetmikoTimeoutException:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Connection timeout")
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Connection timeout")
            if attempt == retries:
                raise Exception(f"Connection timeout to {firewall_ip} after {retries} attempts")
        except NetmikoAuthenticationException:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Authentication failed")
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {firewall_ip} - Authentication failed")
            if attempt == retries:
                raise Exception(f"Authentication failed for {firewall_ip}")
        except Exception as e:
            logger.error(f"Attempt {attempt}/{retries}: Failed to connect or execute commands on {firewall_ip} - Error: {str(e)}")
            print(f"Attempt {attempt}/{retries}: Failed to connect or execute commands on {firewall_ip} - Error: {str(e)}")
            if attempt == retries:
                raise Exception(f"Failed to connect or execute: {str(e)}")
        
        # Wait before retrying
        if attempt < retries:
            print(f"Retrying connection to {firewall_ip} in {delay} seconds...")
            time.sleep(delay)