from netmiko import ConnectHandler
import logging
import time
import ipaddress
import re

logger = logging.getLogger(__name__)

def create_address_book(rule, username, password, secret, retries=3, delay=2):
    """
    Create address book entries for source and destination IPs/subnets in the specified zones.
    
    Args:
        rule: FirewallRule object containing source_ip, source_subnet, dest_ip, dest_subnet, source_zone, dest_zone
        username: Firewall username
        password: Firewall password
        secret: Enable secret
        retries: Number of retry attempts for connection
        delay: Delay between retries in seconds
    
    Returns:
        dict: Status of operation, source and destination address book lines
    """
    device = {
        "device_type": "juniper_junos",
        "ip": rule.firewallIP,
        "username": username,
        "password": password,
        "secret": secret,
        "port": 22
    }
    
    # Initialize commands list
    commands = []
    
    # Function to decrement last octet by 1 if subnet is present
    def decrement_last_octet(ip, should_decrement):
        if not ip or not should_decrement:
            return ip  # Return original if no decrement needed
        octets = ip.split('.')
        if len(octets) == 4 and octets[3].isdigit():
            last_octet = int(octets[3]) - 1
            if last_octet >= 0:
                octets[3] = str(last_octet)
                return '.'.join(octets)
        logger.warning(f"Cannot decrement last octet of {ip}, using original")
        print(f"Cannot decrement last octet of {ip}, using original")
        return ip  # Return original if invalid
    
    # Determine if decrement should happen based on source_subnet
    should_decrement = rule.source_subnet is not None
    
    # Determine naming convention based on subnet presence
    use_n_naming_source = rule.source_subnet is not None
    use_n_naming_dest = rule.dest_subnet is not None
    
    # Check existing address book entries
    try:
        connection = ConnectHandler(**device)
        adjusted_source_ip = decrement_last_octet(rule.source_ip, should_decrement)
        source_subnet_str = f"/{ipaddress.ip_network(f'{adjusted_source_ip}/{rule.source_subnet}', strict=False).prefixlen}" if rule.source_subnet else "/32"
        check_command_source = f'show configuration | display set | match "{adjusted_source_ip}{source_subnet_str}"'
        check_output_source = connection.send_command(check_command_source)
        logger.debug(f"Check command source output: {check_output_source}")
        print(f"Check command source output: {check_output_source}")

        adjusted_dest_ip = decrement_last_octet(rule.dest_ip, should_decrement)
        dest_subnet_str = f"/{ipaddress.ip_network(f'{adjusted_dest_ip}/{rule.dest_subnet}', strict=False).prefixlen}" if rule.dest_subnet else "/32"
        check_command_dest = f'show configuration | display set | match "{adjusted_dest_ip}{dest_subnet_str}"'
        check_output_dest = connection.send_command(check_command_dest)
        logger.debug(f"Check command dest output: {check_output_dest}")
        print(f"Check command dest output: {check_output_dest}")
    except Exception as e:
        logger.error(f"Failed to check existing address book entries: {str(e)}")
        print(f"Failed to check existing address book entries: {str(e)}")
        connection.disconnect()
        return {"status": "failed", "error": str(e)}

    # Handle Source IP/Subnet
    src_address_line = None
    source_exists = check_output_source.strip()  # True if any match found
    if rule.source_ip and rule.source_zone and not source_exists:
        try:
            adjusted_source_ip = decrement_last_octet(rule.source_ip, should_decrement)
            if rule.source_subnet:
                net = ipaddress.ip_network(f"{adjusted_source_ip}/{rule.source_subnet}", strict=False)
                src_address_name = f"N_{adjusted_source_ip}" if use_n_naming_source else f"h_{adjusted_source_ip}"
                src_command = (
                    f"set security zones security-zone {rule.source_zone} "
                    f"address-book address {src_address_name} {adjusted_source_ip}/{net.prefixlen}"
                )
            else:
                ipaddress.ip_address(adjusted_source_ip)
                src_address_name = f"h_{adjusted_source_ip}"
                src_command = (
                    f"set security zones security-zone {rule.source_zone} "
                    f"address-book address {src_address_name} {adjusted_source_ip}/32"
                )
            commands.append(src_command)
            print(f"Added source command: {src_command}")
            src_address_line = src_command
        except ValueError as e:
            logger.error(f"Invalid source IP/subnet: {adjusted_source_ip}/{rule.source_subnet}: {str(e)}")
            print(f"Invalid source IP/subnet: {adjusted_source_ip}/{rule.source_subnet}: {str(e)}")
            connection.disconnect()
            return {"status": "failed", "error": f"Invalid source IP/subnet: {str(e)}"}
    elif source_exists:
        # Extract first matching line
        src_lines = check_output_source.strip().split('\n')
        src_address_line = src_lines[0] if src_lines else None
        logger.info(f"Existing source address line found: {src_address_line}")
        print(f"Existing source address line found: {src_address_line}")

    # Handle Destination IP/Subnet
    dst_address_line = None
    dest_exists = check_output_dest.strip()  # True if any match found
    if rule.dest_ip and rule.dest_zone and not dest_exists:
        try:
            adjusted_dest_ip = decrement_last_octet(rule.dest_ip, should_decrement)
            if rule.dest_subnet:
                net = ipaddress.ip_network(f"{adjusted_dest_ip}/{rule.dest_subnet}", strict=False)
                dst_address_name = f"N_{adjusted_dest_ip}" if use_n_naming_dest else f"h_{adjusted_dest_ip}"
                dest_command = (
                    f"set security zones security-zone {rule.dest_zone} "
                    f"address-book address {dst_address_name} {adjusted_dest_ip}/{net.prefixlen}"
                )
            else:
                ipaddress.ip_address(adjusted_dest_ip)
                dst_address_name = f"h_{adjusted_dest_ip}"
                dest_command = (
                    f"set security zones security-zone {rule.dest_zone} "
                    f"address-book address {dst_address_name} {adjusted_dest_ip}/32"
                )
            commands.append(dest_command)
            print(f"Added destination command: {dest_command}")
            dst_address_line = dest_command
        except ValueError as e:
            logger.error(f"Invalid destination IP/subnet: {adjusted_dest_ip}/{rule.dest_subnet}: {str(e)}")
            print(f"Invalid destination IP/subnet: {adjusted_dest_ip}/{rule.dest_subnet}: {str(e)}")
            connection.disconnect()
            return {"status": "failed", "error": f"Invalid destination IP/subnet: {str(e)}"}
    elif dest_exists:
        # Extract first matching line
        dst_lines = check_output_dest.strip().split('\n')
        dst_address_line = dst_lines[0] if dst_lines else None
        logger.info(f"Existing destination address line found: {dst_address_line}")
        print(f"Existing destination address line found: {dst_address_line}")

    # Debug: Print commands before execution
    print("Commands to execute:", commands)

    # If no new commands needed, pass and return existing lines
    if not commands and src_address_line and dst_address_line:
        connection.disconnect()
        return {"status": "passed", "src_address_line": src_address_line, "dst_address_line": dst_address_line, "message": "Existing address book entries found"}

    # If no commands needed but one or both lines are missing, return error or existing
    if not commands and (not src_address_line or not dst_address_line):
        connection.disconnect()
        return {"status": "failed", "error": "One or both address book entries missing but not created", "src_address_line": src_address_line, "dst_address_line": dst_address_line}

    # Add configure and exit commands if there are commands to execute
    if commands:
        commands.insert(0, "configure")
        commands.append("commit")
        commands.append("exit")
    
        # Execute commands
        for attempt in range(1, retries + 1):
            try:
                output = connection.send_config_set(commands)
                print(f"Command output: {output}")
                connection.disconnect()
                logger.info(f"Successfully created address book entries for rule {rule.itsr_number}")
                print(f"Successfully created address book entries for rule {rule.itsr_number}")
                return {
                    "status": "success",
                    "src_address_line": src_address_line,
                    "dst_address_line": dst_address_line,
                    "commands": commands 
                }
            except Exception as e:
                logger.error(f"Attempt {attempt}: Failed to create address book entries: {str(e)}")
                print(f"Attempt {attempt}: Failed to create address book entries: {str(e)}")
                if attempt == retries:
                    connection.disconnect()
                    return {"status": "failed", "error": str(e)}
                time.sleep(delay)

    connection.disconnect()
    return {"status": "failed", "error": "Max retries reached", "src_address_line": src_address_line, "dst_address_line": dst_address_line}