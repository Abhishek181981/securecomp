from netmiko import ConnectHandler
import logging
import time

logger = logging.getLogger(__name__)

def check_connectivity(rule, username, password, secret, retries=3, delay=2):
    """
    Check connectivity to the Juniper firewall using Netmiko.
    
    Args:
        rule: FirewallRule object containing firewallIP and itsr_number
        username: Firewall username
        password: Firewall password
        secret: Enable secret
        retries: Number of retry attempts for connection (default: 3)
        delay: Delay between retries in seconds (default: 2)
    
    Returns:
        dict: Status of operation and message
    """
    device = {
        "device_type": "juniper_junos",
        "ip": rule.firewallIP,
        "username": username,
        "password": password,
        "secret": secret,
        "port": 22
    }

    connection = None
    try:
        logger.info(f"Attempting to connect to firewall {rule.firewallIP} for rule {rule.itsr_number}")
        print(f"Attempting to connect to firewall {rule.firewallIP} for rule {rule.itsr_number}")
        for attempt in range(1, retries + 1):
            try:
                connection = ConnectHandler(**device)
                logger.info(f"Connectivity success for firewall {rule.firewallIP} for rule {rule.itsr_number}")
                print(f"Connectivity success for firewall {rule.firewallIP} for rule {rule.itsr_number}")
                return {"status": "success", "message": "Connectivity success"}
            except Exception as e:
                logger.error(f"Attempt {attempt}/{retries}: Failed to connect to {rule.firewallIP} for rule {rule.itsr_number}: {str(e)}")
                print(f"Attempt {attempt}/{retries}: Failed to connect to {rule.firewallIP} for rule {rule.itsr_number}: {str(e)}")
                if attempt == retries:
                    return {"status": "failed", "error": f"Failed to connect after {retries} attempts: {str(e)}"}
                time.sleep(delay)
    
    except Exception as e:
        logger.error(f"Failed to process connectivity check for rule {rule.itsr_number} on {rule.firewallIP}: {str(e)}")
        print(f"Failed to process connectivity check for rule {rule.itsr_number} on {rule.firewallIP}: {str(e)}")
        return {"status": "failed", "error": str(e)}
    finally:
        if connection:
            connection.disconnect()
            logger.info(f"Disconnected from firewall: {rule.firewallIP}")
            print(f"Disconnected from firewall: {rule.firewallIP}")