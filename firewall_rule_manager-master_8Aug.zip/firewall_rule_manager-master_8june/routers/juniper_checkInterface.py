from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
import time
import re

def update_firewall_interfaces_for_rule(rule, username, password, secret, retries=3, delay=2):
    """
    Run 'show route <source_ip>', 'show route <destination_ip>', and 'show configuration | display set | match <src_interface>'
    on Juniper SRX to get interfaces and source zone.
    Args:
        rule: FirewallRule object with source_ip, dest_ip, and firewallIP.
        username (str): SSH username.
        password (str): SSH password.
        secret (str): Enable password.
        retries (int): Number of retry attempts (default: 3).
        delay (int): Delay between retries in seconds (default: 2).
    Returns:
        tuple: (source_interface, dest_interface, src_zone) or (None, None, None) if failed.
    """
    device = {
        'device_type': 'juniper_junos',
        'ip': rule.firewallIP,
        'username': username,
        'password': password,
        'secret': secret,
        'port': 22
    }
    
    for attempt in range(1, retries + 1):
        try:
            # Establish SSH connection
            connection = ConnectHandler(**device)
            print(f"Successfully connected to Juniper firewall: {rule.firewallIP} for interface and zone lookup")
            
            # Run 'show route <source_ip>'
            source_cmd = f"show route {rule.source_ip}"
            source_output = connection.send_command(source_cmd)
            print(f"Source route output for {rule.source_ip}: {source_output}")
            
            # Parse source interface (e.g., 'reth3.970')
            source_interface = None
            source_match = re.search(r'via\s+(\S+)', source_output)
            if source_match:
                source_interface = source_match.group(1)
                print(f"Extracted source interface: {source_interface}")
            
            # Run 'show route <destination_ip>'
            dest_cmd = f"show route {rule.dest_ip}"
            dest_output = connection.send_command(dest_cmd)
            print(f"Destination route output for {rule.dest_ip}: {dest_output}")
            
            # Parse destination interface
            dest_interface = None
            dest_match = re.search(r'via\s+(\S+)', dest_output)
            if dest_match:
                dest_interface = dest_match.group(1)
                print(f"Extracted destination interface: {dest_interface}")
            
            # Run 'show configuration | display set | match <src_interface>' for source zone
            src_zone = None
            if source_interface:
                zone_cmd = f"show configuration | display set | match {source_interface}"
                zone_output = connection.send_command(zone_cmd)
                print(f"Zone output for interface {source_interface}: {zone_output}")
                
                # Parse source zone (e.g., 'set security zones security-zone untrust interfaces reth3.970' -> 'untrust')
                zone_match = re.search(r'set security zones security-zone (\S+) interfaces {}'.format(re.escape(source_interface)), zone_output)
                if zone_match:
                    src_zone = zone_match.group(1)
                    print(f"Extracted source zone: {src_zone}")
            
            dest_zone = None
            if dest_interface:
                zone_cmd = f"show configuration | display set | match {dest_interface}"
                zone_output = connection.send_command(zone_cmd)
                print(f"Zone output for interface {dest_interface}: {zone_output}")
                
                # Parse source zone (e.g., 'set security zones security-zone untrust interfaces reth3.970' -> 'untrust')
                zone_match = re.search(r'set security zones security-zone (\S+) interfaces {}'.format(re.escape(dest_interface)), zone_output)
                if zone_match:
                    dest_zone = zone_match.group(1)
                    print(f"Extracted source zone: {dest_zone}")
            
            # Disconnect
            connection.disconnect()
            
            return source_interface, dest_interface, src_zone ,dest_zone
            
        except NetmikoTimeoutException:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Connection timeout")
            if attempt == retries:
                print(f"Interface and zone lookup failed for {rule.firewallIP} after {retries} attempts")
                return None, None, None
        except NetmikoAuthenticationException:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Authentication failed")
            if attempt == retries:
                print(f"Interface and zone lookup failed for {rule.firewallIP} - Authentication failed")
                return None, None, None
        except Exception as e:
            print(f"Attempt {attempt}/{retries}: Failed to connect to Juniper firewall: {rule.firewallIP} - Error: {str(e)}")
            if attempt == retries:
                print(f"Interface and zone lookup failed for {rule.firewallIP} - Error: {str(e)}")
                return None, None, None
        
        # Wait before retrying
        if attempt < retries:
            print(f"Retrying connection to {rule.firewallIP} in {delay} seconds...")
            time.sleep(delay)
    
    return None, None, None