from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from database import get_db, Base, engine
from sqlalchemy.orm import Session
from models import FirewallRule, FirewallList, Risk
from jinja2 import Environment, FileSystemLoader
from routers import finalExecute, checkInterface
from routers.failOver import failOver
from routers.showfailoverstate import show_failover_state
from routers import juniper_failOver
from routers import juniper_checkInterface
from routers import juniper_packettracer
from routers import juniper_address_book
from routers.juniper_port_check import check_ports  # New file integration
from pydantic import BaseModel
from typing import Optional
from datetime import date
import ipaddress
import logging

app = FastAPI()

# Configure logging
logging.basicConfig(level=logging.INFO, filename='app.log', format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set up Jinja2 environment
templates = Environment(loader=FileSystemLoader("templates"))

app.include_router(finalExecute.router)

# Create tables
FirewallList.__table__.create(bind=engine, checkfirst=True)
FirewallRule.__table__.create(bind=engine, checkfirst=True)
Risk.__table__.create(bind=engine, checkfirst=True)

# Dependency to get DB session
def get_database():
    yield from get_db()

class RuleUpdate(BaseModel):
    itsr_number: str
    source_ip: str
    dest_ip: str
    risk_description: Optional[str] = None
    security_exception_number: Optional[str] = None
    security_exception_expiry_date: Optional[date] = None

async def run_batch_process(db: Session):
    try:
        db.execute(
            FirewallRule.__table__.update()
            .where(FirewallRule.source_ip == Risk.Src_ip)
            .where(FirewallRule.dest_ip == Risk.Dst_IP)
            .values(Risk_Description=Risk.Risk_Description)
        )
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Batch process failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Batch process failed: {str(e)}")

@app.post("/run-batch", response_class=JSONResponse)
async def run_batch(db: Session = Depends(get_database)):
    await run_batch_process(db)
    return {"message": "Batch process completed successfully"}

@app.put("/update-rule", response_class=JSONResponse)
async def update_rule(update: RuleUpdate, db: Session = Depends(get_database)):
    try:
        rule = db.query(FirewallRule).filter(
            FirewallRule.itsr_number == update.itsr_number,
            FirewallRule.source_ip == update.source_ip,
            FirewallRule.dest_ip == update.dest_ip
        ).first()

        if not rule:
            raise HTTPException(status_code=404, detail="Rule not found")

        if update.risk_description is not None:
            rule.Risk_Description = update.risk_description
        if update.security_exception_number is not None:
            rule.Security_Exception_number = update.security_exception_number
        if update.security_exception_expiry_date is not None:
            rule.Security_Exception_expiry_date = update.security_exception_expiry_date

        db.commit()
        db.refresh(rule)
        return {"message": "Rule updated successfully", "data": rule.__dict__}

    except Exception as e:
        db.rollback()
        logger.error(f"Update failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")

@app.post("/update-rule", response_class=HTMLResponse)
async def update_rule_form(request: Request, db: Session = Depends(get_database)):
    form_data = await request.form()
    try:
        rule = db.query(FirewallRule).filter(
            FirewallRule.itsr_number == form_data.get("itsr_number"),
            FirewallRule.source_ip == form_data.get("source_ip"),
            FirewallRule.dest_ip == form_data.get("dest_ip")
        ).first()

        if not rule:
            raise HTTPException(status_code=404, detail="Rule not found")

        if form_data.get("risk_description"):
            rule.Risk_Description = form_data.get("risk_description")
        if form_data.get("security_exception_number"):
            rule.Security_Exception_number = form_data.get("security_exception_number")
        if form_data.get("security_exception_expiry_date"):
            rule.Security_Exception_expiry_date = form_data.get("security_exception_expiry_date")

        db.commit()
        db.refresh(rule)

        rules = db.query(FirewallRule).filter(FirewallRule.final_status != "Completed").all()
        firewalls = db.query(FirewallList).all()
        firewall_data = [
            {
                "firewall_hostname": fw.firewall_hostname,
                "context_names": [fw.context_name] if fw.context_name else []
            }
            for fw in firewalls
        ]
        return templates.get_template("index.html").render(
            request=request,
            rules=rules,
            firewalls=firewall_data,
            message="Rule updated successfully!"
        )

    except Exception as e:
        db.rollback()
        logger.error(f"Update failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")

@app.post("/update-status", response_class=JSONResponse)
async def update_status(request: Request, db: Session = Depends(get_database)):
    try:
        form_data = await request.form()
        itsr_number = form_data.get("itsr_number")
        source_ip = form_data.get("source_ip")
        dest_ip = form_data.get("dest_ip")
        final_status = form_data.get("final_status")
        if final_status not in ["Pending", "Cancelled"]:
            raise HTTPException(status_code=400, detail="Invalid status value")
        rule = db.query(FirewallRule).filter(
            FirewallRule.itsr_number == itsr_number,
            FirewallRule.source_ip == source_ip,
            FirewallRule.dest_ip == dest_ip
        ).first()
        if not rule:
            raise HTTPException(status_code=404, detail="Rule not found")
        rule.final_status = final_status
        db.commit()
        db.refresh(rule)
        return {"message": f"Status updated to {final_status}"}
    except Exception as e:
        db.rollback()
        logger.error(f"Status update failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Status update failed: {str(e)}")

@app.post("/delete-rule-ui", response_class=JSONResponse)
async def delete_rule_ui(request: Request, db: Session = Depends(get_database)):
    try:
        form_data = await request.form()
        itsr_number = form_data.get("itsr_number")
        source_ip = form_data.get("source_ip")
        dest_ip = form_data.get("dest_ip")
        rule = db.query(FirewallRule).filter(
            FirewallRule.itsr_number == itsr_number,
            FirewallRule.source_ip == source_ip,
            FirewallRule.dest_ip == dest_ip
        ).first()
        if not rule:
            raise HTTPException(status_code=404, detail="Rule not found")
        db.commit()
        db.refresh(rule)
        return {"message": "Rule remains Cancelled and removed from UI"}
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to process rule: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to process rule: {str(e)}")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request, db: Session = Depends(get_database)):
    rules = db.query(FirewallRule).filter(
        FirewallRule.final_status.notin_(["Completed", "Cancelled"])
    ).all()
    firewalls = db.query(FirewallList).all()
    risks = db.query(Risk).all()

    for rule in rules:
        matched_risk_description = None
        for risk in risks:
            rule_source_ip = rule.source_ip.strip() if rule.source_ip else ""
            rule_dest_ip = rule.dest_ip.strip() if rule.dest_ip else ""
            risk_src_ip = risk.Src_ip.strip() if risk.Src_ip else ""
            risk_dst_ip = risk.Dst_IP.strip() if risk.Dst_IP else ""

            if (
                (rule_source_ip and (rule_source_ip.startswith(risk_src_ip) or rule_source_ip.startswith(risk_dst_ip)))
                and
                (rule_dest_ip and (rule_dest_ip.startswith(risk_src_ip) or rule_dest_ip.startswith(risk_dst_ip)))
            ):
                matched_risk_description = risk.Risk_Description
                break
        setattr(rule, 'matched_Risk_Description', matched_risk_description or rule.Risk_Description or '')

        # Fetch the firewall model for this rule
        firewall = db.query(FirewallList).filter(FirewallList.firewall_hostname == rule.Firewall).first()
        if firewall:
            setattr(rule, 'model', firewall.model.lower())  # Add model attribute to rule

    firewall_data = [
        {
            "firewall_hostname": fw.firewall_hostname,
            "context_names": [fw.context_name] if fw.context_name else []
        }
        for fw in firewalls
    ]
    return templates.get_template("index.html").render(
        request=request,
        rules=rules,
        firewalls=firewall_data
    )

def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

def is_valid_subnet(subnet):
    try:
        ipaddress.ip_network(f"0.0.0.0/{subnet}", strict=False)
        return True
    except ValueError:
        return False

def parse_and_increment_ip(ip_string, should_increment=False):
    """Modified to only increment when should_increment=True"""
    try:
        if not ip_string:
            return None, None

        if '-' in ip_string:
            ip, subnet = ip_string.split('-', 1)
            if not (is_valid_ip(ip) and is_valid_subnet(subnet)):
                return None, None
        else:
            ip = ip_string
            subnet = None

        if not is_valid_ip(ip):
            return None, None

        # Only increment if explicitly requested
        if should_increment:
            ip_parts = ip.split('.')
            last_octet = int(ip_parts[-1])
            if last_octet >= 255:
                return None, None
            ip_parts[-1] = str(last_octet + 1)
            ip = '.'.join(ip_parts)

        return ip, subnet

    except Exception as e:
        logger.error(f"IP processing error: {str(e)}")
        return None, None

@app.post("/submit-rule")
async def submit_rule(request: Request, db: Session = Depends(get_database)):
    form_data = await request.form()
    firewall_display = form_data.get("Firewall")

    def parse_firewall_value(display_value):
        if not display_value or display_value == "None":
            return None, None
        parts = display_value.split(":")
        hostname = parts[0]
        context = parts[1] if len(parts) > 1 else None
        return hostname, context

    firewall_hostname, context = parse_firewall_value(firewall_display)
    firewall = db.query(FirewallList).filter(FirewallList.firewall_hostname == firewall_hostname).first() if firewall_hostname else None

    if not firewall:
        logger.error(f"Source firewall not found: {firewall_hostname}")
        raise HTTPException(status_code=404, detail="Source firewall not found")

    firewallIP = firewall.ip
    model = firewall.model.lower()  # Cisco or Juniper

    # Connectivity check
    try:
        if model == "juniper":
            print(f"Attempting to connect to Juniper firewall: {firewallIP}")
            connect_result = juniper_failOver.failOver(
                firewallIP,
                username="amishra11",
                password="Dru56%Pty8",
                secret="Dru56%Pty8",
                retries=3
            )
            if connect_result != "connected":
                logger.error(f"Failed to connect to Juniper firewall: {firewall_hostname}")
                raise HTTPException(status_code=400, detail=f"Failed to connect to Juniper firewall: {firewall_hostname}")
        else:  # Cisco
            if context:
                if not show_failover_state(
                    firewallIP,
                    username="amishra11",
                    password="Dru56%Pty8",
                    secret="Dru56%Pty8",
                    context_name=context
                ):
                    logger.error(f"{firewall_hostname} ({context}) is not ACTIVE")
                    raise HTTPException(status_code=400, detail=f"{firewall_hostname} ({context}) is not ACTIVE")
            else:
                if not failOver(
                    firewallIP,
                    username="amishra11",
                    password="Dru56%Pty8",
                    secret="Dru56%Pty8"
                ):
                    logger.error(f"{firewall_hostname} is not ACTIVE")
                    raise HTTPException(status_code=400, detail=f"{firewall_hostname} is not ACTIVE")
    except Exception as e:
        logger.error(f"Connectivity check failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Connectivity check failed: {str(e)}")

    from itertools import product
    source_ips = [ip.strip() for ip in form_data.get("source_ip", "").split() if ip.strip()]
    dest_ips = [ip.strip() for ip in form_data.get("dest_ip", "").split() if ip.strip()]
    source_has_subnet = any('-' in ip for ip in source_ips) if source_ips else False
    src_ip_list = source_ips or [None]
    dst_ip_list = dest_ips or [None]
    created_rule = []

    for src_ip, dst_ip in product(src_ip_list, dst_ip_list):
        should_increment = source_has_subnet
        src_processed, src_subnet = parse_and_increment_ip(src_ip, should_increment)
        dst_processed, dst_subnet = parse_and_increment_ip(dst_ip, should_increment)

        if (src_ip and not src_processed) or (dst_ip and not dst_processed):
            continue

        new_rule = FirewallRule(
            itsr_number=form_data.get("itsr_number"),
            email=form_data.get("email"),
            source_ip=src_processed,
            source_subnet=src_subnet,
            dest_ip=dst_processed,
            dest_subnet=dst_subnet,
            multiple_ports=form_data.get("multiple_ports"),
            port_range_start=form_data.get("port_range_start"),
            port_range_end=form_data.get("port_range_end"),
            protocol=form_data.get("protocol"),
            ports=form_data.get("ports", ""),
            Firewall=firewall_hostname,
            pre_status="Added to queue",
            post_status="Pending",
            final_status="Pending",
            created_by=form_data.get("created_by", "admin"),
            firewallIP=firewallIP,
            context=context,
            Security_Exception_number=form_data.get("Security_Exception_number"),
            Security_Exception_expiry_date=form_data.get("Security_Exception_expiry_date")
        )
        db.add(new_rule)
        created_rule.append(new_rule)

    if not created_rule:
        logger.error("No valid rules created")
        raise HTTPException(status_code=400, detail="No valid rules created")

    db.flush()

    for rule in created_rule:
        if model == "juniper":
            source_interface, dest_interface, src_zone, dst_zone = juniper_checkInterface.update_firewall_interfaces_for_rule(
                rule=rule,
                username="amishra11",
                password="Dru56%Pty8",
                secret="Dru56%Pty8",
                retries=3
            )
            logger.info(f"Received from juniper_checkInterface: src_intf={source_interface}, dst_intf={dest_interface}, src_zone={src_zone}, dst_zone={dst_zone}")
            if source_interface or dest_interface or src_zone or dst_zone:
                rule.src_interface = source_interface
                rule.dst_interface = dest_interface
                rule.source_zone = src_zone
                rule.dest_zone = dst_zone
                logger.info(f"Setting rule {rule.itsr_number}: src_intf={source_interface}, dst_intf={dest_interface}, src_zone={src_zone}, dst_zone={dst_zone}")
                print("-"*100)
                print(f"Saving interfaces and zones for rule {rule.itsr_number}: src_intf={source_interface}, dst_intf={dest_interface}, src_zone={src_zone}, dst_zone={dst_zone}")

                # Run policy check
                policy_result = juniper_packettracer.run_packet_tracer(
                    rule=rule,
                    username="amishra11",
                    password="Dru56%Pty8",
                    secret="Dru56%Pty8",
                    retries=3
                )
                logger.info(f"Policy check result for rule {rule.itsr_number}: {policy_result}")
                print(f"Policy check result for rule {rule.itsr_number}: {policy_result}")
                print("-"*100)

                # Save policy_result to database
                if policy_result.get("matched"):
                    rule.Action = policy_result.get("action")
                    rule.Reason = f"policy:{policy_result.get('policy_name')},Source Address: {policy_result.get('source_address')}, Destination Address: {policy_result.get('destination_address')}"
                    logger.info(f"Saving to database for rule {rule.itsr_number}: Action={rule.Action}, Reason={rule.Reason}")
                    print(f"Saving to database for rule {rule.itsr_number}: Action={rule.Action}, Reason={rule.Reason}")

                    # Create address book entries if policy denies traffic
                    if policy_result.get("action") == "deny,":
                        address_result = juniper_address_book.create_address_book(
                            rule=rule,
                            username="amishra11",
                            password="Dru56%Pty8",
                            secret="Dru56%Pty8",
                            retries=3
                        )
                        if address_result["status"] == "success":
                            rule.src_address_line = address_result["src_address_line"]
                            rule.dst_address_line = address_result["dst_address_line"]
                            logger.info(f"Address book entries created for rule {rule.itsr_number}: {address_result['commands']}")
                            print(f"Address book entries created for rule {rule.itsr_number}: {address_result['commands']}")
                        elif address_result["status"] == "passed":
                            rule.src_address_line = address_result["src_address_line"]
                            rule.dst_address_line = address_result["dst_address_line"]
                            logger.info(f"Existing address book entries found for rule {rule.itsr_number}, proceeding with submission")
                        else:  # failed
                            logger.error(f"Failed to create address book entries for rule {rule.itsr_number}: {address_result.get('error', 'Unknown error')}")
                            print(f"Failed to create address book entries for rule {rule.itsr_number}: {address_result.get('error', 'Unknown error')}")
                            raise HTTPException(status_code=500, detail=f"Failed to create address book: {address_result.get('error', 'Unknown error')}")

                    # Run port check after address book creation
                    port_result = check_ports(
                        rule=rule,
                        username="amishra11",
                        password="Dru56%Pty8",
                        secret="Dru56%Pty8",
                        retries=3
                    )
                    if port_result and port_result.get("status") == "success":
                        rule.check_port = ", ".join(port_result.get("app_names", []))  # Save matching_apps to check_port
                        logger.info(f"Saved check_port for rule {rule.itsr_number}: {rule.check_port}")
                        print(f"Saved check_port for rule {rule.itsr_number}: {rule.check_port}")
                    elif port_result and port_result.get("status") == "failed":
                        logger.error(f"Port check failed for rule {rule.itsr_number}: {port_result.get('error')}")
                        print(f"Port check failed for rule {rule.itsr_number}: {port_result.get('error')}")

                db.add(rule)  # Ensure rule is marked for update
                db.flush()  # Flush to catch any database errors early
            else:
                logger.warning(f"No interfaces or zones found for rule {rule.itsr_number}")
        else:  # Cisco
            checkInterface.update_firewall_interfaces_for_rule(
                rule=rule,
                username="amishra11",
                password="Dru56%Pty8",
                secret="Dru56%Pty8",
                db=db
            )

    try:
        db.commit()
        logger.info(f"Successfully committed rule {rule.itsr_number} to database")
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to commit rule {rule.itsr_number} to database: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to commit rule to database: {str(e)}")

    return {"message": "Firewall rules submitted successfully!"}

@app.get("/get-rules/{itsr_number}")
async def get_rules(itsr_number: str, db: Session = Depends(get_database)):
    try:
        rules = db.query(FirewallRule).filter(FirewallRule.itsr_number == itsr_number).all()
        if not rules:
            return {"rules": [], "message": "No rules found for this ITSR number"}

        risks = db.query(Risk).all()

        rule_list = []
        for rule in rules:
            matched_risk_description = rule.Risk_Description or ""

            if not matched_risk_description:
                for risk in risks:
                    rule_source_ip = rule.source_ip.strip() if rule.source_ip else ""
                    rule_dest_ip = rule.dest_ip.strip() if rule.dest_ip else ""
                    risk_src_ip = risk.Src_ip.strip() if risk.Src_ip else ""
                    risk_dst_ip = risk.Dst_IP.strip() if risk.Dst_IP else ""

                    if (
                        (rule_source_ip and (rule_source_ip.startswith(risk_src_ip) or rule_source_ip.startswith(risk_dst_ip)))
                        and
                        (rule_dest_ip and (rule_dest_ip.startswith(risk_src_ip) or rule_dest_ip.startswith(risk_dst_ip)))
                    ):
                        matched_risk_description = risk.Risk_Description
                        break

            rule_list.append({
                "itsr_number": rule.itsr_number,
                "source_ip": rule.source_ip,
                "source_subnet": rule.source_subnet or "",
                "dest_ip": rule.dest_ip,
                "dest_subnet": rule.dest_subnet or "",
                "multiple_ports": rule.multiple_ports or "",
                "Firewall": rule.Firewall,
                "inLine": rule.inLine or "",
                "Action": rule.Action or "",
                "pre_status": rule.pre_status,
                "post_status": rule.post_status,
                "post_action": rule.post_action or "",
                "post_reason": rule.post_reason or "",
                "email": rule.email,
                "port_range_start": rule.port_range_start,
                "port_range_end": rule.port_range_end,
                "protocol": rule.protocol,
                "final_status": rule.final_status,
                "matched_Risk_Description": matched_risk_description,
                "Security_Exception_number": rule.Security_Exception_number or "",
                "Security_Exception_expiry_date": rule.Security_Exception_expiry_date,
                "src_interface": rule.src_interface or "",
                "dst_interface": rule.dst_interface or "",
                "source_zone": rule.source_zone or "",
                "dest_zone": rule.dest_zone or "",
                "Reason": rule.Reason or "",
                # Remove or make optional if not in model
                "src_address_name": getattr(rule, 'src_address_name', '') or "",
                "dst_address_name": getattr(rule, 'dst_address_name', '') or "",
                "check_port": rule.check_port or "",
                "src_address_line": rule.src_address_line or "",
                "dst_address_line": rule.dst_address_line or ""
            })

        return {
            "rules": rule_list,
            "message": f"{len(rules)} rule(s) found"
        }
    except Exception as e:
        logger.error(f"Error in get_rules for itsr_number {itsr_number}: {str(e)}")
        return {"rules": [], "message": f"Error fetching rules: {str(e)}"}