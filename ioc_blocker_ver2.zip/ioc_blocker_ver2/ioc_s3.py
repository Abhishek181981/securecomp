from __future__ import annotations
import os
import csv
import ipaddress
import threading
from datetime import datetime
from typing import List, Dict, Tuple, Optional
import pandas as pd
from netmiko import (
    ConnectHandler,
    NetmikoTimeoutException,
    NetmikoAuthenticationException,
)
from paramiko.ssh_exception import SSHException
from tkinter import (
    Tk, Label, Button, Text, Scrollbar, END, RIGHT, Y, LEFT, BOTH,
    messagebox, simpledialog, Frame
)
from tkinter import ttk

# ====== Config files ======
FW_CSV = "firewalls.csv"          # INPUT-ONLY; will NOT be modified by this program
MASTER_IOC = "master_ioc.csv"     # Append-only ledger of IOCs pushed

# ====== Global cancel flag ======
cancel_event = threading.Event()

# =========================
# Helpers (UI-safe updates)
# =========================
def ui_log(line: str):
    def _do():
        log_text.configure(state="normal")
        log_text.insert(END, line.rstrip() + "\n")
        log_text.see(END)
        log_text.configure(state="disabled")
    root.after(0, _do)

def ui_status(text: str):
    root.after(0, lambda: status_label.config(text=text))

def ui_overall_progress(maximum: Optional[int] = None, value: Optional[int] = None):
    def _do():
        if maximum is not None:
            overall_progress.config(maximum=max(1, maximum))
        if value is not None:
            overall_progress["value"] = max(0, min(overall_progress["maximum"], value))
    root.after(0, _do)

def ui_device_progress(maximum: Optional[int] = None, value: Optional[int] = None, label: Optional[str] = None):
    def _do():
        if maximum is not None:
            device_progress.config(maximum=max(1, maximum))
        if value is not None:
            device_progress["value"] = max(0, min(device_progress["maximum"], value))
        if label is not None:
            device_label.config(text=label)
    root.after(0, _do)

# =========================
# Validation & utilities
# =========================
def is_valid_ip(ip: str) -> bool:
    ip = str(ip).strip()
    if not ip or ip == "0.0.0.0":
        return False
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

def append_master_log(ioc_ips: List[str]) -> Tuple[bool, str]:
    try:
        os.makedirs(os.path.dirname(MASTER_IOC) or ".", exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(MASTER_IOC, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for ip in ioc_ips:
                w.writerow([ts, ip])
        return True, "IOC entries appended to master_ioc.csv"
    except Exception as e:
        return False, f"⚠️ Could not append to {MASTER_IOC}: {e}"

# === New helpers for writing reports (instead of modifying firewalls.csv) ===
def make_run_report_path(prefix: str = "firewalls_status") -> str:
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    os.makedirs("reports", exist_ok=True)
    return os.path.join("reports", f"{prefix}_{ts}.csv")

def write_status_report(rows, path):
    """rows: list[dict] with keys: firewall_name, ip, platform, port, status_text, status_code"""
    cols = ["firewall_name", "ip", "platform", "port", "status_text", "status_code"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in cols})

def append_failures_ledger(rows, ledger_path=os.path.join("reports", "firewalls_failures.csv")):
    """Append only failed rows to a cumulative ledger."""
    fail_rows = [r for r in rows if str(r.get("status_code", "")).startswith("failed")]
    if not fail_rows:
        return
    cols = ["timestamp", "firewall_name", "ip", "platform", "port", "status_text", "status_code"]
    os.makedirs(os.path.dirname(ledger_path) or ".", exist_ok=True)
    exists = os.path.exists(ledger_path)
    with open(ledger_path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        if not exists:
            w.writeheader()
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for r in fail_rows:
            w.writerow({
                "timestamp": ts,
                "firewall_name": r.get("firewall_name", ""),
                "ip": r.get("ip", ""),
                "platform": r.get("platform", ""),
                "port": r.get("port", ""),
                "status_text": r.get("status_text", ""),
                "status_code": r.get("status_code", ""),
            })

# Version-tolerant Netmiko connect
def connect_compat(params: Dict) -> any:
    """
    Try to connect with given params. If TypeError due to version-mismatch
    on kwargs (e.g., ssh_strict), retry with compatible params.
    """
    try:
        return ConnectHandler(**params)
    except TypeError as e:
        msg = str(e)
        p = dict(params)
        # Retry without ssh_strict on very old Netmiko; use permissive host key flags
        if "ssh_strict" in msg:
            p.pop("ssh_strict", None)
            p.setdefault("system_host_keys", False)
            p.setdefault("alt_host_keys", False)
            return ConnectHandler(**p)
        # If other unexpected kw issues pop up, re-raise
        raise

# =========================
# Core push per firewall
# =========================
def push_to_one_firewall(
    fw_row: pd.Series,
    ioc_ips: List[str],
    creds: Dict[str, str],
    per_ip_progress_cb: Optional[callable] = None,
) -> Tuple[str, str, str]:
    """
    Returns: (display_name, status_text, status_code)
    status_code in {"success", "failed_auth", "failed_timeout", "failed_other", "cancelled", "skipped"}
    """
    fw_name = str(fw_row.get("firewall_name", "")).strip()
    fw_ip = str(fw_row.get("ip", "")).strip()
    platform = str(fw_row.get("platform", "")).strip().lower()
    port = 22
    try:
        if "port" in fw_row and str(fw_row["port"]).strip():
            port = int(fw_row["port"])  # type: ignore
    except Exception:
        port = 22

    name_disp = fw_name or fw_ip or "?"

    if not fw_ip or not platform:
        return name_disp, "Skipped (missing ip/platform)", "skipped"
    if platform not in ("asa", "srx"):
        return name_disp, f"Skipped (unknown platform '{platform}')", "skipped"
    if cancel_event.is_set():
        return name_disp, "Cancelled", "cancelled"

    device_type = "cisco_asa" if platform == "asa" else "juniper_junos"

    os.makedirs("logs", exist_ok=True)
    session_log = os.path.join("logs", f"{(fw_name or fw_ip).replace(' ', '_')}_{fw_ip}.log")

    params = {
        "device_type": device_type,
        "ip": fw_ip,
        "port": port,
        "username": creds["user"],
        "password": creds["pass"],
        "secret": creds.get("enable", ""),
        # Robustness
        "timeout": 30,
        "banner_timeout": 30,
        "auth_timeout": 25,
        "global_delay_factor": 1.0,
        "allow_agent": False,
        "use_keys": False,  # version-safe alternative to look_for_keys
        "ssh_strict": False,  # removed automatically if too old
        "fast_cli": False,
        "session_log": session_log,
    }

    try:
        with connect_compat(params) as conn:
            if cancel_event.is_set():
                return name_disp, "Cancelled", "cancelled"

            # Quick prompt check (best effort)
            try:
                conn.find_prompt()
            except Exception:
                pass

            # Prepare per-device progress
            total_ip = len(ioc_ips)
            if per_ip_progress_cb:
                per_ip_progress_cb(0, total_ip, f"{name_disp}: connected; starting IOC updates")

            if platform == "asa":
                # Enable mode (best-effort)
                try:
                    if not conn.check_enable_mode():
                        conn.enable()
                except Exception:
                    pass
                # Disable pager
                try:
                    conn.send_command_timing("terminal pager 0")
                except Exception:
                    pass
                # Ensure object-group exists
                try:
                    out = conn.send_command("show run object-group id GENERAL_IOC", read_timeout=15)
                    if "not found" in out.lower() or "error" in out.lower():
                        conn.send_config_set(["object-group network GENERAL_IOC"])
                except Exception:
                    pass

                done = 0
                for ip in ioc_ips:
                    if cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled"
                    cmds = [
                        "object-group network GENERAL_IOC",
                        f"network-object host {ip}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        # tolerate duplicates/benign errors
                        pass
                    done += 1
                    if per_ip_progress_cb:
                        per_ip_progress_cb(done, total_ip, f"{name_disp}: added {ip} ({done}/{total_ip})")

            else:  # SRX
                done = 0
                for ip in ioc_ips:
                    if cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled"
                    addr_name = f"IOC_{ip.replace('.', '_').replace(':', '_')}"
                    cmds = [
                        f"set security address-book global address {addr_name} {ip}",
                        f"set security address-book global address-set GENERAL_IOC address {addr_name}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        pass
                    done += 1
                    if per_ip_progress_cb:
                        per_ip_progress_cb(done, total_ip, f"{name_disp}: added {ip} ({done}/{total_ip})")
                try:
                    conn.commit()
                except Exception:
                    pass

            return name_disp, "Success", "success"

    except NetmikoAuthenticationException as e:
        return name_disp, f"Failed (Auth: {e})", "failed_auth"
    except NetmikoTimeoutException as e:
        return name_disp, f"Failed (Timeout: {e})", "failed_timeout"
    except SSHException as e:
        return name_disp, f"Failed (SSH: {e})", "failed_other"
    except TypeError as e:
        return name_disp, f"Failed (Param: {e})", "failed_other"
    except Exception as e:
        return name_disp, f"Error ({e})", "failed_other"

# =========================
# Batch orchestration (worker thread)
# =========================
def push_ioc(fw_user: str, fw_pass: str, enable_pass: str, pasted_iocs: List[str], root_ref: Tk):
    try:
        if not os.path.exists(FW_CSV):
            root_ref.after(0, lambda: messagebox.showerror("Error", f"'{FW_CSV}' not found."))
            return

        # Read firewalls.csv as INPUT-ONLY; do not mutate or save it back
        df_fw = pd.read_csv(FW_CSV)
        total_fw = len(df_fw)
        if total_fw == 0:
            root_ref.after(0, lambda: messagebox.showwarning("Warning", "No firewalls in firewalls.csv."))
            return

        if not pasted_iocs:
            root_ref.after(0, lambda: messagebox.showwarning("Warning", "No valid IOC IPs provided."))
            return

        # Init overall progress
        ui_overall_progress(maximum=total_fw, value=0)
        ui_device_progress(maximum=1, value=0, label="")

        success_count = fail_auth_count = fail_timeout_count = fail_other_count = skipped_count = 0
        cancelled = False
        completed_fw = 0

        # Collect per-device results here (instead of writing back to FW_CSV)
        run_results = []  # list of dicts

        for _, fw_row in df_fw.iterrows():
            if cancel_event.is_set():
                cancelled = True
                break

            fw_name = str(fw_row.get("firewall_name", "")).strip()
            fw_ip = str(fw_row.get("ip", "")).strip()
            platform = str(fw_row.get("platform", "")).strip()
            port = fw_row.get("port", 22)
            name_disp = fw_name or fw_ip or "?"

            ui_status(f"Connecting to {name_disp} ...")
            ui_log(f"Connecting to {name_disp} ({fw_ip})")

            # Reset per-device progress
            ui_device_progress(maximum=len(pasted_iocs), value=0, label=f"{name_disp}: starting")

            def per_ip_cb(done_ip: int, total_ip: int, msg: str):
                ui_device_progress(maximum=total_ip, value=done_ip, label=msg)

            name, status_text, status_code = push_to_one_firewall(
                fw_row,
                pasted_iocs,
                {"user": fw_user, "pass": fw_pass, "enable": enable_pass or ""},
                per_ip_progress_cb=per_ip_cb
            )

            ui_log(f"{name}: {status_text}")

            # Record result in memory only (do not update firewalls.csv)
            run_results.append({
                "firewall_name": fw_name,
                "ip": fw_ip,
                "platform": platform,
                "port": port,
                "status_text": status_text,
                "status_code": status_code,
            })

            if status_code == "success":
                success_count += 1
            elif status_code == "failed_auth":
                fail_auth_count += 1
            elif status_code == "failed_timeout":
                fail_timeout_count += 1
            elif status_code == "failed_other":
                fail_other_count += 1
            elif status_code == "skipped":
                skipped_count += 1
            elif status_code == "cancelled":
                cancelled = True
                break

            completed_fw += 1
            ui_overall_progress(value=completed_fw)
            ui_status(f"Processed {completed_fw}/{total_fw}: {name} → {status_text}")

        # === NEW: write a separate per-run report ===
        report_path = make_run_report_path()
        try:
            write_status_report(run_results, report_path)
            ui_log(f"📝 Wrote run report: {report_path}")
        except Exception as e:
            ui_log(f"⚠️ Could not write run report: {e}")

        # OPTIONAL: keep a rolling ledger of only failures
        try:
            append_failures_ledger(run_results)
        except Exception as e:
            ui_log(f"⚠️ Could not append failures ledger: {e}")

        # Decide final outcome
        if cancelled:
            msg = (
                "🚫 IOC push was CANCELLED by user.\n\n"
                f"Summary:\n"
                f" ✔ Success: {success_count}\n"
                f" ✖ Auth Failures: {fail_auth_count}\n"
                f" ⌛ Timeouts: {fail_timeout_count}\n"
                f" ⚠ Other Failures: {fail_other_count}\n"
                f" ↷ Skipped: {skipped_count}\n\n"
                "No entries were appended to master_ioc.csv."
            )
            root_ref.after(0, lambda: messagebox.showwarning("IOC Blocker - Cancelled", msg))
            return

        if success_count == 0:
            msg = (
                "❌ IOC push completed with NO SUCCESSFUL devices.\n\n"
                f"Summary:\n"
                f" ✔ Success: {success_count}\n"
                f" ✖ Auth Failures: {fail_auth_count}\n"
                f" ⌛ Timeouts: {fail_timeout_count}\n"
                f" ⚠ Other Failures: {fail_other_count}\n"
                f" ↷ Skipped: {skipped_count}\n\n"
                "No entries were appended to master_ioc.csv.\n"
                "Tip: verify credentials/connectivity or check logs/ for session details."
            )
            root_ref.after(0, lambda: messagebox.showerror("IOC Blocker - Failed", msg))
            return

        ok, note = append_master_log(pasted_iocs)
        final = (
            "✅ IOC push completed.\n\n"
            f"Summary:\n"
            f" ✔ Success: {success_count}\n"
            f" ✖ Auth Failures: {fail_auth_count}\n"
            f" ⌛ Timeouts: {fail_timeout_count}\n"
            f" ⚠ Other Failures: {fail_other_count}\n"
            f" ↷ Skipped: {skipped_count}\n\n"
            f"{note}\n"
            f"Run report: {report_path}"
        )
        root_ref.after(0, lambda: messagebox.showinfo("IOC Blocker", final))

    except Exception as e:
        root_ref.after(0, lambda: messagebox.showerror("Error", f"Unexpected error: {str(e)}"))

# =========================
# GUI events
# =========================
def start_push():
    # Read pasted IOCs (one per line, allow # comments)
    raw = ioc_text.get("1.0", END)
    lines = [ln.strip() for ln in raw.splitlines()]
    lines = [ln for ln in lines if ln and not ln.startswith("#")]

    # Validate & de-duplicate (preserve order)
    pasted_iocs, invalids, seen = [], [], set()
    for ln in lines:
        if is_valid_ip(ln):
            if ln not in seen:
                seen.add(ln)
                pasted_iocs.append(ln)
        else:
            invalids.append(ln)

    if invalids:
        messagebox.showwarning(
            "Invalid IPs",
            f"These entries are invalid and will be skipped:\n{', '.join(invalids[:20])}" + ("..." if len(invalids) > 20 else "")
        )

    fw_user = simpledialog.askstring("Credentials", "Enter firewall username:")
    fw_pass = simpledialog.askstring("Credentials", "Enter firewall password:", show="*")
    enable_pass = simpledialog.askstring("Credentials", "Enter enable password (ASA):", show="*")

    if not fw_user or not fw_pass:
        messagebox.showwarning("Warning", "Credentials not entered.")
        return

    # Reset progress & cancel flag
    cancel_event.clear()
    ui_overall_progress(maximum=1, value=0)
    ui_device_progress(maximum=1, value=0, label="")
    ui_status("Starting...")

    # Launch worker
    threading.Thread(
        target=push_ioc,
        args=(fw_user.strip(), fw_pass, enable_pass or "", pasted_iocs, root),
        daemon=True
    ).start()

def cancel_run():
    cancel_event.set()
    ui_status("Cancelling... Please wait.")
    ui_log("Cancellation requested by user.")

# =========================
# Build GUI
# =========================
root = Tk()
root.title("IOC Blocker")
root.geometry("780x620")
Label(root, text="IOC Blocker Automation", font=("Arial", 16, "bold")).pack(pady=(10, 6))

# Status + Progress bars
status_label = Label(root, text="Idle", fg="blue", anchor="w", justify="left")
status_label.pack(fill="x", padx=16)

prog_frame = Frame(root)
prog_frame.pack(fill="x", padx=16)
Label(prog_frame, text="Overall Progress (firewalls):").pack(anchor="w")
overall_progress = ttk.Progressbar(prog_frame, length=720, mode="determinate")
overall_progress.pack(pady=(0, 8))

device_label = Label(prog_frame, text="Current Device: —")
device_label.pack(anchor="w")
device_progress = ttk.Progressbar(prog_frame, length=720, mode="determinate")
device_progress.pack(pady=(0, 8))

# Paste area with scrollbar
paste_frame = Frame(root)
paste_frame.pack(fill=BOTH, expand=True, padx=16, pady=(6, 6))
Label(paste_frame, text="Paste IOC IPs (one per line):").pack(anchor="w")
ioc_text = Text(paste_frame, height=10, width=96, wrap="none")
ioc_text.pack(side=LEFT, fill=BOTH, expand=True)
scrollbar = Scrollbar(paste_frame, orient="vertical", command=ioc_text.yview)
scrollbar.pack(side=RIGHT, fill=Y)
ioc_text.configure(yscrollcommand=scrollbar.set)

# Optional placeholder
ioc_text.insert("1.0", "203.0.113.5\n198.51.100.10\n# One IP per line; lines starting with # are ignored")

# Log area
Label(root, text="Activity Log:").pack(anchor="w", padx=16)
log_text = Text(root, height=12, width=96, state="disabled", wrap="none")
log_text.pack(padx=16, pady=(0, 6))
log_scroll = ttk.Scrollbar(root, orient="vertical", command=log_text.yview)
log_text.configure(yscrollcommand=log_scroll.set)
log_scroll.place(in_=log_text, relx=1.0, rely=0, relheight=1.0, anchor="ne")

# Buttons
btn_frame = Frame(root)
btn_frame.pack(pady=10)
Button(btn_frame, text="Push IOC to Firewalls", command=start_push, width=24, height=2, bg="green", fg="white").grid(row=0, column=0, padx=8)
Button(btn_frame, text="Cancel", command=cancel_run, width=12, height=2, bg="red", fg="white").grid(row=0, column=1, padx=8)

if __name__ == "__main__":
    root.mainloop()