
import os
import csv
import ipaddress
import threading
from datetime import datetime

import pandas as pd
from netmiko import (
    ConnectHandler,
    NetmikoTimeoutException,
    NetmikoAuthenticationException,
)
from paramiko.ssh_exception import SSHException

from tkinter import Tk, Label, Button, Text, Scrollbar, END, RIGHT, Y, LEFT, BOTH, messagebox, simpledialog, Frame

FW_CSV = "firewalls.csv"
MASTER_IOC = "master_ioc.csv"

# ---------- Helpers ----------
def is_valid_ip(ip: str) -> bool:
    ip = str(ip).strip()
    if not ip or ip == "0.0.0.0":
        return False
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

# ---------- Core push ----------
def push_to_one_firewall(fw_row, ioc_ips, creds, cancel_event=None):
    """
    Returns (display_name, status_string, status_code)
    status_code in {"success", "failed_auth", "failed_timeout", "failed_other", "cancelled", "skipped"}
    """
    fw_name = str(fw_row.get("firewall_name", "")).strip()
    fw_ip = str(fw_row.get("ip", "")).strip()
    platform = str(fw_row.get("platform", "")).strip().lower()
    port = int(fw_row.get("port", 22)) if "port" in fw_row and str(fw_row["port"]).strip() else 22

    name_disp = fw_name or fw_ip or "?"
    if not fw_ip or not platform:
        return name_disp, "Skipped (missing ip/platform)", "skipped"
    if platform not in ("asa", "srx"):
        return name_disp, f"Skipped (unknown platform '{platform}')", "skipped"

    if cancel_event and cancel_event.is_set():
        return name_disp, "Cancelled", "cancelled"

    device_type = "cisco_asa" if platform == "asa" else "juniper_junos"

    os.makedirs("logs", exist_ok=True)
    session_log = os.path.join("logs", f"{(fw_name or fw_ip).replace(' ', '_')}_{fw_ip}.log")

    # Netmiko param compatibility across versions: use 'use_keys' instead of 'look_for_keys'
    params = {
        "device_type": device_type,
        "ip": fw_ip,
        "port": port,
        "username": creds["user"],
        "password": creds["pass"],
        "secret": creds.get("enable", ""),
        # Robustness to avoid hangs / prompts:
        "timeout": 30,
        "banner_timeout": 30,
        "auth_timeout": 25,
        "global_delay_factor": 1.0,
        "allow_agent": False,
        "use_keys": False,       # <- version-safe
        "ssh_strict": False,     # if this raises TypeError in your env, remove and add system_host_keys/alt_host_keys False
        "fast_cli": False,
        "session_log": session_log,
    }

    try:
        with ConnectHandler(**params) as conn:
            if cancel_event and cancel_event.is_set():
                return name_disp, "Cancelled", "cancelled"

            # Diagnostic prompt check (best-effort)
            try:
                conn.find_prompt()
            except Exception:
                pass

            if platform == "asa":
                # Enable (best-effort)
                try:
                    if not conn.check_enable_mode():
                        conn.enable()
                except Exception:
                    pass
                # Avoid pager blocking
                try:
                    conn.send_command_timing("terminal pager 0")
                except Exception:
                    pass
                # Ensure object-group exists
                try:
                    out = conn.send_command("show run object-group id GENERAL_IOC", read_timeout=15)
                    if "not found" in out.lower() or "error" in out.lower():
                        conn.send_config_set(["object-group network GENERAL_IOC"])
                except Exception:
                    pass

                for ip in ioc_ips:
                    if cancel_event and cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled"
                    cmds = [
                        "object-group network GENERAL_IOC",
                        f"network-object host {ip}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        # tolerate duplicates/benign errors
                        pass

            else:  # SRX
                for ip in ioc_ips:
                    if cancel_event and cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled"
                    addr_name = f"IOC_{ip.replace('.', '_').replace(':', '_')}"
                    cmds = [
                        f"set security address-book global address {addr_name} {ip}",
                        f"set security address-book global address-set GENERAL_IOC address {addr_name}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        pass
                try:
                    conn.commit()
                except Exception:
                    pass

        return name_disp, "Success", "success"

    except NetmikoAuthenticationException as e:
        return name_disp, f"Failed (Auth: {e})", "failed_auth"
    except NetmikoTimeoutException as e:
        return name_disp, f"Failed (Timeout: {e})", "failed_timeout"
    except SSHException as e:
        return name_disp, f"Failed (SSH: {e})", "failed_other"
    except TypeError as e:
        # Handle older Netmiko rejecting 'ssh_strict' or others
        return name_disp, f"Failed (Param: {e})", "failed_other"
    except Exception as e:
        return name_disp, f"Error ({e})", "failed_other"

def push_ioc(fw_user, fw_pass, enable_pass, pasted_iocs, root_ref, cancel_event=None):
    """
    Runs in background thread. Determines true outcome and shows correct message.
    """
    try:
        # Pre-checks
        if not os.path.exists(FW_CSV):
            root_ref.after(0, lambda: messagebox.showerror("Error", f"'{FW_CSV}' not found."))
            return

        df_fw = pd.read_csv(FW_CSV)

        if not pasted_iocs:
            root_ref.after(0, lambda: messagebox.showwarning("Warning", "No valid IOC IPs provided."))
            return

        # Result tracking
        success_count = 0
        fail_auth_count = 0
        fail_timeout_count = 0
        fail_other_count = 0
        skipped_count = 0
        cancelled = False

        # Initialize/ensure status column exists
        if "status" not in df_fw.columns:
            df_fw["status"] = ""

        for _, fw_row in df_fw.iterrows():
            if cancel_event and cancel_event.is_set():
                cancelled = True
                break

            fw_name = str(fw_row.get("firewall_name", "")).strip()
            fw_ip = str(fw_row.get("ip", "")).strip()
            print(f"\n➡️  Pushing IOC to {fw_name or fw_ip} ({fw_ip})")

            name, status_text, status_code = push_to_one_firewall(
                fw_row,
                pasted_iocs,
                {"user": fw_user, "pass": fw_pass, "enable": enable_pass or ""},
                cancel_event=cancel_event,
            )
            print(f"   {name}: {status_text}")

            # Update counters and df status (per-device)
            df_fw.loc[df_fw["ip"] == fw_ip, "status"] = status_text

            if status_code == "success":
                success_count += 1
            elif status_code == "failed_auth":
                fail_auth_count += 1
            elif status_code == "failed_timeout":
                fail_timeout_count += 1
            elif status_code == "failed_other":
                fail_other_count += 1
            elif status_code == "skipped":
                skipped_count += 1
            elif status_code == "cancelled":
                cancelled = True
                break

        # Persist per-device status regardless of outcome
        try:
            df_fw.to_csv(FW_CSV, index=False)
            print("\nℹ️ Status updated in firewalls.csv")
        except Exception as e:
            print(f"⚠️ Could not write {FW_CSV}: {e}")

        # Decide final outcome and message
        if cancelled:
            final_msg = (
                "🚫 IOC push was CANCELLED by user.\n\n"
                f"Results so far:\n"
                f"  ✔ Success: {success_count}\n"
                f"  ✖ Auth Failures: {fail_auth_count}\n"
                f"  ⌛ Timeouts: {fail_timeout_count}\n"
                f"  ⚠ Other Failures: {fail_other_count}\n"
                f"  ↷ Skipped: {skipped_count}\n\n"
                "No entries were appended to master_ioc.csv."
            )
            # Do NOT append to master on cancel
            root_ref.after(0, lambda: messagebox.showwarning("IOC Blocker - Cancelled", final_msg))
            return

        if success_count == 0:
            # All failed or skipped
            final_msg = (
                "❌ IOC push completed with NO SUCCESSFUL devices.\n\n"
                f"Details:\n"
                f"  ✔ Success: {success_count}\n"
                f"  ✖ Auth Failures: {fail_auth_count}\n"
                f"  ⌛ Timeouts: {fail_timeout_count}\n"
                f"  ⚠ Other Failures: {fail_other_count}\n"
                f"  ↷ Skipped: {skipped_count}\n\n"
                "No entries were appended to master_ioc.csv.\n"
                "Tip: Check credentials, network reachability (TCP/22), or session logs under ./logs/"
            )
            root_ref.after(0, lambda: messagebox.showerror("IOC Blocker - Failed", final_msg))
            return

        # At least one success → append to master
        try:
            os.makedirs(os.path.dirname(MASTER_IOC) or ".", exist_ok=True)
            with open(MASTER_IOC, mode="a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                for ip in pasted_iocs:
                    writer.writerow([timestamp, ip])
            print("✅ IOC entries appended to master_ioc.csv")
            appended_note = "IOC entries appended to master_ioc.csv."
        except Exception as e:
            print(f"⚠️ Could not append to {MASTER_IOC}: {e}")
            appended_note = f"⚠️ Could not append to {MASTER_IOC}: {e}"

        final_msg = (
            "✅ IOC push completed.\n\n"
            f"Summary:\n"
            f"  ✔ Success: {success_count}\n"
            f"  ✖ Auth Failures: {fail_auth_count}\n"
            f"  ⌛ Timeouts: {fail_timeout_count}\n"
            f"  ⚠ Other Failures: {fail_other_count}\n"
            f"  ↷ Skipped: {skipped_count}\n\n"
            f"{appended_note}\n"
            "See firewalls.csv for per-device status."
        )
        root_ref.after(0, lambda: messagebox.showinfo("IOC Blocker", final_msg))

    except Exception as e:
        root_ref.after(0, lambda: messagebox.showerror("Error", f"Unexpected error: {str(e)}"))

# ---------- GUI ----------
# Add a Cancel button and a shared cancel_event
cancel_event = threading.Event()

def start_push():
    # Read pasted IOCs (one per line, ignore # comments)
    raw = ioc_text.get("1.0", END)
    raw_lines = [ln.strip() for ln in raw.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    pasted_iocs_all = [ln for ln in raw_lines if is_valid_ip(ln)]

    # Deduplicate while preserving order
    seen, pasted_iocs = set(), []
    invalids = []
    for ln in raw_lines:
        if is_valid_ip(ln):
            if ln not in seen:
                seen.add(ln)
                pasted_iocs.append(ln)
        else:
            invalids.append(ln)

    if invalids:
        messagebox.showwarning(
            "Invalid IPs",
            f"These entries are invalid and will be skipped:\n{', '.join(invalids[:20])}"
            + ("..." if len(invalids) > 20 else "")
        )

    fw_user = simpledialog.askstring("Credentials", "Enter firewall username:")
    fw_pass = simpledialog.askstring("Credentials", "Enter firewall password:", show="*")
    enable_pass = simpledialog.askstring("Credentials", "Enter enable password (ASA):", show="*")

    if not fw_user or not fw_pass:
        messagebox.showwarning("Warning", "Credentials not entered.")
        return

    # Reset cancel flag and start background worker
    cancel_event.clear()
    threading.Thread(
        target=push_ioc,
        args=(fw_user, fw_pass, enable_pass, pasted_iocs, root, cancel_event),
        daemon=True
    ).start()

def cancel_run():
    cancel_event.set()

# Build GUI
root = Tk()
root.title("IOC Blocker")
root.geometry("600x460")

Label(root, text="IOC Blocker Automation", font=("Arial", 14, "bold")).pack(pady=(10, 6))

# Paste area frame with scrollbar
paste_frame = Frame(root)
paste_frame.pack(fill=BOTH, expand=True, padx=12)

Label(paste_frame, text="Paste IOC IPs (one per line):").pack(anchor="w")

ioc_text = Text(paste_frame, height=14, width=72, wrap="none")
ioc_text.pack(side=LEFT, fill=BOTH, expand=True)

scrollbar = Scrollbar(paste_frame, orient="vertical", command=ioc_text.yview)
scrollbar.pack(side=RIGHT, fill=Y)
ioc_text.configure(yscrollcommand=scrollbar.set)

# Optional: placeholder text
ioc_text.insert("1.0", "203.0.113.5\n198.51.100.10\n# One IP per line; lines starting with # are ignored")

# Buttons
btn_frame = Frame(root)
btn_frame.pack(pady=12)
Button(btn_frame, text="Push IOC to Firewalls", command=start_push, width=25, height=2, bg="green", fg="white").grid(row=0, column=0, padx=6)
Button(btn_frame, text="Cancel", command=cancel_run, width=12, height=2, bg="red", fg="white").grid(row=0, column=1, padx=6)

root.mainloop()
