import sys, os, re

PATCH_HELPERS = r"""
def _count_firewalls_in_scope(self) -> int:
    try:
        base = _collector_dir_or_here()
        path = os.path.join(base, 'firewalls.csv')
        if not os.path.exists(path):
            return 0
        with open(path, 'r', encoding='utf-8', newline='') as f:
            return sum(1 for _ in csv.DictReader(f))
    except Exception:
        return 0

def _count_successful_collection(self, rep_dir: str) -> int:
    def _unique_hosts(path):
        hosts = set()
        with open(path, 'r', encoding='utf-8', newline='') as f:
            for r in csv.DictReader(f):
                h = (r.get('hostname') or '').strip()
                if h:
                    hosts.add(h)
        return len(hosts)

    path_acls = os.path.join(rep_dir, 'acls.csv')
    if os.path.exists(path_acls):
        try:
            return _unique_hosts(path_acls)
        except Exception:
            pass

    path_risky = os.path.join(rep_dir, 'risky_acl.csv')
    if os.path.exists(path_risky):
        try:
            return _unique_hosts(path_risky)
        except Exception:
            pass

    return 0
"""

PATCH_UI = r"""
        # --- Row 3: Collection Status ---
        self.kpi_collect = ttk.LabelFrame(self.tab_dash, text="Collection Status")
        self.kpi_collect.grid(row=3, column=0, sticky='ew', padx=PAD, pady=(0, 4))
        for c in range(6):
            self.kpi_collect.columnconfigure(c, weight=1)

        chip_bg_collect = "#fff6e5"
        self.lbl_collect_scope  = self._make_chip(self.kpi_collect, "In Scope: �",  fg="#7a4b00", bg=chip_bg_collect)
        self.lbl_collect_success = self._make_chip(self.kpi_collect, "Success: �",   fg="#215a21", bg=chip_bg_collect)
        self.lbl_collect_failed  = self._make_chip(self.kpi_collect, "Failed: �",    fg="#7a1f1f", bg=chip_bg_collect)

        self.lbl_collect_scope.grid (row=0, column=0, sticky='w', padx=4, pady=6)
        self.lbl_collect_success.grid(row=0, column=1, sticky='w', padx=4, pady=6)
        self.lbl_collect_failed.grid (row=0, column=2, sticky='w', padx=4, pady=6)
"""

PATCH_SUMMARY = r"""
        # --- Collection Status chips ---
        try:
            total_scope = self._count_firewalls_in_scope()
            successful = self._count_successful_collection(rep_dir)
            failed = max(0, total_scope - successful)

            self.lbl_collect_scope.config(text=f"In Scope: {total_scope}")
            self.lbl_collect_success.config(text=f"Success: {successful}")
            self.lbl_collect_failed.config(text=f"Failed: {failed}")
        except Exception:
            pass
"""

def apply_patch(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    orig = text

    # 1) Insert helper functions (only once)
    if "_count_firewalls_in_scope" not in text:
        text = text.replace(
            "def _count_total_acls",
            PATCH_HELPERS + "\n\ndef _count_total_acls"
        )

    # 2) Insert KPIs (below Zero KPIs row)
    if "self.kpi_collect" not in text:
        marker = "self.lbl_p21_zero.grid"
        text = text.replace(
            marker,
            marker + "\n" + PATCH_UI
        )

    # 3) Insert summary update (after total ACL label)
    if "lbl_collect_scope" not in text:
        marker = "self.lbl_total_acls.config"
        text = re.sub(
            r"(self\.lbl_total_acls\.config[^\n]+)",
            r"\1\n" + PATCH_SUMMARY,
            text
        )

    if text == orig:
        print("Nothing changed: file was already patched.")
        return

    backup = path + ".bak"
    os.rename(path, backup)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    print(f"Patched successfully.\nBackup created: {backup}\nPatched file: {path}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python patch_collection_status.py gui_remediate.py")
        sys.exit(1)

    apply_patch(sys.argv[1])