
from __future__ import annotations
import os
import csv
import ipaddress
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import List, Dict, Tuple, Optional, Any

# Optional premium theming (ttkbootstrap). Falls back to ttk if not present.
_USE_BOOTSTRAP = True
try:
    import ttkbootstrap as tb
    from ttkbootstrap.constants import *
except Exception:
    _USE_BOOTSTRAP = False

import pandas as pd
from netmiko import (
    ConnectHandler,
    NetmikoTimeoutException,
    NetmikoAuthenticationException,
)
from paramiko.ssh_exception import SSHException

import tkinter as tk
from tkinter import (
    Tk, Text, Scrollbar, END, RIGHT, Y, LEFT, BOTH, Toplevel, Menu, messagebox, simpledialog,
)
from tkinter import ttk

# ========= Config files =========
FW_CSV = "firewalls.csv"           # INPUT-ONLY; will NOT be modified by this program
MASTER_IOC = "master_ioc.csv"      # Append-only ledger of IOCs pushed

# ========= Global =========
cancel_event = threading.Event()

# ========= Tunables =========
DEFAULT_MAX_WORKERS = 6
ACCENT_HEX = "#2563EB"             # Fluent-ish blue

# ========= UI-safe helper calls =========
def ui_log(line: str):
    def _do():
        log_text.configure(state="normal")
        log_text.insert(END, line.rstrip() + "\n")
        log_text.see(END)
        log_text.configure(state="disabled")
    root.after(0, _do)

def ui_status(text: str):
    root.after(0, lambda: status_label.config(text=text))

def ui_overall_progress(maximum: Optional[int] = None, value: Optional[int] = None):
    def _do():
        if maximum is not None:
            overall_progress.config(maximum=max(1, maximum))
        if value is not None:
            now_max = overall_progress["maximum"]
            overall_progress["value"] = max(0, min(now_max, value))
    root.after(0, _do)

def ui_device_progress(maximum: Optional[int] = None, value: Optional[int] = None, label: Optional[str] = None):
    def _do():
        if maximum is not None:
            device_progress.config(maximum=max(1, maximum))
        if value is not None:
            now_max = device_progress["maximum"]
            device_progress["value"] = max(0, min(now_max, value))
        if label is not None:
            device_label.configure(text=label)
    root.after(0, _do)

def ui_update_badges(succ: int, fa: int, ft: int, fo: int, sk: int):
    def _do():
        badge_success.config(text=f"Success {succ}")
        badge_auth.config(text=f"Auth {fa}")
        badge_timeout.config(text=f"Timeout {ft}")
        badge_other.config(text=f"Other {fo}")
        badge_skipped.config(text=f"Skipped {sk}")
    root.after(0, _do)

def ui_add_row(row: dict):
    def _do():
        results_tree.insert(
            "", END,
            values=(
                row.get("firewall_name", ""),
                row.get("ip", ""),
                row.get("platform", ""),
                row.get("status_code", ""),
                row.get("status_text", ""),
            )
        )
    root.after(0, _do)

def toast(msg: str, ms: int = 2000):
    def _do():
        top = Toplevel(root)
        top.overrideredirect(True)
        top.attributes("-topmost", True)
        # Neutral dark toast
        bg, fg = "#111827", "#F9FAFB"
        top.configure(bg=bg)
        ttk.Label(top, text=msg, background=bg, foreground=fg).pack(padx=14, pady=8)
        try:
            root.update_idletasks()
            x = root.winfo_rootx() + root.winfo_width() - 320
            y = root.winfo_rooty() + root.winfo_height() - 120
            top.geometry(f"+{x}+{y}")
        except Exception:
            pass
        top.after(ms, top.destroy)
    root.after(0, _do)

# ========= Validation & reporting =========
def is_valid_ip(ip: str) -> bool:
    ip = str(ip).strip()
    if not ip or ip == "0.0.0.0":
        return False
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

def append_master_log(ioc_ips: List[str]) -> Tuple[bool, str]:
    try:
        os.makedirs(os.path.dirname(MASTER_IOC) or ".", exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(MASTER_IOC, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for ip in ioc_ips:
                w.writerow([ts, ip])
        return True, "IOC entries appended to master_ioc.csv"
    except Exception as e:
        return False, f"Could not append to {MASTER_IOC}: {e}"

def make_run_report_path(prefix: str = "firewalls_status") -> str:
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    os.makedirs("reports", exist_ok=True)
    return os.path.join("reports", f"{prefix}_{ts}.csv")

def write_status_report(rows, path):
    cols = ["firewall_name", "ip", "platform", "port", "status_text", "status_code", "ha_reason"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in cols})

def append_failures_ledger(rows, ledger_path=os.path.join("reports", "firewalls_failures.csv")):
    fail_rows = [r for r in rows if str(r.get("status_code", "")).startswith("failed")]
    if not fail_rows:
        return
    cols = ["timestamp", "firewall_name", "ip", "platform", "port", "status_text", "status_code", "ha_reason"]
    os.makedirs(os.path.dirname(ledger_path) or ".", exist_ok=True)
    exists = os.path.exists(ledger_path)
    with open(ledger_path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        if not exists:
            w.writeheader()
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for r in fail_rows:
            w.writerow({
                "timestamp": ts,
                "firewall_name": r.get("firewall_name", ""),
                "ip": r.get("ip", ""),
                "platform": r.get("platform", ""),
                "port": r.get("port", ""),
                "status_text": r.get("status_text", ""),
                "status_code": r.get("status_code", ""),
                "ha_reason": r.get("ha_reason", ""),
            })

# ========= Netmiko compatibility =========
def connect_compat(params: Dict) -> Any:
    try:
        return ConnectHandler(**params)
    except TypeError as e:
        msg = str(e)
        p = dict(params)
        if "ssh_strict" in msg:
            p.pop("ssh_strict", None)
            p.setdefault("system_host_keys", False)
            p.setdefault("alt_host_keys", False)
            return ConnectHandler(**p)
        raise

# ========= Core push (HA removed) =========
def push_to_one_firewall(
    fw_row: pd.Series,
    ioc_ips: List[str],
    creds: Dict[str, str],
    per_ip_progress_cb: Optional[callable] = None,
) -> Tuple[str, str, str, str]:

    fw_name = str(fw_row.get("firewall_name", "")).strip()
    fw_ip = str(fw_row.get("ip", "")).strip()
    platform_raw = str(fw_row.get("platform", "")).strip().lower()

    if platform_raw in {"panos", "paloalto", "palo_alto", "pa"}:
        platform = "panos"
    elif platform_raw in {"asa"}:
        platform = "asa"
    elif platform_raw in {"srx", "junos", "juniper"}:
        platform = "srx"
    else:
        platform = platform_raw

    vsys = str(fw_row.get("vsys", "vsys1")).strip() or "vsys1"

    port = 22
    try:
        if "port" in fw_row and str(fw_row["port"]).strip():
            port = int(fw_row["port"])  # type: ignore
    except Exception:
        port = 22

    name_disp = fw_name or fw_ip or "?"
    if not fw_ip or not platform:
        return name_disp, "Skipped (missing ip/platform)", "skipped", "missing ip/platform"
    if platform not in ("asa", "srx", "panos"):
        return name_disp, f"Skipped (unknown platform '{platform_raw}')", "skipped", f"unknown platform '{platform_raw}'"
    if cancel_event.is_set():
        return name_disp, "Cancelled", "cancelled", "cancel requested"

    if platform == "asa":
        device_type = "cisco_asa"
    elif platform == "srx":
        device_type = "juniper_junos"
    else:
        device_type = "paloalto_panos"

    os.makedirs("logs", exist_ok=True)
    session_log = os.path.join("logs", f"{(fw_name or fw_ip).replace(' ', '_')}_{fw_ip}.log")

    params = {
        "device_type": device_type,
        "ip": fw_ip,
        "port": port,
        "username": creds["user"],
        "password": creds["pass"],
        "secret": creds.get("enable", ""),
        "timeout": 30,
        "banner_timeout": 30,
        "auth_timeout": 25,
        "global_delay_factor": 1.0,
        "allow_agent": False,
        "use_keys": False,
        "ssh_strict": False,
        "fast_cli": False,
        "session_log": session_log,
    }

    try:
        with connect_compat(params) as conn:
            if cancel_event.is_set():
                return name_disp, "Cancelled", "cancelled", "cancel requested"

            try:
                conn.find_prompt()
            except Exception:
                pass

            # HA check removed → proceed
            ha_reason = "HA check disabled"

            total_ip = len(ioc_ips)
            if per_ip_progress_cb:
                per_ip_progress_cb(0, total_ip, f"{name_disp}: connected; starting IOC updates")

            if platform == "asa":
                try:
                    if not conn.check_enable_mode():
                        conn.enable()
                except Exception:
                    pass
                try:
                    conn.send_command_timing("terminal pager 0")
                except Exception:
                    pass
                try:
                    out = conn.send_command("show run object-group id GENERAL_IOC", read_timeout=15)
                    low = out.lower()
                    if ("not found" in low) or ("error" in low):
                        conn.send_config_set(["object-group network GENERAL_IOC"])
                except Exception:
                    pass

                done = 0
                for ip in ioc_ips:
                    if cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled", "cancel requested"
                    cmds = [
                        "object-group network GENERAL_IOC",
                        f"network-object host {ip}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        pass
                    done += 1
                    if per_ip_progress_cb:
                        per_ip_progress_cb(done, total_ip, f"{name_disp}: added {ip} ({done}/{total_ip})")

            elif platform == "srx":
                done = 0
                for ip in ioc_ips:
                    if cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled", "cancel requested"
                    addr_name = f"IOC_{ip.replace('.', '_').replace(':', '_')}"
                    cmds = [
                        f"set security address-book global address {addr_name} {ip}",
                        f"set security address-book global address-set GENERAL_IOC address {addr_name}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        pass
                    done += 1
                    if per_ip_progress_cb:
                        per_ip_progress_cb(done, total_ip, f"{name_disp}: added {ip} ({done}/{total_ip})")
                try:
                    conn.commit()
                except Exception:
                    pass

            else:  # panos
                try:
                    conn.send_config_set([f"set system setting target-vsys {vsys}"], cmd_verify=False)
                except Exception:
                    pass

                done = 0
                for ip in ioc_ips:
                    if cancel_event.is_set():
                        return name_disp, "Cancelled", "cancelled", "cancel requested"
                    addr_name = f"IOC_{ip.replace('.', '_').replace(':', '_')}"
                    cmds = [
                        f"set address {addr_name} ip-netmask {ip}",
                        f"set address-group GENERAL_IOC static {addr_name}",
                    ]
                    try:
                        conn.send_config_set(cmds, cmd_verify=False)
                    except Exception:
                        pass
                    done += 1
                    if per_ip_progress_cb:
                        per_ip_progress_cb(done, total_ip, f"{name_disp}: added {ip} ({done}/{total_ip})")
                try:
                    conn.commit()
                except Exception:
                    return name_disp, "Failed (commit error)", "failed_other", "PAN-OS commit error"

            return name_disp, "Success", "success", ha_reason

    except NetmikoAuthenticationException as e:
        return name_disp, f"Failed (Auth: {e})", "failed_auth", "auth error"
    except NetmikoTimeoutException as e:
        return name_disp, f"Failed (Timeout: {e})", "failed_timeout", "timeout"
    except SSHException as e:
        return name_disp, f"Failed (SSH: {e})", "failed_other", "ssh error"
    except TypeError as e:
        return name_disp, f"Failed (Param: {e})", "failed_other", "param error"
    except Exception as e:
        return name_disp, f"Error ({e})", "failed_other", "exception"

# ========= Orchestration =========
def push_ioc(fw_user: str, fw_pass: str, enable_pass: str, pasted_iocs: List[str], root_ref):
    try:
        if not os.path.exists(FW_CSV):
            root_ref.after(0, lambda: messagebox.showerror("Error", f"'{FW_CSV}' not found."))
            return

        df_fw = pd.read_csv(FW_CSV)
        total_fw = len(df_fw)
        if total_fw == 0:
            root_ref.after(0, lambda: messagebox.showwarning("Warning", "No firewalls in firewalls.csv."))
            return
        if not pasted_iocs:
            root_ref.after(0, lambda: messagebox.showwarning("Warning", "No valid IOC IPs provided."))
            return

        ui_overall_progress(maximum=total_fw, value=0)

        def _spin_start():
            device_progress.configure(mode="indeterminate")
            device_progress.start(50)
        root.after(0, _spin_start)
        ui_device_progress(maximum=1, value=0, label="Preparing parallel run...")

        success_count = fail_auth_count = fail_timeout_count = fail_other_count = 0
        skipped_count = 0
        cancelled = False
        completed_fw = 0
        run_results: List[Dict[str, str]] = []

        creds = {"user": fw_user, "pass": fw_pass, "enable": enable_pass or ""}

        max_workers = min(DEFAULT_MAX_WORKERS, total_fw) if total_fw > 0 else 1

        def _submit_one(row: pd.Series):
            fw_name = str(row.get("firewall_name", "")).strip()
            fw_ip = str(row.get("ip", "")).strip()
            name_disp = fw_name or fw_ip or "?"
            ui_log(f"Queueing {name_disp} ({fw_ip})")
            return push_to_one_firewall(row, pasted_iocs, creds, per_ip_progress_cb=None)

        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="fw") as tp:
            future_map = {tp.submit(_submit_one, fw_row): fw_row for _, fw_row in df_fw.iterrows()}

            def _spin_stop():
                device_progress.stop()
                device_progress.configure(mode="determinate")
                ui_device_progress(label=f"Parallel mode (workers {max_workers})")
            root.after(0, _spin_stop)

            for fut in as_completed(future_map):
                if cancel_event.is_set():
                    cancelled = True
                fw_row = future_map[fut]
                fw_name = str(fw_row.get("firewall_name", "")).strip()
                fw_ip = str(fw_row.get("ip", "")).strip()
                platform = str(fw_row.get("platform", "")).strip()
                port = fw_row.get("port", 22)
                try:
                    name, status_text, status_code, ha_reason = fut.result()
                except Exception as e:
                    name, status_text, status_code, ha_reason = (
                        fw_name or fw_ip or "?",
                        f"Error ({e})", "failed_other", "exception"
                    )

                ui_log(f"{name}: {status_text}")
                run_results.append({
                    "firewall_name": fw_name,
                    "ip": fw_ip,
                    "platform": platform,
                    "port": port,
                    "status_text": status_text,
                    "status_code": status_code,
                    "ha_reason": ha_reason,
                })

                if status_code == "success":
                    success_count += 1
                elif status_code == "failed_auth":
                    fail_auth_count += 1
                elif status_code == "failed_timeout":
                    fail_timeout_count += 1
                elif status_code == "failed_other":
                    fail_other_count += 1
                elif status_code == "skipped":
                    skipped_count += 1
                elif status_code == "cancelled":
                    cancelled = True

                ui_update_badges(success_count, fail_auth_count, fail_timeout_count, fail_other_count, skipped_count)

                completed_fw += 1
                ui_overall_progress(value=completed_fw)
                ui_status(f"Processed {completed_fw}/{total_fw}: {name} → {status_text}")
                ui_add_row({
                    "firewall_name": fw_name,
                    "ip": fw_ip,
                    "platform": platform,
                    "status_code": status_code,
                    "status_text": status_text,
                })

        report_path = make_run_report_path()
        try:
            write_status_report(run_results, report_path)
            ui_log(f"Wrote run report: {report_path}")
            toast(f"Report written: {report_path}")
        except Exception as e:
            ui_log(f"Could not write run report: {e}")

        try:
            append_failures_ledger(run_results)
        except Exception as e:
            ui_log(f"Could not append failures ledger: {e}")

        scope_line = f"Scope (firewalls): {total_fw}"

        if cancelled:
            msg = f"""IOC push was CANCELLED by user.

Summary:
 {scope_line}
 Success: {success_count}
 Auth Failures: {fail_auth_count}
 Timeouts: {fail_timeout_count}
 Other Failures: {fail_other_count}
 Skipped: {skipped_count}

No entries were appended to master_ioc.csv."""
            root_ref.after(0, lambda: messagebox.showwarning("IOC Blocker - Cancelled", msg))
            return

        if success_count == 0:
            msg = f"""IOC push completed with NO SUCCESSFUL devices.

Summary:
 {scope_line}
 Success: {success_count}
 Auth Failures: {fail_auth_count}
 Timeouts: {fail_timeout_count}
 Other Failures: {fail_other_count}
 Skipped: {skipped_count}

No entries were appended to master_ioc.csv.
Tip: verify credentials/connectivity or check logs/ for session details."""
            root_ref.after(0, lambda: messagebox.showerror("IOC Blocker - Failed", msg))
            return

        ok, note = append_master_log(pasted_iocs)
        final = f"""IOC push completed.

Summary:
 {scope_line}
 Success: {success_count}
 Auth Failures: {fail_auth_count}
 Timeouts: {fail_timeout_count}
 Other Failures: {fail_other_count}
 Skipped: {skipped_count}

{note}
Run report: {report_path}"""
        root_ref.after(0, lambda: messagebox.showinfo("IOC Blocker", final))
        toast("IOC push completed")

    except Exception as e:
        root_ref.after(0, lambda: messagebox.showerror("Error", f"Unexpected error: {str(e)}"))

# ========= Events =========
def start_push():
    raw = ioc_text.get("1.0", END)
    lines = [ln.strip() for ln in raw.splitlines()]
    lines = [ln for ln in lines if ln and not ln.startswith("#")]

    pasted_iocs, invalids, seen = [], [], set()
    for ln in lines:
        if is_valid_ip(ln):
            if ln not in seen:
                seen.add(ln)
                pasted_iocs.append(ln)
        else:
            invalids.append(ln)

    if invalids:
        preview = ", ".join(invalids[:20]) + ("..." if len(invalids) > 20 else "")
        messagebox.showwarning("Invalid IPs", "These entries are invalid and will be skipped:\n" + preview)

    fw_user = simpledialog.askstring("Credentials", "Enter firewall username:")
    fw_pass = simpledialog.askstring("Credentials", "Enter firewall password:", show="*")
    enable_pass = simpledialog.askstring("Credentials", "Enter enable password (ASA):", show="*")
    if not fw_user or not fw_pass:
        messagebox.showwarning("Warning", "Credentials not entered.")
        return

    cancel_event.clear()
    ui_overall_progress(maximum=1, value=0)
    ui_device_progress(maximum=1, value=0, label="")
    ui_status("Starting...")
    threading.Thread(
        target=push_ioc,
        args=(fw_user.strip(), fw_pass, enable_pass or "", pasted_iocs, root),
        daemon=True
    ).start()

def cancel_run():
    cancel_event.set()
    ui_status("Cancelling... Please wait.")
    ui_log("Cancellation requested by user.")
    toast("Cancelling...")

def open_folder(path: str):
    try:
        os.makedirs(path, exist_ok=True)
        import subprocess, platform
        if platform.system() == "Windows":
            subprocess.Popen(f'explorer "{os.path.abspath(path)}"')
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", os.path.abspath(path)])
        else:
            subprocess.Popen(["xdg-open", os.path.abspath(path)])
    except Exception as e:
        toast(f"Cannot open folder: {e}")

# ========= Build UI (Modern) =========
if _USE_BOOTSTRAP:
    root = tb.Window(themename="flatly")  # try "cosmo"/"minty"/"flatly"
    # You can switch default theme by changing themename above
else:
    root = Tk()

root.title("IOC Blocker")
root.geometry("1040x800")

# ----- App Bar -----
appbar = ttk.Frame(root)
appbar.pack(fill="x")
title_lbl = ttk.Label(appbar, text="SecurBlock-An IOC Blocker", font=("Segoe UI", 16, "bold"))
title_lbl.pack(side=LEFT, padx=16, pady=10)

# Appbar actions
btn_open_reports = ttk.Button(appbar, text="Open Reports", command=lambda: open_folder("reports"))
btn_open_logs = ttk.Button(appbar, text="Open Logs", command=lambda: open_folder("logs"))
btn_open_reports.pack(side=RIGHT, padx=6, pady=10)
btn_open_logs.pack(side=RIGHT, padx=6, pady=10)

# ----- Notebook (Tabs) -----
notebook = ttk.Notebook(root)
notebook.pack(fill=BOTH, expand=True, padx=12, pady=12)

tab_run = ttk.Frame(notebook)
tab_results = ttk.Frame(notebook)
tab_logs = ttk.Frame(notebook)
notebook.add(tab_run, text="Run")
notebook.add(tab_results, text="Results")
notebook.add(tab_logs, text="Logs")

# RUN tab
# Badges row
badges_row = ttk.Frame(tab_run)
badges_row.pack(fill="x", padx=8, pady=(6, 2))

def _badge(parent, text, bg="#E5E7EB", fg="#111827"):
    c = tk.Label(parent, text=text, bg=bg, fg=fg, padx=10, pady=3, font=("Segoe UI", 9))
    c.pack(side=LEFT, padx=4)
    return c

badge_success = _badge(badges_row, "Success 0", "#D1FAE5", "#065F46")
badge_auth    = _badge(badges_row, "Auth 0",    "#FEE2E2", "#7F1D1D")
badge_timeout = _badge(badges_row, "Timeout 0", "#FEF3C7", "#7C2D12")
badge_other   = _badge(badges_row, "Other 0",   "#EDE9FE", "#4C1D95")
badge_skipped = _badge(badges_row, "Skipped 0", "#E5E7EB", "#1F2937")

# Controls row
controls = ttk.Frame(tab_run)
controls.pack(fill="x", padx=8, pady=(6, 8))
btn_start = ttk.Button(controls, text="Push IOC to Firewalls", command=start_push)
btn_cancel = ttk.Button(controls, text="Cancel", command=cancel_run)
btn_start.pack(side=LEFT, padx=6)
btn_cancel.pack(side=LEFT, padx=6)

# Status + Progress
status_label = ttk.Label(tab_run, text="Idle", anchor="w")
status_label.pack(fill="x", padx=12)
prog_row = ttk.Frame(tab_run)
prog_row.pack(fill="x", padx=12, pady=(4, 4))
ttk.Label(prog_row, text="Overall Progress (firewalls):").pack(anchor="w")
overall_progress = ttk.Progressbar(prog_row, length=960, mode="determinate")
overall_progress.pack(fill="x", pady=(2, 8))
device_label = ttk.Label(prog_row, text="Current Device: —")
device_label.pack(anchor="w")
device_progress = ttk.Progressbar(prog_row, length=960, mode="determinate")
device_progress.pack(fill="x", pady=(2, 6))

# IOC input area
ioc_frame = ttk.LabelFrame(tab_run, text="IOC IPs (one per line)")
ioc_frame.pack(fill=BOTH, expand=True, padx=12, pady=(6, 10))
ioc_text = Text(ioc_frame, height=10, wrap="none", font=("Consolas", 10))
ioc_text.pack(side=LEFT, fill=BOTH, expand=True)
ioc_scroll = ttk.Scrollbar(ioc_frame, orient="vertical", command=ioc_text.yview)
ioc_scroll.pack(side=RIGHT, fill=Y)
ioc_text.configure(yscrollcommand=ioc_scroll.set)
ioc_text.insert("1.0", "203.0.113.5\n198.51.100.10\n# One IP per line; lines starting with # are ignored")

# RESULTS tab
res_top = ttk.Frame(tab_results)
res_top.pack(fill="x", padx=12, pady=(12, 6))
ttk.Label(res_top, text="Quick filter:").pack(side=LEFT)
filter_entry = ttk.Entry(res_top, width=30)
filter_entry.pack(side=LEFT, padx=8)

def apply_filter(*_):
    q = filter_entry.get().strip().lower()
    for iid in results_tree.get_children(""):
        results_tree.reattach(iid, "", "end")
    if q:
        for iid in results_tree.get_children(""):
            vals = results_tree.item(iid, "values")
            show = any(q in str(v).lower() for v in vals)
            if not show:
                results_tree.detach(iid)

filter_entry.bind("<KeyRelease>", apply_filter)

results_frame = ttk.Frame(tab_results)
results_frame.pack(fill=BOTH, expand=True, padx=12, pady=(0, 12))
cols = ("firewall_name", "ip", "platform", "status_code", "status_text")
results_tree = ttk.Treeview(results_frame, columns=cols, show="headings", height=14)
for c in cols:
    results_tree.heading(c, text=c.replace("_", " ").title())
    results_tree.column(c, width=160 if c != "status_text" else 520, anchor="w")
results_tree.pack(side=LEFT, fill=BOTH, expand=True)
results_scroll = ttk.Scrollbar(results_frame, orient="vertical", command=results_tree.yview)
results_scroll.pack(side=RIGHT, fill=Y)
results_tree.configure(yscrollcommand=results_scroll.set)

# LOGS tab
logs_top = ttk.Frame(tab_logs)
logs_top.pack(fill="x", padx=12, pady=(12, 4))
def copy_log_selection(_=None):
    try:
        text = log_text.get("sel.first", "sel.last")
    except Exception:
        text = log_text.get("1.0", END)
    root.clipboard_clear()
    root.clipboard_append(text.strip())
    toast("Log copied")

btn_copy_log = ttk.Button(logs_top, text="Copy Log", command=copy_log_selection)
btn_copy_log.pack(side=LEFT, padx=4)

log_frame = ttk.Frame(tab_logs)
log_frame.pack(fill=BOTH, expand=True, padx=12, pady=(4, 12))
log_text = Text(log_frame, height=24, wrap="none", font=("Consolas", 10))
log_text.pack(side=LEFT, fill=BOTH, expand=True)
log_scroll2 = ttk.Scrollbar(log_frame, orient="vertical", command=log_text.yview)
log_scroll2.pack(side=RIGHT, fill=Y)
log_text.configure(yscrollcommand=log_scroll2.set)
log_text.configure(state="disabled")

# ----- Menubar (Theme switcher if ttkbootstrap present) -----
menubar = Menu(root)
view_menu = Menu(menubar, tearoff=False)
if _USE_BOOTSTRAP:
    themes = ["flatly", "cosmo", "minty", "pulse", "sandstone", "yeti", "journal"]
    sub = Menu(view_menu, tearoff=False)
    for t in themes:
        sub.add_command(label=t.title(), command=lambda n=t: tb.Style().theme_use(n))
    view_menu.add_cascade(label="Bootstrap Theme", menu=sub)
else:
    # Fallback: minimal theme change is limited in base ttk
    view_menu.add_command(label="Use Accent Blue", command=lambda: None)
menubar.add_cascade(label="View", menu=view_menu)
root.config(menu=menubar)

# ----- Keyboard shortcuts -----
root.bind("<Control-Return>", lambda e: start_push())
root.bind("<Escape>", lambda e: cancel_run())
root.bind("<Control-l>", lambda e: (log_text.configure(state="normal"), log_text.delete("1.0", END), log_text.configure(state="disabled")))

# ----- Subtle styling (fallback when no ttkbootstrap) -----
def apply_fallback_style():
    if _USE_BOOTSTRAP:
        # Accent primary button + progress bars
        btn_start.configure(bootstyle=f"PRIMARY")
        overall_progress.configure(bootstyle="success-striped")
        device_progress.configure(bootstyle="info-striped")
        return
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    # Progress accent
    style.configure("Accent.Horizontal.TProgressbar", background=ACCENT_HEX)
    overall_progress.configure(style="Accent.Horizontal.TProgressbar")
    device_progress.configure(style="Accent.Horizontal.TProgressbar")
    # Text widgets: crisp white background, dark caret
    ioc_text.configure(bg="#FFFFFF", fg="#111827", insertbackground="#111827")
    log_text.configure(bg="#FFFFFF", fg="#111827", insertbackground="#111827")

apply_fallback_style()

# ====== RUN ======
if __name__ == "__main__":
    root.mainloop()
