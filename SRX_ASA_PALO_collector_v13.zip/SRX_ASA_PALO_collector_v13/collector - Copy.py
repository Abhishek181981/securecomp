# -*- coding: utf-8 -*-
"""Standalone Network Flow Collector

What it does
- Reads firewall.csv (hostname, ip, platform, [mode], [context])
- Connects to each firewall and collects 3 datasets: routes, interface IPs, ACL/policies
- Writes consolidated CSVs in a timestamped run folder: routes.csv, ips.csv, acls.csv
- Writes per-device raw text dumps in the run folder
- Publishes consolidated CSVs + status.csv into a stable reports/latest/ folder for GUI search
- Tracks connection/collection status per firewall (SUCCESS/FAILED) in status.csv

ASA multi-context behavior (per your correction)
- If firewall.csv column 'mode' is set to 'multi' (case-insensitive), the ASA is treated as multi-context
  and data is collected from ALL contexts (discovered via 'show context').
- If firewall.csv column 'context' contains a specific context name, only that context is collected.
- If 'mode' is not 'multi', device is treated as single-context.
- CLI flags still work:
    --asa-context-filter : regex filter for discovered contexts
    --asa-contexts       : comma-separated contexts to collect (overrides discovery)

Usage examples:
  python collector.py
  python collector.py --threads 12
  python collector.py --asa-all-contexts
  python collector.py --asa-contexts "admin,prod"
"""

import os
import sys
import re
import csv
import argparse
import shutil
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import getpass

from netmiko import ConnectHandler

# ---------------- Inventory & filesystem helpers ----------------

def read_firewall_csv(path: str) -> List[Dict[str, str]]:
    """Read firewall.csv with columns: hostname, ip, platform, [mode], [context]."""
    rows: List[Dict[str, str]] = []
    with open(path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            hostname = (r.get("hostname") or "").strip()
            ip = (r.get("ip") or "").strip()
            platform = (r.get("platform") or "").strip()
            mode = (r.get("mode") or "").strip().lower()
            context = (r.get("context") or "").strip()
            if not hostname or not ip or not platform:
                continue
            rows.append({
                "hostname": hostname,
                "ip": ip,
                "platform": platform,
                "mode": mode,
                "context": context,
            })
    return rows


def ensure_run_dir(base: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(base, ts)
    os.makedirs(run_dir, exist_ok=True)
    return run_dir


def write_csv_header_if_needed(path: str, headers: List[str]) -> None:
    write_header = not os.path.isfile(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        if write_header:
            w.writeheader()


CSV_LOCK = Lock()

def append_csv_row(path: str, headers: List[str], row: Dict[str, str]) -> None:
    """Thread-safe CSV append."""
    with CSV_LOCK:
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writerow(row)


def save_text(run_dir: str, fname: str, text: str) -> None:
    with open(os.path.join(run_dir, fname), "w", encoding="utf-8") as f:
        f.write(text if text is not None else "")


def update_latest_dir(base_reports_dir: str, run_dir: str) -> None:
    """Publish consolidated CSVs into <base_reports_dir>/latest for GUI search.

    Copies: routes.csv, ips.csv, acls.csv, status.csv.
    Uses temp dir + atomic rename (os.replace) to avoid partial reads.
    Writes latest_run.txt with the run folder name.
    """
    latest_dir = os.path.join(base_reports_dir, "latest")
    tmp_dir = os.path.join(base_reports_dir, ".latest_tmp")
    bak_dir = os.path.join(base_reports_dir, ".latest_bak")

    os.makedirs(base_reports_dir, exist_ok=True)

    if os.path.isdir(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)
    os.makedirs(tmp_dir, exist_ok=True)

    copied = 0
    for fname in ("routes.csv", "ips.csv", "acls.csv", "status.csv"):
        src = os.path.join(run_dir, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(tmp_dir, fname))
            copied += 1

    if copied == 0:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise RuntimeError("No consolidated CSVs found to publish to latest/")

    if os.path.isdir(bak_dir):
        shutil.rmtree(bak_dir, ignore_errors=True)

    if os.path.isdir(latest_dir):
        os.replace(latest_dir, bak_dir)

    os.replace(tmp_dir, latest_dir)

    if os.path.isdir(bak_dir):
        shutil.rmtree(bak_dir, ignore_errors=True)

    run_name = os.path.basename(run_dir.rstrip(os.sep))
    with open(os.path.join(base_reports_dir, "latest_run.txt"), "w", encoding="utf-8") as f:
        f.write(run_name)


# ---------------- Platform command map ----------------

def platform_cmds(platform: str) -> Dict[str, str]:
    p = (platform or "").strip().lower()
    if p in {"asa", "cisco asa", "cisco-asa"}:
        return {
            "routes": "show route",
            "ips": "show interface ip brief",
            "acls": "show access-list",
        }
    if ("srx" in p) or ("juniper" in p) or ("junos" in p):
        return {
            "routes": "show route | no-more",
            "ips": "show interfaces terse | no-more",
            "acls": "show security policies | no-more",
        }
    # Palo Alto / PAN-OS
    return {
        "routes": "show routing route",
        "ips": "show interface all",
        "acls": "show running security-policy",
    }


def infer_device_type(platform: str) -> str:
    p = (platform or "").strip().lower()
    if ("srx" in p) or ("juniper" in p) or ("junos" in p):
        return "juniper_junos"
    if ("palo alto" in p) or ("pan-os" in p) or ("panos" in p) or p.startswith("pa ") or (p == "pa"):
        return "paloalto_panos"
    return "cisco_asa"


# ---------------- CSV schemas ----------------

FLOW_HEADERS = ["timestamp", "hostname", "ip", "platform", "context", "command", "line"]
STATUS_HEADERS = ["timestamp", "hostname", "status"]


# ---------------- ASA multi-context helpers ----------------

ASA_CTX_HEADER_RE = re.compile(r'^\s*Context\s+Name\s+Class', re.IGNORECASE)
ASA_CTX_NAME_RE = re.compile(r'^\*?([A-Za-z0-9_.\-]+)\s+', re.ASCII)


def asa_changeto_system(conn) -> None:
    """Best-effort: return to system context and turn pager off."""
    try:
        conn.send_command("changeto system", expect_string=r'[\>\#]', read_timeout=10)
        try:
            conn.send_command("terminal pager 0", expect_string=r'[\>\#]', read_timeout=10)
        except Exception:
            pass
    except Exception:
        pass


def asa_list_contexts(conn) -> List[str]:
    """Return list of context names by parsing 'show context' from system context."""
    names: List[str] = []
    try:
        asa_changeto_system(conn)
        out = conn.send_command("show context", expect_string=r'[\>\#]', read_timeout=30) or ""
    except Exception:
        return names

    for raw in out.splitlines():
        s = (raw or "").strip()
        if not s or ASA_CTX_HEADER_RE.search(s):
            continue
        m = ASA_CTX_NAME_RE.match(s)
        if not m:
            continue
        name = m.group(1).lstrip('*').strip()
        if not name or '/' in name or name.lower().startswith('ethernet') or name.lower() == 'total':
            continue
        if name not in names:
            names.append(name)
    return names


def asa_changeto_context(conn, name: str) -> bool:
    if not name:
        return False
    try:
        conn.send_command(f"changeto context {name}", expect_string=r'[\>\#]', read_timeout=20)
        try:
            conn.send_command("terminal pager 0", expect_string=r'[\>\#]', read_timeout=10)
        except Exception:
            pass
        return True
    except Exception:
        return False


def is_multi_context_row(device_type: str, mode: str) -> bool:
    """Decide if this inventory row should be treated as ASA multi-context (mode=multi)."""
    return device_type == "cisco_asa" and (mode or "").strip().lower() == "multi"


def wants_all_contexts_from_csv(context_field: str) -> bool:
    """Deprecated: multi-context is controlled by mode column, not context."""
    return False


# ---------------- Core collector ----------------

def collect_from_one(
    device_row: Dict[str, str],
    username: str,
    password: str,
    secret: Optional[str],
    run_dir: str,
    read_timeout: int = 180,
    asa_all_contexts: bool = False,
    asa_ctx_filter: Optional[str] = None,
    asa_ctx_list: Optional[List[str]] = None,
) -> Tuple[str, bool, str]:
    """Connect to a device and collect the 3 datasets. Returns (hostname, success, message)."""

    hostname = device_row["hostname"]
    host_ip = device_row["ip"]
    platform = device_row["platform"]
    mode = (device_row.get("mode") or "").strip().lower()
    csv_ctx = (device_row.get("context") or "").strip()

    device_type = infer_device_type(platform)
    cmds = platform_cmds(platform)

    dev = {
        "device_type": device_type,
        "host": host_ip,
        "username": username,
        "password": password,
        "secret": secret or "",
    }

    routes_csv = os.path.join(run_dir, "routes.csv")
    ips_csv = os.path.join(run_dir, "ips.csv")
    acls_csv = os.path.join(run_dir, "acls.csv")

    try:
        conn = ConnectHandler(**dev)

        # Privilege / pager hygiene
        if device_type == "cisco_asa" and secret:
            try:
                conn.enable()
            except Exception:
                pass

        try:
            if device_type == "juniper_junos":
                conn.send_command("set cli screen-length 0", expect_string=r'[\>\#]', read_timeout=10)
            else:
                conn.send_command("terminal pager 0", expect_string=r'[\>\#]', read_timeout=10)
        except Exception:
            pass

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        def _run_and_record(kind: str, cmd: str, out_csv: str, context_name: str) -> None:
            out = conn.send_command(cmd, expect_string=r'[\>\#]', read_timeout=read_timeout) or ""
            dump_ctx_suffix = f"_{context_name}" if context_name else ""
            save_text(run_dir, f"{hostname}{dump_ctx_suffix}_{kind}.txt", out if out.strip() else "<empty>")
            if out:
                for line in out.splitlines():
                    row = {
                        "timestamp": now,
                        "hostname": hostname,
                        "ip": host_ip,
                        "platform": platform,
                        "context": context_name or "",
                        "command": cmd,
                        "line": (line or "").strip(),
                    }
                    append_csv_row(out_csv, FLOW_HEADERS, row)

        # Non-ASA or non-multi => simple collection
        if not is_multi_context_row(device_type, mode):
            _run_and_record("routes", cmds["routes"], routes_csv, context_name="")
            _run_and_record("ips", cmds["ips"], ips_csv, context_name="")
            _run_and_record("acls", cmds["acls"], acls_csv, context_name="")
            try:
                conn.disconnect()
            except Exception:
                pass
            return hostname, True, "ok"

        # ASA multi-context rules
        # 1) If firewall.csv context is a specific name (and not 'multi'), collect only that context.
        if csv_ctx and not wants_all_contexts_from_csv(csv_ctx):
            if asa_changeto_context(conn, csv_ctx):
                _run_and_record("routes", cmds["routes"], routes_csv, context_name=csv_ctx)
                _run_and_record("ips", cmds["ips"], ips_csv, context_name=csv_ctx)
                _run_and_record("acls", cmds["acls"], acls_csv, context_name=csv_ctx)
                asa_changeto_system(conn)
            else:
                # still attempt in current context but label it
                _run_and_record("routes", cmds["routes"], routes_csv, context_name=csv_ctx)
                _run_and_record("ips", cmds["ips"], ips_csv, context_name=csv_ctx)
                _run_and_record("acls", cmds["acls"], acls_csv, context_name=csv_ctx)
            try:
                conn.disconnect()
            except Exception:
                pass
            return hostname, True, "ok"        # 2) Determine contexts to iterate:
        contexts: List[str] = []

        # CLI explicit list wins (if provided)
        if asa_ctx_list:
            contexts = [c.strip() for c in asa_ctx_list if c and c.strip()]

        # Otherwise discover ALL contexts for multi-mode ASA
        if not contexts:
            contexts = asa_list_contexts(conn)

        # Apply regex filter (CLI) if provided
        if contexts and asa_ctx_filter:
            try:
                rx = re.compile(asa_ctx_filter)
                contexts = [c for c in contexts if rx.search(c)]
            except re.error:
                pass

        # If still none, collect in current context
        if not contexts:
            _run_and_record("routes", cmds["routes"], routes_csv, context_name="")
            _run_and_record("ips", cmds["ips"], ips_csv, context_name="")
            _run_and_record("acls", cmds["acls"], acls_csv, context_name="")
            try:
                conn.disconnect()
            except Exception:
                pass
            return hostname, True, "ok"

        # Iterate contexts
        asa_changeto_system(conn)
        for ctx in contexts:
            if not asa_changeto_context(conn, ctx):
                save_text(run_dir, f"{hostname}_{ctx}_context_error.txt", f"Failed to enter context: {ctx}")
                continue
            _run_and_record("routes", cmds["routes"], routes_csv, context_name=ctx)
            _run_and_record("ips", cmds["ips"], ips_csv, context_name=ctx)
            _run_and_record("acls", cmds["acls"], acls_csv, context_name=ctx)
            asa_changeto_system(conn)

        try:
            conn.disconnect()
        except Exception:
            pass
        return hostname, True, "ok"

    except Exception as e:
        return hostname, False, str(e)


# ---------------- CLI entrypoint ----------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Standalone Network Flow Collector")
    ap.add_argument("--csv", default="firewall.csv", help="Path to firewall inventory CSV")
    ap.add_argument("--base", default="reports", help="Base reports directory")
    ap.add_argument("--threads", type=int, default=10, help="Parallel threads")

    ap.add_argument("--asa-all-contexts", action="store_true",
                    help="(Deprecated) Multi-context is controlled by firewall.csv mode=multi; all contexts are swept automatically.")
    ap.add_argument("--asa-context-filter", default="",
                    help="Regex to include only matching ASA contexts (used with --asa-all-contexts).")
    ap.add_argument("--asa-contexts", default="",
                    help="Comma-separated explicit ASA contexts to use (overrides discovery).")

    args = ap.parse_args()

    print("Enter credentials to use for ALL devices in firewall.csv")
    user = input("Username: ").strip()
    pwd = getpass.getpass("Password: ").strip()
    enable = getpass.getpass("ASA Enable Secret (optional, press Enter to skip): ").strip()

    if not user or not pwd:
        print("ERROR: Username and Password are required.")
        sys.exit(2)

    inv_path = args.csv
    if not os.path.isfile(inv_path):
        print(f"ERROR: Inventory '{inv_path}' not found.")
        sys.exit(2)

    # Prepare run folder
    runs_base = os.path.join(args.base, "runs")
    run_dir = ensure_run_dir(runs_base)

    # Initialize consolidated CSVs
    write_csv_header_if_needed(os.path.join(run_dir, "routes.csv"), FLOW_HEADERS)
    write_csv_header_if_needed(os.path.join(run_dir, "ips.csv"), FLOW_HEADERS)
    write_csv_header_if_needed(os.path.join(run_dir, "acls.csv"), FLOW_HEADERS)

    # Status file (temporary in run folder; published to latest/ then removed)
    status_csv = os.path.join(run_dir, "status.csv")
    write_csv_header_if_needed(status_csv, STATUS_HEADERS)

    rows = read_firewall_csv(inv_path)
    if not rows:
        print("No valid rows found in firewall.csv")
        sys.exit(0)

    print(f"[RUN] {run_dir}")
    print(f"[INFO] Devices: {len(rows)} | Threads: {args.threads}")

    ok, fail = 0, 0
    ctx_list = [c.strip() for c in args.asa_contexts.split(",")] if args.asa_contexts.strip() else None

    def record_status(host: str, success: bool) -> None:
        append_csv_row(status_csv, STATUS_HEADERS, {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "hostname": host,
            "status": "SUCCESS" if success else "FAILED",
        })

    if args.threads <= 1:
        for r in rows:
            host, success, msg = collect_from_one(
                r, user, pwd, enable, run_dir,
                asa_all_contexts=args.asa_all_contexts,
                asa_ctx_filter=(args.asa_context_filter or None),
                asa_ctx_list=ctx_list,
            )
            if success:
                ok += 1
                print(f"[OK] {host}")
            else:
                fail += 1
                print(f"[FAIL] {host}: {msg}")
            record_status(host, success)
    else:
        with ThreadPoolExecutor(max_workers=max(1, args.threads)) as ex:
            futs = [
                ex.submit(
                    collect_from_one, r, user, pwd, enable, run_dir,
                    180, args.asa_all_contexts, (args.asa_context_filter or None), ctx_list
                )
                for r in rows
            ]
            for fut in as_completed(futs):
                host, success, msg = fut.result()
                if success:
                    ok += 1
                    print(f"[OK] {host}")
                else:
                    fail += 1
                    print(f"[FAIL] {host}: {msg}")
                record_status(host, success)

    print(f"[DONE] OK={ok} FAIL={fail} -> {run_dir}")
    print("Outputs:")
    print(" - routes.csv, ips.csv, acls.csv")
    print(" - status.csv (published to reports/latest/status.csv)")
    print(" - <hostname>_<context>_routes.txt / _ips.txt / _acls.txt (context omitted for single-mode)")

    # Publish to stable latest/ for GUI search
    try:
        update_latest_dir(args.base, run_dir)
        print(f"[LATEST] Updated: {os.path.join(args.base, 'latest')}")
    except Exception as e:
        print(f"[WARN] Failed to update latest/: {e}")

    # Keep status.csv only in latest/ (remove from run folder)
    try:
        if os.path.isfile(status_csv):
            os.remove(status_csv)
    except Exception:
        pass


if __name__ == "__main__":
    main()
