#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Threads-only modular network-flow collector orchestrator (verbose build).

What this build adds (while preserving your CSV layout and behavior):
• Verbose, timestamped live progress printed to stdout (flushed):
  QUEUE •, CONNECT →, SESSION ✓, FETCH →, DONE ✓, FAILED ✗
• A line-based “Progress: <done>/<total> …” after each device (easy for GUI).
• Session logs under: ./reports/latest/logs/<host>_session.log
• ACL headers keep hit_count and ace_hash; risky/zero align accordingly.
• REPORTS_DIR can be overridden by env (defaults to ./reports/latest).
• Credentials default from env: FW_USER, FW_PASS, FW_EN_SECRET (still overridable).
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import getpass
import time
import socket
import signal
import threading
from pathlib import Path
from typing import Optional, Tuple, List, Dict, IO, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# ---- vendor collectors (remain untouched) ----
try:
    from platforms import asa_collector, srx_collector, palo_collector
except ImportError as e:
    print(f"[FATAL] Could not import vendor collectors: {e}", file=sys.stderr, flush=True)
    sys.exit(2)

# ---- paths ----
BASE = Path(".").resolve()
# Optional env override so GUI can redirect reports later (keeps default otherwise)
REPORTS_DIR = Path(os.getenv("REPORTS_DIR") or (BASE / "reports" / "latest")).resolve()
LOGS_DIR = REPORTS_DIR / "logs"
INVENTORY = BASE / "firewall.csv"

# ---- CSV headers (preserved from your build) ----
ROUTES_HDR = ["hostname", "platform", "vrf", "route", "nexthop"]
IPS_HDR    = ["hostname", "platform", "interface", "ip", "mask"]

# NOTE: Includes hit_count and ace_hash
ACLS_HDR = [
    "hostname","platform","rule_id","action","src","dst",
    "hit_count","ace_hash","remark","raw_ace"
]

OBJECTS_HDR = ["hostname", "platform", "type", "name", "group", "member", "value", "metadata"]
STATUS_HDR  = [
    "firewall hostname",
    "IP status",
    "Route status",
    "Acl status",
    "Object group status",
    "overall-status",
]

# Zero ACLs mirror ACL headers; Risky extends with risk fields
ZERO_ACL_HDR  = ACLS_HDR[:]
RISKY_ACL_HDR = ACLS_HDR[:] + ["risk", "risk_description"]

# ---- Setup & verbose printing ----
def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def vprint(verbose: bool, *args) -> None:
    """Timestamped, flushed prints when verbose is enabled."""
    if verbose:
        print(f"[{_now()}]", *args, flush=True)

# ---- Setup: dirs + pre-create report CSVs with headers ----
def ensure_dirs_and_reports() -> None:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    with (REPORTS_DIR / "routes.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=ROUTES_HDR).writeheader()
    with (REPORTS_DIR / "ips.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=IPS_HDR).writeheader()
    with (REPORTS_DIR / "acls.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=ACLS_HDR).writeheader()
    with (REPORTS_DIR / "objects.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=OBJECTS_HDR).writeheader()
    with (REPORTS_DIR / "status.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=STATUS_HDR).writeheader()
    with (REPORTS_DIR / "zero_acl.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=ZERO_ACL_HDR).writeheader()
    with (REPORTS_DIR / "risky_acl.csv").open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=RISKY_ACL_HDR).writeheader()

def open_writers():
    f_objs   = (REPORTS_DIR / "objects.csv").open("a", newline="", encoding="utf-8")
    f_routes = (REPORTS_DIR / "routes.csv").open("a", newline="", encoding="utf-8")
    f_ips    = (REPORTS_DIR / "ips.csv").open("a", newline="", encoding="utf-8")
    f_acls   = (REPORTS_DIR / "acls.csv").open("a", newline="", encoding="utf-8")
    f_status = (REPORTS_DIR / "status.csv").open("a", newline="", encoding="utf-8")
    f_zero   = (REPORTS_DIR / "zero_acl.csv").open("a", newline="", encoding="utf-8")
    f_risky  = (REPORTS_DIR / "risky_acl.csv").open("a", newline="", encoding="utf-8")

    return (
        csv.DictWriter(f_objs,   fieldnames=OBJECTS_HDR),
        csv.DictWriter(f_routes, fieldnames=ROUTES_HDR),
        csv.DictWriter(f_ips,    fieldnames=IPS_HDR),
        csv.DictWriter(f_acls,   fieldnames=ACLS_HDR),
        csv.DictWriter(f_status, fieldnames=STATUS_HDR),
        csv.DictWriter(f_zero,   fieldnames=ZERO_ACL_HDR),
        csv.DictWriter(f_risky,  fieldnames=RISKY_ACL_HDR),
        [f_objs, f_routes, f_ips, f_acls, f_status, f_zero, f_risky],
    )

def close_writers(files: List[IO[str]]) -> None:
    for fh in files:
        try:
            fh.close()
        except Exception:
            pass

# ---- Inventory ----
def read_inventory(inv_path: Path) -> List[Dict[str, str]]:
    if not inv_path.exists():
        print(f"[FATAL] Inventory not found: {inv_path}", file=sys.stderr, flush=True)
        return []
    rows: List[Dict[str, str]] = []
    with inv_path.open("r", newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f)
        for r in rd:
            r["platform"] = (r.get("platform") or "").strip()
            rows.append(r)
    return rows

# ---- Netmiko helpers ----
def _device_type_for_platform(platform: str) -> Optional[str]:
    p = (platform or "").strip().lower()
    if p in ("asa", "cisco asa"): return "cisco_asa"
    if p in ("srx", "juniper srx"): return "juniper_junos"
    if p in ("palo alto","paloalto","palo-alto","pan-os"): return "paloalto_panos"
    return None

# Resolve creds; interactive=False prevents any stdin prompts in worker threads
def _resolve_credentials(
    row: Dict[str, str], cli_user: str, cli_pass: str, cli_en: str,
    force_global: bool, interactive: bool
) -> Tuple[str, str, str]:
    if force_global:
        user, pwd, en = cli_user, cli_pass, cli_en
    else:
        user = (row.get("username") or cli_user or "").strip()
        pwd  = (row.get("password") or cli_pass or "").strip()
        en   = (row.get("enable_secret") or cli_en or "").strip()

    if not interactive:
        return user, pwd, en

    if not user:
        user = input("Username: ").strip()
    if not pwd:
        pwd  = getpass.getpass("Password: ")
    if (row.get("platform","").lower() in ("asa","cisco asa")) and not en:
        en = getpass.getpass("Enable secret (ASA): ")
    return user, pwd, en

def connect_device(
    row: Dict[str, str], username: str, password: str, secret: str,
    logs_dir: Path, timeouts: Dict[str, int], force_global_creds: bool,
    verbose: bool = True
):
    try:
        from netmiko import ConnectHandler
    except Exception as e:
        raise RuntimeError("Netmiko not installed. Run 'pip install netmiko paramiko'.") from e

    host = row.get("ip") or row.get("hostname") or row.get("host")
    if not host:
        raise RuntimeError("Inventory row missing 'ip' or 'hostname'.")
    platform = row.get("platform") or ""
    device_type = _device_type_for_platform(platform)
    if not device_type:
        raise RuntimeError(f"Unsupported platform: {platform}")

    # Workers are non-interactive
    user, pwd, en = _resolve_credentials(row, username, password, secret, force_global_creds, interactive=False)

    # Fail fast if anything essential is missing
    if not user or not pwd:
        raise RuntimeError("Missing credentials for device (non-interactive thread). Provide --username/--password or per-row creds, or use --force-global-creds.")
    if device_type == "cisco_asa" and not en:
        raise RuntimeError("ASA enable secret missing (non-interactive thread). Provide --enable-secret or per-row enable_secret.")

    session_log = (logs_dir / f"{host}_session.log").resolve()
    params: Dict[str, Any] = {
        "device_type": device_type,
        "ip": host,
        "username": user,
        "password": pwd,
        "port": int(row.get("port") or 22),
        "fast_cli": False,
        "session_log": str(session_log),

        # Password-only + longer timeouts (tunable via --device-timeout)
        "allow_agent": False,
        "use_keys": False,

        "auth_timeout": timeouts.get("auth_timeout", 60),
        "banner_timeout": timeouts.get("banner_timeout", 60),
        "conn_timeout": timeouts.get("conn_timeout", 60),
        "global_delay_factor": timeouts.get("global_delay_factor", 1.5),
    }
    if device_type == "cisco_asa" and en:
        params["secret"] = en

    if (row.get("transport") or "ssh").lower() == "telnet":
        params["device_type"] = device_type + "_telnet"

    vprint(verbose, f"CONNECT  → {host} ({params['device_type']})")
    session = ConnectHandler(**params)

    # shim for vendor collectors that pass expect_string
    def _expect_string(pattern, timeout=10): return None
    session.expect_string = _expect_string  # type: ignore[attr-defined]

    vprint(verbose, f"SESSION  ✓ {host} (connected)")
    return session

# ---- Vendor dispatch (adapters unchanged; writer_risky preserved) ----
def run_vendor_collector(platform: str, session, row: dict,
                         writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky,
                         verbose: bool = True):
    p = (platform or "").strip().lower()
    host_id = (row.get("hostname") or row.get("ip") or "device")
    if p in ("asa", "cisco asa"):
        vprint(verbose, f"FETCH    → {host_id} [ASA] (objs/routes/ips/acls)")
        ctx_raw = (row.get("context_filter") or "").strip()
        ctx_filter = [x.strip() for x in ctx_raw.split(",") if x.strip()] if ctx_raw else None
        return asa_collector.collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky, context_filter=ctx_filter)
    if p in ("srx", "juniper srx"):
        vprint(verbose, f"FETCH    → {host_id} [SRX] (objs/routes/ips/acls)")
        return srx_collector.collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky)
    if p in ("palo alto","paloalto","palo-alto","pan-os"):
        vprint(verbose, f"FETCH    → {host_id} [Palo Alto] (objs/routes/ips/acls)")
        return palo_collector.collect(session, row, writer_objs, writer_routes, writer_ips, writer_acls, writer_zero, writer_risky)
    print(f"[WARN] Unsupported platform: {platform}", flush=True)
    return None, None, None

# ---- Locked writer wrapper (per-file locks) ----
class LockedWriter:
    def __init__(self, writer: csv.DictWriter, lock: threading.Lock):
        self._w = writer
        self._lock = lock
    def writerow(self, row):
        with self._lock:
            self._w.writerow(row)
    def writerows(self, rows):
        with self._lock:
            self._w.writerows(rows)
    def __getattr__(self, name):
        return getattr(self._w, name)

# ---- Thread-safe writers using per-file locks ----
class SafeWriters:
    def __init__(self):
        ( self._w_objs, self._w_routes, self._w_ips, self._w_acls,
          self._w_status, self._w_zero, self._w_risky, self.files ) = open_writers()
        # One lock per file -> concurrent writes to different files are allowed
        self.l_objs   = threading.Lock()
        self.l_routes = threading.Lock()
        self.l_ips    = threading.Lock()
        self.l_acls   = threading.Lock()
        self.l_status = threading.Lock()
        self.l_zero   = threading.Lock()
        self.l_risky  = threading.Lock()
        # Expose locked writers to vendor collectors
        self.w_objs   = LockedWriter(self._w_objs,   self.l_objs)
        self.w_routes = LockedWriter(self._w_routes, self.l_routes)
        self.w_ips    = LockedWriter(self._w_ips,    self.l_ips)
        self.w_acls   = LockedWriter(self._w_acls,   self.l_acls)
        self.w_status = LockedWriter(self._w_status, self.l_status)
        self.w_zero   = LockedWriter(self._w_zero,   self.l_zero)
        self.w_risky  = LockedWriter(self._w_risky,  self.l_risky)
    def write_status(self, row: Dict[str, str]):
        self.w_status.writerow(row)
    def get_writers(self):
        return (self.w_objs, self.w_routes, self.w_ips, self.w_acls, self.w_zero, self.w_risky)
    def close(self):
        close_writers(self.files)

# ---- Retry classification ----
def is_retryable(exc: Exception) -> bool:
    transient = (TimeoutError, EOFError, ConnectionResetError, BrokenPipeError, socket.timeout)
    if isinstance(exc, transient): return True
    name = exc.__class__.__name__
    if name in ("NetmikoTimeoutException","SSHException"): return True
    if name in ("AuthenticationException","NetmikoAuthenticationException"): return False
    return False

# ---- Worker ----
def collect_one(row: Dict[str, str], writers: SafeWriters,
                global_user: str, global_pass: str, global_en: str,
                timeouts: Dict[str, int], retries: int, backoff: float,
                force_global_creds: bool, verbose: bool = True) -> Tuple[str, bool, float, str]:
    hostname = (row.get("hostname") or row.get("host") or row.get("ip") or "device")
    platform = row.get("platform", "")
    status = {
        "firewall hostname": hostname,
        "IP status": "failed",
        "Route status": "failed",
        "Acl status": "failed",
        "Object group status": "failed",
        "overall-status": "failed",
    }
    start = time.time()
    attempt = 0
    while True:
        attempt += 1
        try:
            vprint(verbose, f"QUEUE    • {hostname} [{platform}] (attempt {attempt}/{retries})")
            # Connect
            session = connect_device(row, global_user, global_pass, global_en, LOGS_DIR, timeouts, force_global_creds, verbose=verbose)

            # Collect
            (w_objs, w_routes, w_ips, w_acls, w_zero, w_risky) = writers.get_writers()
            t_collect = time.time()
            routes_txt, ips_txt, acls_txt = run_vendor_collector(platform, session, row, w_objs, w_routes, w_ips, w_acls, w_zero, w_risky, verbose=verbose)

            if routes_txt and str(routes_txt).strip(): status["Route status"] = "success"
            if ips_txt and str(ips_txt).strip():       status["IP status"]    = "success"
            if acls_txt and str(acls_txt).strip():     status["Acl status"]   = "success"

            # ASA objects (best-effort)
            try:
                if (platform or "").strip().lower() in ("asa","cisco asa"):
                    from platforms.asa_collector import get_asa_objects_text
                    objs_txt = get_asa_objects_text(session)
                    if objs_txt and objs_txt.strip():
                        status["Object group status"] = "success"
            except Exception:
                pass

            if all(status[k] == "success" for k in ["IP status","Route status","Acl status","Object group status"]):
                status["overall-status"] = "success"

            writers.write_status(status)
            try:
                session.disconnect()
            except Exception:
                pass

            elapsed = time.time() - start
            vprint(verbose, f"DONE     ✓ {hostname} [{platform}] in {elapsed:0.1f}s  (fetch {time.time()-t_collect:0.1f}s)")
            return hostname, True, elapsed, "ok"

        except Exception as e:
            if attempt <= retries and is_retryable(e):
                sleep_for = (2 ** (attempt - 1)) * max(0.0, backoff)
                vprint(verbose, f"RETRY    ! {hostname} transient error: {e} → {sleep_for:0.1f}s")
                time.sleep(sleep_for)
                continue
            else:
                writers.write_status(status)
                elapsed = time.time() - start
                vprint(verbose, f"FAILED   ✗ {hostname} [{platform}] after {elapsed:0.1f}s → {e}")
                return hostname, False, elapsed, f"{e}"

# ---- Progress + ETA (line-based, friendly to GUI) ----
class Progress:
    def __init__(self, total: int):
        self.total = total
        self.done = 0
        self.ok = 0
        self.fail = 0
        self.lock = threading.Lock()
        self.samples: List[float] = []
    def update(self, success: bool, elapsed: float):
        with self.lock:
            self.done += 1
            if success: self.ok += 1
            else:       self.fail += 1
            self.samples.append(elapsed)
            if len(self.samples) > 50:
                self.samples.pop(0)
    def eta(self) -> str:
        with self.lock:
            if self.done == 0: return "--:--"
            avg = sum(self.samples) / len(self.samples)
            remaining = self.total - self.done
            eta_sec = max(0, int(remaining * avg))
            m, s = divmod(eta_sec, 60)
            return f"{m:02d}m {s:02d}s"

# ---- Graceful shutdown ----
_shutdown = False
def _sigint_handler(signum, frame):
    global _shutdown
    _shutdown = True
    print("\n[WARN] Ctrl+C received. Finishing in-flight devices; no new work will be started.", flush=True)

# ---- Optional flow evaluator (unchanged) ----
def run_flow_eval(src: str, dst: str) -> int:
    acls = REPORTS_DIR / "acls.csv"
    objs = REPORTS_DIR / "objects.csv"
    try:
        from modular_collector.flow_eval_ip_only import evaluate_flow
    except Exception as e:
        print(f"[ERROR] Flow evaluator missing: {e}", flush=True)
        return 3
    res = evaluate_flow(src, dst, acls, objs)
    print(json.dumps(res, indent=2))
    return 0

# ---- Main ----
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    # Optional flow evaluation
    ap.add_argument("--eval-flow", nargs=2, metavar=("SRC_IP","DST_IP"), help="Run IP-only flow evaluation on latest reports")

    # Concurrency & reliability
    ap.add_argument("--threads", type=int, default=max(1, min(16, (os.cpu_count() or 4) * 4)), help="Max concurrent threads")
    ap.add_argument("--retries", type=int, default=1, help="Retries on transient SSH/connectivity errors")
    ap.add_argument("--retry-backoff", type=float, default=2.0, help="Base backoff seconds (exponential 2^n * base)")
    ap.add_argument("--device-timeout", type=int, default=120, help="Per-device connect timeouts (auth/banner/conn) seconds")

    # Credentials (single global prompt; can be forced to apply to all rows)
    # Defaults from ENV support the GUI Option-B: FW_USER, FW_PASS, FW_EN_SECRET
    ap.add_argument("--force-global-creds", action="store_true", help="Ignore per-row creds; use global creds for all devices")
    ap.add_argument("--username", default=os.getenv("FW_USER") or "")
    ap.add_argument("--password", default=os.getenv("FW_PASS") or "")
    ap.add_argument("--enable-secret", default=os.getenv("FW_EN_SECRET") or "")

    # Verbose progress
    ap.add_argument("--verbose", dest="verbose", action="store_true", default=True, help="Enable verbose live progress")
    ap.add_argument("--no-verbose", dest="verbose", action="store_false", help="Disable verbose live progress")

    args = ap.parse_args(argv)

    # Flow eval short-circuit
    if args.eval_flow:
        return run_flow_eval(args.eval_flow[0], args.eval_flow[1])

    signal.signal(signal.SIGINT, _sigint_handler)

    # Output dirs & CSVs
    ensure_dirs_and_reports()
    writers = SafeWriters()
    try:
        # Inventory + quick info
        inventory = read_inventory(INVENTORY)
        print(f"[INFO] Inventory: {INVENTORY}", flush=True)
        print(f"[INFO] Inventory rows: {len(inventory)}", flush=True)
        if not inventory:
            print("[WARN] Inventory empty.", flush=True)
            writers.close()
            return 0

        # Prompt once in main (if not supplied from args/env)
        global_user = args.username or input("Username: ").strip()
        global_pass = args.password or getpass.getpass("Password: ")

        # Prompt ASA enable once if any ASA present and not provided via arg/env
        global_en = args.enable_secret or ""
        has_asa = any((r.get("platform","").strip().lower() in ("asa","cisco asa")) for r in inventory)
        if has_asa and not global_en:
            global_en = getpass.getpass("Enable secret (ASA): ")

        timeouts = {
            "auth_timeout": args.device_timeout,
            "banner_timeout": args.device_timeout,
            "conn_timeout": args.device_timeout,
            "global_delay_factor": 1.5,
        }

        total = len(inventory)
        progress = Progress(total)
        print(f"[INFO] Starting threaded collection with {args.threads} worker(s) for {total} device(s).", flush=True)

        results: List[Tuple[str, bool, float, str]] = []
        futures = []
        with ThreadPoolExecutor(max_workers=args.threads, thread_name_prefix="collector") as ex:
            for row in inventory:
                if _shutdown: break
                futures.append(
                    ex.submit(
                        collect_one, row, writers,
                        global_user, global_pass, global_en,
                        timeouts, args.retries, args.retry_backoff,
                        args.force_global_creds, args.verbose
                    )
                )

            for fut in as_completed(futures):
                try:
                    hostname, ok, elapsed, msg = fut.result()
                except Exception as e:
                    hostname, ok, elapsed, msg = ("<unknown>", False, 0.0, f"{e}")
                results.append((hostname, ok, elapsed, msg))
                progress.update(ok, elapsed)
                # Emit a clean progress line for GUI parsing (no carriage returns)
                print(f"Progress: {progress.done}/{progress.total} • Success: {progress.ok} • Failed: {progress.fail} • ETA: {progress.eta()}", flush=True)

        ok_count   = sum(1 for _, ok, _, _ in results if ok)
        fail_count = sum(1 for _, ok, _, _ in results if not ok)
        print(f"[SUMMARY] Success: {ok_count} Failed: {fail_count}", flush=True)

        # Device-wise summary (nice to have)
        for host, ok, elapsed, msg in sorted(results, key=lambda x: (not x[1], x[0])):
            status = "OK" if ok else "FAIL"
            extra  = "" if ok else msg
            print(f" - {host:30s} {status:4s} {elapsed:5.1f}s {extra}", flush=True)

        print(f"[OK] Reports written to: {REPORTS_DIR}", flush=True)
        return 0

    finally:
        writers.close()

if __name__ == "__main__":
    sys.exit(main())