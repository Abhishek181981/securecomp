import re
import ipaddress
from .models import RouteEntry


def _mask_to_prefix(mask: str) -> int:
    try:
        return ipaddress.IPv4Network(f'0.0.0.0/{mask}').prefixlen
    except Exception:
        return 0


def parse_routes(rows):
    """
    Turn raw route rows (collector schema with 'line') into RouteEntry objects.
    Handles SRX (Junos), ASA, and Palo Alto. Emits SRX Local/Direct/Connected/Access
    immediately from the prefix line (no '> to ... via ...' needed).
    """
    out = []
    groups = {}

    # group lines per device/context/platform
    for r in rows:
        key = (
            (r.get('hostname') or '').strip(),
            (r.get('context')  or '').strip(),
            (r.get('platform') or '').strip().lower()
        )
        groups.setdefault(key, []).append((r.get('line') or '').rstrip())

    for (host, ctx, plat), lines in groups.items():
        if not host:
            continue

        # --- SRX / Junos ---
        if 'srx' in plat or 'juniper' in plat or 'junos' in plat:
            current_prefix = None
            current_proto  = ''
            for ln in lines:
                # Prefix line: "<prefix>   *[Proto/Pref] ..."
                m = re.match(r'^(\d+\.\d+\.\d+\.\d+/\d+)\s+.*\[(\w+)', ln)
                if m:
                    current_prefix = m.group(1)
                    current_proto  = m.group(2)     # e.g., Local / Direct / Static / BGP
                    # Immediate emit for Local/Direct/Connected/Access (no continuation line)
                    if current_proto.lower() in ('local', 'direct', 'connected', 'access'):
                        out.append(RouteEntry(
                            hostname=host, context=ctx, platform=plat,
                            prefix=current_prefix,
                            nexthop="",
                            interface=current_proto,   # or "" if you prefer
                            protocol=current_proto,
                            raw=ln
                        ))
                        current_prefix = None
                        current_proto  = ''
                        continue
                    continue

                # Continuation line: " > to X via IF"
                m = re.search(r'>\s+to\s+(\d+\.\d+\.\d+\.\d+)\s+via\s+(\S+)', ln)
                if m and current_prefix:
                    out.append(RouteEntry(
                        hostname=host, context=ctx, platform=plat,
                        prefix=current_prefix,
                        nexthop=m.group(1),
                        interface=m.group(2),
                        protocol=current_proto,
                        raw=ln
                    ))
                    current_prefix = None
                    current_proto  = ''
                    continue

            continue  # next device

        # --- ASA ---
        if 'asa' in plat:
            for ln in lines:
                # Example: "S 10.1.2.0 255.255.255.0 [1/0] via 10.1.2.1, Gi0/0"
                m = re.search(
                    r'^(\w)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+\[[^\]]+\]\s+via\s+(\d+\.\d+\.\d+\.\d+),\s*([^\s]+)',
                    ln
                )
                if m:
                    code = m.group(1)   # 'S', 'O', ...
                    net  = m.group(2)
                    mask = m.group(3)
                    plen = _mask_to_prefix(mask)
                    prefix = f'{net}/{plen}'
                    out.append(RouteEntry(
                        hostname=host, context=ctx, platform=plat,
                        prefix=prefix,
                        nexthop=m.group(4),
                        interface=m.group(5),
                        protocol=code,
                        raw=ln
                    ))
            continue  # next device

        # --- Palo Alto ---
        if 'palo' in plat or 'pan' in plat:
            for ln in lines:
                # Typical: "<prefix> <nexthop> <metric> <flags> <age> <interface>"
                m = re.match(
                    r'^(\d+\.\d+\.\d+\.\d+/\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+\d+\s+\S+\s+\S+\s+(\S+)',
                    ln
                )
                if m:
                    out.append(RouteEntry(
                        hostname=host, context=ctx, platform=plat,
                        prefix=m.group(1),
                        nexthop=m.group(2),
                        interface=m.group(3),
                        protocol='static',   # best effort default
                        raw=ln
                    ))

    return out