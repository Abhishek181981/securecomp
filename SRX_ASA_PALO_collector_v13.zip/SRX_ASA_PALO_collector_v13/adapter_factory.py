
# -*- coding: utf-8 -*-
"""
Adapter factory
- Provides create_adapter(platform, logger=None, debug=True)
- Avoid circular imports by importing adapters inside the function.
"""
from typing import Optional


def _import_first(module_names, class_names):
    """Try importing the first available (module, class) combo.
    module_names: list[str]
    class_names: list[str]
    Returns the class or raises the last ImportError.
    """
    last_exc = None
    for mod in module_names:
        try:
            m = __import__(mod, fromlist=class_names)
            for cname in class_names:
                if hasattr(m, cname):
                    return getattr(m, cname)
        except Exception as e:
            last_exc = e
            continue
    if last_exc:
        raise last_exc
    raise ImportError(f"None of modules {module_names} provided classes {class_names}")


def create_adapter(platform: str, logger: Optional[object] = None, debug: bool = True):
    """
    Return a concrete adapter instance based on platform string.
    Supported examples:
    - 'ASA'       -> AsaAdapter (asa_adapter_refactored_interface.py)
    - 'SRX'       -> SrxAdapter (srx_adapter_refactored_interface.py / srx_adapter / juniper_srx_adapter)
    - 'Palo Alto' -> PaloAdapter (palo_adapter.py / pan_adapter / paloalto_adapter)
    Raises:
    ValueError: if platform is unsupported or adapter import fails.
    """
    p = (platform or '').strip().lower()

    # ASA
    if p in {'asa', 'cisco asa', 'cisco-asa'}:
        try:
            AsaAdapter = _import_first(
                ['asa_adapter_refactored_interface', 'asa_adapter'],
                ['AsaAdapter']
            )
        except Exception as e:
            raise ValueError(f"Failed to import AsaAdapter: {e}") from e
        return AsaAdapter(logger=logger, debug=debug)

    # SRX / Juniper / Junos
    elif (
        p in {'srx', 'juniper srx', 'juniper', 'junos', 'juniper junos'}
        or 'srx' in p
        or 'juniper' in p
        or 'junos' in p
    ):
        try:
            SrxAdapter = _import_first(
                [
                    'srx_adapter_refactored_interface',  # current file name in your repo
                    'srx_adapter',                       # legacy/alternative
                    'juniper_srx_adapter',               # original expectation
                ],
                ['SrxAdapter']
            )
        except Exception as e:
            raise ValueError(f"Failed to import SrxAdapter: {e}") from e
        return SrxAdapter(logger=logger, debug=debug)

    # Palo Alto / PAN-OS
    elif p in {'palo alto', 'paloalto', 'pan', 'pan-os', 'panos'}:
        try:
            PaloAdapter = _import_first(
                ['palo_adapter', 'pan_adapter', 'paloalto_adapter'],
                ['PaloAdapter']
            )
        except Exception as e:
            raise ValueError(f"Failed to import PaloAdapter: {e}") from e
        return PaloAdapter(logger=logger, debug=debug)

    # Unsupported
    else:
        raise ValueError(
            f"Unsupported platform '{platform}'. Expected one of: ASA, SRX, Palo Alto."
        )


__all__ = ['create_adapter']
