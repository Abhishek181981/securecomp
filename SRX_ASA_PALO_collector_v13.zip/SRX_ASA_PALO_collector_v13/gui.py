﻿# -*- coding: utf-8 -*-
"""
Firewall ACL Automation Tool (GUI) – LITE (Tabs, Isolated Consoles)
[WITH DASHBOARD v6.7 – KPI Tiles + Exec PDF + Advanced Filters + Per‑tab Table Consoles + Risk Chart Toggle]

Dashboard layout (clean):
 [ KPI Tiles ]
 [ Buttons Row: Refresh \\ Generate \\ Save Charts \\ Executive PDF ]
 [ Scrollable Charts (Bar + Pie) ]
 [ Top 10 Firewalls ]

Risk & Compliance:
 - Advanced filter: Free‑text (token aware) + Firewall + Category (Apply / Only this FW / Clear / Reload / ▼ Console)
 - Risky rules pager, Export to Excel, **mini Risk KPIs chart (hidden by default via checkbox)**, isolated Output Console (table grid)

Zero‑hit ACL:
 - Same model as R&C: Advanced filter, pager, export, isolated Output Console (table grid)

Notes:
 - OTP gate + reporting_utils helpers preserved.
 - dashboard.py computes KPIs; GUI reads dashboard.csv metrics.
 - Isolated consoles per tab: Risk (table), Zero (table), Logs (text). Dashboard hides console.
"""
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import json, csv, os, sys, subprocess, re, time
from datetime import datetime

# ---------------- Optional charting (matplotlib) ----------------
try:
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    MATPLOT_OK = True
except Exception:
    MATPLOT_OK = False
print("[CHART] MATPLOT_OK={}".format(MATPLOT_OK))

# ---------------- Report PDF (reportlab) ----------------
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet
    REPORTLAB_OK = True
except Exception:
    REPORTLAB_OK = False
    print("[PDF] reportlab not available; Executive PDF disabled")

# ---------------- OTP gate ----------------
def _auth_token_path():
    base = os.path.expanduser('~')
    try:
        base = os.environ.get('LOCALAPPDATA') or base
    except Exception:
        pass
    folder = os.path.join(base, 'AclToolAuth')
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception:
        pass
    return os.path.join(folder, 'auth_token.json')

def _require_launcher_auth(root) -> bool:
    token_file = _auth_token_path()
    try:
        if not os.path.isfile(token_file):
            messagebox.showerror('Authentication required',
                                 'Please launch this tool using into.py (OTP login)\n\nAuth token not found.')
            return False
        with open(token_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        exp = float(data.get('expires_at') or 0)
        email = (data.get('email') or '').strip().lower()
        if not email.endswith('@colt.net'):
            messagebox.showerror('Authentication required',
                                 'Invalid auth token email domain. Please login again using your @colt.net email.')
            return False
        now = time.time()
        if exp <= now:
            messagebox.showerror('Authentication required',
                                 'Your session token has expired. Please login again using into.py (OTP).')
            return False
        try:
            os.remove(token_file)
        except Exception:
            pass
        return True
    except Exception as e:
        try:
            messagebox.showerror('Authentication required', f'Failed to validate auth token: {e}')
        except Exception:
            pass
        return False

# ---------------- Local project helpers ----------------
from reporting_utils import (
    load_settings, get_global_logger, make_run_dir, get_run_logger,
    write_text, write_json, append_csv, write_error
)

# ---------------- Build ID & constants ----------------
PAD = 8
GUI_BUILD_ID = 'gui_tabs_isolated_consoles_v6_7_clean'
print('[BUILD]', GUI_BUILD_ID)

class ASAACLTool:
    # ---- Risky Rules helpers ----
    def _resolve_reports_latest(self):
        base = os.path.abspath(os.path.dirname(__file__))
        return os.path.join(base, 'modular_collector', 'reports', 'latest')

    def _find_risky_csv(self):
        target = self._resolve_reports_latest()
        try:
            files = os.listdir(target)
        except Exception as e:
            self._append_ctx(f"[RISK] Cannot access {target}: {e}\n", ctx='logs'); return None
        for name in ['risky_acl.csv','risky_rules.csv','risky.csv','top_risky.csv','dashboard_risky.csv']:
            p = os.path.join(target, name)
            if os.path.isfile(p):
                return p
        risky = [f for f in files if re.match(r'risky.*\.csv$', f, re.IGNORECASE)]
        if risky:
            return os.path.join(target, risky[0])
        return None

    def _load_all_risky_rows(self):
        p = self._find_risky_csv()
        self.risky_rows, self.risky_rows_view = [], None
        if not p: return
        try:
            with open(p, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    n = dict(r)
                    if ('line' not in n) and ('rule_id' in n):
                        n['line'] = n.get('rule_id')
                    remark = (n.get('remark') or '').strip()
                    if remark:
                        toks = []
                        for part in remark.split(','):
                            p2 = (part or '').strip()
                            if p2.lower().startswith('risk='):
                                toks.append(p2[len('risk='):].strip())
                            if p2.lower().startswith('category=') and not n.get('category'):
                                n['category'] = p2.split('=',1)[1].strip()
                        if toks:
                            n['risk_tags'] = '; '.join(toks)
                    self.risky_rows.append(n)
        except Exception as e:
            self._append_ctx(f"[RISK] Failed to read risky CSV: {e}\n", ctx='logs'); self.risky_rows = []; return
        def sc(rec):
            for k in ('score','risk_score','rank','risky_rank','hits'):
                v = rec.get(k)
                if v in (None, ''): continue
                try:
                    return float(str(v))
                except Exception:
                    continue
            return 0.0
        try:
            self.risky_rows.sort(key=sc, reverse=True)
        except Exception:
            pass
        self.risky_page = 0
        try: self._refresh_category_list()
        except Exception: pass
        try: self._refresh_device_list()
        except Exception: pass

    def _risky__preferred_columns(self, rows):
        base_pref = ['hostname','device','platform','acl','line','rule_id','action','src','dst','apps','hits','score','risk_tags','category']
        present = set(rows[0].keys()) if rows else set()
        cols = [c for c in base_pref if c in present]
        for k in (list(rows[0].keys()) if rows else []):
            if k not in cols: cols.append(k)
        if 'remark' in cols:
            cols = [c for c in cols if c!='remark'] + ['remark']
        if not cols and rows:
            cols = list(rows[0].keys())
        return cols

    @staticmethod
    def _norm(v):
        if v is None: return ''
        return ' '.join(str(v).strip().split())

    def _render_risky_page(self, page:int):
        page_size = getattr(self,'risky_page_size',100) or 100
        rows_all = getattr(self,'risky_rows_view',None) or getattr(self,'risky_rows',[])
        total = len(rows_all)
        if total == 0:
            self._append_ctx('No risky rules available. Run "Generate Dashboard" first or adjust filter.\n', ctx='risk')
            return
        max_page = (total-1)//page_size
        page = max(0, min(page, max_page))
        start, end = page*page_size, min((page+1)*page_size, total)
        rows = rows_all[start:end]
        cols = self._risky__preferred_columns(rows)
        header = ['#'] + cols
        # Text info for context
        self._append_ctx(f"[RISK] Showing {start+1}-{end} of {total} (page {page+1}/{max_page+1})\n", ctx='risk')
        # Render table in isolated console
        base_idx = page * page_size
        self._console_show_table(True, ctx='risk')
        self._render_console_table(header, rows, base_idx=base_idx, ctx='risk')
        # Remember header/rows for copy helpers
        self._risky_last_header = header
        self._risky_last_rows = rows
        self.risky_page = page

    def _load_risky_page(self, page:int):
        if not getattr(self,'risky_rows',[]): self._load_all_risky_rows()
        self._render_risky_page(page)

    def _export_risky_excel(self):
        rows = getattr(self,'risky_rows_view',None) or getattr(self,'risky_rows',[])
        if not rows:
            self._load_all_risky_rows()
            rows = getattr(self,'risky_rows_view',None) or getattr(self,'risky_rows',[])
        if not rows:
            try: messagebox.showinfo('Export','No risky rules available to export.')
            except Exception: pass
            return
        try:
            base = os.path.dirname(self._find_risky_csv()) or '.'
        except Exception:
            base = '.'
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = os.path.join(base, f'risky_rules_{ts}.csv')
        xlsx_path = os.path.join(base, f'risky_rules_{ts}.xlsx')
        try:
            if isinstance(rows[0], dict):
                headers = list(rows[0].keys())
                with open(csv_path,'w',newline='',encoding='utf-8') as f:
                    w = csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerows(rows)
            else:
                with open(csv_path,'w',newline='',encoding='utf-8') as f:
                    w = csv.writer(f); w.writerows(rows)
        except Exception as e:
            try: messagebox.showerror('Export Error', f'Failed to write CSV: {e}')
            except Exception: pass
            self._append_ctx(f"[ERROR] CSV export failed: {e}\n", ctx='risk'); return
        final_path = csv_path
        try:
            import pandas as pd
            pd.read_csv(csv_path).to_excel(xlsx_path, index=False, engine='openpyxl')
            final_path = xlsx_path
        except Exception as e:
            self._append_ctx(f"[RISK] pandas/openpyxl unavailable; kept CSV ({e})\n", ctx='risk')
        self._append_ctx(f"[RISK] Exported risky ACL rules -> {final_path}\n", ctx='risk')
        try: self._open_path(final_path)
        except Exception: pass
        try: messagebox.showinfo('Export Complete', f'Exported to:\n{final_path}')
        except Exception: pass

    def _matches_risky_filter(self, rec, query:str) -> bool:
        q = (query or '').strip()
        if not q: return True
        tokens = [t.strip() for t in re.split(r'[, ;]+', q) if t.strip()]
        apps = str(rec.get('apps') or rec.get('service') or '')
        src = str(rec.get('src') or '')
        dst = str(rec.get('dst') or '')
        plat = str(rec.get('platform') or '')
        host = str(rec.get('hostname') or rec.get('device') or '')
        rtag = str(rec.get('risk_tags') or '')
        cat = str(rec.get('category') or '')
        remark = str(rec.get('remark') or '')
        hay = ' '.join([host, plat, str(rec.get('acl') or ''), str(rec.get('name') or ''),
                        str(rec.get('action') or ''), src, dst, apps, rtag, cat, remark]).lower()
        for t in tokens:
            tl = t.lower()
            if tl in ('any->any','any→any'):
                if not (src.strip().lower()=='any' and dst.strip().lower()=='any'): return False
            elif tl == 'sensitive':
                if not any(p in apps for p in ('22','3389','1433','1521','27017')): return False
            elif tl.startswith('device:'):
                if tl.split(':',1)[1] not in host.lower(): return False
            elif tl.startswith('platform:'):
                if tl.split(':',1)[1] not in plat.lower(): return False
            elif tl.startswith('acl:'):
                if tl.split(':',1)[1] not in str(rec.get('acl') or '').lower(): return False
            elif tl.startswith('risk:'):
                if tl.split(':',1)[1] not in rtag.lower(): return False
            elif tl.startswith('remark:'):
                if tl.split(':',1)[1] not in remark.lower(): return False
            elif tl.startswith('category:'):
                if tl.split(':',1)[1] not in cat.lower(): return False
            else:
                if tl not in hay: return False
        return True

    def _apply_risky_filter(self):
        try: q = self.risk_filter_var.get()
        except Exception: q = ''
        base = getattr(self,'risky_rows',[])
        self.risky_rows_view = [r for r in base if self._matches_risky_filter(r, q)]
        self._append_ctx(f"[RISK] Filter applied: '{q}' -> {len(self.risky_rows_view)} / {len(base)} rows\n", ctx='risk')
        self.risky_page = 0; self._render_risky_page(0)

    def _clear_risky_filter(self):
        try: self.risk_filter_var.set('')
        except Exception: pass
        self._apply_risky_filter()

    # ---------------- Dashboard helpers ----------------
    def _open_path(self, path):
        try:
            if sys.platform.startswith('win'): os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == 'darwin': subprocess.call(['open', path])
            else: subprocess.call(['xdg-open', path])
        except Exception:
            try: messagebox.showwarning("Open", f"Unable to open: {path}")
            except Exception: pass

    def _run_in_thread(self, target, before=None):
        def worker():
            try:
                target()
            finally:
                try: self.root.after(0, self.progress.stop)
                except Exception: pass
        if before:
            try: before()
            except Exception: pass
        import threading
        threading.Thread(target=worker, daemon=True).start()

    def _run_dashboard_and_refresh(self):
        base = os.path.dirname(os.path.abspath(__file__))
        dash_csv_hint = self.risk_path_var.get() or os.path.normpath(os.path.join('modular_collector','reports','latest','dashboard.csv'))
        candidates = [
            os.path.join(base,'dashboard.py'),
            os.path.join(base,'modular_collector','dashboard.py'),
            os.path.join(os.path.dirname(base),'dashboard.py'),
            os.path.join(os.path.dirname(base),'modular_collector','dashboard.py'),
            'dashboard.py',
        ]
        script=None; diag=['[DASHBOARD] Searching for dashboard.py in:']
        for c in candidates:
            diag.append(' - ' + os.path.abspath(c))
            if (not script) and os.path.isfile(c): script=c
        if not script:
            diag.append('[ERROR] Could not find dashboard.py in any candidate path.')
            self._push_diag(diag); self._set_status('Dashboard run failed (script not found)', 'red'); return
        diag.append('[DASHBOARD] Using: ' + os.path.abspath(script))
        run_cwd = os.path.dirname(os.path.abspath(script)) or base
        cmd=[sys.executable, os.path.basename(script)]
        diag.append(f"[DASHBOARD] cwd={run_cwd}"); diag.append(f"[DASHBOARD] cmd={' '.join(cmd)}")
        try:
            self.progress.start(10)
            start_ts=time.time()
            res = subprocess.run(cmd, cwd=run_cwd, capture_output=True, text=True, timeout=900)
            dur=round(time.time()-start_ts,2)
            rc=res.returncode; out=(res.stdout or '').strip(); err=(res.stderr or '').strip()
            diag.append(f"[DASHBOARD] returncode={rc} ({dur}s)")
            rep_dir = os.path.dirname(os.path.abspath(dash_csv_hint))
            try: os.makedirs(rep_dir, exist_ok=True)
            except Exception: pass
            run_report=os.path.join(rep_dir,'dashboard_run_report.txt')
            try:
                with open(run_report,'w',encoding='utf-8') as f:
                    f.write('\n'.join(diag)+'\n\n[stdout]\n'+out+'\n\n[stderr]\n'+err+'\n')
            except Exception: pass
            self._append_ctx('[dashboard.py stdout]\n'+(out or '<empty>')+'\n', ctx='logs')
            if err:
                self._append_ctx('[dashboard.py stderr]\n'+err+'\n', ctx='logs')
            self._append_ctx('[report] wrote '+str(run_report)+'\n', ctx='logs')
            csv_ok = os.path.isfile(dash_csv_hint)
            html_path = os.path.join(rep_dir, 'dashboard.html'); html_ok = os.path.isfile(html_path)
            if rc != 0:
                self._set_status('Dashboard failed (non-zero exit)', 'red')
            if not csv_ok:
                self._append_ctx(f"[DASHBOARD] dashboard.csv not found at {dash_csv_hint}\n", ctx='logs'); return
            if not csv_ok:
                self._set_status('Dashboard ran, but dashboard.csv is missing', 'red')
                self._append_ctx(f"[DASHBOARD] Expected: {dash_csv_hint}\n[DASHBOARD] See run report: {run_report}\n", ctx='logs'); return
            try:
                if html_ok and self.risk_open_html.get(): self._open_path(html_path)
            except Exception: pass
            try: self._refresh_risk_tab()
            except Exception: pass
            self._set_status('Dashboard updated', 'green')
        except subprocess.TimeoutExpired:
            self._set_status('Dashboard timeout (900s)', 'red'); self._append_ctx('[DASHBOARD] ERROR: Timeout after 900 seconds\n', ctx='logs')
        except FileNotFoundError as e:
            self._set_status('Python or script not found', 'red'); self._append_ctx(f"[DASHBOARD] ERROR: {e}\n", ctx='logs')
        except Exception as e:
            self._set_status('Dashboard run failed (exception)', 'red'); self._append_ctx(f"[DASHBOARD] ERROR: {e}\n", ctx='logs')

    def _push_diag(self, lines):
        self._append_ctx("\n".join(lines) + "\n", ctx='logs')

    def _set_status(self, message, color="blue"):
        try:
            self.status_label.config(text=f"Status: {message}"); self.status_label.config(foreground=color); self.root.update_idletasks()
        except Exception: pass

    # ---------------- Dashboard visualizations & Top-10 ----------------
    def _draw_dashboard_charts(self, any_any, any_to_priv, broad_broad, zero_permit, total_risky, p22, p3389, p1433, p1521, p27017):
        if not getattr(self, 'dash_canvas', None):
            return
        try:
            self.dash_fig.clf()
            self.dash_fig.set_size_inches(11.5, 4.8)
            # Bar chart
            ax1 = self.dash_fig.add_subplot(1, 2, 1)
            labels_bar = ['ANY→ANY', 'ANY→RFC1918', 'Broad↔Broad', 'Zero‑hit', 'Total risky']
            values_bar = [any_any, any_to_priv, broad_broad, zero_permit, total_risky]
            colors_bar = ['#cc0000','#cc0000','#e69138','#6fa8dc','#3c78d8']
            ax1.bar(labels_bar, values_bar, color=colors_bar)
            ax1.set_title('Risk KPIs', fontsize=12)
            ax1.grid(axis='y', linestyle=':', alpha=0.35)
            for i, v in enumerate(values_bar):
                ax1.text(i, v, str(v), ha='center', va='bottom', fontsize=9)
            ax1.tick_params(axis='x', labelrotation=18)
            # Pie chart
            ax2 = self.dash_fig.add_subplot(1, 2, 2)
            pie_labels = ['ANY→ANY', 'ANY→RFC1918', 'Broad↔Broad', 'Zero‑hit', 'Ports 22/3389/1433/1521/27017']
            pie_values = [any_any, any_to_priv, broad_broad, zero_permit,
                          max(0, p22) + max(0, p3389) + max(0, p1433) + max(0, p1521) + max(0, p27017)]
            total_pie = sum(pie_values)
            if total_pie == 0:
                pie_values = [1]; pie_labels = ['No Risk Slices']; autopct = None
            else:
                autopct = (lambda pct: f"{pct:.0f}%")
            ax2.pie(pie_values, labels=pie_labels, autopct=autopct,
                    colors=['#cc0000','#cc0000','#e69138','#6fa8dc','#6d9eeb'],
                    startangle=140, textprops={'fontsize': 9}, radius=1.25)
            ax2.set_title('Risk Composition (overlapping)', fontsize=12)
            ax2.axis('equal')
            self.dash_canvas.draw()
        except Exception as e:
            self._append_ctx(f"[CHART] Dashboard chart draw failed: {e}\n", ctx='logs')

    def _draw_rc_charts(self, any_any, any_to_priv, broad_broad, zero_permit, total_risky,
                        p22, p3389, p1433, p1521, p27017):
        if not getattr(self, 'rc_canvas', None): return
        try:
            self.rc_fig.clf()
            ax = self.rc_fig.add_subplot(1,1,1)
            labels=['ANY→ANY','ANY→RFC1918','Broad↔Broad','Zero‑hit','Total risky']
            vals=[any_any,any_to_priv,broad_broad,zero_permit,total_risky]
            colors=['#cc0000','#cc0000','#e69138','#6fa8dc','#3c78d8']
            ax.bar(labels,vals,color=colors)
            ax.set_title('Risk KPIs (dashboard.csv)',fontsize=11)
            ax.grid(axis='y',linestyle=':',alpha=0.35)
            for i,v in enumerate(vals): ax.text(i,v,str(v),ha='center',va='bottom',fontsize=9)
            ax.tick_params(axis='x',labelrotation=18)
            self.rc_canvas.draw()
        except Exception as e:
            self._append_ctx(f"[CHART] R&C chart draw failed: {e}\n", ctx='risk')

    def _compute_top10_firewalls(self):
        if not getattr(self, 'risky_rows', []):
            self._load_all_risky_rows()
        agg = {}
        for r in getattr(self, 'risky_rows', []):
            host = (r.get('hostname') or r.get('device') or '').strip() or '(unknown)'
            plat = (r.get('platform') or '').strip()
            s = 0.0
            for k in ('score','risk_score','rank','risky_rank','hits'):
                if r.get(k) not in (None, ''):
                    try:
                        s = float(str(r.get(k)))
                        break
                    except Exception:
                        pass
            if host not in agg:
                agg[host] = {'score_sum': 0.0, 'count': 0, 'platform': plat}
            agg[host]['score_sum'] += s if s else 0.0
            agg[host]['count'] += 1
            if plat and not agg[host]['platform']:
                agg[host]['platform'] = plat
        rows = [{'device': k, 'platform': v.get('platform',''), 'score_sum': v['score_sum'], 'count': v['count']} for k, v in agg.items()]
        rows.sort(key=lambda x: (x['score_sum'], x['count']), reverse=True)
        self.top10_firewalls = rows[:10]

    def _render_top10_firewalls(self):
        if not hasattr(self, 'top10_tree'):
            return
        for iid in self.top10_tree.get_children():
            self.top10_tree.delete(iid)
        for i, r in enumerate(getattr(self, 'top10_firewalls', []), start=1):
            self.top10_tree.insert('', 'end', values=(i, r['device'], r['platform'], f"{r['score_sum']:.2f}", r['count']))

    def _on_top10_dblclick(self, event=None):
        sel = self.top10_tree.selection()
        if not sel: return
        values = self.top10_tree.item(sel[0], 'values')
        if not values or len(values) < 2: return
        device = str(values[1]).strip()
        try: self.nb.select(self.tab_risk)
        except Exception: pass
        q0 = (self.risk_filter_var.get() or '').strip()
        self.risk_filter_var.set((q0 + ' ' + f'device:{device}').strip())
        self._apply_risky_filter()

    def _save_dashboard_charts_png(self):
        if not (MATPLOT_OK and getattr(self, 'dash_fig', None)):
            try: messagebox.showinfo("Save Charts", "Charts not available.")
            except Exception: pass
            return
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        base = os.path.dirname(os.path.abspath(self.risk_path_var.get() or 'dashboard.csv')) or '.'
        out = os.path.join(base, f'dashboard_charts_{ts}.png')
        try:
            self.dash_fig.savefig(out, dpi=130, bbox_inches='tight')
            self._append_ctx(f"[CHART] Saved Dashboard charts -> {out}\n", ctx='logs')
            self._open_path(out)
        except Exception as e:
            self._append_ctx(f"[CHART] Save failed: {e}\n", ctx='logs')
            try: messagebox.showerror("Save Charts", f"Failed to save: {e}")
            except Exception: pass

    # ---------- Executive PDF ----------
    def _generate_executive_pdf(self):
        if not REPORTLAB_OK:
            try: messagebox.showerror("Executive PDF", "ReportLab not available. Please install reportlab.")
            except Exception: pass
            self._append_ctx("[PDF] reportlab not available; cannot generate PDF.\n", ctx='logs')
            return
        try: self._refresh_risk_tab()
        except Exception: pass
        base_dir = os.path.dirname(os.path.abspath(self.risk_path_var.get() or 'dashboard.csv')) or '.'
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        pdf_path = os.path.join(base_dir, f"Executive_Risk_Report_{ts}.pdf")
        chart_path = None
        if MATPLOT_OK and getattr(self, 'dash_fig', None):
            try:
                chart_path = os.path.join(base_dir, f"dashboard_charts_{ts}.png")
                self.dash_fig.savefig(chart_path, dpi=150, bbox_inches='tight')
            except Exception as e:
                self._append_ctx(f"[PDF] Warning: failed to snapshot charts: {e}\n", ctx='logs')
                chart_path = None
        try:
            doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=36, rightMargin=36, topMargin=36, bottomMargin=36)
            styles = getSampleStyleSheet()
            story = []
            title = Paragraph("<b>Executive Risk & Compliance Report</b>", styles['Title'])
            when = Paragraph(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), styles['Normal'])
            story += [title, Spacer(1, 6), when, Spacer(1, 12)]
            kpi_data = [
                ["ANY→ANY", self.rc_any_any.get(), "ANY→RFC1918", self.rc_any_to_priv.get(), "Broad↔Broad", self.rc_broad_broad.get()],
                ["Zero‑hit", self.rc_zero_permit.get(), "Total risky", self.rc_total_risky.get(), "Compliance", self.rc_score.get()],
            ]
            kpi_table = Table(kpi_data, colWidths=[90, 70, 100, 70, 100, 80])
            kpi_style = TableStyle([
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
                ('FONTSIZE', (0,0), (-1,-1), 10),
                ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                ('TOPPADDING', (0,0), (-1,-1), 6),
                ('ALIGN', (1,0), (1,1), 'RIGHT'),
                ('ALIGN', (3,0), (3,1), 'RIGHT'),
                ('ALIGN', (5,0), (5,1), 'RIGHT'),
                ('TEXTCOLOR', (0,0), (0,0), colors.HexColor('#cc0000')),
                ('TEXTCOLOR', (2,0), (2,0), colors.HexColor('#cc0000')),
                ('TEXTCOLOR', (4,0), (4,0), colors.HexColor('#e69138')),
                ('TEXTCOLOR', (0,1), (0,1), colors.HexColor('#6fa8dc')),
                ('TEXTCOLOR', (2,1), (2,1), colors.HexColor('#3c78d8')),
                ('TEXTCOLOR', (4,1), (4,1), colors.HexColor('#1a7f37')),
                ('LINEBELOW', (0,0), (-1,0), 0.3, colors.lightgrey),
                ('LINEABOVE', (0,1), (-1,1), 0.3, colors.lightgrey),
            ])
            kpi_table.setStyle(kpi_style)
            story += [Paragraph("<b>Key Performance Indicators</b>", styles['Heading2']), Spacer(1, 6), kpi_table, Spacer(1, 12)]
            if chart_path and os.path.isfile(chart_path):
                story += [Paragraph("<b>Dashboard Charts</b>", styles['Heading2']), Spacer(1, 6)]
                img = RLImage(chart_path, width=480, height=None)
                story += [img, Spacer(1, 12)]
            story += [Paragraph("<b>Top 10 Firewalls by Risk</b>", styles['Heading2']), Spacer(1, 6)]
            headers = ['#','Device/Hostname','Platform','Risk Score Sum','Risky Rules']
            rows = []
            for i, r in enumerate(getattr(self, 'top10_firewalls', []), start=1):
                rows.append([i, r.get('device',''), r.get('platform',''), f"{r.get('score_sum',0.0):.2f}", r.get('count',0)])
            data = [headers] + rows if rows else [headers, ['—','(no data)','—','—','—']]
            tbl = Table(data, colWidths=[30, 200, 120, 100, 80])
            tbl_style = TableStyle([
                ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
                ('FONTSIZE', (0,0), (-1,-1), 9),
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#f2f2f2')),
                ('TEXTCOLOR', (0,0), (-1,0), colors.HexColor('#333333')),
                ('ALIGN', (0,0), (0,-1), 'CENTER'),
                ('ALIGN', (3,1), (3,-1), 'RIGHT'),
                ('ALIGN', (4,1), (4,-1), 'RIGHT'),
                ('GRID', (0,0), (-1,-1), 0.25, colors.lightgrey),
            ])
            tbl.setStyle(tbl_style)
            story += [tbl]
            doc.build(story)
            self._append_ctx(f"[PDF] Executive report generated -> {pdf_path}\n", ctx='logs')
            self._open_path(pdf_path)
            try: messagebox.showinfo("Executive PDF", f"Report generated:\n{pdf_path}")
            except Exception: pass
        except Exception as e:
            self._append_ctx(f"[PDF] Failed to generate report: {e}\n", ctx='logs')
            try: messagebox.showerror("Executive PDF", f"Failed: {e}")
            except Exception: pass

    # ---------------------------- Risk & Compliance (metrics) ----------------------------
    def _refresh_risk_tab(self):
        path = self.risk_path_var.get() or os.path.normpath(os.path.join('modular_collector','reports','latest','dashboard.csv'))
        metrics = {}
        try:
            with open(path,'r',encoding='utf-8',newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    k = (r.get('metric') or '').strip(); v = (r.get('value') or '').strip()
                    if k: metrics[k]=v
        except Exception as e:
            self._append_ctx(f"[ERROR] Failed to read {path}: {e}\n", ctx='logs')
            metrics = {}
        def _ival(k):
            try: return int(float(str(metrics.get(k,'0')).split()[0]))
            except Exception: return 0
        total_risky = _ival('total_risky_rules')
        any_any = _ival('any_any_allow')
        any_to_priv = _ival('any_to_rfc1918_permit')
        broad_broad = _ival('broad_to_broad')
        p22=_ival('port22_rules'); p3389=_ival('port3389_rules'); p1433=_ival('port1433_rules'); p1521=_ival('port1521_rules'); p27017=_ival('port27017_rules')
        zero_permit = _ival('total_zero_hit_permit_rules')
        self.rc_total_risky.set(str(total_risky))
        self.rc_any_any.set(str(any_any))
        self.rc_any_to_priv.set(str(any_to_priv))
        self.rc_broad_broad.set(str(broad_broad))
        self.rc_sensitive.set(f"22:{p22} 3389:{p3389} 1433:{p1433} 1521:{p1521} 27017:{p27017}")
        self.rc_zero_permit.set(str(zero_permit))
        self.rc_score.set(str(metrics.get('compliance_score') or metrics.get('score') or 'N/A'))
        # Remember last KPIs for on-demand RC chart drawing
        self._last_kpis = (any_any, any_to_priv, broad_broad, zero_permit, total_risky, p22, p3389, p1433, p1521, p27017)
        # Draw charts
        if MATPLOT_OK and getattr(self, 'dash_canvas', None):
            self._draw_dashboard_charts(any_any, any_to_priv, broad_broad, zero_permit, total_risky,
                                        p22, p3389, p1433, p1521, p27017)
        if MATPLOT_OK and getattr(self, 'rc_canvas', None) and getattr(self, 'rc_show_chart', None) and self.rc_show_chart.get():
            self._draw_rc_charts(any_any, any_to_priv, broad_broad, zero_permit, total_risky,
                                 p22, p3389, p1433, p1521, p27017)
        # Top10
        self._compute_top10_firewalls(); self._render_top10_firewalls()
        # Refresh combobox lists
        try: self._refresh_category_list()
        except Exception: pass
        try: self._refresh_device_list()
        except Exception: pass
        try: self.nb.select(self.tab_dash)
        except Exception: pass

    # ---------------------------- INIT / UI BUILD ----------------------------
    def __init__(self, root):
        self.root = root
        self.settings = load_settings(); self.global_logger = get_global_logger()
        self.root.title("Firewall ACL Automation Tool – LITE (Tabs, Isolated Consoles) [WITH DASHBOARD]")
        try: self.root.geometry("1320x880+80+60")
        except Exception: pass
        self.root.minsize(1100, 720)

        main = ttk.Frame(self.root); main.grid(row=0, column=0, sticky='nsew')
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=0)  # status bar
        main.columnconfigure(0, weight=1); main.rowconfigure(0, weight=1)

        self.nb = ttk.Notebook(main)
        self.nb.grid(row=0, column=0, sticky='nsew', padx=PAD, pady=PAD)

        default_dash = os.path.normpath(os.path.join('modular_collector','reports','latest','dashboard.csv'))
        self.risk_path_var = tk.StringVar(value=default_dash)
        self.rc_total_risky=tk.StringVar(value='0')
        self.rc_any_any=tk.StringVar(value='0')
        self.rc_any_to_priv=tk.StringVar(value='0')
        self.rc_broad_broad=tk.StringVar(value='0')
        self.rc_sensitive=tk.StringVar(value='22:0 3389:0 1433:0 1521:0 27017:0')
        self.rc_zero_permit=tk.StringVar(value='0')
        self.rc_score=tk.StringVar(value='N/A')
        self.risk_open_html = tk.BooleanVar(value=False)

        # ---------------- Dashboard TAB ----------------
        self.tab_dash = ttk.Frame(self.nb); self.nb.add(self.tab_dash, text="Dashboard")
        self.tab_dash.columnconfigure(0, weight=1)
        self.tab_dash.rowconfigure(2, weight=1)
        self.tab_dash.rowconfigure(3, weight=1)

        tiles = ttk.LabelFrame(self.tab_dash, text="KPI Tiles")
        tiles.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
        for c in range(6): tiles.columnconfigure(c, weight=1)

        def _mk_tile(parent, label, var, color):
            frm = ttk.Frame(parent)
            ttk.Label(frm, text=label, foreground='#666666').pack(anchor='w')
            ttk.Label(frm, textvariable=var, foreground=color, font=("Segoe UI", 12, "bold")).pack(anchor='w')
            return frm

        _mk_tile(tiles, "ANY→ANY", self.rc_any_any, '#cc0000').grid(row=0, column=0, sticky='ew', padx=(0, PAD//2))
        _mk_tile(tiles, "ANY→RFC1918", self.rc_any_to_priv, '#cc0000').grid(row=0, column=1, sticky='ew', padx=(PAD//4, PAD//4))
        _mk_tile(tiles, "Broad↔Broad", self.rc_broad_broad, '#e69138').grid(row=0, column=2, sticky='ew', padx=(PAD//4, PAD//4))
        _mk_tile(tiles, "Zero‑hit", self.rc_zero_permit, '#6fa8dc').grid(row=0, column=3, sticky='ew', padx=(PAD//4, PAD//4))
        _mk_tile(tiles, "Total risky", self.rc_total_risky, '#3c78d8').grid(row=0, column=4, sticky='ew', padx=(PAD//4, PAD//4))
        _mk_tile(tiles, "Compliance", self.rc_score, '#1a7f37').grid(row=0, column=5, sticky='ew', padx=(PAD//2, 0))

        dash_btns = ttk.Frame(self.tab_dash); dash_btns.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(4): dash_btns.columnconfigure(c, weight=1)
        ttk.Checkbutton(dash_btns, text="Open HTML after generate", variable=self.risk_open_html).grid(row=1, column=0, columnspan=4, sticky='w', pady=(6,0))
        ttk.Button(dash_btns, text="Refresh Summary", command=self._refresh_risk_tab).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(dash_btns, text="Generate Dashboard",
                   command=lambda: self._run_in_thread(self._run_dashboard_and_refresh,
                                                       before=lambda: self._set_status("Generating dashboard...", "orange"))
                   ).grid(row=0, column=1, sticky='ew')
        ttk.Button(dash_btns, text="Save Charts (PNG)", command=self._save_dashboard_charts_png).grid(row=0, column=2, sticky='ew')
        ttk.Button(dash_btns, text="Executive PDF", command=self._generate_executive_pdf).grid(row=0, column=3, sticky='ew', padx=(PAD,0))

        dash_charts = ttk.LabelFrame(self.tab_dash, text="Dashboard Charts")
        dash_charts.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        dash_charts.columnconfigure(0, weight=1); dash_charts.rowconfigure(0, weight=1)
        self.dash_chart_canvas = tk.Canvas(dash_charts, highlightthickness=0)
        dash_vsb = ttk.Scrollbar(dash_charts, orient='vertical', command=self.dash_chart_canvas.yview)
        dash_hsb = ttk.Scrollbar(dash_charts, orient='horizontal', command=self.dash_chart_canvas.xview)
        self.dash_chart_canvas.configure(yscrollcommand=dash_vsb.set, xscrollcommand=dash_hsb.set)
        self.dash_chart_canvas.grid(row=0, column=0, sticky='nsew')
        dash_vsb.grid(row=0, column=1, sticky='ns')
        dash_hsb.grid(row=1, column=0, sticky='ew')
        self.dash_chart_frame = ttk.Frame(self.dash_chart_canvas)
        self.dash_chart_canvas.create_window((0, 0), window=self.dash_chart_frame, anchor='nw')
        self.dash_chart_frame.bind('<Configure>', lambda e: self.dash_chart_canvas.configure(scrollregion=self.dash_chart_canvas.bbox('all')))
        self.dash_canvas = None
        if MATPLOT_OK:
            self.dash_fig = Figure(figsize=(11.5, 4.8), dpi=100)
            self.dash_canvas = FigureCanvasTkAgg(self.dash_fig, master=self.dash_chart_frame)
            self.dash_canvas.get_tk_widget().grid(row=0, column=0, sticky='nw')
        else:
            ttk.Label(self.dash_chart_frame, text="Charts unavailable (matplotlib not installed)", foreground='red').grid(
                row=0, column=0, sticky='w', padx=4, pady=4
            )

        top_frame = ttk.LabelFrame(self.tab_dash, text="Top 10 Firewalls by Risk")
        top_frame.grid(row=3, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        top_frame.columnconfigure(0, weight=1); top_frame.rowconfigure(0, weight=1)
        cols = ('#', 'Device/Hostname', 'Platform', 'Risk Score Sum', 'Risky Rules')
        self.top10_tree = ttk.Treeview(top_frame, columns=cols, show='headings', height=10)
        for c, w in zip(cols, (60, 360, 160, 140, 120)):
            self.top10_tree.heading(c, text=c)
            self.top10_tree.column(c, width=w, anchor='w')
        vsb = ttk.Scrollbar(top_frame, orient='vertical', command=self.top10_tree.yview)
        self.top10_tree.configure(yscrollcommand=vsb.set)
        self.top10_tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        self.top10_tree.bind('<Double-1>', self._on_top10_dblclick)

        # ---------------- Risk & Compliance TAB ----------------
        self.tab_risk = ttk.Frame(self.nb); self.nb.add(self.tab_risk, text="Risk & Compliance")
        self.tab_risk.columnconfigure(0, weight=1)
        self.tab_risk.rowconfigure(3, weight=1)
        self.tab_risk.rowconfigure(4, weight=1)

        rc_btns = ttk.Frame(self.tab_risk)
        rc_btns.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, PAD))
        for c in range(6): rc_btns.columnconfigure(c, weight=1)
        ttk.Checkbutton(rc_btns, text="Open HTML after generate",
                        variable=self.risk_open_html).grid(row=1, column=0, columnspan=2, sticky='w', pady=(6,0))
        ttk.Button(rc_btns, text="Refresh Risk & Compliance",
                   command=self._refresh_risk_tab).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(rc_btns, text="Generate Dashboard",
                   command=lambda: self._run_in_thread(
                       self._run_dashboard_and_refresh,
                       before=lambda: self._set_status("Generating dashboard...", "orange"))
                   ).grid(row=0, column=1, sticky='ew')
        ttk.Button(rc_btns, text="View Risky Rules (Top 100)",
                   command=lambda: self._load_risky_page(0)).grid(row=0, column=2, sticky='ew', padx=(PAD,0))
        ttk.Button(rc_btns, text="Export Risky ACL to Excel",
                   command=self._export_risky_excel).grid(row=0, column=3, sticky='ew')
        ttk.Button(rc_btns, text="▼ Console", command=lambda: self._console_show_table(True, ctx='risk')).grid(row=0, column=4, sticky='e')
        # Show/Hide Risk mini chart (hidden by default)
        self.rc_show_chart = tk.BooleanVar(value=False)
        ttk.Checkbutton(rc_btns, text="Show Risk KPIs chart", variable=self.rc_show_chart,
                        command=self._apply_rc_chart_visibility).grid(row=1, column=2, columnspan=3, sticky='w', pady=(6,0))

        # Advanced filter
        adv = ttk.LabelFrame(self.tab_risk, text="Advanced filter")
        adv.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(7): adv.columnconfigure(c, weight=1)
        ttk.Label(adv, text="Free-text:").grid(row=0, column=0, sticky='w')
        self.risk_filter_var = tk.StringVar(value='')
        self.adv_text_entry = ttk.Entry(adv, textvariable=self.risk_filter_var)
        self.adv_text_entry.grid(row=0, column=1, columnspan=3, sticky='ew', padx=(PAD//2, PAD))
        ttk.Label(adv, text="Firewall:").grid(row=1, column=0, sticky='w')
        self.adv_device_var = tk.StringVar(value='')
        self.adv_device_cb = ttk.Combobox(adv, textvariable=self.adv_device_var, state='readonly', width=28, values=[])
        self.adv_device_cb.grid(row=1, column=1, sticky='w', padx=(PAD//2, PAD))
        ttk.Label(adv, text="Category:").grid(row=1, column=2, sticky='w')
        self.adv_category_var = tk.StringVar(value='')
        self.adv_category_cb = ttk.Combobox(adv, textvariable=self.adv_category_var, state='readonly', width=24, values=[])
        self.adv_category_cb.grid(row=1, column=3, sticky='w', padx=(PAD//2, PAD))
        btns = ttk.Frame(adv); btns.grid(row=1, column=4, columnspan=3, sticky='e', padx=(PAD,0))
        ttk.Button(btns, text="Apply (Text + Device + Category)", command=self._apply_advanced_filter).grid(row=0, column=0, sticky='w')
        ttk.Button(btns, text="Only this Firewall", command=self._apply_device_only_filter).grid(row=0, column=1, sticky='w', padx=(PAD//2, 0))
        ttk.Button(btns, text="Clear", command=lambda: [self._clear_advanced_filter(), self._clear_risky_filter()]).grid(row=0, column=2, sticky='w', padx=(PAD//2, 0))
        ttk.Button(btns, text="Reload Devices", command=self._refresh_device_list).grid(row=0, column=3, sticky='w', padx=(PAD//2, 0))

        # Page controls
        nav = ttk.Frame(self.tab_risk)
        nav.grid(row=2, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(4): nav.columnconfigure(c, weight=1)
        self.prev_risky_btn = ttk.Button(nav, text="< Prev 100",
                                         command=lambda: self._load_risky_page(getattr(self,'risky_page',0)-1))
        self.prev_risky_btn.grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        self.next_risky_btn = ttk.Button(nav, text="Next 100 >",
                                         command=lambda: self._load_risky_page(getattr(self,'risky_page',0)+1))
        self.next_risky_btn.grid(row=0, column=1, sticky='ew')
        ttk.Button(nav, text="Copy Page (Markdown)", command=self._copy_risky_markdown).grid(row=0, column=2, sticky='ew', padx=(PAD,0))
        ttk.Button(nav, text="Copy Page (CSV)", command=self._copy_risky_csv).grid(row=0, column=3, sticky='ew', padx=(PAD,0))

        # Risk charts (frame hidden by default via visibility method)
        rc_charts = ttk.LabelFrame(self.tab_risk, text="Charts (optional)")
        rc_charts.grid(row=3, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.rc_charts_frame = rc_charts
        rc_charts.columnconfigure(0, weight=1); rc_charts.rowconfigure(0, weight=1)
        self.rc_chart_canvas = tk.Canvas(rc_charts, highlightthickness=0)
        rc_vsb = ttk.Scrollbar(rc_charts, orient='vertical', command=self.rc_chart_canvas.yview)
        rc_hsb = ttk.Scrollbar(rc_charts, orient='horizontal', command=self.rc_chart_canvas.xview)
        self.rc_chart_canvas.configure(yscrollcommand=rc_vsb.set, xscrollcommand=rc_hsb.set)
        self.rc_chart_canvas.grid(row=0, column=0, sticky='nsew')
        rc_vsb.grid(row=0, column=1, sticky='ns')
        rc_hsb.grid(row=1, column=0, sticky='ew')
        self.rc_chart_frame = ttk.Frame(self.rc_chart_canvas)
        self.rc_chart_canvas.create_window((0,0), window=self.rc_chart_frame, anchor='nw')
        self.rc_chart_frame.bind('<Configure>', lambda e: self.rc_chart_canvas.configure(scrollregion=self.rc_chart_canvas.bbox('all')))
        self.rc_canvas = None
        if MATPLOT_OK:
            self.rc_fig = Figure(figsize=(6.2, 2.0), dpi=100)  # compact
            self.rc_canvas = FigureCanvasTkAgg(self.rc_fig, master=self.rc_chart_frame)
            self.rc_canvas.get_tk_widget().grid(row=0, column=0, sticky='nw')
        # Hide chart frame by default
        try: self.rc_charts_frame.grid_remove()
        except Exception: pass

        # Risk tab Output Console (isolated)
        risk_console = ttk.LabelFrame(self.tab_risk, text="Output Console")
        risk_console.grid(row=4, column=0, padx=PAD, pady=(0, PAD), sticky='nsew')
        risk_console.columnconfigure(0, weight=1)
        risk_console.rowconfigure(0, weight=1)
        risk_console.rowconfigure(1, weight=0)
        self.output_risk = scrolledtext.ScrolledText(risk_console, width=100, height=18, font=("Consolas", 10), wrap='none')
        self.output_risk.grid(row=0, column=0, sticky='nsew')
        self.output_risk_hsb = ttk.Scrollbar(risk_console, orient='horizontal', command=self.output_risk.xview)
        self.output_risk.configure(xscrollcommand=self.output_risk_hsb.set)
        self.output_risk_hsb.grid(row=1, column=0, sticky='ew')
        try:
            self.output_risk.tag_config('found', foreground='green'); self.output_risk.tag_config('missing', foreground='red')
        except Exception: pass
        self._init_console_table(ctx='risk', parent=risk_console)

        # ---------------- Zero‑hit ACL TAB ----------------
        self.tab_zero = ttk.Frame(self.nb); self.nb.add(self.tab_zero, text="Zero‑hit ACL")
        self.tab_zero.columnconfigure(0, weight=1)
        self.tab_zero.rowconfigure(3, weight=1)
        self.tab_zero.rowconfigure(4, weight=1)

        zc_btns = ttk.Frame(self.tab_zero)
        zc_btns.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, PAD))
        for c in range(5): zc_btns.columnconfigure(c, weight=1)
        ttk.Checkbutton(zc_btns, text="Open HTML after generate",
                        variable=self.risk_open_html).grid(row=1, column=0, columnspan=5, sticky='w', pady=(6,0))
        ttk.Button(zc_btns, text="Refresh Zero‑hit Summary",
                   command=lambda: [self._load_all_zero_rows(), self._render_zero_page(0)]).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(zc_btns, text="Generate Dashboard",
                   command=lambda: self._run_in_thread(
                       self._run_dashboard_and_refresh,
                       before=lambda: self._set_status("Generating dashboard...", "orange"))
                   ).grid(row=0, column=1, sticky='ew')
        ttk.Button(zc_btns, text="View Zero‑hit (Top 100)",
                   command=lambda: self._load_zero_page(0)).grid(row=0, column=2, sticky='ew', padx=(PAD,0))
        ttk.Button(zc_btns, text="Export Zero‑hit to Excel",
                   command=self._export_zero_excel).grid(row=0, column=3, sticky='ew')
        ttk.Button(zc_btns, text='▼ Console', command=lambda: self._console_show_table(True, ctx='zero')).grid(row=0, column=4, sticky='e')

        zadv = ttk.LabelFrame(self.tab_zero, text="Advanced filter")
        zadv.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(7): zadv.columnconfigure(c, weight=1)
        ttk.Label(zadv, text="Free-text:").grid(row=0, column=0, sticky='w')
        self.zero_filter_var = tk.StringVar(value='')
        self.zero_adv_text_entry = ttk.Entry(zadv, textvariable=self.zero_filter_var)
        self.zero_adv_text_entry.grid(row=0, column=1, columnspan=3, sticky='ew', padx=(PAD//2, PAD))
        ttk.Label(zadv, text='Firewall:').grid(row=1, column=0, sticky='w')
        self.zero_adv_device_var = tk.StringVar(value='')
        self.zero_adv_device_cb = ttk.Combobox(zadv, textvariable=self.zero_adv_device_var, state='readonly', width=28, values=[])
        self.zero_adv_device_cb.grid(row=1, column=1, sticky='w', padx=(PAD//2, PAD))
        ttk.Label(zadv, text='Category:').grid(row=1, column=2, sticky='w')
        self.zero_adv_category_var = tk.StringVar(value='')
        self.zero_adv_category_cb = ttk.Combobox(zadv, textvariable=self.zero_adv_category_var, state='readonly', width=24, values=[])
        self.zero_adv_category_cb.grid(row=1, column=3, sticky='w', padx=(PAD//2, PAD))
        zbtns = ttk.Frame(zadv); zbtns.grid(row=1, column=4, columnspan=3, sticky='e', padx=(PAD,0))
        ttk.Button(zbtns, text='Apply (Text + Device + Category)', command=self._apply_zero_advanced_filter).grid(row=0, column=0, sticky='w')
        ttk.Button(zbtns, text='Only this Firewall', command=self._apply_zero_device_only_filter).grid(row=0, column=1, sticky='w', padx=(PAD//2, 0))
        ttk.Button(zbtns, text='Clear', command=lambda: [self._clear_zero_advanced_filter(), self._apply_zero_filter()]).grid(row=0, column=2, sticky='w', padx=(PAD//2, 0))
        ttk.Button(zbtns, text='Reload Devices', command=self._refresh_device_list).grid(row=0, column=3, sticky='w', padx=(PAD//2, 0))

        znav = ttk.Frame(self.tab_zero)
        znav.grid(row=2, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(4): znav.columnconfigure(c, weight=1)
        self.prev_zero_btn = ttk.Button(znav, text='< Prev 100',
            command=lambda: self._load_zero_page(getattr(self,'zero_page',0)-1))
        self.prev_zero_btn.grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        self.next_zero_btn = ttk.Button(znav, text='Next 100 >',
            command=lambda: self._load_zero_page(getattr(self,'zero_page',0)+1))
        self.next_zero_btn.grid(row=0, column=1, sticky='ew')
        ttk.Button(znav, text='Copy Page (Markdown)', command=self._copy_zero_markdown).grid(row=0, column=2, sticky='ew', padx=(PAD,0))
        ttk.Button(znav, text='Copy Page (CSV)', command=self._copy_zero_csv).grid(row=0, column=3, sticky='ew', padx=(PAD,0))

        # Zero Output Console (isolated)
        zero_console = ttk.LabelFrame(self.tab_zero, text="Output Console")
        zero_console.grid(row=4, column=0, padx=PAD, pady=(0, PAD), sticky='nsew')
        zero_console.columnconfigure(0, weight=1)
        zero_console.rowconfigure(0, weight=1)
        zero_console.rowconfigure(1, weight=0)
        self.output_zero = scrolledtext.ScrolledText(zero_console, width=100, height=18, font=("Consolas", 10), wrap='none')
        self.output_zero.grid(row=0, column=0, sticky='nsew')
        self.output_zero_hsb = ttk.Scrollbar(zero_console, orient='horizontal', command=self.output_zero.xview)
        self.output_zero.configure(xscrollcommand=self.output_zero_hsb.set)
        self.output_zero_hsb.grid(row=1, column=0, sticky='ew')
        try:
            self.output_zero.tag_config('found', foreground='green'); self.output_zero.tag_config('missing', foreground='red')
        except Exception: pass
        self._init_console_table(ctx='zero', parent=zero_console)

        # ---------------- Logs & Reports TAB ----------------
        self.tab_logs = ttk.Frame(self.nb); self.nb.add(self.tab_logs, text="Logs & Reports")
        self.tab_logs.columnconfigure(0, weight=1)
        logs_frame = ttk.LabelFrame(self.tab_logs, text="Logs & Reports")
        logs_frame.grid(row=0, column=0, sticky='nsew', padx=PAD, pady=PAD)
        for c in range(3): logs_frame.columnconfigure(c, weight=1)
        self.logs_base_var = tk.StringVar(value=self.settings.get('reports_base_dir','reports'))
        ttk.Label(logs_frame, text="Reports Base Dir:").grid(row=0, column=0, sticky='w')
        ttk.Label(logs_frame, textvariable=self.logs_base_var, foreground='blue').grid(row=0, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Reports", command=lambda: self._open_path(self.logs_base_var.get())).grid(row=0, column=2, sticky='ew')
        self.logs_run_var = tk.StringVar(value='-')
        ttk.Label(logs_frame, text="Current Run Dir:").grid(row=1, column=0, sticky='w')
        ttk.Label(logs_frame, textvariable=self.logs_run_var, foreground='blue').grid(row=1, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Current Run", command=lambda: self._open_path(self.logs_run_var.get())).grid(row=1, column=2, sticky='ew')
        self.logs_global_var = tk.StringVar(value=self.settings.get('global_log_file','acl_tool.log'))
        ttk.Label(logs_frame, text="Global Log:").grid(row=2, column=0, sticky='w')
        ttk.Label(logs_frame, textvariable=self.logs_global_var, foreground='blue').grid(row=2, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Global Log", command=lambda: self._open_path(self.logs_global_var.get())).grid(row=2, column=2, sticky='ew')

        # Logs Output Console (text)
        logs_console = ttk.LabelFrame(self.tab_logs, text="Output Console")
        logs_console.grid(row=3, column=0, padx=PAD, pady=(0, PAD), sticky='nsew')
        logs_console.columnconfigure(0, weight=1)
        logs_console.rowconfigure(0, weight=1)
        logs_console.rowconfigure(1, weight=0)
        self.output_logs = scrolledtext.ScrolledText(logs_console, width=100, height=18, font=("Consolas", 10), wrap='none')
        self.output_logs.grid(row=0, column=0, sticky='nsew')
        self.output_logs_hsb = ttk.Scrollbar(logs_console, orient='horizontal', command=self.output_logs.xview)
        self.output_logs.configure(xscrollcommand=self.output_logs_hsb.set)
        self.output_logs_hsb.grid(row=1, column=0, sticky='ew')
        try:
            self.output_logs.tag_config('found', foreground='green'); self.output_logs.tag_config('missing', foreground='red')
        except Exception: pass

        # ---------------- Global Status bar ----------------
        status_frame = ttk.Frame(self.root); status_frame.grid(row=1, column=0, padx=PAD, pady=(0, PAD), sticky='ew')
        self.status_label = ttk.Label(status_frame, text="Status: Idle", foreground='blue'); self.status_label.pack(side='left', padx=5)
        self.progress = ttk.Progressbar(status_frame, mode='indeterminate', length=200); self.progress.pack(side='right', padx=5)

        # State
        self.run_dir=None; self.run_logger=None; self.risky_rows=[]; self.risky_rows_view=None; self.risky_page=0; self.risky_page_size=100
        self.top10_firewalls = []
        self.zero_rows = []; self.zero_rows_view=None; self.zero_page=0; self.zero_page_size=100

        try: self.nb.select(self.tab_dash)
        except Exception: pass
        self._append_ctx('[Layout] Isolated per-tab output consoles (Risk / Zero / Logs).\n', ctx='logs')
        self.nb.bind('<<NotebookTabChanged>>', self._on_tab_changed)
        self._apply_console_visibility()
        self._apply_rc_chart_visibility()

        try:
            self._refresh_risk_tab()
        except Exception as e:
            self._append_ctx(f"[INIT] Initial refresh failed: {e}\n", ctx='logs')

        # --- Load static categories (authoritative list for the combobox) ---
        try:
            self._load_static_category_map()
        except Exception as e:
            self._append_ctx(f"[INIT] Static category map load failed: {e}\n", ctx='logs')
        try:
            self._refresh_category_list()
        except Exception:
            pass

    # ----- Category/device helpers -----
    def _refresh_category_list(self):
        cats = []
        try:
            mapping = getattr(self, '_static_category_map', None)
            if mapping is None:
                mapping = self._load_static_category_map()
            cats = list(mapping.keys()) if mapping else []
        except Exception:
            cats = []
        if not cats:
            derived = set()
            for r in getattr(self, 'risky_rows', []):
                c = (r.get('category') or '').strip()
                if not c:
                    remark = (r.get('remark') or '').lower()
                    if 'category=' in remark:
                        for part in remark.split(','):
                            p2 = (part or '').strip()
                            if p2.startswith('category='):
                                c = p2.split('=', 1)[1].strip()
                                break
                if c:
                    derived.add(c)
            cats = sorted(derived, key=lambda s: s.lower())
        try:
            if hasattr(self, 'adv_category_cb'):
                self.adv_category_cb['values'] = cats
        except Exception:
            pass
        try:
            if hasattr(self, 'zero_adv_category_cb'):
                self.zero_adv_category_cb['values'] = cats
        except Exception:
            pass

    def _read_csv_rows(self, path) -> list:
        try:
            rows = []
            with open(path, 'r', encoding='utf-8-sig', newline='') as f:
                rd = csv.DictReader(f)
                for r in rd:
                    rows.append({k: (v or '') for k, v in r.items()})
            return rows
        except Exception:
            return []

    def _firewall_csv_path(self) -> str:
        try:
            here = os.path.abspath(os.path.dirname(__file__))
            return os.path.join(here, 'modular_collector', 'firewall.csv')
        except Exception:
            return 'modular_collector/firewall.csv'

    def _collect_devices_from_firewall_csv(self) -> set:
        devices = set()
        try:
            fpath = self._firewall_csv_path()
            rows = self._read_csv_rows(fpath)
            for r in rows:
                cand = (r.get('hostname') or r.get('device') or r.get('name') or r.get('fw_name') or '').strip()
                if not cand:
                    cand = (r.get('management_ip') or r.get('ip') or '').strip()
                if cand:
                    devices.add(cand)
        except Exception:
            pass
        return devices

    def _collect_devices_from_risky_rows(self) -> set:
        devices = set()
        for r in getattr(self, 'risky_rows', []):
            host = (r.get('hostname') or r.get('device') or '').strip()
            if host:
                devices.add(host)
        return devices

    def _refresh_device_list(self):
        dev_csv = self._collect_devices_from_firewall_csv()
        dev_risky = self._collect_devices_from_risky_rows()
        vals = sorted(dev_csv.union(dev_risky), key=lambda s: s.lower())
        try:
            if hasattr(self, 'adv_device_cb'):
                self.adv_device_cb['values'] = vals
        except Exception:
            pass
        try:
            if hasattr(self, 'zero_adv_device_cb'):
                self.zero_adv_device_cb['values'] = vals
        except Exception:
            pass

    def _load_static_category_map(self, path=None):
        from collections import OrderedDict
        mapping = OrderedDict()
        try:
            if path is None:
                here = os.path.abspath(os.path.dirname(__file__))
                path = os.path.join(here, 'modular_collector', 'categories_map.csv')
            if os.path.isfile(path):
                with open(path, 'r', encoding='utf-8-sig', newline='') as f:
                    rd = csv.DictReader(f)
                    for r in rd:
                        cat = (r.get('category') or '').strip()
                        q   = (r.get('query') or '').strip()
                        if cat and q:
                            mapping[cat] = q
                self._append_ctx(f"[CAT] Loaded static categories: {len(mapping)} from {path}\n", ctx='logs')
            else:
                self._append_ctx(f"[CAT] No static category map found at: {path}\n", ctx='logs')
        except Exception as e:
            self._append_ctx(f"[CAT] Failed to load static category map: {e}\n", ctx='logs')
        self._static_category_map = mapping
        return mapping

    def _apply_advanced_filter(self):
        dev = (self.adv_device_var.get() or '').strip()
        cat = (self.adv_category_var.get() or '').strip()
        q0  = (self.risk_filter_var.get() or '').strip()
        try:
            if not getattr(self, 'risky_rows', []):
                self._append_ctx("[RISK] Loading risky rows on demand for filtering...\n", ctx='risk')
                self._load_all_risky_rows()
        except Exception as e:
            self._append_ctx(f"[RISK] Lazy load failed: {e}\n", ctx='risk')
        tokens = []
        if dev:
            tokens.append(f"device:{dev}")
        if cat:
            tokens.append(f"category:{cat}")
            try:
                mapped = (getattr(self, '_static_category_map', {}) or {}).get(cat)
                if mapped:
                    tokens.append(mapped)
            except Exception:
                pass
        new_q = (q0 + ' ' + ' '.join(tokens)).strip()
        self.risk_filter_var.set(new_q)
        self._apply_risky_filter()

    def _apply_device_only_filter(self):
        dev = (self.adv_device_var.get() or '').strip()
        if not dev: return
        q0 = (self.risk_filter_var.get() or '').strip()
        new_q = (q0 + ' ' + f"device:{dev}").strip()
        self.risk_filter_var.set(new_q)
        self._apply_risky_filter()

    def _clear_advanced_filter(self):
        try:
            self.adv_device_var.set('')
            self.adv_category_var.set('')
        except Exception:
            pass

    # ----- Console visibility (isolated consoles need minimal logic) -----
    def _apply_console_visibility(self):
        # With isolated consoles, no special behavior is needed here for now.
        pass

    def _on_tab_changed(self, event=None):
        self._apply_console_visibility()

    def _apply_rc_chart_visibility(self):
        # Show/hide the Risk & Compliance mini chart based on the checkbox.
        frm = getattr(self, 'rc_charts_frame', None)
        if not frm:
            return
        try:
            if self.rc_show_chart.get():
                frm.grid()
                # If we already have last KPIs, draw without forcing a full refresh
                try:
                    k = getattr(self, '_last_kpis', None)
                    if k and MATPLOT_OK and getattr(self, 'rc_canvas', None):
                        self._draw_rc_charts(*k)
                except Exception:
                    pass
            else:
                frm.grid_remove()
        except Exception:
            pass

    # ---------------- Output Console: Table Mode Helpers ----------------
    def _init_console_table(self, ctx: str, parent):
        style = ttk.Style(self.root)
        try:
            style.configure("Console.Treeview", rowheight=22, font=("Segoe UI", 9))
            style.configure("Console.Treeview.Heading", font=("Segoe UI", 9, "bold"))
            style.map("Console.Treeview", background=[("selected", "#cfe8ff")])
        except Exception:
            pass

        tree = ttk.Treeview(
            parent,
            columns=("#",),
            show="headings",
            style="Console.Treeview",
            height=18
        )
        vsb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')

        try:
            tree.grid_remove(); vsb.grid_remove(); hsb.grid_remove()
        except Exception: pass
        try:
            tree.tag_configure('odd', background='#ffffff')
            tree.tag_configure('even', background='#f7f7f7')
        except Exception: pass

        if ctx == 'risk':
            self.console_tree_risk, self.console_tree_risk_vsb, self.console_tree_risk_hsb = tree, vsb, hsb
        elif ctx == 'zero':
            self.console_tree_zero, self.console_tree_zero_vsb, self.console_tree_zero_hsb = tree, vsb, hsb

    def _console_show_table(self, show: bool, ctx: str = None):
        if ctx == 'risk':
            tv, vsb, hsb = getattr(self, 'console_tree_risk', None), getattr(self, 'console_tree_risk_vsb', None), getattr(self, 'console_tree_risk_hsb', None)
            out, hscroll = getattr(self, 'output_risk', None), getattr(self, 'output_risk_hsb', None)
        elif ctx == 'zero':
            tv, vsb, hsb = getattr(self, 'console_tree_zero', None), getattr(self, 'console_tree_zero_vsb', None), getattr(self, 'console_tree_zero_hsb', None)
            out, hscroll = getattr(self, 'output_zero', None), getattr(self, 'output_zero_hsb', None)
        else:
            return
        if not tv or not out:
            return
        if show:
            try:
                out.grid_remove(); hscroll.grid_remove()
            except Exception: pass
            try:
                tv.grid(); vsb.grid(); hsb.grid()
            except Exception: pass
        else:
            try:
                tv.grid_remove(); vsb.grid_remove(); hsb.grid_remove()
            except Exception: pass
            try:
                out.grid(); hscroll.grid()
            except Exception: pass

    def _render_console_table(self, header:list, rows:list, base_idx:int=0, ctx: str = None):
        if ctx == 'risk':
            tv = getattr(self, 'console_tree_risk', None)
        elif ctx == 'zero':
            tv = getattr(self, 'console_tree_zero', None)
        else:
            tv = None
        if not tv: return
        current = tv['columns']
        if tuple(header) != tuple(current):
            tv['columns'] = tuple(header)
            for c in header:
                tv.heading(c, text=c, anchor='w')
                w = 120
                cl = c.lower()
                if c == '#': w = 46
                elif cl in ('hostname','device','acl','apps','remark','name'): w = 220
                elif cl in ('src','dst'): w = 180
                elif cl in ('action','platform','line','rule_id'): w = 100
                tv.column(c, width=w, anchor='w', stretch=True)
        for iid in tv.get_children():
            tv.delete(iid)
        for i, r in enumerate(rows, start=1):
            vals = []
            for c in header:
                if c == '#': vals.append(str(base_idx + i))
                else:
                    if isinstance(r, dict):
                        vals.append(self._norm(r.get(c, '')))
                    else:
                        idx = header.index(c)
                        try:
                            vals.append(self._norm(r[idx-1] if idx>0 else ''))
                        except Exception:
                            vals.append('')
            tag = 'even' if i % 2 == 0 else 'odd'
            tv.insert('', 'end', values=vals, tags=(tag,))

    # ---- Zero‑hit helpers ----
    def _find_zero_csv(self):
        target = self._resolve_reports_latest()
        try:
            files = os.listdir(target)
        except Exception as e:
            self._append_ctx(f"[ZERO] Cannot access {target}: {e}\n", ctx='logs'); return None
        for name in ['zero_acl.csv','zero-hit.csv','zero_permit.csv','dashboard_zero.csv','zero.csv']:
            p = os.path.join(target, name)
            if os.path.isfile(p):
                return p
        zero = [f for f in files if re.match(r'.*zero.*\.csv$', f, re.IGNORECASE)]
        if zero:
            return os.path.join(target, zero[0])
        return None

    def _load_all_zero_rows(self):
        p = self._find_zero_csv()
        self.zero_rows, self.zero_rows_view = [], None
        if not p: return
        try:
            with open(p, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    n = dict(r)
                    if ('line' not in n) and ('rule_id' in n):
                        n['line'] = n.get('rule_id')
                    remark = (n.get('remark') or '').strip()
                    if remark:
                        for part in remark.split(","):
                            p2 = (part or "").strip()
                            if p2.lower().startswith('category=') and not n.get('category'):
                                n['category'] = p2.split('=',1)[1].strip()
                    self.zero_rows.append(n)
        except Exception as e:
            self._append_ctx(f"[ZERO] Failed to read zero CSV: {e}\n", ctx='logs'); self.zero_rows = []; return
        self.zero_page = 0
        try: self._refresh_category_list()
        except Exception: pass
        try: self._refresh_device_list()
        except Exception: pass

    def _zero__preferred_columns(self, rows):
        return self._risky__preferred_columns(rows)

    def _render_zero_page(self, page:int):
        page_size = getattr(self,'zero_page_size',100) or 100
        rows_all = getattr(self,'zero_rows_view',None) or getattr(self,'zero_rows',[])
        total = len(rows_all)
        if total == 0:
            self._append_ctx('No zero‑hit ACLs available. Run "Generate Dashboard" first or adjust filter.\n', ctx='zero')
            return
        max_page = (total-1)//page_size
        page = max(0, min(page, max_page))
        start, end = page*page_size, min((page+1)*page_size, total)
        rows = rows_all[start:end]
        cols = self._zero__preferred_columns(rows)
        header = ['#'] + cols
        base_idx = page * page_size
        self._console_show_table(True, ctx='zero')
        self._render_console_table(header, rows, base_idx=base_idx, ctx='zero')
        self._zero_last_header = header
        self._zero_last_rows = rows
        # also update risky last header/rows so Copy buttons reuse existing helpers
        self._risky_last_header = header
        self._risky_last_rows = rows
        self.zero_page = page

    def _load_zero_page(self, page:int):
        if not getattr(self,'zero_rows',[]): self._load_all_zero_rows()
        self._render_zero_page(page)

    def _apply_zero_filter(self):
        try: q = self.zero_filter_var.get()
        except Exception: q = ''
        base = getattr(self,'zero_rows',[])
        self.zero_rows_view = [r for r in base if self._matches_risky_filter(r, q)]
        self._append_ctx(f"[ZERO] Filter applied: '{q}' -> {len(self.zero_rows_view)} / {len(base)} rows\n", ctx='zero')
        self.zero_page = 0; self._render_zero_page(0)

    def _apply_zero_advanced_filter(self):
        dev = (self.zero_adv_device_var.get() or '').strip()
        cat = (self.zero_adv_category_var.get() or '').strip()
        q0  = (self.zero_filter_var.get() or '').strip()
        try:
            if not getattr(self, 'zero_rows', []):
                self._append_ctx('[ZERO] Loading zero‑hit rows on demand for filtering...\n', ctx='zero')
                self._load_all_zero_rows()
        except Exception as e:
            self._append_ctx(f'[ZERO] Lazy load failed: {e}\n', ctx='zero')
        tokens = []
        if dev: tokens.append(f'device:{dev}')
        if cat:
            tokens.append(f'category:{cat}')
            try:
                mapped = (getattr(self, '_static_category_map', {}) or {}).get(cat)
                if mapped: tokens.append(mapped)
            except Exception: pass
        new_q = (q0 + ' ' + ' '.join(tokens)).strip()
        self.zero_filter_var.set(new_q)
        self._apply_zero_filter()

    def _apply_zero_device_only_filter(self):
        dev = (self.zero_adv_device_var.get() or '').strip()
        if not dev: return
        q0 = (self.zero_filter_var.get() or '').strip()
        new_q = (q0 + ' ' + f'device:{dev}').strip()
        self.zero_filter_var.set(new_q)
        self._apply_zero_filter()

    def _clear_zero_advanced_filter(self):
        try:
            self.zero_adv_device_var.set('')
            self.zero_adv_category_var.set('')
        except Exception:
            pass

    def _export_zero_excel(self):
        rows = getattr(self,'zero_rows_view',None) or getattr(self,'zero_rows',[])
        if not rows:
            self._load_all_zero_rows()
            rows = getattr(self,'zero_rows_view',None) or getattr(self,'zero_rows',[])
        if not rows:
            try: messagebox.showinfo('Export','No zero‑hit ACLs available to export.')
            except Exception: pass
            return
        try:
            base = os.path.dirname(self._find_zero_csv()) or "."
        except Exception:
            base = "."
        ts = __import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = os.path.join(base, f'zero_hit_acl_{ts}.csv')
        xlsx_path = os.path.join(base, f'zero_hit_acl_{ts}.xlsx')
        try:
            if isinstance(rows[0], dict):
                headers = list(rows[0].keys())
                with open(csv_path,'w',newline='',encoding='utf-8') as f:
                    w = csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerows(rows)
            else:
                with open(csv_path,'w',newline='',encoding='utf-8') as f:
                    w = csv.writer(f); w.writerows(rows)
        except Exception as e:
            try: messagebox.showerror('Export Error', f'Failed to write CSV: {e}')
            except Exception: pass
            self._append_ctx(f"[ERROR] CSV export failed: {e}\n", ctx='zero')
            return
        final_path = csv_path
        try:
            import pandas as pd
            pd.read_csv(csv_path).to_excel(xlsx_path, index=False, engine='openpyxl')
            final_path = xlsx_path
        except Exception as e:
            self._append_ctx(f"[ZERO] pandas/openpyxl unavailable; kept CSV ({e})\n", ctx='zero')
        self._append_ctx(f"[ZERO] Exported zero‑hit ACLs -> {final_path}\n", ctx='zero')
        try: self._open_path(final_path)
        except Exception: pass
        try: messagebox.showinfo('Export Complete', f'Exported to:\n{final_path}')
        except Exception: pass

    # ---------------- Copy helpers ----------------
    def _copy_risky_markdown(self):
        header = getattr(self, '_risky_last_header', None)
        rows = getattr(self, '_risky_last_rows', None)
        if not header or not rows:
            msg = "*(No rows to render)*"
        else:
            md = []
            md.append('| ' + ' | '.join(header) + ' |\n')
            md.append('| ' + ' | '.join(['---'] * len(header)) + ' |\n')
            base_idx = getattr(self, 'risky_page', 0) * (getattr(self, 'risky_page_size', 100) or 100)
            for i, r in enumerate(rows, start=1):
                cells = []
                for c in header:
                    if c == '#':
                        cells.append(str(base_idx + i))
                    else:
                        cells.append(self._norm(r.get(c, '')))
                md.append('| ' + ' | '.join(cells) + ' |\n')
            msg = ''.join(md)
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(msg); self.root.update()
            try: messagebox.showinfo("Copy", "Current page copied as Markdown table.")
            except Exception: pass
        except Exception:
            self._append_ctx("[RISK] Unable to access clipboard.\n", ctx='risk')

    def _copy_risky_csv(self):
        import io as _io, csv as _csv
        header = getattr(self, '_risky_last_header', None)
        rows = getattr(self, '_risky_last_rows', None)
        if not header or not rows:
            self._append_ctx("[RISK] No rows to copy as CSV.\n", ctx='risk'); return
        base_idx = getattr(self, 'risky_page', 0) * (getattr(self, 'risky_page_size', 100) or 100)
        buf = _io.StringIO(); w = _csv.writer(buf)
        w.writerow(header)
        for i, r in enumerate(rows, start=1):
            out_row = []
            for c in header:
                if c == '#': out_row.append(str(base_idx + i))
                else: out_row.append(self._norm(r.get(c, '')))
            w.writerow(out_row)
        text = buf.getvalue()
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(text); self.root.update()
            try: messagebox.showinfo("Copy", "Current page copied as CSV.")
            except Exception: pass
        except Exception:
            self._append_ctx("[RISK] Unable to access clipboard.\n", ctx='risk')

    def _copy_zero_markdown(self):
        header = getattr(self, '_zero_last_header', None)
        rows = getattr(self, '_zero_last_rows', None)
        if not header or not rows:
            msg = "*(No rows to render)*"
        else:
            md = []
            md.append('| ' + ' | '.join(header) + ' |\n')
            md.append('| ' + ' | '.join(['---'] * len(header)) + ' |\n')
            base_idx = getattr(self, 'zero_page', 0) * (getattr(self, 'zero_page_size', 100) or 100)
            for i, r in enumerate(rows, start=1):
                cells = []
                for c in header:
                    if c == '#':
                        cells.append(str(base_idx + i))
                    else:
                        cells.append(self._norm(r.get(c, '')))
                md.append('| ' + ' | '.join(cells) + ' |\n')
            msg = ''.join(md)
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(msg); self.root.update()
            try: messagebox.showinfo("Copy", "Current page copied as Markdown table.")
            except Exception: pass
        except Exception:
            self._append_ctx("[ZERO] Unable to access clipboard.\n", ctx='zero')

    def _copy_zero_csv(self):
        import io as _io, csv as _csv
        header = getattr(self, '_zero_last_header', None)
        rows = getattr(self, '_zero_last_rows', None)
        if not header or not rows:
            self._append_ctx("[ZERO] No rows to copy as CSV.\n", ctx='zero'); return
        base_idx = getattr(self, 'zero_page', 0) * (getattr(self, 'zero_page_size', 100) or 100)
        buf = _io.StringIO(); w = _csv.writer(buf)
        w.writerow(header)
        for i, r in enumerate(rows, start=1):
            out_row = []
            for c in header:
                if c == '#': out_row.append(str(base_idx + i))
                else: out_row.append(self._norm(r.get(c, '')))
            w.writerow(out_row)
        text = buf.getvalue()
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(text); self.root.update()
            try: messagebox.showinfo("Copy", "Current page copied as CSV.")
            except Exception: pass
        except Exception:
            self._append_ctx("[ZERO] Unable to access clipboard.\n", ctx='zero')

    # ---------------- Console context helpers ----------------
    def _append_ctx(self, text: str, ctx: str = None):
        widget = None
        if ctx == 'risk':
            widget = getattr(self, 'output_risk', None)
        elif ctx == 'zero':
            widget = getattr(self, 'output_zero', None)
        else:
            widget = getattr(self, 'output_logs', None)
        if widget:
            try:
                widget.config(state='normal'); widget.insert('end', text); widget.see('end'); widget.config(state='disabled')
            except Exception:
                pass
        try: print(text, end='')
        except Exception: pass

# ------------------------------ Main ------------------------------
if __name__ == '__main__':
    print('Running:', __file__)
    root = tk.Tk()
    try: root.withdraw()
    except Exception: pass
    if not _require_launcher_auth(root):
        try: root.destroy()
        except Exception: pass
        raise SystemExit(1)
    try: root.deiconify()
    except Exception: pass
    app = ASAACLTool(root)
    root.mainloop()
