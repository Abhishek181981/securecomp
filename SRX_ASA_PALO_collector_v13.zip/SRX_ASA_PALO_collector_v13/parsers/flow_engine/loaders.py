import csv
import os
import json
from dataclasses import asdict
from typing import Dict, Any

from .models import InterfaceEntry, RouteEntry, PolicyRule
from .normalize_ips import parse_ips
from .normalize_routes import parse_routes
from .normalize_acls import parse_acls

_DATA: Dict[str, Any] = {"interfaces": [], "routes": [], "policies": [], "meta": {}}


def load_latest(reports_base: str = 'reports') -> Dict[str, Any]:
    """Load collector outputs from <reports_base>/latest/*.csv and normalize."""
    global _DATA
    latest = os.path.join(reports_base, 'latest')

    def read_csv(path):
        if not os.path.isfile(path):
            return []
        with open(path, 'r', encoding='utf-8', newline='') as f:
            return list(csv.DictReader(f))

    ips_rows = read_csv(os.path.join(latest, 'ips.csv'))
    routes_rows = read_csv(os.path.join(latest, 'routes.csv'))
    acls_rows = read_csv(os.path.join(latest, 'acls.csv'))

    _DATA = {
        "interfaces": parse_ips(ips_rows),
        "routes": parse_routes(routes_rows),
        "policies": parse_acls(acls_rows),
        "meta": {
            "reports_base": reports_base,
            "latest_dir": latest,
            "counts": {
                "ips_rows": len(ips_rows),
                "routes_rows": len(routes_rows),
                "acls_rows": len(acls_rows),
            }
        }
    }
    return _DATA


def load_latest_json(reports_base: str = 'reports') -> Dict[str, Any]:
    """Prefer normalized JSON files if present; fallback to CSV normalization."""
    global _DATA
    latest = os.path.join(reports_base, 'latest')
    p_int = os.path.join(latest, 'normalized_interfaces.json')
    p_rt = os.path.join(latest, 'normalized_routes.json')
    p_pol = os.path.join(latest, 'normalized_policies.json')
    p_meta = os.path.join(latest, 'normalized_meta.json')

    if os.path.isfile(p_int) and os.path.isfile(p_rt) and os.path.isfile(p_pol):
        with open(p_int, 'r', encoding='utf-8') as f:
            interfaces = [InterfaceEntry.from_dict(x) for x in json.load(f)]
        with open(p_rt, 'r', encoding='utf-8') as f:
            routes = [RouteEntry.from_dict(x) for x in json.load(f)]
        with open(p_pol, 'r', encoding='utf-8') as f:
            policies = [PolicyRule.from_dict(x) for x in json.load(f)]
        meta = {}
        if os.path.isfile(p_meta):
            with open(p_meta, 'r', encoding='utf-8') as f:
                meta = json.load(f)

        _DATA = {"interfaces": interfaces, "routes": routes, "policies": policies, "meta": meta}
        return _DATA

    # fallback to raw CSV
    return load_latest(reports_base)


def get_data() -> Dict[str, Any]:
    return _DATA


def dump_normalized_json(reports_base: str = 'reports') -> Dict[str, str]:
    """Dump normalized data (in-memory) to JSON files under <reports_base>/latest."""
    latest = os.path.join(reports_base, 'latest')
    os.makedirs(latest, exist_ok=True)

    def to_list(objs):
        return [asdict(o) for o in objs]

    p_int = os.path.join(latest, 'normalized_interfaces.json')
    p_rt = os.path.join(latest, 'normalized_routes.json')
    p_pol = os.path.join(latest, 'normalized_policies.json')
    p_meta = os.path.join(latest, 'normalized_meta.json')

    with open(p_int, 'w', encoding='utf-8') as f:
        json.dump(to_list(_DATA.get('interfaces', [])), f, indent=2)
    with open(p_rt, 'w', encoding='utf-8') as f:
        json.dump(to_list(_DATA.get('routes', [])), f, indent=2)
    with open(p_pol, 'w', encoding='utf-8') as f:
        json.dump(to_list(_DATA.get('policies', [])), f, indent=2)

    meta = dict(_DATA.get('meta', {}) or {})
    meta['normalized_at'] = __import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(p_meta, 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2)

    return {"interfaces": p_int, "routes": p_rt, "policies": p_pol, "meta": p_meta}
