Network Flow Normalization (JSON) - Level 1

This package makes collector outputs structured for the Network Flow GUI.

1) Run collector (unchanged):
   python collector.py --base reports

2) Normalize latest outputs into JSON:
   python normalize_latest.py --base reports

3) GUI Network Flow tab should call:
   from flow_engine.loaders import load_latest_json
   load_latest_json(reports_base)

Level-1 policy logic: the flow engine returns the FIRST policy record on the last firewall (with evidence).

Generated files are stored in: <reports_base>/latest/
