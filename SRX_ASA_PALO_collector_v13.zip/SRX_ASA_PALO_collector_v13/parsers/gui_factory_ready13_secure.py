
# -*- coding: utf-8 -*-
"""
Firewall ACL Automation Tool (GUI) - ASA + SRX + Palo Alto (via adapters)
Highlights:
- ACL & Actions tab selected by default; explicit window geometry and wider left pane.
- Manual interface selection removed (auto-detect via adapter).
- Inputs organized in Source / Destination / Ports tabs (Ports visible by default).
- Platform-aware zone line printed (ASA / SRX / Palo) with 'N/A' placeholders when needed.
- SRX diagnostics and preview of 'show security match-policies' command.
- Palo Alto: ACL preview, push (addresses/services/rule), move rule, commit, verify (single policy-match).
- ASA: ACL generation/push + single packet-tracer verification.
Prereqs:
- reporting_utils.py providing: load_settings, get_global_logger, make_run_dir, get_run_logger,
  write_text, write_json, append_csv, write_error
- adapter_factory.py providing: create_adapter (returns platform-specific adapter)
- Palo push requires updated palo_adapter.py implementing: generate_policy_snippet, push_policy,
  zones_for_flow, packet_tracer, summarize_verdict, etc.
"""
import tkinter as tk
import json
from tkinter import ttk, scrolledtext, messagebox
from netmiko import ConnectHandler
import threading
import logging
import re
import csv
import ipaddress
import os
import sys
import subprocess
from datetime import datetime


# --- Launcher Auth (OTP gate) ---
# This GUI will refuse to start unless a valid auth token exists (created by into.py/intro.py).
import time

def _auth_token_path():
    """Store token under LocalAppData (Windows) or ~/.acl_tool (others)."""
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    folder = os.path.join(base, 'AclToolAuth')
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception:
        pass
    return os.path.join(folder, 'auth_token.json')


def _require_launcher_auth(root) -> bool:
    """Return True if auth token present and valid. Consumes token on success."""
    token_file = _auth_token_path()
    try:
        if not os.path.isfile(token_file):
            messagebox.showerror('Authentication required',
                                 'Please launch this tool using into.py (OTP login).\n\nAuth token not found.')
            return False
        with open(token_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        exp = float(data.get('expires_at') or 0)
        email = (data.get('email') or '').strip().lower()
        if not email.endswith('@colt.net'):
            messagebox.showerror('Authentication required',
                                 'Invalid auth token email domain. Please login again using your @colt.net email.')
            return False
        now = time.time()
        if exp <= now:
            messagebox.showerror('Authentication required',
                                 'Your session token has expired. Please login again using into.py (OTP).')
            return False
        # Consume token (single-use) to prevent direct re-runs.
        try:
            os.remove(token_file)
        except Exception:
            pass
        return True
    except Exception as e:
        try:
            messagebox.showerror('Authentication required', f'Failed to validate auth token: {e}')
        except Exception:
            pass
        return False
# Local project helpers
from reporting_utils import (
    load_settings, get_global_logger, make_run_dir, get_run_logger,
    write_text, write_json, append_csv, write_error
)
# Adapter factory (ASA/SRX/Palo)
from adapter_factory import create_adapter

# FLOW ENGINE IMPORTS (JSON-first)
try:
    from flow_engine.loaders import load_latest_json
    from flow_engine.flow_search import find_flow
except Exception:
    load_latest_json = None
    find_flow = None


# Suppress logging handler exceptions (Windows file locks)
logging.raiseExceptions = False
PAD = 8
GUI_BUILD_ID = 'gui_factory_ready13_srx_cidr_fixed_v5'
print('[BUILD]', GUI_BUILD_ID)

# ------------------------------ Core helpers ------------------------------
def read_firewall_data():
    rows = []
    try:
        with open('firewall.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                hostname = row.get('hostname', '').strip()
                ip = row.get('ip', '').strip()
                platform = row.get('platform', '').strip()
                mode = (row.get('mode') or '').strip().lower()
                context = (row.get('context') or '').strip()
                if not hostname or not ip or not platform:
                    continue
                display_name = f"{hostname} ({platform})"
                rows.append({
                    'hostname': hostname,
                    'ip': ip,
                    'platform': platform,
                    'display': display_name,
                    'mode': mode,
                    'context': context,
                })
    except FileNotFoundError:
        rows = []
    return rows

def _parse_multiline(text: str):
    return [l.strip() for l in text.splitlines() if l.strip()]

def _parse_ip_list(text: str):
    items = _parse_multiline(text)
    ips = []
    for it in items:
        ipaddress.IPv4Address(it)  # raises on invalid
        ips.append(it)
    out, seen = [], set()
    for ip in ips:
        if ip not in seen:
            seen.add(ip)
            out.append(ip)
    return out


def _parse_ip_or_cidr_list(text: str):
    """Parse multi-line list of IPv4 hosts and CIDR subnets (strict=False).

    - Hosts returned as canonical dotted-quad strings.
    - CIDR returned as normalized prefix-length form (e.g. 10.0.0.0/255.255.255.0 -> 10.0.0.0/24).
    """
    items = _parse_multiline(text)
    out, seen = [], set()
    for it in items:
        s = (it or "").strip()
        if not s:
            continue
        try:
            ip = ipaddress.IPv4Address(s)
            norm = str(ip)
        except Exception:
            net = ipaddress.IPv4Network(s, strict=False)
            norm = str(net)
        if norm not in seen:
            seen.add(norm)
            out.append(norm)
    return out

def _parse_ports(text: str):
    items = _parse_multiline(text)
    out = []
    for it in items:
        if '-' in it:
            m = re.fullmatch(r"\s*(\d{1,5})\s*\-\s*(\d{1,5})\s*", it)
            if not m:
                raise ValueError(f"Invalid port range: {it}")
            a, b = int(m.group(1)), int(m.group(2))
            if not (1 <= a <= 65535 and 1 <= b <= 65535 and a <= b):
                raise ValueError(f"Invalid port range bounds: {it}")
            out.append((a, b))
        else:
            if not it.isdigit():
                raise ValueError(f"Invalid port: {it}")
            p = int(it)
            if not (1 <= p <= 65535):
                raise ValueError(f"Invalid port: {it}")
            out.append(p)
    dedup, seen = [], set()
    for v in out:
        if v not in seen:
            seen.add(v)
            dedup.append(v)
    return dedup

def _first_representative_port(ports):
    if not ports:
        raise ValueError("No ports provided")
    first = ports[0]
    if isinstance(first, int):
        return first
    a, _b = first
    return a



def _wrap_srx_set_commands(set_lines: str) -> str:
    # SRX-safe interactive paste wrapper (does NOT affect ASA/Palo)
    body = (set_lines or '').strip('\n')
    if not body:
        return ''
    parts = [
        '# --- SRX COPY/PASTE (RECOMMENDED) ---',
        'configure',
        'load set terminal',
        body,
        '# (Press Ctrl-D to finish load set terminal)',
        'commit check',
        'commit',
        '# --- END SRX COPY/PASTE ---',
    ]
    return '\n'.join(parts) + '\n'
def _open_path(path):
    try:
        if sys.platform.startswith('win'):
            os.startfile(path)
        elif sys.platform == 'darwin':
            subprocess.call(['open', path])
        else:
            subprocess.call(['xdg-open', path])
    except Exception:
        messagebox.showwarning("Open", f"Unable to open: {path}")

def _latest_run_dir(base):
    try:
        if not os.path.isdir(base):
            return None
        entries = [d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d))]
        if not entries:
            return None
        latest = sorted(entries)[-1]
        return os.path.join(base, latest)
    except Exception:
        return None

# ------------------------------ GUI ------------------------------
class ASAACLTool:
    # -- UI @ class level --
    @staticmethod
    def _extract_platform(display_name: str) -> str:
        # FIXED: Extract platform inside trailing "(<platform>)"
        m = re.search(r"\(([^)]+)\)\s*$", display_name or "")
        return m.group(1) if m else ""

    def safe_update_status(self, message, color="blue", progress=False):
        self.root.after(0, lambda: self.update_status(message, color, progress))

    def update_status(self, message, color="blue", progress=False):
        self.status_label.config(text=f"Status: {message}")
        self.status_label.config(foreground=color)
        if progress:
            self.progress.start(10)
        else:
            self.progress.stop()
        self.root.update_idletasks()

    def set_controls_enabled(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        self.ip_dropdown.configure(state="readonly" if enabled else "disabled")
        self.fw_filter.configure(state=state)
        self.platform_filter.configure(state="readonly" if enabled else "disabled")
        self.pick_btn.configure(state=state)
        self.user_entry.configure(state=state)
        self.pass_entry.configure(state=state)
        self.enable_entry.configure(state=state)
        self.test_btn.configure(state=state)
        self.refresh_btn.configure(state=state)
        self.disconnect_btn.configure(state=state if (self.connection) else "disabled")
        # ASA context controls disabled for SRX and Palo
        self.detect_ctx_btn.configure(state=state if (self.connection and not self.platform_is_srx and not self.platform_is_palo) else "disabled")
        self.select_ctx_btn.configure(state=state if (self.connection and self.context_list and not self.platform_is_srx and not self.platform_is_palo) else "disabled")
        self.src_entry.configure(state=state)
        self.dst_entry.configure(state=state)
        self.port_entry.configure(state=state)
        self.status_btn.configure(state=state)
        self.interface_btn.configure(state=state)
        self.inline_check_btn.configure(state=state)
        self.connectivity_btn.configure(state=state)
        self.generate_btn.configure(state=state)
        self.final_btn.configure(state=state)
        # NEW: capture buttons enabled state tracks overall controls (neutral)
        try:
            self.start_cap_btn.configure(state=state)
            self.stop_cap_btn.configure(state=state)
        except Exception:
            pass

    def log_output(self, message):
        prefix = f"[CTX={self.context_name}] " if self.context_name else ""
        self.output.insert(tk.END, prefix + message + "\n")
        self.output.see(tk.END)
        try:
            if self.run_logger:
                self.run_logger.info(message)
        except Exception:
            pass
        try:
            self.global_logger.info(prefix + message)
        except Exception:
            pass

    def open_last_run(self):
        base = self.logs_base_var.get()
        latest = _latest_run_dir(base)
        if latest:
            self.logs_last_var.set(latest)
            _open_path(latest)
        else:
            messagebox.showinfo("Reports", "No run folder found yet.")

    def toggle_debug(self):
        enabled = self.debug_enabled.get()
        lvl = logging.DEBUG if enabled else logging.INFO
        try:
            self.global_logger.setLevel(lvl)
        except Exception:
            pass
        messagebox.showinfo("Debug", f"Debug logging {'ENABLED' if enabled else 'DISABLED'}.")

    # ------------------------------ Reporting helpers ------------------------------
    def start_run(self, action_name: str):
        try:
            self.run_dir = make_run_dir()
            self.run_logger = get_run_logger(self.run_dir)
            self.run_logger.info(f"Starting {action_name}")
            self.global_logger.info(f"Run started: {action_name} -> {self.run_dir}")
            self.logs_run_var.set(self.run_dir)
        except Exception as e:
            try:
                self.global_logger.warning(f"start_run failed: {e}")
            except Exception:
                pass
            self.run_dir = None
            self.run_logger = None
            self.logs_run_var.set('-')

    def write_error(self, message: str):
        try:
            if self.run_dir:
                write_error(self.run_dir, message)
            if self.run_logger:
                self.run_logger.error(message)
        except Exception:
            pass
        try:
            self.global_logger.error(message)
        except Exception:
            pass

    # ------------------------------ List & picker ------------------------------
    def _rebuild_fw_index(self):
        self.display_to_row = {r['display']: r for r in self.all_fw}
        self.all_fw_display = [r['display'] for r in self.all_fw]

    def _filter_firewalls(self, event=None):
        q = (self.fw_filter.get() or "").strip().lower()
        plat_sel = (self.platform_filter.get() or "All")
        filtered = []
        for r in self.all_fw:
            d = r['display']; ip = r['ip']
            if plat_sel != "All":
                plat = self._extract_platform(d)
                if plat != plat_sel:
                    continue
            if not q or (q in d.lower()) or (q in (ip or "").lower()):
                filtered.append(d)
        self.ip_dropdown['values'] = filtered if filtered else ["<no matches>"]

    def open_fw_picker(self):
        top = tk.Toplevel(self.root)
        top.title("Select Firewall")
        top.transient(self.root)
        top.grab_set()
        top.minsize(640, 500)
        frm = ttk.Frame(top)
        frm.pack(fill="both", expand=True, padx=PAD, pady=PAD)
        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(1, weight=1)
        ttk.Label(frm, text="Search (host/platform/IP):").grid(row=0, column=0, sticky="w")
        search = ttk.Entry(frm)
        search.grid(row=0, column=0, sticky="nsew", pady=(0, PAD))
        list_frame = ttk.Frame(frm)
        list_frame.grid(row=1, column=0, sticky="nsew")
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        lst = tk.Listbox(list_frame, activestyle='dotbox')
        sb = ttk.Scrollbar(list_frame, orient="vertical", command=lst.yview)
        lst.configure(yscrollcommand=sb.set)
        lst.grid(row=0, column=0, sticky="nsew"); sb.grid(row=0, column=1, sticky="ns")
        btn_row = ttk.Frame(frm)
        btn_row.grid(row=2, column=0, sticky="ew", pady=(PAD, 0))
        btn_row.columnconfigure(0, weight=1)
        btn_row.columnconfigure(1, weight=1)

        def do_select():
            sel = lst.curselection()
            if not sel:
                return
            # 'text' is rendered as "<display> <ip>"; we want the original display (with platform)
            text = lst.get(sel[0])
            # Extract the display part before the last space + IP
            parts = text.rsplit(" ", 1)
            display = parts[0] if len(parts) == 2 else text
            # IMPORTANT: keep the "(SRX)" or "(Palo Alto)" suffix in display
            self.ip_dropdown.set(display.strip())
            top.destroy()

        ttk.Button(btn_row, text="Select", command=do_select).grid(row=0, column=0, sticky="ew", padx=(0, PAD))
        ttk.Button(btn_row, text="Cancel", command=top.destroy).grid(row=0, column=1, sticky="ew")

        items = [(r['display'], r['ip']) for r in self.firewall_data]

        def render_list(query=""):
            lst.delete(0, tk.END)
            q = (query or "").strip().lower()
            plat_sel = self.platform_filter.get() or "All"
            for d, ip in items:
                if plat_sel != "All":
                    plat = self._extract_platform(d)
                    if plat != plat_sel:
                        continue
                if not q or (q in d.lower()) or (q in (ip or "").lower()):
                    lst.insert(tk.END, f"{d} {ip}")

        def on_search(_e=None):
            render_list(search.get())

        lst.bind("<Double-Button-1>", lambda _e: do_select())
        lst.bind("<Return>", lambda _e: do_select())
        search.bind("<KeyRelease>", on_search)
        render_list()
        search.focus_set()

    # ------------------------------ Context picker (ASA only) ------------------------------
    def open_context_picker(self):
        if not getattr(self, "context_list", None):
            messagebox.showwarning("Context", "No contexts discovered yet. Click 'Detect Mode / List Contexts' first.")
            return
        top = tk.Toplevel(self.root)
        top.title("Select ASA Context")
        top.transient(self.root)
        top.grab_set()
        top.minsize(420, 360)
        frm = ttk.Frame(top)
        frm.pack(fill="both", expand=True, padx=PAD, pady=PAD)
        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(1, weight=1)
        ttk.Label(frm, text=f"Detected contexts ({len(self.context_list)}):").grid(row=0, column=0, sticky="w")
        lst = tk.Listbox(frm, activestyle='dotbox')
        sb = ttk.Scrollbar(frm, orient="vertical", command=lst.yview)
        lst.configure(yscrollcommand=sb.set)
        lst.grid(row=1, column=0, sticky="nsew"); sb.grid(row=1, column=1, sticky="ns")
        for name in self.context_list:
            lst.insert(tk.END, name)
        btn_row = ttk.Frame(frm)
        btn_row.grid(row=2, column=0, sticky="ew", pady=(PAD, 0))
        btn_row.columnconfigure(0, weight=1)
        btn_row.columnconfigure(1, weight=1)

        def do_select():
            sel = lst.curselection()
            if not sel:
                return
            name = lst.get(sel[0]).strip('*').strip()
            if self.enter_context(name):
                top.destroy()

        ttk.Button(btn_row, text="Select", command=do_select).grid(row=0, column=0, sticky="ew", padx=(0, PAD))
        ttk.Button(btn_row, text="Cancel", command=top.destroy).grid(row=0, column=1, sticky="ew")

    # ------------------------------ Device list ------------------------------
    def refresh_firewall_list(self):
        self.firewall_data = read_firewall_data()
        self.all_fw = list(self.firewall_data)
        self._rebuild_fw_index()
        self._filter_firewalls()
        self.log_output(f"Firewall list refreshed: {[r['display'] for r in self.firewall_data]}")
        try:
            self.global_logger.info("Firewall list refreshed")
        except Exception:
            pass

    def _selected_row(self):
        selected_display = (self.ip_dropdown.get() or "").strip()
        if not selected_display or selected_display == "<no matches>":
            return None
        # Primary: full display match (e.g., "JPN-EDG-IO-FW01 (SRX)")
        row = self.display_to_row.get(selected_display)
        if row:
            return row
        # Fallback A: match by hostname (left side before " (")
        host_key = selected_display.split(" (", 1)[0].strip()
        for r in self.firewall_data:
            if (r.get("hostname") or "").strip() == host_key:
                return r
        # Fallback B: match by IP if the combobox was set to IP
        for r in self.firewall_data:
            if (r.get("ip") or "").strip() == selected_display:
                return r
        return None

    def connect_to_firewall(self):
        # Diagnostic: confirm current combobox value before lookup
        chosen = (self.ip_dropdown.get() or "")
        self.log_output(f"[DBG] Combobox value: '{chosen}'")

        row = self._selected_row()
        if not row:
            self.log_output("No firewall selected.")
            return False

        selected_ip = row['ip']
        platform = (row.get('platform') or "").strip()
        # Create adapter for the selected platform
        self.adapter = create_adapter(platform, logger=self.run_logger or self.global_logger, debug=True)
        # === Visibility: log chosen adapter ===
        try:
            self.log_output(f"[DBG] Platform '{platform}' -> adapter {type(self.adapter).__name__}")
        except Exception:
            pass
        # === Defensive guard: never proceed with a None adapter ===
        if self.adapter is None:
            self.log_output(f"[WARN] No adapter matched for platform '{platform}'. Defaulting to ASA adapter.")
            try:
                from asa_adapter_refactored_interface import AsaAdapter
                self.adapter = AsaAdapter(logger=self.run_logger or self.global_logger, debug=True)
                self.log_output("[DBG] Fallback to AsaAdapter succeeded.")
            except Exception:
                # Minimal safe fallback
                class _NullAdapter:
                    def __init__(self, logger=None, debug=True):
                        self.logger = logger; self.debug = debug
                    def attach(self, conn): self.conn = conn
                    def check_status(self): return ("Connected", "green")
                    def _pick_representative_ip(self, item): return item
                    def detect_interfaces(self, src_ip, dst_ip): return (None, None)
                    def zones_for_flow(self, src_iface, dst_ip): return (None, None)
                    def packet_tracer(self, inif, proto, sip, sport, dip, dport, timeout=120, delay_factor=2):
                        return "[WARN] NullAdapter in use; no packet-tracer available."
                self.adapter = _NullAdapter(logger=self.run_logger or self.global_logger, debug=True)
                self.log_output("[DBG] Fallback to NullAdapter applied.")
        # Platform flags
        is_srx = ("juniper" in platform.lower()) or ("srx" in platform.lower())
        is_palo = ("palo alto" in platform.lower()) or ("pan-os" in platform.lower()) or ("panos" in platform.lower()) or platform.lower().startswith("pa ") or (platform.lower() == "pa")
        self.platform_is_srx = is_srx
        self.platform_is_palo = is_palo
        device_type = "juniper_junos" if is_srx else ("paloalto_panos" if is_palo else "cisco_asa")
        device = {
            'device_type': device_type,
            'host': selected_ip,
            'username': self.user_entry.get(),
            'password': self.pass_entry.get(),
            'secret': self.enable_entry.get(),
        }
        try:
            self.connection = ConnectHandler(**device)
            # Enable privilege for ASA only
            if (not is_srx) and (not is_palo) and self.enable_entry.get():
                self.connection.enable()
            # CLI / pager hygiene
            try:
                if is_srx:
                    self.connection.send_command("set cli screen-length 0", expect_string=r'[\>\#]')
                else:
                    self.connection.send_command("terminal pager 0", expect_string=r'[\>\#]')
            except Exception:
                pass
            # Attach adapter & set Palo context if provided in CSV
            csv_ctx = (row.get('context') or '').strip()
            try:
                if is_palo and csv_ctx and hasattr(self.adapter, "set_context"):
                    self.adapter.set_context(csv_ctx)
            except Exception:
                pass
            try:
                self.adapter.attach(self.connection)
            except Exception as e:
                self.log_output(f"[WARN] adapter.attach failed: {e}")
            # Helpful: prime zones for Palo
            try:
                if is_palo and hasattr(self.adapter, "refresh_zones_and_interfaces"):
                    self.adapter.refresh_zones_and_interfaces()
            except Exception:
                pass
            # ASA multi-context UI only when ASA
            if is_srx:
                self.asa_mode = 'single'
                self.mode_var.set('Single')
                self.detect_ctx_btn.configure(state="disabled")
                self.select_ctx_btn.configure(state="disabled")
            else:
                csv_mode = (row.get('mode') or '').strip().lower()
                if csv_mode in ('single', 'multi'):
                    self.asa_mode = csv_mode
                    self.mode_var.set(self.asa_mode.capitalize())
                else:
                    self.asa_mode = 'unknown'
                    self.mode_var.set('Unknown')
                csv_ctx = (row.get('context') or '').strip()
                if (not is_palo) and self.asa_mode == 'multi' and csv_ctx:
                    if self.enter_context(csv_ctx):
                        self.log_output(f"Auto-switched to context from CSV: {csv_ctx}")
            # Context detection button disabled for SRX & Palo
            self.detect_ctx_btn.configure(state="normal" if (not is_srx and not is_palo) else "disabled")
            self.disconnect_btn.configure(state="normal")
            return True
        except Exception as e:
            self.log_output(f"Connection failed: {e}")
            try:
                self.global_logger.exception("Connection failed")
            except Exception:
                pass
            return False

    def disconnect_firewall(self):
        try:
            if self.connection:
                self.safe_update_status("Disconnecting...", "orange", True)
                # Safety: stop monitor loop if running
                try:
                    self.stop_monitor()
                except Exception:
                    pass
                try:
                    self.connection.disconnect()
                except Exception:
                    pass
                self.connection = None
                self.adapter = None
                self.interface_name = None
                self.context_name = None
                self.context_list = []
                self.ctx_var.set('-')
                self.detect_ctx_btn.configure(state="disabled")
                self.select_ctx_btn.configure(state="disabled")
                self.disconnect_btn.configure(state="disabled")
                self.safe_update_status("Disconnected", "green")
                self.log_output("Disconnected from firewall.")
                try:
                    self.global_logger.info("Disconnected from firewall")
                except Exception:
                    pass
        finally:
            self.progress.stop()
            self.set_controls_enabled(True)

    def test_connection(self):
        self.safe_update_status("Connecting to firewall...", "orange", True)
        self.start_run("test_connection")
        if self.connect_to_firewall():
            self.safe_update_status("Connected successfully", "green")
            self.log_output("Connection successful!")
            try:
                self.global_logger.info("Connection successful")
            except Exception:
                pass
            # Palo Alto: do NOT run ASA CSV mode/context detection
            if self.platform_is_palo:
                self.safe_update_status("Connected (PAN-OS)", "green")
                return
            # ASA-only mode/context detection (SRX skipped)
            if not self.platform_is_srx:
                self.detect_mode_and_contexts()
        else:
            self.safe_update_status("Connection failed", "red")
            self.progress.stop()
            messagebox.showerror("Error", "Failed to connect to firewall.")
            self.write_error("Failed to connect to firewall")

    def _get_prompt_context_hint(self):
        try:
            prompt = self.connection.find_prompt()
        except Exception:
            return None
        m = re.search(r"/(\w[\w\-.]*)[\#\>]\s*$", prompt or "")
        return m.group(1) if m else None

    def detect_mode_and_contexts(self):
        # ASA only
        row = self._selected_row()
        if not row or not self.connection:
            self.log_output("Not connected. Cannot detect mode/contexts.")
            return
        self.safe_update_status("Determining ASA mode from CSV...", "orange", True)
        selected_display = self.ip_dropdown.get()
        row = self.display_to_row.get(selected_display, {})
        csv_mode = (row.get('mode') or '').strip().lower()
        self.asa_mode = csv_mode if csv_mode in ('single', 'multi') else 'unknown'
        self.mode_var.set(self.asa_mode.capitalize() if self.asa_mode != "unknown" else "Unknown")
        self.log_output(f"ASA mode set from CSV: {self.asa_mode}")
        try:
            self.global_logger.info(f"ASA mode: {self.asa_mode}")
        except Exception:
            pass
        if self.asa_mode != "multi":
            self.context_name = None
            self.ctx_var.set("-")
            self.select_ctx_btn.configure(state="disabled")
            self.safe_update_status("Mode set from CSV", "green")
            self.progress.stop()
            return
        self.safe_update_status("Listing contexts...", "orange", True)
        contexts = []
        try:
            try:
                self.connection.send_command("changeto system", expect_string=r"[\>\#]", read_timeout=10)
            except Exception:
                pass
            ctx_out = self.connection.send_command("show context", expect_string=r"[\>\#]", read_timeout=30)
            for line in ctx_out.splitlines():
                s = line.strip()
                if not s or s.lower().startswith("context") or (s.lower().startswith("admin") and "url" in s.lower()):
                    continue
                m = re.match(r"^\*?([A-Za-z0-9_.\-]+)\s+", s)
                if m and m.group(1).upper() not in ("CONTEXT", "NAME", "CLASS", "URL"):
                    contexts.append(m.group(1))
        except Exception as e:
            self.log_output(f"Context listing failed: {e}")
            try:
                self.global_logger.exception("Context listing failed")
            except Exception:
                pass
        if not contexts:
            hint = self._get_prompt_context_hint()
            if hint:
                contexts = [hint]
                self.log_output(f"Operating in current context (discovery limited): {hint}")
            else:
                self.log_output("No contexts discovered; operating in current context (unknown).")
        seen, ordered = set(), []
        for n in contexts:
            if n not in seen:
                seen.add(n)
                ordered.append(n)
        self.context_list = ordered
        self.select_ctx_btn.configure(state="normal" if self.context_list else "disabled")
        if len(self.context_list) == 1:
            chosen = self.context_list[0]
            if self.enter_context(chosen):
                self.safe_update_status("Mode/context handling complete", "green")
                self.progress.stop()
                return
        self.safe_update_status("Select a context to continue", "orange")
        self.progress.stop()
        self.open_context_picker()

    def enter_context(self, name: str) -> bool:
        if not self.connection:
            return False
        try:
            self.connection.send_command(
                f"changeto context {name}", expect_string=r"[\>\#]", read_timeout=20
            )
            try:
                self.connection.send_command("terminal pager 0", expect_string=r"[\>\#]")
            except Exception:
                pass
            self.context_name = name
            self.ctx_var.set(name)
            self.log_output(f"Entered context: {name}")
            try:
                self.global_logger.info(f"Entered context: {name}")
            except Exception:
                pass
            return True
        except Exception as e:
            self.log_output(f"Failed to enter context {name}: {e}")
            try:
                self.global_logger.exception("Context change failed")
            except Exception:
                pass
            messagebox.showerror("Context", f"Failed to enter context '{name}': {e}")
            return False

    # ------------------------------ Detect interface & zones ------------------------------
    def detect_interface(self):
        self.safe_update_status("Detecting interface...", "orange", True)
        self.start_run("detect_interface")
        row = self._selected_row()
        if not row or not self.connection or not self.adapter:
            self.safe_update_status("Not connected", "red")
            self.progress.stop()
            self.log_output("Not connected to firewall.")
            self.write_error("Detect interface: not connected")
            return
        try:
            adapter = self.adapter
            raw_src_lines = (self.src_entry.get("1.0", "end") or "").strip().splitlines()
            raw_dst_lines = (self.dst_entry.get("1.0", "end") or "").strip().splitlines()
            # Normalize hosts (if CIDR, use adapter to pick representative host)
            src_ip = None
            try:
                src_ips = _parse_ip_list("\n".join(raw_src_lines))
                if src_ips:
                    src_ip = src_ips[0]
            except Exception:
                if raw_src_lines:
                    first_src = raw_src_lines[0].strip()
                    if first_src and hasattr(adapter, "_pick_representative_ip"):
                        try:
                            src_ip = adapter._pick_representative_ip(first_src)
                        except Exception:
                            src_ip = None
            dst_ip = None
            try:
                dst_ips = _parse_ip_list("\n".join(raw_dst_lines))
                if dst_ips:
                    dst_ip = dst_ips[0]
            except Exception:
                if raw_dst_lines:
                    first_dst = raw_dst_lines[0].strip()
                    if first_dst and hasattr(adapter, "_pick_representative_ip"):
                        try:
                            dst_ip = adapter._pick_representative_ip(first_dst)
                        except Exception:
                            dst_ip = None
            src_if, dst_if = adapter.detect_interfaces(src_ip, dst_ip)
            self.interface_name = src_if
            # Reset zone placeholders
            try:
                self.zone_from_var.set("N/A")
                self.zone_to_var.set("N/A")
            except Exception:
                pass
            from_zone, to_zone = None, None
            try:
                if hasattr(adapter, 'zones_for_flow'):
                    self.log_output(f"[DBG] zones_for_flow: src_if={src_if}, dst_ip={dst_ip}")
                    from_zone, to_zone = adapter.zones_for_flow(src_if, dst_ip)
            except Exception as e:
                self.log_output(f"Zone discovery failed: {e}")
            # Diagnostics (optional raw dumps if adapter supports)
            try:
                self.log_output(
                    f"[DIAG] adapter={type(adapter).__name__} "
                    f"src_if={src_if} dst_if={dst_if} dst_ip={dst_ip}"
                )
                for fname, getter in [
                    ("zones_oper_raw.txt", getattr(adapter, "_fetch_zones_oper_raw", None)),
                    ("zones_oper_xml.xml", getattr(adapter, "_fetch_zones_oper_xml", None)),
                    ("zones_cfg_set.txt", getattr(adapter, "_fetch_zones_cfg_set", None)),
                ]:
                    try:
                        if callable(getter):
                            raw = getter() or ""
                            write_text(self.run_dir, fname, raw if raw.strip() else "<empty>")
                    except Exception as e:
                        write_text(self.run_dir, fname, f"<error: {e}>")
            except Exception as diag_e:
                self.log_output(f"[DIAG] dump failed: {diag_e}")
            from_zone_str = from_zone or "N/A"
            to_zone_str = to_zone or "N/A"
            detection = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "context": self.context_name,
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "src_if": src_if,
                "dst_if": dst_if,
                "from_zone": from_zone_str,
                "to_zone": to_zone_str,
            }
            write_json(self.run_dir, "detection.json", detection)
            write_text(
                self.run_dir,
                "detection.txt",
                f"src_if={src_if or 'N/A'}, dst_if={dst_if or 'N/A'}, "
                f"from_zone={from_zone_str}, to_zone={to_zone_str}"
            )
            append_csv(
                self.run_dir,
                "results.csv",
                headers=["timestamp","action","context","src_ip","dst_ip","src_if","dst_if","from_zone","to_zone","status"],
                row={**detection, "action": "detect_interface", "status": "ok" if src_if else "fail"}
            )
            if src_if:
                msg = (
                    f"Interface detected: src_if={src_if}, dst_if={dst_if or 'N/A'}; "
                    f"zones: from={from_zone_str}, to={to_zone_str}"
                )
                self.safe_update_status(msg, "green")
                self.log_output(msg)
            else:
                msg = f"Interface detection failed (src_if=N/A, dst_if={dst_if or 'N/A'})"
                self.safe_update_status(msg, "red")
                self.log_output(msg)
                messagebox.showwarning(
                    "Warning",
                    "Interface detection failed. Manual selection removed—please retry detection."
                )
            if self.platform_is_srx:
                label = "Zones (SRX)"
            elif self.platform_is_palo:
                label = "Zones (Palo)"
            else:
                label = "Zones (ASA)"
            self.output.insert(tk.END, f"{label}: from={from_zone_str} to={to_zone_str}\n", 'found')
            self.output.see(tk.END)
            try:
                self.zone_from_var.set(from_zone_str)
                self.zone_to_var.set(to_zone_str)
            except Exception:
                pass
        except Exception as e:
            self.safe_update_status("Interface detection failed", "red")
            self.log_output(f"Error detecting interface via adapter: {e}")
            self.write_error(f"Detect interface error: {e}")
        finally:
            self.progress.stop()

    def get_access_group_for_interface(self):
        # ASA-only helper
        try:
            output = self.connection.send_command(
                "show run access-group", expect_string=r"[\>\#]", read_timeout=30
            )
        except Exception:
            return "OUTSIDE_IN"
        match = re.search(
            rf"access-group (\S+) in interface {re.escape(self.interface_name or '')}",
            output
        )
        return match.group(1) if match else "OUTSIDE_IN"

    def _build_srx_policy_commands(self, from_zone: str, to_zone: str,
                                   src_ips, dst_ips, ports, proto_label: str) -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        policy_name = f"TEMP-{ts}"
        lines = []

        def _sanitize_obj_token(s: str) -> str:
            # Keep object names safe (avoid '/', spaces, etc.)
            return re.sub(r"[^A-Za-z0-9_.-]+", "_", (s or "").strip())

        def _canonical_prefix(ip_or_cidr: str) -> str:
            """Return a Junos-safe address value.

            - Host: x.x.x.x/32
            - CIDR or dotted-netmask: normalized prefix-length x.x.x.x/yy
            """
            s = (ip_or_cidr or "").strip()
            if not s:
                return s
            try:
                ip = ipaddress.IPv4Address(s)
                return f"{ip}/32"
            except Exception:
                net = ipaddress.IPv4Network(s, strict=False)
                return str(net)

        # Address objects (zone-scoped)
        for ip in src_ips:
            name = f"SRC-{_sanitize_obj_token(ip)}"
            lines.append(f"set security zones security-zone {from_zone} address-book address {name} {_canonical_prefix(ip)}")
        for ip in dst_ips:
            name = f"DST-{_sanitize_obj_token(ip)}"
            lines.append(f"set security zones security-zone {to_zone} address-book address {name} {_canonical_prefix(ip)}")

        # Applications
        apps = []

        def _app_name(proto, a, b=None):
            return f"APP-{proto.upper()}-{a}" if b is None else f"APP-{proto.upper()}-{a}-{b}"

        def _add_app(proto, a, b=None):
            name = _app_name(proto, a, b)
            if b is None:
                lines.append(f"set applications application {name} protocol {proto} destination-port {a}")
            else:
                lines.append(f"set applications application {name} protocol {proto} destination-port {a}-{b}")
            apps.append(name)

        use_tcp = (proto_label == "tcp" or proto_label == "both")
        use_udp = (proto_label == "udp" or proto_label == "both")
        for p in ports:
            if isinstance(p, int):
                if use_tcp:
                    _add_app("tcp", p)
                if use_udp:
                    _add_app("udp", p)
            else:
                a, b = p
                if use_tcp:
                    _add_app("tcp", a, b)
                if use_udp:
                    _add_app("udp", a, b)

        src_names = " ".join([f"SRC-{_sanitize_obj_token(ip)}" for ip in src_ips]) if src_ips else "any"
        dst_names = " ".join([f"DST-{_sanitize_obj_token(ip)}" for ip in dst_ips]) if dst_ips else "any"
        app_names = " ".join(apps) if apps else "any"

        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} match source-address [ {src_names} ]")
        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} match destination-address [ {dst_names} ]")
        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} match application [ {app_names} ]")
        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} then permit")
        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} then log session-init")
        lines.append(f"set security policies from-zone {from_zone} to-zone {to_zone} policy {policy_name} then log session-close")
        return "\n".join(lines)

    def generate_acl(self):
        self.start_run("generate_acl")
        row = self._selected_row()
        if not row:
            messagebox.showerror("Error", "Select a firewall first.")
            return
        if not self.connection or not self.adapter:
            messagebox.showerror("Error", "Not connected to firewall.")
            return
        # -- Palo Alto path: preview readable 'set' commands --
        if self.platform_is_palo and self.adapter:
            try:
                src_ips = _parse_ip_or_cidr_list(self.src_entry.get("1.0", "end"))
                dst_ips = _parse_ip_or_cidr_list(self.dst_entry.get("1.0", "end"))
                ports = _parse_ports(self.port_entry.get("1.0", "end"))
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
                return
            if not self.interface_name:
                messagebox.showerror("Error", "No interface detected. Please run 'Detect Interface' first.")
                return
            try:
                from_zone, to_zone = self.adapter.zones_for_flow(self.interface_name, dst_ips[0] if dst_ips else None)
            except Exception:
                from_zone, to_zone = None, None
            if not from_zone or not to_zone:
                messagebox.showwarning("PA Policy", "Zones not resolved. Preview will use 'any'.")
                from_zone = from_zone or "any"
                to_zone = to_zone or "any"
            proto_label = (self.asa_proto.get() or "TCP").strip().lower()
            service_protocol = "both" if proto_label == "both" else ("udp" if proto_label == "udp" else "tcp")
            try:
                policy_text = self.adapter.generate_policy_snippet(
                    src_ips, dst_ips, ports, from_zone, to_zone,
                    vsys=getattr(self.adapter, "current_context_hint", lambda: None)(),
                    service_protocol=service_protocol
                )
            except Exception as e:
                messagebox.showerror("Error", f"Preview failed: {e}")
                return
            self.acl_commands = policy_text
            self.output.insert(tk.END, "[PA POLICY - PREVIEW]\n", "found")
            self.output.insert(tk.END, policy_text + "\n")
            self.output.see(tk.END)
            return  # done

        # -- SRX / ASA path below --
        try:
            # SRX branch uses host-only parsing
            if self.platform_is_srx:
                src_ips = _parse_ip_or_cidr_list(self.src_entry.get("1.0", "end"))
                dst_ips = _parse_ip_or_cidr_list(self.dst_entry.get("1.0", "end"))
                ports = _parse_ports(self.port_entry.get("1.0", "end"))
            else:
                # ASA-safe: normalize any CIDR -> representative host first
                raw_src = (self.src_entry.get("1.0", "end") or "").strip().splitlines()
                raw_dst = (self.dst_entry.get("1.0", "end") or "").strip().splitlines()
                norm_src_lines, norm_dst_lines = [], []
                for line in raw_src:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            norm_src_lines.append(ip)
                        else:
                            norm_src_lines.append(s)
                    else:
                        norm_src_lines.append(s)
                for line in raw_dst:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            norm_dst_lines.append(ip)
                        else:
                            norm_dst_lines.append(s)
                    else:
                        norm_dst_lines.append(s)
                src_ips = _parse_ip_or_cidr_list("\n".join(norm_src_lines))
                dst_ips = _parse_ip_or_cidr_list("\n".join(norm_dst_lines))
                ports = _parse_ports(self.port_entry.get("1.0", "end"))
        except ValueError as ve:
            messagebox.showerror("Error", str(ve))
            self.write_error(f"Generate ACL input error: {ve}")
            return

        if not src_ips or not dst_ips or not ports:
            messagebox.showerror(
                "Error",
                "Enter at least one source IP, one destination IP, and one port (or range) one per line.",
            )
            self.write_error("Generate ACL: insufficient inputs")
            return

        if not self.interface_name:
            messagebox.showerror("Error", "No interface detected. Please run 'Detect Interface' first.")
            self.write_error("Generate ACL: no interface detected")
            return

        # ASA path: build commands (print only)
        if not self.platform_is_srx:
            acl_name = self.get_access_group_for_interface()
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            proto_label = (self.asa_proto.get() or "TCP").strip().lower()
            use_tcp = (proto_label == "tcp" or proto_label == "both")
            use_udp = (proto_label == "udp" or proto_label == "both")
            src_name, dst_name = (f"SRC_OBJ_{ts}", f"DST_OBJ_{ts}")
            srv_tcp_name = f"SRV_OBJ_TCP_{ts}" if use_tcp else None
            srv_udp_name = f"SRV_OBJ_UDP_{ts}" if use_udp else None
            # Build ASA ACL preview via adapter helpers (subnet-preserving)
            adapter = self.adapter
            try:
                src_hosts, src_subnets = adapter.parse_hosts_and_subnets(self.src_entry.get("1.0", "end"))
                dst_hosts, dst_subnets = adapter.parse_hosts_and_subnets(self.dst_entry.get("1.0", "end"))
            except ValueError as ve:
                messagebox.showerror("Error", str(ve))
                self.write_error(f"Generate ACL input error (ASA): {ve}")
                return

            if (not src_hosts and not src_subnets) or (not dst_hosts and not dst_subnets) or not ports:
                messagebox.showerror("Error", "Enter at least one source (host/CIDR), one destination (host/CIDR), and one port (or range).")
                self.write_error("Generate ACL: insufficient inputs")
                return

            lines = []
            lines += adapter.build_network_object_group(src_name, src_hosts, src_subnets)
            lines += adapter.build_network_object_group(dst_name, dst_hosts, dst_subnets)

            if use_tcp:
                lines += adapter.build_service_object_group(srv_tcp_name, ports, "tcp")
                lines.append(
                    f"access-list {acl_name} line 20 extended permit tcp object-group {src_name} object-group {dst_name} object-group {srv_tcp_name}"
                )
            if use_udp:
                lines += adapter.build_service_object_group(srv_udp_name, ports, "udp")
                lines.append(
                    f"access-list {acl_name} line 21 extended permit udp object-group {src_name} object-group {dst_name} object-group {srv_udp_name}"
                )

            self.acl_commands = "\n".join(lines)
            write_text(self.run_dir, "acl_commands.txt", self.acl_commands)
            try:
                self.global_logger.info("ACL commands written to report")
            except Exception:
                pass
            self.output.insert(tk.END, "[ACL COMMANDS - ASA]\n", "found")
            self.output.insert(tk.END, self.acl_commands + "\n")
            self.output.see(tk.END)
            return

        # SRX: read-only policy snippet
        try:
            adapter = self.adapter
            from_zone, to_zone = adapter.zones_for_flow(self.interface_name, dst_ips[0])
        except Exception:
            from_zone, to_zone = None, None
        if not from_zone or not to_zone:
            messagebox.showwarning("SRX Policy", "Could not resolve from/to zones. Generate policy skipped.")
            self.output.insert(tk.END, "[SRX POLICY] Skipped (zones not known)\n", "missing")
            return
        proto_label = (self.asa_proto.get() or "TCP").strip().lower()
        srx_policy = self._build_srx_policy_commands(from_zone, to_zone, src_ips, dst_ips, ports, proto_label)
        srx_policy_wrapped = _wrap_srx_set_commands(srx_policy)
        preview = "\n".join((srx_policy_wrapped or srx_policy).splitlines()[:12])
        self.output.insert(tk.END, "[SRX POLICY] Preview:\n", "found")
        self.output.insert(tk.END, preview + ("\n...\n" if len((srx_policy_wrapped or srx_policy).splitlines()) > 12 else "\n"), "found")
        if srx_policy_wrapped:
            self.output.insert(tk.END, '\n[SRX POLICY - COPY/PASTE BLOCK]\n', 'found')
            self.output.insert(tk.END, srx_policy_wrapped + '\n', 'found')
        self.output.see(tk.END)
        write_text(self.run_dir, "srx_acl_commands.txt", srx_policy_wrapped or srx_policy)
        try:
            self.global_logger.info("SRX policy (read-only) written to report")
        except Exception:
            pass
        self.safe_update_status("SRX policy snippet generated (read-only)", "green")

    # ------------------------------ Final submission ------------------------------
    def final_submission(self):
        self.set_controls_enabled(False)
        self.safe_update_status("Final submission in progress...", "orange", True)
        self.start_run("final_submission")
        try:
            row = self._selected_row()
            if not row:
                self.safe_update_status("No firewall selected", "red")
                return
            if not self.connection or not self.adapter:
                if not self.connect_to_firewall():
                    self.safe_update_status("Connection failed", "red")
                    return

            # --- Palo Alto push + commit + single verification ---
            if self.platform_is_palo and self.adapter:
                try:
                    src_ips = _parse_ip_list(self.src_entry.get("1.0", "end"))
                    dst_ips = _parse_ip_list(self.dst_entry.get("1.0", "end"))
                    ports = _parse_ports(self.port_entry.get("1.0", "end"))
                except ValueError as ve:
                    self.safe_update_status("Invalid input", "red")
                    self.log_output(str(ve))
                    self.write_error(f"Final submission input error (Palo): {ve}")
                    return
                if not self.interface_name:
                    self.safe_update_status("Interface not detected. Please run 'Detect Interface' first.", "red")
                    return
                if not src_ips or not dst_ips or not ports:
                    self.safe_update_status("Nothing to push (empty lists)", "red")
                    return
                # zones (best-effort)
                try:
                    from_zone, to_zone = self.adapter.zones_for_flow(self.interface_name, dst_ips[0])
                except Exception:
                    from_zone, to_zone = None, None
                if not from_zone or not to_zone:
                    self.output.insert(tk.END, "[PA] Zones unknown; using 'any' (rule scope may be broad)\n", "missing")
                    from_zone = from_zone or "any"
                    to_zone = to_zone or "any"
                proto_label = (self.asa_proto.get() or "TCP").strip().lower()
                service_protocol = "both" if proto_label == "both" else ("udp" if proto_label == "udp" else "tcp")
                # push + commit
                try:
                    res = self.adapter.push_policy(
                        src_ips, dst_ips, ports, from_zone, to_zone,
                        vsys=getattr(self.adapter, "current_context_hint", lambda: None)(),
                        move_rule="top",
                        do_commit=True,
                        service_protocol=service_protocol
                    )
                except Exception as e:
                    self.safe_update_status("Push failed", "red")
                    self.log_output(f"[PA] Push error: {e}")
                    self.write_error(f"PA push error: {e}")
                    return
                # logs
                self.output.insert(tk.END, "[PA push output]\n", "found")
                self.output.insert(tk.END, (res.get("config") or "") + "\n", "found")
                if res.get("move"):
                    self.output.insert(tk.END, "[PA move]\n" + res["move"] + "\n", "found")
                self.output.insert(tk.END, "[PA commit]\n" + (res.get("commit") or "") + "\n", "found")
                # single policy-match verification
                test_src, test_dst = src_ips[0], dst_ips[0]
                test_port = _first_representative_port(ports)
                proto_for_test = 'udp' if proto_label == 'udp' else 'tcp'
                out = self.adapter.packet_tracer(
                    self.interface_name, proto_for_test, test_src, 12345, test_dst, test_port, timeout=120
                )
                self.output.insert(tk.END, "Verification: Policy Match Output (single test):\n", "found")
                self.output.insert(tk.END, out + "\n")
                ok = getattr(self.adapter, "summarize_verdict", lambda x: False)(out)
                self.safe_update_status("ACL pushed and verified (PA)" if ok else "Verification failed (PA)", "green" if ok else "red")
                append_csv(
                    self.run_dir,
                    "results.csv",
                    headers=["timestamp","action","context","src_ip","dst_ip","iface","protocol","from_zone","to_zone","pt_verdict"],
                    row={
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "action": "final_submission",
                        "context": self.context_name,
                        "src_ip": test_src,
                        "dst_ip": test_dst,
                        "iface": self.interface_name,
                        "protocol": proto_for_test,
                        "from_zone": from_zone,
                        "to_zone": to_zone,
                        "pt_verdict": "allow" if ok else "deny/unk"
                    }
                )
                return

            # --- SRX branch ---
            if self.platform_is_srx:
                try:
                    src_ips = _parse_ip_list(self.src_entry.get("1.0", "end"))
                    dst_ips = _parse_ip_list(self.dst_entry.get("1.0", "end"))
                    ports = _parse_ports(self.port_entry.get("1.0", "end"))
                except ValueError as ve:
                    self.safe_update_status("Invalid input", "red")
                    self.log_output(str(ve))
                    self.write_error(f"Final submission input error: {ve}")
                    return
                if not self.interface_name:
                    self.safe_update_status("Interface not detected. Please run 'Detect Interface' first.", "red")
                    return
                if not src_ips or not dst_ips or not ports:
                    self.safe_update_status("Nothing to verify (empty lists)", "red")
                    return
                test_src, test_dst = src_ips[0], dst_ips[0]
                test_port = _first_representative_port(ports)
                proto_label = (self.asa_proto.get() or "TCP").strip().lower()
                proto_for_test = 'udp' if proto_label == 'udp' else 'tcp'  # if 'both', test tcp
                adapter = self.adapter
                # SRX zones for command print
                try:
                    from_zone, to_zone = adapter.zones_for_flow(self.interface_name, test_dst)
                except Exception:
                    from_zone, to_zone = None, None
                # 1) Print SRX command
                proto_norm = 'udp' if proto_for_test == 'udp' else 'tcp'
                if from_zone and to_zone:
                    lsys = getattr(adapter, "logical_system", None)
                    if lsys:
                        cmd_str = (
                            f"show security match-policies logical-system {lsys} "
                            f"from-zone {from_zone} to-zone {to_zone} "
                            f"source-ip {test_src} destination-ip {test_dst} "
                            f"source-port 12345 destination-port {test_port} "
                            f"protocol {proto_norm}"
                        )
                    else:
                        cmd_str = (
                            f"show security match-policies "
                            f"from-zone {from_zone} to-zone {to_zone} "
                            f"source-ip {test_src} destination-ip {test_dst} "
                            f"source-port 12345 destination-port {test_port} "
                            f"protocol {proto_norm}"
                        )
                else:
                    cmd_str = (
                        f"show security match-policies global "
                        f"source-ip {test_src} destination-ip {test_dst} "
                        f"source-port 12345 destination-port {test_port} "
                        f"protocol {proto_norm}"
                    )
                self.output.insert(tk.END, f"[SRX CMD] {cmd_str}\n", 'found')
                self.output.see(tk.END)
                # 2) SRX policy snippet
                if from_zone and to_zone:
                    srx_policy = self._build_srx_policy_commands(from_zone, to_zone, src_ips, dst_ips, ports, proto_label)
                    preview = "\n".join(srx_policy.splitlines()[:8])
                    self.output.insert(tk.END, "[SRX POLICY] Preview:\n", "found")
                    self.output.insert(tk.END, preview + ("\n...\n" if len(srx_policy.splitlines()) > 8 else "\n"), "found")
                    write_text(self.run_dir, "srx_acl_commands.txt", srx_policy)
                # 3) Run SRX policy match (verification)
                try:
                    pt_output = adapter.packet_tracer(
                        self.interface_name, proto_for_test, test_src, 12345, test_dst, test_port, timeout=120
                    )
                except Exception as e:
                    pt_output = f"[ERROR] match-policies failed: {e}"
                write_text(self.run_dir, "packet_tracer.txt", pt_output)
                self.output.insert(tk.END, 'Verification: Policy Match Output (single test):\n', 'found')
                self.output.insert(tk.END, (pt_output or '') + '\n')
                low = (pt_output or "").lower()
                verdict_allow = ("then permit" in low) or ("action: permit" in low) or ("permit" in low)
                from_zone_str = from_zone or "N/A"
                to_zone_str = to_zone or "N/A"
                self.log_output(f"Verify zones (SRX): from={from_zone_str} to={to_zone_str}")
                if verdict_allow:
                    self.safe_update_status("Policy allows traffic (SRX)", "green")
                else:
                    self.safe_update_status("Policy does NOT show allow (SRX)", "red")
                append_csv(
                    self.run_dir,
                    "results.csv",
                    headers=["timestamp","action","context","src_ip","dst_ip","iface","protocol","from_zone","to_zone","pt_verdict"],
                    row={
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "action": "final_submission",
                        "context": self.context_name,
                        "src_ip": test_src,
                        "dst_ip": test_dst,
                        "iface": self.interface_name,
                        "protocol": proto_for_test,
                        "from_zone": from_zone_str,
                        "to_zone": to_zone_str,
                        "pt_verdict": "allow" if verdict_allow else "deny/unk"
                    }
                )
                try:
                    self.output.insert(tk.END, f"Verify zones (SRX): from={from_zone_str} to={to_zone_str}\n", 'found')
                    self.output.see(tk.END)
                except Exception:
                    pass
                try:
                    self.zone_from_var.set(from_zone_str)
                    self.zone_to_var.set(to_zone_str)
                except Exception:
                    pass
                return

            # --- ASA branch ---
            if self.asa_mode == "unknown":
                self.detect_mode_and_contexts()
            if self.asa_mode == "multi" and not self.context_name:
                hint = self._get_prompt_context_hint()
                if hint:
                    self.context_name = hint
                    self.ctx_var.set(hint)
                    self.log_output(f"No context selected; operating in current context: {hint}")
                else:
                    self.log_output("Warning: multi-mode detected but context not selected; proceeding in current context (unknown).")
            if not self.interface_name:
                self.safe_update_status("Interface not detected. Please run 'Detect Interface' first.", "red")
                return
            # Normalize CIDR -> single host for verification inputs
            try:
                src_ips = _parse_ip_list(self.src_entry.get("1.0", "end"))
            except ValueError:
                raw_src = (self.src_entry.get("1.0", "end") or "").strip().splitlines()
                src_norm_lines = []
                for line in raw_src:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            src_norm_lines.append(ip)
                        else:
                            src_norm_lines.append(s)
                    else:
                        src_norm_lines.append(s)
                src_ips = _parse_ip_list("\n".join(src_norm_lines))
            try:
                dst_ips = _parse_ip_list(self.dst_entry.get("1.0", "end"))
            except ValueError:
                raw_dst = (self.dst_entry.get("1.0", "end") or "").strip().splitlines()
                dst_norm_lines = []
                for line in raw_dst:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            dst_norm_lines.append(ip)
                        else:
                            dst_norm_lines.append(s)
                    else:
                        dst_norm_lines.append(s)
                dst_ips = _parse_ip_list("\n".join(dst_norm_lines))
            try:
                ports = _parse_ports(self.port_entry.get("1.0", "end"))
            except ValueError as ve:
                self.safe_update_status("Invalid input", "red")
                self.log_output(str(ve))
                self.write_error(f"Final submission input error: {ve}")
                return
            if not src_ips or not dst_ips or not ports:
                self.safe_update_status("Nothing to push (empty lists)", "red")
                return
            acl_name = self.get_access_group_for_interface()
            adapter = self.adapter
            # Build ASA object-groups via adapter (subnet-preserving)
            src_hosts, src_subnets = adapter.parse_hosts_and_subnets(self.src_entry.get("1.0", "end"))
            dst_hosts, dst_subnets = adapter.parse_hosts_and_subnets(self.dst_entry.get("1.0", "end"))
            if (not src_hosts and not src_subnets) or (not dst_hosts and not dst_subnets):
                self.safe_update_status("Nothing to push (empty lists)", "red")
                return
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            proto_label = (self.asa_proto.get() or "TCP").strip().lower()
            use_tcp = (proto_label == "tcp" or proto_label == "both")
            use_udp = (proto_label == "udp" or proto_label == "both")
            src_name, dst_name = (f"SRC_OBJ_{ts}", f"DST_OBJ_{ts}")
            srv_tcp_name = f"SRV_OBJ_TCP_{ts}" if use_tcp else None
            srv_udp_name = f"SRV_OBJ_UDP_{ts}" if use_udp else None
            # push SRC/DST groups
            src_cfg = adapter.build_network_object_group(src_name, src_hosts, src_subnets)
            out1 = self.connection.send_config_set(src_cfg, cmd_verify=False)
            self.log_output("SRC object-group output:\n" + out1)
            dst_cfg = adapter.build_network_object_group(dst_name, dst_hosts, dst_subnets)
            out2 = self.connection.send_config_set(dst_cfg, cmd_verify=False)
            self.log_output("DST object-group output:\n" + out2)
            if use_tcp:
                srv_tcp_cfg = adapter.build_service_object_group(srv_tcp_name, ports, 'tcp')
                out3t = self.connection.send_config_set(srv_tcp_cfg, cmd_verify=False)
                self.log_output("SRV TCP object-group output:\n" + out3t)
            if use_udp:
                srv_udp_cfg = adapter.build_service_object_group(srv_udp_name, ports, 'udp')
                out3u = self.connection.send_config_set(srv_udp_cfg, cmd_verify=False)
                self.log_output("SRV UDP object-group output:\n" + out3u)

            # ACL add
            acl_cfg = []
            if use_tcp:
                acl_cfg.append(
                    f"access-list {acl_name} line 20 extended permit tcp "
                    f"object-group {src_name} object-group {dst_name} object-group {srv_tcp_name}"
                )
            if use_udp:
                acl_cfg.append(
                    f"access-list {acl_name} line 21 extended permit udp "
                    f"object-group {src_name} object-group {dst_name} object-group {srv_udp_name}"
                )
            self.connection.send_config_set(acl_cfg, cmd_verify=False)
            # single PT verification
            test_src = adapter.pick_test_ip(src_hosts, src_subnets)
            test_dst = adapter.pick_test_ip(dst_hosts, dst_subnets)
            test_port = _first_representative_port(ports)
            proto_for_test = 'udp' if proto_label == 'udp' else 'tcp'
            try:
                # Defensive normalization in case CIDR slipped through
                try:
                    test_src_norm = self.adapter._pick_representative_ip(test_src) or test_src
                except Exception:
                    test_src_norm = test_src
                try:
                    test_dst_norm = self.adapter._pick_representative_ip(test_dst) or test_dst
                except Exception:
                    test_dst_norm = test_dst
                pt_output = self.adapter.packet_tracer(
                    self.interface_name, proto_for_test, test_src_norm, 12345, test_dst_norm, test_port, timeout=120
                )
            except Exception as e:
                pt_output = f"[ERROR] packet-tracer failed: {e}"
            write_text(self.run_dir, "packet_tracer.txt", pt_output)
            self.output.insert(tk.END, 'Verification: Packet-Tracer Output (single test):\n', 'found')
            self.output.insert(tk.END, (pt_output or '') + '\n')
            low = (pt_output or "").lower()
            verdict_allow = ("result:" in low and "result: allow" in low)
            if verdict_allow:
                self.safe_update_status("ACL pushed and verified", "green")
            else:
                self.safe_update_status("Verification failed", "red")
            append_csv(
                self.run_dir,
                "results.csv",
                headers=["timestamp","action","context","src_ip","dst_ip","iface","protocol","pt_verdict"],
                row={
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "action": "final_submission",
                    "context": self.context_name,
                    "src_ip": test_src,
                    "dst_ip": test_dst,
                    "iface": self.interface_name,
                    "protocol": proto_for_test,
                    "pt_verdict": "allow" if verdict_allow else "deny/unk"
                }
            )
            self.output.see(tk.END)
        except Exception as e:
            self.log_output(f"Final submission error: {e}")
            try:
                self.global_logger.exception("Final submission error")
            except Exception:
                pass
            self.safe_update_status("Final submission failed", "red")
            self.write_error(f"Final submission error: {e}")
        finally:
            self.progress.stop()
            self.set_controls_enabled(True)

    # ------------------------------ Connectivity / status / inline ------------------------------
    def check_connectivity(self):
        self.safe_update_status("Running packet tracer...", "orange", True)
        self.start_run("check_connectivity")
        row = self._selected_row()
        if not row or not self.connection or not self.adapter or not self.interface_name:
            self.safe_update_status("Interface not detected", "red")
            self.progress.stop()
            return
        try:
            # Parse hosts/CIDR. For SRX we allow CIDR directly; adapter will normalize for PT.
            try:
                if self.platform_is_srx:
                    src_ips = _parse_ip_or_cidr_list(self.src_entry.get("1.0", "end"))
                else:
                    src_ips = _parse_ip_list(self.src_entry.get("1.0", "end"))
            except ValueError:
                raw_src = (self.src_entry.get("1.0", "end") or "").strip().splitlines()
                src_norm_lines = []
                for line in raw_src:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            src_norm_lines.append(ip)
                        else:
                            src_norm_lines.append(s)
                    else:
                        src_norm_lines.append(s)
                src_ips = _parse_ip_list("\n".join(src_norm_lines))
            try:
                if self.platform_is_srx:
                    dst_ips = _parse_ip_or_cidr_list(self.dst_entry.get("1.0", "end"))
                else:
                    dst_ips = _parse_ip_list(self.dst_entry.get("1.0", "end"))
            except ValueError:
                raw_dst = (self.dst_entry.get("1.0", "end") or "").strip().splitlines()
                dst_norm_lines = []
                for line in raw_dst:
                    s = line.strip()
                    if not s:
                        continue
                    if "/" in s and hasattr(self.adapter, "_pick_representative_ip"):
                        ip = self.adapter._pick_representative_ip(s)
                        if ip:
                            dst_norm_lines.append(ip)
                        else:
                            dst_norm_lines.append(s)
                    else:
                        dst_norm_lines.append(s)
                dst_ips = _parse_ip_list("\n".join(dst_norm_lines))
            ports = _parse_ports(self.port_entry.get("1.0", "end"))
            if not src_ips or not dst_ips or not ports:
                self.safe_update_status("Insufficient inputs", "red")
                return
            test_src = src_ips[0]
            test_dst = dst_ips[0]
            test_port = _first_representative_port(ports)
            proto_label = (self.asa_proto.get() or "TCP").strip().lower()
            proto_for_test = 'udp' if proto_label == 'udp' else 'tcp'
            adapter = self.adapter
            # SRX: compute zones & build command preview (print only for SRX)
            try:
                from_zone, to_zone = adapter.zones_for_flow(self.interface_name, test_dst)
            except Exception:
                from_zone, to_zone = None, None
            proto_norm = 'udp' if proto_for_test == 'udp' else 'tcp'
            if self.platform_is_srx:
                if from_zone and to_zone:
                    lsys = getattr(adapter, "logical_system", None)
                    if lsys:
                        cmd_str = (
                            f"show security match-policies logical-system {lsys} "
                            f"from-zone {from_zone} to-zone {to_zone} "
                            f"source-ip {test_src} destination-ip {test_dst} "
                            f"source-port 12345 destination-port {test_port} "
                            f"protocol {proto_norm}"
                        )
                    else:
                        cmd_str = (
                            f"show security match-policies "
                            f"from-zone {from_zone} to-zone {to_zone} "
                            f"source-ip {test_src} destination-ip {test_dst} "
                            f"source-port 12345 destination-port {test_port} "
                            f"protocol {proto_norm}"
                        )
                else:
                    cmd_str = (
                        f"show security match-policies global "
                        f"source-ip {test_src} destination-ip {test_dst} "
                        f"source-port 12345 destination-port {test_port} "
                        f"protocol {proto_norm}"
                    )
                self.output.insert(tk.END, f"[SRX CMD] {cmd_str}\n", 'found')
                self.output.see(tk.END)
            # Run packet-tracer / policy match (single test)
            try:
                # Defensive normalization for PT
                try:
                    test_src_norm = adapter._pick_representative_ip(test_src) or test_src
                except Exception:
                    test_src_norm = test_src
                try:
                    test_dst_norm = adapter._pick_representative_ip(test_dst) or test_dst
                except Exception:
                    test_dst_norm = test_dst
                output = adapter.packet_tracer(
                    self.interface_name, proto_for_test, test_src_norm, 12345, test_dst_norm, test_port, timeout=120
                )
            except Exception as e:
                output = f"[ERROR] packet-tracer/match-policies failed: {e}"
            self.log_output(f"Packet tracer / policy match (single test) result:\n{output}")
            write_text(self.run_dir, "packet_tracer.txt", output)
            self.safe_update_status("Packet tracer completed", "green")
        except ValueError as ve:
            self.safe_update_status("Invalid input", "red")
            self.log_output(str(ve))
            self.write_error(f"Connectivity input error: {ve}")
        finally:
            self.progress.stop()

    def inline_check(self):
        self.safe_update_status("Inline check in progress...", "orange", True)
        self.start_run("inline_check")
        try:
            row = self._selected_row()
            if not row or not self.connection or not self.adapter:
                self.safe_update_status("Not connected", "red")
                self.log_output("Not connected to firewall.")
                self.write_error("Inline check: not connected")
                return
            src_iface = self.interface_name
            if not src_iface:
                self.safe_update_status("Source interface not known", "red")
                self.log_output("Inline check requires the source interface (run 'Detect Interface' first).")
                self.write_error("Inline check: no source interface")
                return
            src_ips = _parse_ip_list(self.src_entry.get("1.0", "end"))
            dst_ips = _parse_ip_list(self.dst_entry.get("1.0", "end"))
            if not src_ips or not dst_ips:
                self.safe_update_status("Insufficient inputs", "red")
                return
            adapter = self.adapter
            dst_iface = adapter.route_out_interface(dst_ips[0])
            self.log_output(
                f"Inline check routes: src {src_ips[0]} -> {src_iface or 'N/A'}, "
                f"dst {dst_ips[0]} -> {dst_iface or 'N/A'}"
            )
            try:
                self.zone_from_var.set("N/A")
                self.zone_to_var.set("N/A")
            except Exception:
                pass
            from_zone, to_zone = None, None
            try:
                if hasattr(adapter, 'zones_for_flow'):
                    from_zone, to_zone = adapter.zones_for_flow(src_iface, dst_ips[0])
            except Exception as e:
                self.log_output(f"[WARN] Inline zone lookup failed: {e}")
            from_zone_str = from_zone or "N/A"
            to_zone_str = to_zone or "N/A"
            self.log_output(f"Inline zones ({'SRX' if self.platform_is_srx else ('Palo' if self.platform_is_palo else 'ASA')}): from={from_zone_str} to={to_zone_str}")
            write_json(self.run_dir, "inline_check.json", {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "context": self.context_name,
                "src_ip": src_ips[0],
                "dst_ip": dst_ips[0],
                "src_if": src_iface,
                "dst_if": dst_iface,
                "from_zone": from_zone_str,
                "to_zone": to_zone_str,
            })
            append_csv(
                self.run_dir,
                "results.csv",
                headers=["timestamp","action","context","src_ip","dst_ip","src_if","dst_if","from_zone","to_zone","status"],
                row={
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "action": "inline_check",
                    "context": self.context_name,
                    "src_ip": src_ips[0],
                    "dst_ip": dst_ips[0],
                    "src_if": src_iface,
                    "dst_if": dst_iface,
                    "from_zone": from_zone_str,
                    "to_zone": to_zone_str,
                    "status": "ok" if (src_iface and dst_iface and (src_iface == dst_iface)) else "unknown"
                }
            )
            if src_iface and dst_iface and (src_iface == dst_iface):
                self.output.insert(tk.END, "Firewall not inline no firewall rule required\n", "found")
                self.safe_update_status("Firewall not inline no rule required", "green")
            else:
                self.output.insert(
                    tk.END,
                    "Inline check: Interfaces differ or not found firewall may be inline\n",
                    "missing",
                )
                self.safe_update_status("Inline check completed", "green")
            try:
                self.zone_from_var.set(from_zone_str)
                self.zone_to_var.set(to_zone_str)
            except Exception:
                pass
        except Exception as e:
            self.log_output(f"[ERROR] Inline check exception: {e}")
            try:
                self.global_logger.exception("Inline check error")
            except Exception:
                pass
            self.safe_update_status("Inline check failed", "red")
            self.write_error(f"Inline check error: {e}")
        finally:
            self.progress.stop()

    def check_status(self):
        self.safe_update_status("Checking firewall status...", "orange", True)
        self.start_run("check_status")
        try:
            row = self._selected_row()
            if not row or not self.connection or not self.adapter:
                self.safe_update_status("Not connected", "red")
                self.progress.stop()
                self.log_output("Not connected to firewall.")
                self.write_error("Status: not connected")
                return
            text, color = self.adapter.check_status()
            write_text(self.run_dir, "status.txt", text)
            self.safe_update_status(text, color)
        except Exception as e:
            self.log_output(f"Status check failed: {e}")
            try:
                self.global_logger.exception("Status check error")
            except Exception:
                pass
            self.safe_update_status("Status check failed", "red")
            self.write_error(f"Status check error: {e}")
        finally:
            self.progress.stop()

    # ------------------------------ NEW: NEUTRAL CAPTURE HANDLERS ------------------------------
    def _on_start_capture(self):
        """
        Neutral Start Capture:
        - Calls adapter.start_capture(...) if available.
        - Uses src/dst IP from GUI, protocol from existing proto combobox, ports from Ports tab.
        - Defaults: proto=tcp, src_port=12345, dst_port=<first port or None>, stages=['firewall'].
        """
        try:
            if not hasattr(self.adapter, "start_capture"):
                self._append("[CAPTURE] Current adapter does not support start_capture() yet.\n")
                messagebox.showinfo("Traffic Capture", "Start capture is not available for this platform yet.")
                return
            # Gather inputs
            src_ip = None
            dst_ip = None
            try:
                src_list = _parse_ip_list(self.src_entry.get("1.0", "end"))
                if src_list: src_ip = src_list[0]
            except Exception:
                pass
            try:
                dst_list = _parse_ip_list(self.dst_entry.get("1.0", "end"))
                if dst_list: dst_ip = dst_list[0]
            except Exception:
                pass
            proto = (self.asa_proto.get() or "TCP").strip().lower()
            proto = "udp" if proto == "udp" else "tcp"  # if 'both', default to tcp
            # Ports
            dst_port = None
            try:
                ports = _parse_ports(self.port_entry.get("1.0", "end"))
                if ports:
                    dst_port = _first_representative_port(ports)
            except Exception:
                pass
            src_port = 12345
            stages = ["firewall"]  # lightweight default
            self._append(f"[CAPTURE] Starting: src={src_ip or '(any)'} dst={dst_ip or '(any)'} "
                         f"proto={proto} sport={src_port or 'any'} dport={dst_port or 'any'} stages={stages}\n")
            out = self.adapter.start_capture(
                src_ip=src_ip, dst_ip=dst_ip, proto=proto,
                src_port=src_port, dst_port=dst_port, stages=stages
            )
            self._append("[CAPTURE START OUTPUT]\n" + (out or "") + "\n")
            self.safe_update_status("Traffic capture started", "green")
        except Exception as e:
            self._append(f"[ERROR] start_capture failed: {e}\n")
            self.write_error(f"Start capture failed: {e}")
            messagebox.showerror("Traffic Capture", f"Start capture failed: {e}")

    def _on_stop_capture(self):
        """
        Neutral Stop Capture:
        - Calls adapter.stop_capture() if available.
        - Clears filters if adapter implements clear_capture_filters().
        """
        try:
            if not hasattr(self.adapter, "stop_capture"):
                self._append("[CAPTURE] Current adapter does not support stop_capture() yet.\n")
                messagebox.showinfo("Traffic Capture", "Stop capture is not available for this platform yet.")
                return
            self._append("[CAPTURE] Stopping capture...\n")
            out = self.adapter.stop_capture()
            self._append("[CAPTURE STOP OUTPUT]\n" + (out or "") + "\n")
            if hasattr(self.adapter, "clear_capture_filters"):
                clr = self.adapter.clear_capture_filters()
                self._append("[CAPTURE CLEAR OUTPUT]\n" + (clr or "") + "\n")
            else:
                self._append("[CAPTURE] Adapter has no clear_capture_filters(); skipped.\n")
            self.safe_update_status("Traffic capture stopped", "green")
        except Exception as e:
            self._append(f"[ERROR] stop_capture failed: {e}\n")
            self.write_error(f"Stop capture failed: {e}")
            messagebox.showerror("Traffic Capture", f"Stop capture failed: {e}")

    # ------------------------------ Thread wrappers ------------------------------
    def _run_in_thread(self, target, before=None, after=None, btn=None):
        def worker():
            try:
                target()
            finally:
                if after:
                    try:
                        self.root.after(0, after)
                    except Exception:
                        pass
                if btn:
                    try:
                        self.root.after(0, lambda: btn.configure(state="normal"))
                    except Exception:
                        pass
                try:
                    self.root.after(0, self.progress.stop)
                except Exception:
                    pass
        if before:
            try:
                before()
            except Exception:
                pass
        try:
            if btn:
                btn.configure(state="disabled")
        except Exception:
            pass
        threading.Thread(target=worker, daemon=True).start()

    def test_connection_thread(self):
        self._run_in_thread(
            target=self.test_connection,
            before=lambda: self.safe_update_status("Testing connection...", "orange", True),
            btn=self.test_btn
        )

    def disconnect_thread(self):
        self._run_in_thread(
            target=self.disconnect_firewall,
            before=lambda: self.safe_update_status("Disconnecting...", "orange", True),
            btn=self.disconnect_btn
        )

    def detect_mode_and_contexts_thread(self):
        self._run_in_thread(
            target=self.detect_mode_and_contexts,
            before=lambda: self.safe_update_status("Detecting mode/contexts...", "orange", True),
            btn=self.detect_ctx_btn
        )

    def detect_interface_thread(self):
        self._run_in_thread(
            target=self.detect_interface,
            before=lambda: self.safe_update_status("Detecting interface...", "orange", True),
            btn=self.interface_btn
        )

    def inline_check_thread(self):
        self._run_in_thread(
            target=self.inline_check,
            before=lambda: self.safe_update_status("Running inline check...", "orange", True),
            btn=self.inline_check_btn
        )

    def check_status_thread(self):
        self._run_in_thread(
            target=self.check_status,
            before=lambda: self.safe_update_status("Checking firewall status...", "orange", True),
            btn=self.status_btn
        )

    def check_connectivity_thread(self):
        self._run_in_thread(
            target=self.check_connectivity,
            before=lambda: self.safe_update_status("Running packet tracer...", "orange", True),
            btn=self.connectivity_btn
        )

    def final_submission_thread(self):
        self._run_in_thread(
            target=self.final_submission,
            before=lambda: self.safe_update_status("Final submission in progress...", "orange", True),
            btn=self.final_btn
        )

    # NEW: neutral capture thread starters
    def start_capture_thread(self):
        self._run_in_thread(
            target=self._on_start_capture,
            before=lambda: self.safe_update_status("Starting traffic capture...", "orange", True),
            btn=self.start_cap_btn
        )

    def stop_capture_thread(self):
        self._run_in_thread(
            target=self._on_stop_capture,
            before=lambda: self.safe_update_status("Stopping traffic capture...", "orange", True),
            btn=self.stop_cap_btn
        )

    # ------------------------------ Build UI ------------------------------

    # ============================================================
    # NETWORK FLOW (Offline) - Level 1
    # ============================================================
    def _flow_arrow(self):
        return "        ↓
"

    def refresh_flow_db(self):
        # Load normalized JSON (preferred) from <reports_base>/latest/*.json
        try:
            if load_latest_json is None:
                messagebox.showwarning("Network Flow", "flow_engine package not found. Please add flow_engine folder.")
                return
            base = self.logs_base_var.get()
            try:
                self.flow_output.insert("end", f"[INFO] Loading normalized JSON from: {base}\n", "header")
                self.flow_output.see("end")
            except Exception:
                pass
            load_latest_json(base)
            try:
                self.flow_output.insert("end", "✔ Data loaded.\n\n", "header")
                self.flow_output.see("end")
            except Exception:
                pass
        except Exception as e:
            try:
                self.flow_output.insert("end", f"[ERROR] {e}\n", "deny")
                self.flow_output.see("end")
            except Exception:
                pass

    def search_flow(self):
        src = (self.flow_src_entry.get() or "").strip()
        dst = (self.flow_dst_entry.get() or "").strip()
        if not src or not dst:
            messagebox.showwarning("Flow Search", "Please enter both Source and Destination IPs.")
            return
        if find_flow is None:
            messagebox.showwarning("Network Flow", "flow_engine package not found.")
            return

        try:
            self.flow_output.insert("end", f"[FLOW] {src} → {dst}\n", "header")
            self.flow_output.see("end")
        except Exception:
            pass

        try:
            result = find_flow(src, dst)
            if result.get('error'):
                self.flow_output.insert("end", result['error'] + "\n\n", "deny")
                return

            self.flow_output.insert("end", "---- Routing Path ----\n", "header")
            path = result.get('path', [])
            last = len(path) - 1
            for i, hop in enumerate(path):
                host = hop.get('hostname','?')
                prefix = hop.get('prefix','')
                nh = hop.get('nexthop','')
                iface = hop.get('interface','')
                self.flow_output.insert("end", f"{host:20}  {prefix:18}  → {nh:15}  via {iface}\n")
                if i != last:
                    self.flow_output.insert("end", self._flow_arrow())

            self.flow_output.insert("end", "\n---- Policy (Level-1) ----\n", "header")
            acl = result.get('acl')
            if acl:
                action = (acl.get('action') or 'unknown').lower()
                tag = 'allow' if action == 'permit' else 'deny'
                self.flow_output.insert("end", f"Final Verdict: {action.upper()}\n", tag)
                if acl.get('name'):
                    self.flow_output.insert("end", f"Policy: {acl.get('name')}\n", "header")
                self.flow_output.insert("end", "Evidence (top):\n", "header")
                for ln in acl.get('evidence', []):
                    self.flow_output.insert("end", ln + "\n", tag)
            else:
                self.flow_output.insert("end", "No policy found on last firewall (unknown).\n", "deny")

            self.flow_output.insert("end", "\n")
            self.flow_output.see("end")
        except Exception as e:
            self.flow_output.insert("end", f"[ERROR] Flow search failed: {e}\n", "deny")
            self.flow_output.see("end")

    def __init__(self, root):
        self.root = root
        self.root.title("Firewall ACL Automation Tool")
        # Initial geometry
        try:
            self.root.geometry("1400x840+80+60")
        except Exception:
            pass
        self.root.minsize(1200, 740)
        # Theme
        try:
            style = ttk.Style()
            if 'vista' in style.theme_names():
                style.theme_use('vista')
            elif 'clam' in style.theme_names():
                style.theme_use('clam')
            style.configure('TLabel', padding=(0, 2))
            style.configure('TButton', padding=(8, 6))
            style.configure('TLabelframe', padding=(PAD, PAD))
            style.configure('TLabelframe.Label', padding=(6, 2))
        except Exception:
            pass
        # Paned window
        self.paned = ttk.Panedwindow(self.root, orient=tk.HORIZONTAL)
        self.paned.grid(row=0, column=0, sticky="nsew")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        left = ttk.Frame(self.paned)
        right = ttk.Frame(self.paned)
        self.paned.add(left, weight=1)
        self.paned.add(right, weight=1)
        self.root.after(100, lambda: self.paned.sashpos(0, 720))
        try:
            self.paned.paneconfigure(left, minsize=640)
        except Exception:
            pass
        # Tabs (left)
        nb = ttk.Notebook(left)
        nb.grid(row=0, column=0, sticky="nsew", padx=PAD, pady=PAD)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        self.tab_conn = ttk.Frame(nb)
        self.tab_acl = ttk.Frame(nb)
        self.tab_logs = ttk.Frame(nb)
        nb.add(self.tab_conn, text="Connection")
        nb.add(self.tab_acl, text="ACL & Actions")
        nb.add(self.tab_logs, text="Logs & Reports")

        # -- Monitor tab (neutral) --
        self.tab_monitor = ttk.Frame(nb)
        try:
            nb.insert(1, self.tab_monitor, text="Monitor")  # place after Connection
        except Exception:
            nb.add(self.tab_monitor, text="Monitor")  # fallback
        self.tab_monitor.columnconfigure(0, weight=1)
        self.tab_monitor.rowconfigure(1, weight=1)
        mon_filters = ttk.LabelFrame(self.tab_monitor, text="Traffic Monitor Filters")
        mon_filters.grid(row=0, column=0, sticky="ew", padx=PAD, pady=PAD)
        for c in range(4):
            mon_filters.columnconfigure(c, weight=1)
        ttk.Label(mon_filters, text="Source IP:").grid(row=0, column=0, sticky="w")
        self.mon_src_entry = ttk.Entry(mon_filters)
        self.mon_src_entry.grid(row=0, column=1, sticky="ew", padx=(0, PAD))
        ttk.Label(mon_filters, text="Destination IP:").grid(row=0, column=2, sticky="w")
        self.mon_dst_entry = ttk.Entry(mon_filters)
        self.mon_dst_entry.grid(row=0, column=3, sticky="ew")
        ttk.Label(mon_filters, text="Application (optional):").grid(row=1, column=0, sticky="w", pady=(6,0))
        self.mon_app_entry = ttk.Entry(mon_filters)
        self.mon_app_entry.grid(row=1, column=1, sticky="ew", padx=(0, PAD), pady=(6,0))
        ttk.Label(mon_filters, text="Interval:").grid(row=1, column=2, sticky="w", pady=(6,0))
        self.mon_interval_cb = ttk.Combobox(mon_filters, values=["2s", "5s", "10s"], state="readonly")
        self.mon_interval_cb.grid(row=1, column=3, sticky="ew", pady=(6,0))
        self.mon_interval_cb.set("5s")
        mon_btns = ttk.Frame(self.tab_monitor)
        mon_btns.grid(row=2, column=0, sticky="ew", padx=PAD, pady=(0, PAD))
        for c in range(3):  # CHANGED: 3 columns for Start/Stop/Snapshot
            mon_btns.columnconfigure(c, weight=1)
        self.mon_start_btn = ttk.Button(mon_btns, text="Start Monitor", command=self.start_monitor)
        self.mon_start_btn.grid(row=0, column=0, sticky="ew", padx=(0, PAD))
        self.mon_stop_btn = ttk.Button(mon_btns, text="Stop Monitor", command=self.stop_monitor, state="disabled")
        self.mon_stop_btn.grid(row=0, column=1, sticky="ew")
        # NEW: Neutral snapshot button (one-time)
        self.mon_snap_btn = ttk.Button(mon_btns, text="Snapshot Monitor (One-Time)", command=self.snapshot_monitor_once)
        self.mon_snap_btn.grid(row=0, column=2, sticky="ew", padx=(PAD, 0))
        mon_out_frame = ttk.LabelFrame(self.tab_monitor, text="Live Sessions")
        mon_out_frame.grid(row=1, column=0, sticky="nsew", padx=PAD, pady=(0, PAD))
        mon_out_frame.columnconfigure(0, weight=1)
        mon_out_frame.rowconfigure(0, weight=1)
        self.monitor_out = scrolledtext.ScrolledText(mon_out_frame, width=60, height=20, font=("Consolas", 10), state="disabled")
        self.monitor_out.grid(row=0, column=0, sticky="nsew", padx=(PAD//2), pady=(PAD//2))
        self.monitor_status_var = tk.StringVar(value="Idle")
        ttk.Label(mon_out_frame, textvariable=self.monitor_status_var, foreground="blue").grid(row=1, column=0, sticky="w", padx=(PAD//2))

        # ============================================================
        # NEW: NETWORK FLOW TAB (inserted AFTER MONITOR tab)
        # ============================================================
        try:
            self.tab_flow = ttk.Frame(nb)
            nb.insert(2, self.tab_flow, text="Network Flow")
        except Exception:
            self.tab_flow = ttk.Frame(nb)
            nb.add(self.tab_flow, text="Network Flow")

        self.tab_flow.columnconfigure(0, weight=1)
        self.tab_flow.rowconfigure(1, weight=1)

        flow_frame = ttk.LabelFrame(self.tab_flow, text="Offline Network Flow Lookup (JSON, Level-1)")
        flow_frame.grid(row=0, column=0, sticky="ew", padx=PAD, pady=PAD)
        for c in range(4):
            flow_frame.columnconfigure(c, weight=1)

        ttk.Label(flow_frame, text="Source IP:").grid(row=0, column=0, sticky="w")
        self.flow_src_entry = ttk.Entry(flow_frame)
        self.flow_src_entry.grid(row=0, column=1, sticky="ew", padx=(0, PAD))

        ttk.Label(flow_frame, text="Destination IP:").grid(row=0, column=2, sticky="w")
        self.flow_dst_entry = ttk.Entry(flow_frame)
        self.flow_dst_entry.grid(row=0, column=3, sticky="ew")

        self.flow_refresh_btn = ttk.Button(flow_frame, text="Refresh Collector Data", command=self.refresh_flow_db)
        self.flow_refresh_btn.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(PAD, 0))

        self.flow_search_btn = ttk.Button(flow_frame, text="Search Flow", command=self.search_flow)
        self.flow_search_btn.grid(row=1, column=2, columnspan=2, sticky="ew", pady=(PAD, 0))

        flow_out = ttk.LabelFrame(self.tab_flow, text="Flow Result")
        flow_out.grid(row=1, column=0, sticky="nsew", padx=PAD, pady=(0, PAD))
        flow_out.columnconfigure(0, weight=1)
        flow_out.rowconfigure(0, weight=1)

        self.flow_output = scrolledtext.ScrolledText(flow_out, width=90, height=20, font=("Consolas", 10))
        self.flow_output.grid(row=0, column=0, sticky="nsew")
        self.flow_output.tag_config('allow', foreground='blue')
        self.flow_output.tag_config('deny', foreground='red')
        self.flow_output.tag_config('header', foreground='green')

        self.root.after(250, lambda: nb.select(self.tab_acl))

        # Connection Tab
        conn_sel = ttk.LabelFrame(self.tab_conn, text="Firewall Selection")
        conn_sel.grid(row=0, column=0, sticky="ew", padx=PAD, pady=(PAD, PAD))
        for c in range(3):
            conn_sel.columnconfigure(c, weight=1)
        ttk.Label(conn_sel, text="Firewall:").grid(row=0, column=0, sticky="w", padx=(0, PAD), pady=(0, 4))
        self.firewall_data = read_firewall_data()
        if not self.firewall_data:
            messagebox.showwarning("Warning", "No firewall data found.")
        self.all_fw = list(self.firewall_data)
        self._rebuild_fw_index()
        self.ip_dropdown = ttk.ComboBox = ttk.Combobox(conn_sel, values=[r['display'] for r in self.all_fw], state="readonly")
        self.ip_dropdown.grid(row=0, column=1, sticky="ew", pady=(0, 4))
        self.pick_btn = ttk.Button(conn_sel, text="Pick...", command=self.open_fw_picker)
        self.pick_btn.grid(row=0, column=2, sticky="ew", padx=(PAD, 0), pady=(0, 4))
        ttk.Label(conn_sel, text="Filter (host/platform/IP):").grid(row=1, column=0, sticky="w", padx=(0, PAD))
        self.fw_filter = ttk.Entry(conn_sel)
        self.fw_filter.grid(row=1, column=1, columnspan=2, sticky="ew", pady=(0, 4))
        self.fw_filter.bind("<KeyRelease>", self._filter_firewalls)
        ttk.Label(conn_sel, text="Platform:").grid(row=2, column=0, sticky="w", padx=(0, PAD))
        platforms = sorted({self._extract_platform(r['display']) for r in self.all_fw if self._extract_platform(r['display'])})
        self.platform_filter = ttk.Combobox(conn_sel, values=(['All'] + platforms), state="readonly")
        self.platform_filter.grid(row=2, column=1, sticky="ew", pady=(0, 4))
        self.platform_filter.set("All")
        self.platform_filter.bind("<<ComboboxSelected>>", self._filter_firewalls)

        # Credentials & Connection
        cred = ttk.LabelFrame(self.tab_conn, text="Credentials & Connection")
        cred.grid(row=1, column=0, sticky="ew", padx=PAD, pady=(0, PAD))
        cred.columnconfigure(1, weight=1)
        ttk.Label(cred, text="Username:").grid(row=0, column=0, sticky="w", padx=(0, PAD))
        self.user_entry = ttk.Entry(cred); self.user_entry.grid(row=0, column=1, sticky="ew", pady=(0, 4))
        ttk.Label(cred, text="Password:").grid(row=1, column=0, sticky="w", padx=(0, PAD))
        self.pass_entry = ttk.Entry(cred, show="*"); self.pass_entry.grid(row=1, column=1, sticky="ew", pady=(0, 4))
        ttk.Label(cred, text="Enable Secret:").grid(row=2, column=0, sticky="w", padx=(0, PAD))
        self.enable_entry = ttk.Entry(cred, show="*"); self.enable_entry.grid(row=2, column=1, sticky="ew", pady=(0, 4))
        conn_btns = ttk.Frame(cred)
        conn_btns.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(PAD, 0))
        for c in range(3):
            conn_btns.columnconfigure(c, weight=1)
        self.test_btn = ttk.Button(conn_btns, text="Test Connection", command=self.test_connection_thread)
        self.test_btn.grid(row=0, column=0, sticky="ew", padx=(0, PAD))
        self.refresh_btn = ttk.Button(conn_btns, text="Refresh List", command=self.refresh_firewall_list)
        self.refresh_btn.grid(row=0, column=1, sticky="ew", padx=(0, PAD))
        self.disconnect_btn = ttk.Button(conn_btns, text="Disconnect", command=self.disconnect_thread, state="disabled")
        self.disconnect_btn.grid(row=0, column=2, sticky="ew")

        # Mode & Context
        ctx_box = ttk.LabelFrame(self.tab_conn, text="Mode & Context")
        ctx_box.grid(row=2, column=0, sticky="ew", padx=PAD, pady=(0, PAD))
        for c in range(3):
            ctx_box.columnconfigure(c, weight=1)
        ttk.Label(ctx_box, text="Mode:").grid(row=0, column=0, sticky="w")
        self.mode_var = tk.StringVar(value="Unknown")
        ttk.Label(ctx_box, textvariable=self.mode_var, foreground="blue").grid(row=0, column=1, sticky="w")
        ttk.Label(ctx_box, text="Current Context:").grid(row=1, column=0, sticky="w")
        self.ctx_var = tk.StringVar(value="-")
        ttk.Label(ctx_box, textvariable=self.ctx_var, foreground="blue").grid(row=1, column=1, sticky="w")
        self.detect_ctx_btn = ttk.Button(
            ctx_box, text="Detect Mode / List Contexts",
            command=self.detect_mode_and_contexts_thread, state="disabled"
        )
        self.detect_ctx_btn.grid(row=2, column=0, sticky="ew", padx=(0, PAD), pady=(PAD, 0))
        self.select_ctx_btn = ttk.Button(
            ctx_box, text="Select Context",
            command=self.open_context_picker, state="disabled"
        )
        self.select_ctx_btn.grid(row=2, column=1, sticky="ew", pady=(PAD, 0))

        # ACL & Actions Tab
        self.tab_acl.columnconfigure(0, weight=1)
        self.tab_acl.rowconfigure(0, weight=1)
        self.tab_acl.rowconfigure(1, weight=0)
        acl_frame = ttk.LabelFrame(self.tab_acl, text="ACL Inputs")
        acl_frame.grid(row=0, column=0, sticky="nsew", padx=PAD, pady=PAD)
        acl_frame.columnconfigure(0, weight=1)
        acl_frame.rowconfigure(0, weight=1)
        inputs_nb = ttk.Notebook(acl_frame)
        inputs_nb.grid(row=0, column=0, sticky="nsew")
        src_tab = ttk.Frame(inputs_nb); src_tab.columnconfigure(0, weight=1); src_tab.rowconfigure(0, weight=1)
        dst_tab = ttk.Frame(inputs_nb); dst_tab.columnconfigure(0, weight=1); dst_tab.rowconfigure(0, weight=1)
        ports_tab = ttk.Frame(inputs_nb); ports_tab.columnconfigure(0, weight=1); ports_tab.rowconfigure(0, weight=1)
        inputs_nb.add(src_tab, text="Source IPs")
        inputs_nb.add(dst_tab, text="Destination IPs")
        inputs_nb.add(ports_tab, text="Ports")
        self.src_entry = scrolledtext.ScrolledText(src_tab, width=36, height=8, font=("Consolas", 10))
        self.src_entry.grid(row=0, column=0, sticky="nsew", padx=(PAD//2), pady=(PAD//2))
        self.dst_entry = scrolledtext.ScrolledText(dst_tab, width=36, height=8, font=("Consolas", 10))
        self.dst_entry.grid(row=0, column=0, sticky="nsew", padx=(PAD//2), pady=(PAD//2))
        self.port_entry = scrolledtext.ScrolledText(ports_tab, width=36, height=10, font=("Consolas", 10))
        self.port_entry.grid(row=0, column=0, sticky="nsew", padx=(PAD//2), pady=(PAD//2))
        try:
            self.port_entry.configure(borderwidth=2, relief="solid")
        except Exception:
            pass
        try:
            inputs_nb.select(ports_tab)
        except Exception:
            pass
        act_frame = ttk.LabelFrame(self.tab_acl, text="Interface & Actions")
        act_frame.grid(row=1, column=0, sticky="ew", padx=PAD, pady=(0, PAD))
        for c in range(3):
            act_frame.columnconfigure(c, weight=1)
        self.status_btn = ttk.Button(act_frame, text="Check Firewall Status", command=self.check_status_thread)
        self.status_btn.grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, PAD))
        self.interface_btn = ttk.Button(act_frame, text="Detect Interface", command=self.detect_interface_thread)
        self.interface_btn.grid(row=1, column=0, columnspan=2, sticky="ew", padx=(0, PAD))
        self.inline_check_btn = ttk.Button(act_frame, text="Inline check", command=self.inline_check_thread)
        self.inline_check_btn.grid(row=1, column=2, sticky="ew")
        # NEW: Neutral Traffic Capture buttons (work for Palo now; ASA/SRX later once adapters implement)
        self.start_cap_btn = ttk.Button(act_frame, text="Start Traffic Capture", command=self.start_capture_thread)
        self.start_cap_btn.grid(row=2, column=0, sticky="ew", padx=(0, PAD), pady=(PAD//2))
        self.stop_cap_btn = ttk.Button(act_frame, text="Stop Traffic Capture", command=self.stop_capture_thread)
        self.stop_cap_btn.grid(row=2, column=1, sticky="ew", pady=(PAD//2))
        ttk.Label(act_frame, text="Protocol (ASA/SRX):").grid(row=3, column=0, sticky="w", pady=(PAD, 0))
        self.asa_proto = ttk.Combobox(act_frame, values=["TCP", "UDP", "Both"], state="readonly")
        self.asa_proto.grid(row=3, column=1, sticky="ew", pady=(PAD, 0))
        self.asa_proto.set("TCP")
        self.connectivity_btn = ttk.Button(
            act_frame, text="Check Connectivity (Single PT)", command=self.check_connectivity_thread
        )
        self.connectivity_btn.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(PAD, 0))
        ttk.Label(act_frame, text="From Zone:").grid(row=5, column=0, sticky="w", pady=(PAD, 0))
        self.zone_from_var = tk.StringVar(value="N/A")
        self.zone_from_lbl = ttk.Label(act_frame, textvariable=self.zone_from_var, foreground="blue")
        self.zone_from_lbl.grid(row=5, column=1, sticky="w", pady=(PAD, 0))
        ttk.Label(act_frame, text="To Zone:").grid(row=6, column=0, sticky="w", pady=(2, 0))
        self.zone_to_var = tk.StringVar(value="N/A")
        self.zone_to_lbl = ttk.Label(act_frame, textvariable=self.zone_to_var, foreground="blue")
        self.zone_to_lbl.grid(row=6, column=1, sticky="w", pady=(2, 0))
        btns2 = ttk.Frame(act_frame)
        btns2.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(PAD, 0))
        for c in range(2):
            btns2.columnconfigure(c, weight=1)
        self.generate_btn = ttk.Button(btns2, text="Generate ACL", command=self.generate_acl)
        self.generate_btn.grid(row=0, column=0, sticky="ew", padx=(0, PAD))
        self.final_btn = ttk.Button(btns2, text="Final Submission", command=self.final_submission_thread)
        self.final_btn.grid(row=0, column=1, sticky="ew")

        # Right pane
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)
        right.rowconfigure(1, weight=0)
        self.output = scrolledtext.ScrolledText(right, width=90, height=35, font=("Consolas", 10))
        self.output.grid(row=0, column=0, padx=(0, PAD), pady=PAD, sticky="nsew")
        self.output.tag_config('found', foreground='green')
        self.output.tag_config('missing', foreground='red')
        status_frame = ttk.Frame(right)
        status_frame.grid(row=1, column=0, padx=(0, PAD), pady=(0, PAD), sticky="ew")
        self.status_label = ttk.Label(status_frame, text="Status: Idle", foreground="blue")
        self.status_label.pack(side="left", padx=5)
        self.progress = ttk.Progressbar(status_frame, mode="indeterminate", length=200)
        self.progress.pack(side="right", padx=5)

        # ------------------------------ State ------------------------------
        self.connection = None
        self.adapter = None
        self.acl_commands = ""
        self.interface_name = None
        self.asa_mode = "unknown"
        self.context_list = []
        self.context_name = None
        self.platform_is_srx = False
        self.platform_is_palo = False
        self.settings = load_settings()
        self.global_logger = get_global_logger()
        self.run_dir = None
        self.run_logger = None

        # Monitor state
        self.monitor_running = False
        self.monitor_job = None
        self.monitor_interval_ms = 5000

        # Logs & Reports Tab
        logs_frame = ttk.LabelFrame(self.tab_logs, text="Logs & Reports")
        logs_frame.grid(row=0, column=0, sticky="nsew", padx=PAD, pady=PAD)
        for c in range(3):
            logs_frame.columnconfigure(c, weight=1)
        ttk.Label(logs_frame, text="Reports Base Dir:").grid(row=0, column=0, sticky='w')
        self.logs_base_var = tk.StringVar(value=self.settings.get('reports_base_dir', 'reports'))
        ttk.Label(logs_frame, textvariable=self.logs_base_var, foreground='blue').grid(row=0, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Reports", command=lambda: _open_path(self.logs_base_var.get())).grid(row=0, column=2, sticky='ew')
        ttk.Label(logs_frame, text="Current Run Dir:").grid(row=1, column=0, sticky='w')
        self.logs_run_var = tk.StringVar(value='-')
        ttk.Label(logs_frame, textvariable=self.logs_run_var, foreground='blue').grid(row=1, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Current Run", command=lambda: _open_path(self.logs_run_var.get())).grid(row=1, column=2, sticky='ew')
        ttk.Label(logs_frame, text="Last Run Dir:").grid(row=2, column=0, sticky='w')
        self.logs_last_var = tk.StringVar(value=_latest_run_dir(self.logs_base_var.get()) or '-')
        ttk.Label(logs_frame, textvariable=self.logs_last_var, foreground='blue').grid(row=2, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Last Run", command=self.open_last_run).grid(row=2, column=2, sticky='ew')
        ttk.Label(logs_frame, text="Global Log:").grid(row=3, column=0, sticky='w')
        self.logs_global_var = tk.StringVar(value=self.settings.get('global_log_file', 'acl_tool.log'))
        ttk.Label(logs_frame, textvariable=self.logs_global_var, foreground='blue').grid(row=3, column=1, sticky='w')
        ttk.Button(logs_frame, text="Open Global Log", command=lambda: _open_path(self.logs_global_var.get())).grid(row=3, column=2, sticky='ew')
        ttk.Label(logs_frame, text="Debug Level:").grid(row=4, column=0, sticky='w')
        self.debug_enabled = tk.BooleanVar(value=True)
        dbg_chk = ttk.Checkbutton(logs_frame, text="Enable Debug", variable=self.debug_enabled, command=self.toggle_debug)
        dbg_chk.grid(row=4, column=1, sticky='w')

        # Small helper used by capture handlers for console + UI log
        def _append(self, text: str):
            self.output_text = getattr(self, "output", None)
            if self.output_text:
                self.output_text.configure(state="normal")
                self.output_text.insert("end", text)
                self.output_text.see("end")
                self.output_text.configure(state="disabled")
            # Also print to console for quick diagnostics
            try:
                print(text, end="")
            except Exception:
                pass
        # Bind helper
        self._append = _append.__get__(self, ASAACLTool)

        # ------------------------------ Monitor methods ------------------------------
    def _monitor_set_status(self, text, color="blue"):
        try:
            self.monitor_status_var.set(text)
        except Exception:
            pass
        self.safe_update_status(text, color)

    def _parse_first_host(self, s: str) -> str:
        s = (s or "").strip()
        if not s:
            return ""
        try:
            ipaddress.IPv4Address(s)
            return s
        except Exception:
            pass
        try:
            net = ipaddress.IPv4Network(s, strict=False)
            return str(next(net.hosts()))
        except Exception:
            return s

    def _monitor_fetch_once(self):
        if not self.connection or not self.adapter:
            self.root.after(0, lambda: self._monitor_set_status("Not connected", "red"))
            return
        # Gather filters
        try:
            src = self._parse_first_host(self.mon_src_entry.get())
            dst = self._parse_first_host(self.mon_dst_entry.get())
            app = (self.mon_app_entry.get() or "").strip()
        except Exception:
            src, dst, app = None, None, None
        # Prefer Palo verdict monitor first
        snap = None
        if hasattr(self.adapter, "monitor_live_verdicts"):
            try:
                snap = self.adapter.monitor_live_verdicts(src_ip=src or None, dst_ip=dst or None, app=app or None, limit=200, timeout=45)
            except Exception:
                snap = None
        # Fallback to session snapshot
        if (snap is None) and hasattr(self.adapter, "monitor_snapshot"):
            try:
                snap = self.adapter.monitor_snapshot(src_ip=src or None, dst_ip=dst or None, app=app or None, limit=200, timeout=45)
            except Exception:
                snap = None
        if snap is None:
            snap = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "summary": "[MONITOR] Adapter lacks monitor APIs; implement to enable.",
                "raw": ""
            }
        def update_ui():
            try:
                self.monitor_out.configure(state="normal")
                self.monitor_out.delete("1.0", "end")
                self.monitor_out.insert("end", f"[{snap.get('timestamp','')}] Monitor Summary\n")
                if snap.get("summary"):
                    self.monitor_out.insert("end", snap["summary"] + "\n\n")
                if snap.get("raw"):
                    self.monitor_out.insert("end", snap["raw"])
                self.monitor_out.see("end")
                self.monitor_out.configure(state="disabled")
            except Exception:
                pass
            self._monitor_set_status("Monitor tick OK", "green")
        self.root.after(0, update_ui)

    def _monitor_do_fetch(self):
        if not self.monitor_running:
            return
        def worker():
            try:
                self._monitor_fetch_once()
            finally:
                sel = (self.mon_interval_cb.get() or "5s").strip().lower()
                self.monitor_interval_ms = 2000 if sel.startswith("2") else (10000 if sel.startswith("10") else 5000)
                self._monitor_schedule_next(self.monitor_interval_ms)
        threading.Thread(target=worker, daemon=True).start()

    def start_monitor(self):
        if self.monitor_running:
            self._monitor_set_status("Monitor already running", "orange")
            return
        self.monitor_running = True
        try:
            self.mon_start_btn.configure(state="disabled")
            self.mon_stop_btn.configure(state="normal")
        except Exception:
            pass
        self._monitor_set_status("Starting monitor...", "orange")
        # Immediate first tick so user sees output right away
        try:
            self._monitor_fetch_once()
        except Exception as e:
            try:
                self._monitor_set_status(f"Start failed: {e}", "red")
            except Exception:
                pass
        # Schedule continuous fetches using the current interval
        sel = (self.mon_interval_cb.get() or "5s").strip().lower()
        self.monitor_interval_ms = 2000 if sel.startswith("2") else (10000 if sel.startswith("10") else 5000)
        self._monitor_schedule_next(self.monitor_interval_ms)

    def stop_monitor(self):
        self.monitor_running = False
        try:
            if self.monitor_job:
                self.root.after_cancel(self.monitor_job)
        except Exception:
            pass
        self.monitor_job = None
        try:
            self.mon_start_btn.configure(state="normal")
            self.mon_stop_btn.configure(state="disabled")
        except Exception:
            pass
        self._monitor_set_status("Monitor stopped", "green")

    # ------------------------------ NEW: missing scheduler (fixes AttributeError) ------------------------------
    def _monitor_schedule_next(self, delay_ms: int):
        """Schedule the next monitor tick in a neutral, cross-platform way."""
        try:
            if self.monitor_job:
                self.root.after_cancel(self.monitor_job)
        except Exception:
            pass
        def tick():
            if self.monitor_running:
                self._monitor_do_fetch()
        try:
            self.monitor_job = self.root.after(int(delay_ms), tick)
        except Exception:
            # Fallback to default 5s on failure
            self.monitor_job = self.root.after(5000, tick)

    # ------------------------------ NEW: Neutral one-time snapshot ------------------------------
    def snapshot_monitor_once(self):
        """Neutral snapshot: prefer adapter.monitor_snapshot; fall back to sessions; otherwise show a neutral message."""
        if not self.connection or not self.adapter:
            self._monitor_set_status("Not connected", "red")
            return
        # Gather filters neutrally
        src = (self.mon_src_entry.get() or "").strip() or None
        dst = (self.mon_dst_entry.get() or "").strip() or None
        app = (self.mon_app_entry.get() or "").strip() or None
        snap = None
        # Prefer snapshot (historical logs where available)
        try:
            if hasattr(self.adapter, "monitor_snapshot"):
                snap = self.adapter.monitor_snapshot(src_ip=src, dst_ip=dst, app=app, limit=200, timeout=45)
        except Exception as e:
            snap = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "summary": f"[MONITOR] Error: {e}", "raw": ""}
        # Fallback: sessions summary (if available)
        if snap is None:
            try:
                if hasattr(self.adapter, "show_sessions"):
                    raw = self.adapter.show_sessions(src_ip=src, dst_ip=dst, app=app, limit=200, timeout=45)
                    summarizer = getattr(self.adapter, "summarize_sessions", None)
                    summary = summarizer(raw, top_n=10) if callable(summarizer) else ("[MONITOR] Sessions snapshot (raw below)\n")
                    snap = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "summary": summary, "raw": raw or ""}
            except Exception as e:
                snap = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "summary": f"[MONITOR] Error: {e}", "raw": ""}
        # Final fallback: neutral message when adapter has no APIs
        if snap is None:
            snap = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "summary": "[MONITOR] Adapter lacks snapshot/session APIs.", "raw": ""}
        # Render (neutral labels)
        try:
            self.monitor_out.configure(state="normal")
            self.monitor_out.delete("1.0", "end")
            self.monitor_out.insert("end", f"[{snap.get('timestamp','')}] Monitor Snapshot\n")
            if snap.get("summary"):
                self.monitor_out.insert("end", snap["summary"] + "\n\n")
            if snap.get("raw"):
                self.monitor_out.insert("end", snap["raw"])
            self.monitor_out.see("end")
            self.monitor_out.configure(state="disabled")
        except Exception:
            pass
        self._monitor_set_status("Historical snapshot complete" if hasattr(self.adapter, "monitor_snapshot") else "Snapshot complete", "green")

# ------------------------------ Main ------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    # Hide window until auth check passes
    try:
        root.withdraw()
    except Exception:
        pass
    if not _require_launcher_auth(root):
        try:
            root.destroy()
        except Exception:
            pass
        raise SystemExit(1)
    try:
        root.deiconify()
    except Exception:
        pass
    app = ASAACLTool(root)
    root.mainloop()
