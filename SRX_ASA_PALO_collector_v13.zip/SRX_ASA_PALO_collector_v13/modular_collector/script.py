#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scoring engine used by dashboard.py.
Provides:
    compute_top10(rules) ? (top10_list, ranked_list)

Auto-locates reports/latest/ next to this file.
Loads:
    firewalls.csv
    interfaces.csv
    routes.csv
    policies.csv

This script is CWD-safe and works correctly when launched from GUI.
"""

import os
import re
import json
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

# ------------------------------------------------------------
#  PATH DISCOVERY (CWD SAFE)
# ------------------------------------------------------------
BASE = Path(__file__).resolve().parent
REPORTS = BASE / "reports" / "latest"

# Ensure directory exists (dashboard will populate it)
REPORTS.mkdir(parents=True, exist_ok=True)

def resolve_csv(name: str) -> Path:
    """Return path to CSV inside reports/latest."""
    return (REPORTS / name).resolve()


FIREWALL_CSV   = resolve_csv("firewalls.csv")
INTERFACES_CSV = resolve_csv("interfaces.csv")
ROUTES_CSV     = resolve_csv("routes.csv")
POLICIES_CSV   = resolve_csv("policies.csv")

# ------------------------------------------------------------
#  SAFE CSV LOADERS
# ------------------------------------------------------------

def load_csv(path: Path) -> List[Dict[str, Any]]:
    """Load CSV safely as list[dict]."""
    if not path.exists():
        return []
    try:
        df = pd.read_csv(path)
        df = df.fillna("")
        return df.to_dict(orient="records")
    except Exception as e:
        # Return empty list instead of crashing the dashboard
        (REPORTS / "script_loader_error.txt").write_text(
            f"Failed to load {path}:\n{e}\n",
            encoding="utf-8"
        )
        return []


# ------------------------------------------------------------
#  RULE NORMALIZATION
# ------------------------------------------------------------

def toklist(v: Any) -> List[str]:
    if v is None:
        return []
    s = str(v).strip()
    if not s:
        return []
    return [x.strip() for x in re.split(r"[ ,]+", s) if x.strip()]


def norm(v: Any) -> str:
    return str(v).strip() if v is not None else ""


def normalize_rules(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert risky_acl.csv rows into standard rule format for scoring."""
    out = []
    for r in rows:
        services_val = r.get("services") or r.get("service") or ""
        if isinstance(services_val, str):
            services_val = toklist(services_val)

        out.append({
            "fw_name":   norm(r.get("hostname") or r.get("device")),
            "platform":  norm(r.get("platform")),
            "rule_id":   norm(r.get("rule_id") or r.get("rule") or r.get("name")),
            "rule_name": norm(r.get("name") or r.get("rule")),
            "from_zone": norm(r.get("from_zone") or r.get("src_zone")),
            "to_zone":   norm(r.get("to_zone") or r.get("dst_zone")),
            "src_addrs": toklist(r.get("src")),
            "dst_addrs": toklist(r.get("dst")),
            "services":  services_val,
            "action":    norm(r.get("action") or r.get("rule_action") or "allow"),
            "enabled":   str(r.get("enabled", "true")).lower() in {"1", "true", "yes", "y"},
            "logging":   str(r.get("logging", r.get("log","true"))).lower() in {"1","true","yes","y"},
            "hit_count": int(str(r.get("hit_count", "0")).strip() or 0),
            "first_seen": norm(r.get("first_seen")),
            "last_modified": norm(r.get("last_modified")),
            "remark": norm(r.get("remark")),
        })
    return out


# ------------------------------------------------------------
#  SCORING ENGINE (same as dashboard inline fallback)
# ------------------------------------------------------------

HIGH_RISK_PORTS = {22,23,25,53,80,110,143,389,445,1433,1521,2049,3306,3389,5900}
WEIGHTS = {
    "exposure":   0.30,
    "service":    0.25,
    "scope":      0.15,
    "guardrails": 0.10,
    "usage":      0.10,
    "age":        0.10,
}

ANY_TOKENS = {"any","any4","any-ip","0.0.0.0/0","0.0.0.0","0/0"}

def is_any_addr(lst: List[str]) -> bool:
    return any(str(x).lower() in ANY_TOKENS for x in lst)

def exposure_score(fz: str, tz: str) -> int:
    f = fz.lower()
    t = tz.lower()
    if t in {"untrust","external","internet"}: return 70
    if f in {"untrust","external","internet"} and t in {"trust","internal","dmz"}:
        return 100
    if t == "dmz": return 60
    return 40

def service_score(services: List[str]) -> int:
    if not services:
        return 40
    lo = [s.lower() for s in services]
    if "any" in lo:
        return 100
    score = 0
    for s in lo:
        try:
            port = int(s.split("/",1)[1]) if "/" in s else int(s)
            score = max(score, 90 if port in HIGH_RISK_PORTS else 60)
        except:
            score = max(score, 50)
    return score

def scope_score(src: List[str], dst: List[str]) -> int:
    score = 0
    if is_any_addr(src) or is_any_addr(dst):
        score += 70
    score += min(30, 2 * max(len(src), len(dst)))
    return min(100, score)

def guardrails_score(action: str, logging: bool, enabled: bool, profiles: Optional[List[str]]) -> int:
    if not enabled:
        return 0
    if action.lower() != "allow":
        return 10
    score = 60
    if not logging: score += 20
    if profiles is not None and len([p for p in profiles if norm(p)]) == 0:
        score += 10
    return min(100, score)

def usage_score(hit_count: int, p95: int) -> int:
    if p95 <= 0:
        return 0
    return min(100, int((hit_count / p95) * 100))

def age_score(first: str, last: str) -> int:
    ref = (last or first or "")[:19]
    try:
        dt = datetime.fromisoformat(ref)
        days = (datetime.now() - dt).days
        return min(100, days // 2)
    except:
        return 40


# ------------------------------------------------------------
#  compute_top10
# ------------------------------------------------------------

def compute_top10(rules: List[Dict[str, Any]]):
    """Compute top 10 risky rules with full scoring."""
    hits = sorted([int(r.get("hit_count", 0) or 0) for r in rules])
    p95 = hits[int(0.95 * (len(hits) - 1))] if hits else 0

    ranked = []
    for r in rules:
        src = r["src_addrs"]
        dst = r["dst_addrs"]
        services = r["services"]
        action = r["action"]
        enabled = r["enabled"]
        logging = r["logging"]

        fz = r["from_zone"]
        tz = r["to_zone"]

        factors = {
            "exposure":   exposure_score(fz, tz),
            "service":    service_score(services),
            "scope":      scope_score(src, dst),
            "guardrails": guardrails_score(action, logging, enabled, None),
            "usage":      usage_score(r["hit_count"], p95),
            "age":        age_score(r.get("first_seen",""), r.get("last_modified","")),
        }

        score = int(sum(factors[k] * WEIGHTS[k] for k in WEIGHTS))

        ranked.append({
            **r,
            "risk_score": score,
            "factors": factors,
        })

    ranked.sort(key=lambda x: x["risk_score"], reverse=True)
    return ranked[:10], ranked


# ------------------------------------------------------------
# Optional: load firewall/policy CSVs (not required by dashboard)
# ------------------------------------------------------------

def load_firewall_data():
    return {
        "firewalls": load_csv(FIREWALL_CSV),
        "interfaces": load_csv(INTERFACES_CSV),
        "routes": load_csv(ROUTES_CSV),
        "policies": load_csv(POLICIES_CSV),
    }