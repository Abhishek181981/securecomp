#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dashboard generator for Modular Collector outputs (enhanced; robust scorer import).
Reads (by default):
  - reports/latest/risky_acl.csv
  - reports/latest/zero_acl.csv
Produces in the same directory:
  - dashboard.md
  - dashboard.html
  - dashboard.csv (high-level metrics key,value)
  - top10_rules.json  (auto-ranked risky rules)
  - top10_rules.csv   (same as JSON, tabular)

Notes
-----
* Heuristics are conservative; vendor adapters remain unchanged.
* Robust scorer import shim supports modules named 'script', 'risk.script', or 'risk.scorer';
  if none is present, a minimal inline fallback is used so the dashboard never fails.
"""
import argparse
import csv
import html
import json
import os
import re
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Any, Optional

# ---------------------------------------------------------------------------
# Robust scorer import shim (so a missing 'script' will not break dashboard)
# Exposes: compute_top10(rules) -> (top10_list, all_ranked_list)
# ---------------------------------------------------------------------------
try:
    # Preferred: a local scorer named script.py living next to dashboard.py
    import script as _scior
    compute_top10 = _scior.compute_top10  # type: ignore[attr-defined]
except ModuleNotFoundError:
    try:
        # Package form: risk/script.py
        from risk import script as _scior  # type: ignore
        compute_top10 = _scior.compute_top10  # type: ignore[attr-defined]
    except ModuleNotFoundError:
        try:
            # Alternate name used by some repos
            from risk.scorer import compute_top10  # type: ignore
        except ModuleNotFoundError:
            # ---------------- Inline minimal scorer fallback -----------------
            HIGH_RISK_PORTS = {22, 23, 25, 53, 80, 110, 143, 389, 445, 1433, 1521, 2049, 3306, 3389, 5900}
            WEIGHTS = {"exposure": 0.30, "service": 0.25, "scope": 0.15, "guardrails": 0.10, "usage": 0.10, "age": 0.10}

            def _s_norm(v):  # local helper for fallback
                return (str(v).strip() if v is not None else '')

            def _toklist(v) -> List[str]:
                s = _s_norm(v)
                if not s:
                    return []
                parts = re.split(r"[\s,]+", s)
                return [p for p in (t.strip() for t in parts) if p]

            def _is_any_addr_list(lst: List[str]):
                return bool(lst) and any(x.lower() in {"any", "0.0.0.0/0", "any-ip", "any4"} for x in lst)

            def _internet_facing(src: List[str], dst: List[str], fz: str, tz: str) -> bool:
                lz = {(fz or '').lower(), (tz or '').lower()}
                if {'untrust', 'external', 'internet'} & lz:
                    return True
                return _is_any_addr_list(src) or _is_any_addr_list(dst)

            def _zone_exposure(fz: str, tz: str) -> int:
                f, t = (fz or '').lower(), (tz or '').lower()
                if t in {"untrust", "external", "internet"}:
                    return 70
                if f in {"untrust", "external", "internet"} and t in {"trust", "internal", "dmz"}:
                    return 100
                if t in {"dmz"}:
                    return 60
                return 40

            def _service_risk(services: List[str]) -> int:
                if not services:
                    return 40
                lo = [s.lower() for s in services]
                if "any" in lo:
                    return 100
                score = 0
                for s in lo:
                    try:
                        port = int(s.split('/', 1)[1]) if '/' in s else int(s)
                        score = max(score, 90 if port in HIGH_RISK_PORTS else 60)
                    except Exception:
                        score = max(score, 50)
                return score

            def _scope_breadth(src: List[str], dst: List[str]) -> int:
                score = 0
                if _is_any_addr_list(src) or _is_any_addr_list(dst):
                    score += 70
                score += min(30, 2 * max(len(src or []), len(dst or [])))
                return min(100, score)

            def _guardrails(action: str, logging: bool, sec_profiles: Optional[List[str]], enabled: bool) -> int:
                if not enabled:
                    return 0
                if (action or '').lower() != 'allow':
                    return 10
                score = 60
                if not logging:
                    score += 20
                if sec_profiles is not None and len([p for p in (sec_profiles or []) if _s_norm(p)]) == 0:
                    score += 10
                return min(100, score)

            def _usage(hit_count: int, p95: int) -> int:
                hit = int(hit_count or 0)
                return 0 if p95 <= 0 else min(100, int((hit / p95) * 100))

            def _age_score(first_seen: str, last_modified: str) -> int:
                ts = (last_modified or first_seen or '')[:19]
                try:
                    dt = datetime.fromisoformat(ts)
                    days = (datetime.now() - dt).days
                    return min(100, int(days / 2))
                except Exception:
                    return 40

            def compute_top10(rules: List[Dict[str, Any]]):
                hits = sorted([int(r.get("hit_count", 0) or 0) for r in rules])
                p95 = hits[int(0.95 * (len(hits) - 1))] if hits else 0
                out: List[Dict[str, Any]] = []
                for r in rules:
                    fz, tz = _s_norm(r.get('from_zone')), _s_norm(r.get('to_zone'))
                    src = r.get('src_addrs') or _toklist(r.get('src') or '')
                    dst = r.get('dst_addrs') or _toklist(r.get('dst') or '')
                    services = r.get('services') or _toklist(r.get('service') or r.get('services') or '')
                    action = _s_norm(r.get('action') or r.get('rule_action') or 'allow')
                    enabled = str(r.get('enabled', 'true')).lower() in {'1', 'true', 'yes', 'y'}
                    logging = str(r.get('logging', r.get('log', 'true'))).lower() in {'1', 'true', 'yes', 'y'}
                    sec_profiles = r.get('security_profiles')
                    factors: Dict[str, int] = {}
                    exp = _zone_exposure(fz, tz)
                    exp = min(100, exp + 20) if _internet_facing(src, dst, fz, tz) else exp
                    factors['exposure'] = exp
                    factors['service'] = _service_risk(services)
                    factors['scope'] = _scope_breadth(src, dst)
                    factors['guardrails'] = _guardrails(action, logging, sec_profiles, enabled)
                    factors['usage'] = _usage(int(r.get('hit_count', 0) or 0), p95)
                    factors['age'] = _age_score(_s_norm(r.get('first_seen')), _s_norm(r.get('last_modified')))
                    score = int(round(sum(factors[k] * WEIGHTS[k] for k in WEIGHTS)))
                    evid: List[str] = []
                    if action.lower() == 'allow':
                        evid.append('allow')
                    if _is_any_addr_list(src):
                        evid.append('src:any')
                    if _is_any_addr_list(dst):
                        evid.append('dst:any')
                    if services and any(str(s).lower() == 'any' for s in services):
                        evid.append('svc:any')
                    if not logging:
                        evid.append('no-logging')
                    if _internet_facing(src, dst, fz, tz):
                        evid.append('internet-facing')
                    if int(r.get('hit_count', 0) or 0) > 0:
                        evid.append(f"hits:{r.get('hit_count')}")
                    if r.get('last_modified'):
                        evid.append(f"last_mod:{str(r['last_modified'])[:10]}")
                    rr = dict(r)
                    rr['risk_score'] = score
                    rr['factors'] = factors
                    rr['evidence'] = ", ".join(evid)
                    out.append(rr)
                out.sort(key=lambda x: x.get('risk_score', 0), reverse=True)
                return out[:10], out
            # ---------------- End inline fallback scorer ----------------------

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
ANY_TOKENS = {'any', 'any4', '0.0.0.0/0', '0.0.0.0 0.0.0.0', '0/0', '::/0', '0.0.0.0'}

PORT_TOKENS = {
    22: {'ssh', 'tcp/22', 'udp/22', ':22'},
    3389: {'rdp', 'tcp/3389', 'udp/3389', ':3389'},
    1433: {'mssql', 'sql', 'tcp/1433', 'udp/1433', ':1433'},
    1521: {'oracle', 'tcp/1521', 'udp/1521', ':1521'},
    27017: {'mongodb', 'mongo', 'tcp/27017', 'udp/27017', ':27017'},
}

CIDR_RE = re.compile(r'^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$')

def _norm(s: Any) -> str:
    return (str(s) if s is not None else '').strip()

def _is_any(s: str) -> bool:
    v = _norm(s).lower()
    return bool(v) and (v in ANY_TOKENS or v.startswith('any-ipv'))

def _parse_cidr(s: str):
    m = CIDR_RE.match(_norm(s))
    if not m:
        return None, None
    return m.group(1), int(m.group(2))

def _broad_prefix(s: str) -> bool:
    ip, mask = _parse_cidr(s)
    if ip is None:
        return False
    try:
        return int(mask) <= 16
    except Exception:
        return False

def _is_rfc1918_token(s: str) -> bool:
    v = _norm(s)
    if v.lower() in ANY_TOKENS:
        return False
    ip, mask = _parse_cidr(v)
    if ip is not None:
        if ip.startswith('10.') and (mask <= 8):
            return True
        if ip.startswith('192.168.') and (mask <= 16):
            return True
        if ip.startswith('172.'):
            try:
                oct2 = int(ip.split('.')[1])
                if 16 <= oct2 <= 31 and mask <= 12:
                    return True
            except Exception:
                pass
        # relaxed RFC1918 match if CIDR is more specific
        if ip.startswith('10.') or ip.startswith('192.168.'):
            return True
        if ip.startswith('172.'):
            try:
                oct2 = int(ip.split('.')[1])
                if 16 <= oct2 <= 31:
                    return True
            except Exception:
                pass
        return False
    # dotted-quad shortcuts
    if v.startswith('10.'):
        return True
    if v.startswith('192.168.'):
        return True
    if v.startswith('172.'):
        try:
            oct2 = int(v.split('.')[1])
            return 16 <= oct2 <= 31
        except Exception:
            return False
    return False

def _is_10net(s: str) -> bool:
    v = _norm(s)
    if v.lower() in ANY_TOKENS:
        return False
    if v.startswith('10.'):
        return True
    ip, mask = _parse_cidr(v)
    return bool(ip and ip.startswith('10.'))

def _mentions_port(text: str, port: int) -> bool:
    t = _norm(text).lower()
    if any(tok in t for tok in PORT_TOKENS[port]):
        return True
    return bool(re.search(rf'(?<!\d)(?:/|:)\s*{port}(?!\d)', t))

# ---------------------------------------------------------------------------
# IO helper
# ---------------------------------------------------------------------------
def _read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    rows: List[Dict[str, str]] = []
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        rd = csv.DictReader(f)
        for r in rd:
            rows.append({k: (v or '') for k, v in r.items()})
    return rows

# ---------------------------------------------------------------------------
# Analyzers (risky + zero-hit)
# ---------------------------------------------------------------------------
def analyze_risky(rows: List[Dict[str, str]]) -> Dict[str, object]:
    total = len(rows)
    any_src = any_dst = any_any_allow = any_to_10 = 0
    broad_to_broad = any_to_rfc1918_permit = 0
    p22 = p3389 = p1433 = p1521 = p27017 = 0
    by_device: Dict[Tuple[str, str], int] = {}
    for r in rows:
        host = _norm(r.get('hostname', ''))
        plat = _norm(r.get('platform', ''))
        by_device[(host, plat)] = by_device.get((host, plat), 0) + 1
        src = _norm(r.get('src', ''))
        dst = _norm(r.get('dst', ''))
        act = _norm(r.get('action', '')).lower()
        rem = _norm(r.get('remark', ''))
        src_is_any = _is_any(src)
        dst_is_any = _is_any(dst)
        if src_is_any:
            any_src += 1
        if dst_is_any:
            any_dst += 1
        if act.startswith('permit') and src_is_any and dst_is_any:
            any_any_allow += 1
        if act.startswith('permit') and src_is_any and _is_10net(dst):
            any_to_10 += 1
        if act.startswith('permit') and src_is_any and _is_rfc1918_token(dst):
            any_to_rfc1918_permit += 1
        if _broad_prefix(src) and _broad_prefix(dst):
            broad_to_broad += 1
        port_context = ' '.join([rem, src, dst])
        if _mentions_port(port_context, 22):    p22 += 1
        if _mentions_port(port_context, 3389):  p3389 += 1
        if _mentions_port(port_context, 1433):  p1433 += 1
        if _mentions_port(port_context, 1521):  p1521 += 1
        if _mentions_port(port_context, 27017): p27017 += 1
    top_devices = sorted(
        ({'hostname': k[0], 'platform': k[1], 'risky_rules': v} for k, v in by_device.items()),
        key=lambda x: x['risky_rules'], reverse=True
    )[:10]
    return {
        'total_risky_rules': total,
        'any_src': any_src,
        'any_dst': any_dst,
        'any_any_allow': any_any_allow,
        'any_to_10': any_to_10,
        'any_to_rfc1918_permit': any_to_rfc1918_permit,
        'broad_to_broad': broad_to_broad,
        'port22_rules': p22,
        'port3389_rules': p3389,
        'port1433_rules': p1433,
        'port1521_rules': p1521,
        'port27017_rules': p27017,
        'top_devices': top_devices,
    }

def _parse_timestamp(val: str):
    t = _norm(val)
    if not t:
        return None
    fmts = [
        '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d',
        '%d-%m-%Y %H:%M:%S', '%d-%m-%Y', '%m/%d/%Y %H:%M:%S', '%m/%d/%Y'
    ]
    for f in fmts:
        try:
            return datetime.strptime(t, f).replace(tzinfo=timezone.utc)
        except Exception:
            continue
    return None

def analyze_zero(rows: List[Dict[str, str]]) -> Dict[str, object]:
    """Zero-hit analysis, permits only, with optional age buckets and per-ACL grouping."""
    permit_rows = [r for r in rows if _norm(r.get('action', '')).lower().startswith('permit')]
    total = len(permit_rows)
    by_device: Dict[Tuple[str, str], int] = {}
    by_rule: Dict[str, int] = {}
    now = datetime.now(timezone.utc)
    buckets = {'le_7d': 0, 'd8_30': 0, 'd31_90': 0, 'gt_90': 0, 'unknown': 0}
    has_ts = False
    for r in permit_rows:
        host = _norm(r.get('hostname', ''))
        plat = _norm(r.get('platform', ''))
        by_device[(host, plat)] = by_device.get((host, plat), 0) + 1
        rid = _norm(r.get('rule_id', ''))
        by_rule[rid] = by_rule.get(rid, 0) + 1
        ts = _parse_timestamp(r.get('timestamp') or r.get('ts') or '')
        if ts is not None:
            has_ts = True
            days = (now - ts).days
            if days <= 7:
                buckets['le_7d'] += 1
            elif days <= 30:
                buckets['d8_30'] += 1
            elif days <= 90:
                buckets['d31_90'] += 1
            else:
                buckets['gt_90'] += 1
        else:
            buckets['unknown'] += 1
    top_devices = sorted(
        ({'hostname': k[0], 'platform': k[1], 'zero_hit_permit_rules': v} for k, v in by_device.items()),
        key=lambda x: x['zero_hit_permit_rules'], reverse=True
    )[:10]
    top_rules = sorted(
        ({'rule_id': k, 'count': v} for k, v in by_rule.items()),
        key=lambda x: x['count'], reverse=True
    )[:15]
    return {
        'total_zero_hit_permit_rules': total,
        'top_devices': top_devices,
        'has_timestamps': has_ts,
        'age_buckets': buckets,
        'top_rule_ids': top_rules,
    }

# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------
def to_markdown(risky: Dict[str, object], zero: Dict[str, object]) -> str:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    md: List[str] = []
    md.append('# Firewall Risk & Zero-Hit Dashboard\n')
    md.append(f'_Generated: {ts}_\n')
    md.append('\n## Risky Rules Summary\n')
    md.append(
        '\n'
        + f'- **Total risky rules**: {risky.get("total_risky_rules", 0)}\n'
        + f'- **ANY in source**: {risky.get("any_src", 0)}\n'
        + f'- **ANY in destination**: {risky.get("any_dst", 0)}\n'
        + f'- **Permit ANY→ANY rules**: {risky.get("any_any_allow", 0)}\n'
        + f'- **ANY→10/8 permits**: {risky.get("any_to_10", 0)}\n'
        + f'- **Permit to RFC1918 from ANY**: {risky.get("any_to_rfc1918_permit", 0)}\n'
        + f'- **Broad→Broad (CIDR ≤ /16 on both sides)**: {risky.get("broad_to_broad", 0)}\n'
        + f'- **Sensitive services (22/3389/1433/1521/27017)**: '
          f'22={risky.get("port22_rules",0)}, 3389={risky.get("port3389_rules",0)}, '
          f'1433={risky.get("port1433_rules",0)}, 1521={risky.get("port1521_rules",0)}, '
          f'27017={risky.get("port27017_rules",0)}\n'
    )
    if risky.get('top_devices'):
        md.append('\n### Top Devices by Risky Rule Count\n')
        md.append('\nHostname | Platform | Risky Rules\n--|--:|--:\n')
        for row in risky['top_devices']:
            md.append(f"{row.get('hostname','')} | {row.get('platform','')} | {row.get('risky_rules',0)}\n")

    md.append('\n## Zero Hit Rules Summary (Permits only)\n')
    zero_total = zero.get('total_zero_hit_permit_rules', 0)
    md.append('\n' + f'- **Total zero-hit permit rules**: {zero_total}\n')
    if zero.get('has_timestamps'):
        b = zero.get('age_buckets', {})
        md.append('\n**Age buckets (by rule timestamp):**\n')
        md.append(
            f"- ≤7 days: {b.get('le_7d',0)}\n"
            f"- 8–30 days: {b.get('d8_30',0)}\n"
            f"- 31–90 days: {b.get('d31_90',0)}\n"
            f"- >90 days: {b.get('gt_90',0)}\n"
            f"- Unknown: {b.get('unknown',0)}\n"
        )
    if zero.get('top_devices'):
        md.append('\n### Top Devices by Zero-Hit Permit Rule Count\n')
        md.append('\nHostname | Platform | Zero-Hit Permit Rules\n--|--:|--:\n')
        for row in zero['top_devices']:
            md.append(f"{row.get('hostname','')} | {row.get('platform','')} | {row.get('zero_hit_permit_rules',0)}\n")
    if zero.get('top_rule_ids'):
        md.append('\n### Top Zero-Hit Permit Rule IDs (Global, Top 15)\n')
        md.append('\nRule ID | Count\n--|--:\n')
        for row in zero['top_rule_ids']:
            md.append(f"{row.get('rule_id','')} | {row.get('count',0)}\n")

    md.append('\n\n_Heuristics: ANY includes 0.0.0.0/0 and synonyms. RFC1918 detection covers 10/8, 172.16/12, 192.168/16. '
              'Sensitive ports are matched by numbers and common labels. Broadness uses CIDR parsing when present. '
              "Zero-hit counts reflect **permits only**; age buckets require a 'timestamp' or 'ts' column._\n")
    return ''.join(md)

def to_html(md: str) -> str:
    # Plain conversion: very simple paragraphs and tables without external deps
    lines = md.split('\n')
    out = [
        "<html><head><meta charset='utf-8'><title>Firewall Dashboard</title>\n",
        "<style>body{font-family:Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:24px;} "
        "table{border-collapse:collapse;} th,td{border:1px solid #ddd;padding:6px 10px;} "
        "th{background:#f8f8f8;} code{background:#f2f2f2;padding:2px 4px;border-radius:3px;} "
        "h1,h2,h3{margin-top:1.2em}</style></head><body>\n"
    ]
    in_table = False
    for line in lines:
        if line.startswith('# '):
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append(f"<h1>{html.escape(line[2:])}</h1>\n")
        elif line.startswith('## '):
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append(f"<h2>{html.escape(line[3:])}</h2>\n")
        elif line.startswith('### '):
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append(f"<h3>{html.escape(line[4:])}</h3>\n")
        elif '|' in line and line.count('|') >= 1 and ('--' in line or in_table):
            if not in_table:
                out.append('<table>\n'); in_table = True
            if set(line.strip()) == {'-', '|', ':', ' '}:
                continue
            cells = [html.escape(c.strip()) for c in line.split('|')]
            out.append('<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>\n')
        elif line.startswith('- '):
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append(f"<li>{html.escape(line[2:])}</li>\n")
        elif line.strip() == '':
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append('<br/>\n')
        else:
            if in_table:
                out.append('</table>\n'); in_table = False
            out.append(f"<p>{html.escape(line)}</p>\n")
    if in_table:
        out.append('</table>\n')
    out.append('</body></html>\n')
    return ''.join(out)

def write_summary_csv(risky: Dict[str, object], zero: Dict[str, object], out_path: Path) -> None:
    rows = [
        ('total_risky_rules', risky.get('total_risky_rules', 0)),
        ('any_src', risky.get('any_src', 0)),
        ('any_dst', risky.get('any_dst', 0)),
        ('any_any_allow', risky.get('any_any_allow', 0)),
        ('any_to_10', risky.get('any_to_10', 0)),
        ('any_to_rfc1918_permit', risky.get('any_to_rfc1918_permit', 0)),
        ('broad_to_broad', risky.get('broad_to_broad', 0)),
        ('port22_rules', risky.get('port22_rules', 0)),
        ('port3389_rules', risky.get('port3389_rules', 0)),
        ('port1433_rules', risky.get('port1433_rules', 0)),
        ('port1521_rules', risky.get('port1521_rules', 0)),
        ('port27017_rules', risky.get('port27017_rules', 0)),
        ('total_zero_hit_permit_rules', zero.get('total_zero_hit_permit_rules', 0)),
    ]
    with out_path.open('w', encoding='utf-8', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['metric', 'value'])
        for k, v in rows:
            wr.writerow([k, v])

# ---------------------------------------------------------------------------
# Top 10 writer
# ---------------------------------------------------------------------------
def _rules_from_risky_rows(rows: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    rules: List[Dict[str, Any]] = []
    for r in rows:
        services_val: Any = r.get('services') or r.get('service') or ''
        if isinstance(services_val, str):
            services_val = [s.strip() for s in re.split(r'[ ,]+', services_val) if s.strip()]
        rules.append({
            'fw_name': _norm(r.get('hostname') or r.get('device') or ''),
            'platform': _norm(r.get('platform') or ''),
            'rule_id': _norm(r.get('rule_id') or r.get('rule') or r.get('name') or ''),
            'rule_name': _norm(r.get('name') or r.get('rule') or ''),
            'from_zone': _norm(r.get('from_zone') or r.get('src_zone') or ''),
            'to_zone': _norm(r.get('to_zone') or r.get('dst_zone') or ''),
            'src_addrs': [a.strip() for a in re.split(r'[ ,]+', r.get('src', '')) if a.strip()],
            'dst_addrs': [a.strip() for a in re.split(r'[ ,]+', r.get('dst', '')) if a.strip()],
            'services': services_val,
            'action': _norm(r.get('action') or r.get('rule_action') or 'allow'),
            'enabled': str(r.get('enabled', 'true')).lower() in {'1', 'true', 'yes', 'y'},
            'logging': str(r.get('logging', r.get('log', 'true'))).lower() in {'1', 'true', 'yes', 'y'},
            'hit_count': int(r.get('hit_count') or r.get('hits') or r.get('hit') or 0)
                         if str(r.get('hit_count') or r.get('hits') or r.get('hit') or '').strip().isdigit()
                         else 0,
            'first_seen': _norm(r.get('first_seen')),
            'last_modified': _norm(r.get('last_modified')),
            'remark': _norm(r.get('remark')),
        })
    return rules

def write_top10_outputs(risky_rows: List[Dict[str, str]], out_dir: Path) -> None:
    rules = _rules_from_risky_rows(risky_rows)
    try:
        top10, ranked = compute_top10(rules)  # type: ignore[misc]
    except Exception as e:
        # If external scorer crashes, do not fail dashboard entirely; record error
        (out_dir / 'top10_error.txt').write_text(f"compute_top10 error: {e}\n", encoding='utf-8')
        return
    # JSON
    (out_dir / 'top10_rules.json').write_text(json.dumps(top10, ensure_ascii=False, indent=2), encoding='utf-8')
    # CSV
    csv_path = out_dir / 'top10_rules.csv'
    if top10:
        cols = ['risk_score', 'fw_name', 'platform', 'rule_id', 'rule_name',
                'from_zone', 'to_zone', 'services', 'evidence']
        with csv_path.open('w', encoding='utf-8', newline='') as f:
            wr = csv.writer(f)
            wr.writerow(cols)
            for r in top10:
                wr.writerow([
                    r.get('risk_score', 0),
                    r.get('fw_name', ''),
                    r.get('platform', ''),
                    r.get('rule_id', ''),
                    r.get('rule_name', ''),
                    r.get('from_zone', ''),
                    r.get('to_zone', ''),
                    ', '.join(r.get('services') or []),
                    r.get('evidence', ''),
                ])
    else:
        csv_path.write_text("", encoding='utf-8')

# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------
def resolve_reports_dir(cli_reports_dir: Optional[str]) -> Path:
    if cli_reports_dir:
        return Path(cli_reports_dir).expanduser().resolve()
    here = Path(__file__).resolve().parent
    if (here / 'risky_acl.csv').exists() and (here / 'zero_acl.csv').exists():
        return here
    return (Path.cwd() / 'reports' / 'latest').resolve()

def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--reports-dir', help='Directory that contains risky_acl.csv and zero_acl.csv (defaults to auto detection)')
    args = ap.parse_args(argv)

    reports_dir = resolve_reports_dir(args.reports_dir)
    risky_csv = reports_dir / 'risky_acl.csv'
    zero_csv  = reports_dir / 'zero_acl.csv'

    risky_rows = _read_csv(risky_csv)
    zero_rows  = _read_csv(zero_csv)

    if not risky_rows:
        print(f"[WARN] risky_acl.csv is empty or not found at: {risky_csv}")
    if not zero_rows:
        print(f"[WARN] zero_acl.csv is empty or not found at: {zero_csv}")

    risky = analyze_risky(risky_rows)
    zero  = analyze_zero(zero_rows)

    # Build Top 10 outputs (JSON/CSV) for the GUI table
    try:
        write_top10_outputs(risky_rows, reports_dir)
    except Exception as e:
        (reports_dir / 'top10_error.txt').write_text(f"top10 write error: {e}\n", encoding='utf-8')

    md = to_markdown(risky, zero)
    html_doc = to_html(md)
    out_md   = reports_dir / 'dashboard.md'
    out_html = reports_dir / 'dashboard.html'
    out_csv  = reports_dir / 'dashboard.csv'

    out_md.write_text(md, encoding='utf-8')
    out_html.write_text(html_doc, encoding='utf-8')
    write_summary_csv(risky, zero, out_csv)

    print(f"[OK] Dashboard written to: {out_md}")
    print(f"[OK] Dashboard written to: {out_html}")
    print(f"[OK] Summary metrics written to: {out_csv}")
    print(f"[OK] Top10 outputs: {reports_dir/'top10_rules.json'}, {reports_dir/'top10_rules.csv'}")
    return 0


if __name__ == '__main__':
    sys.exit(main())