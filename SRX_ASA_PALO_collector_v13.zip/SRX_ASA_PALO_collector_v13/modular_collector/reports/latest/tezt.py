#!/usr/bin/env python3
# Patch script: adds a "Remediate…" thin-UI (Sprint 1: plan-only, dry-run) to your existing GUI file.
# Usage:
#   python patch_gui_v6_7_for_remediation.py [--file gui.py]
# If --file is omitted, the script will try gui_v6_7.py then gui.py in current dir.

import os, re, sys, json, datetime

TARGETS = ['gui_v6_7.py','gui.py']

def load_target(path):
    if path:
        if os.path.isfile(path):
            return path, open(path,'r',encoding='utf-8').read()
        else:
            print(f"[PATCH] File not found: {path}")
            sys.exit(2)
    for cand in TARGETS:
        if os.path.isfile(cand):
            return cand, open(cand,'r',encoding='utf-8').read()
    print("[PATCH] Could not find gui_v6_7.py or gui.py in current folder.")
    sys.exit(2)

def patch(code:str) -> str:
    # 1) Add Remediate button near Zero tab controls
    pat_btns = r"(zc_btns = ttk\.Frame\(self\.tab_zero\)[\s\S]*?ttk\.Button\(zc_btns, text='\\u25BC Console', command=lambda: self\\._console_show_table\(True, ctx='zero'\)\)\\.grid\(row=0, column=4, sticky='e'\))"
    m = re.search(pat_btns, code)
    if m:
        block = m.group(1)
        code = code.replace("for c in range(5): zc_btns.columnconfigure(c, weight=1)",
                            "for c in range(6): zc_btns.columnconfigure(c, weight=1)")
        code = code.replace(block, block + "\n        ttk.Button(zc_btns, text=\"Remediate…\", command=self._open_remediate_dialog).grid(row=0, column=5, sticky='ew')")
    else:
        print('[PATCH] WARN: could not locate Zero-hit buttons block; the button may not be added.')

    # 2) Inject helper methods before Logs tab marker
    marker = "# ---------------- Logs & Reports TAB ----------------"
    idx = code.find(marker)
    helpers = """
    # ---------------- Remediation (Thin-UI, Sprint 1: Plan-only, Dry-run) ----------------
    def _open_remediate_dialog(self):
        import tkinter as tk
        from tkinter import ttk
        top = tk.Toplevel(self.root)
        top.title("Remediate Zero-hit ACLs")
        top.transient(self.root)
        top.grab_set()
        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        for c in range(2): frm.columnconfigure(c, weight=1)
        self._rm_dry = tk.BooleanVar(value=True)
        self._rm_backup = tk.BooleanVar(value=True)
        self._rm_ticket = tk.StringVar(value='')
        self._rm_confirm = tk.IntVar(value=5)
        self._rm_panorama = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text="Dry-run (no device changes)", variable=self._rm_dry).grid(row=0, column=0, columnspan=2, sticky='w')
        ttk.Checkbutton(frm, text="Backup before change (when enabled in future)", variable=self._rm_backup).grid(row=1, column=0, columnspan=2, sticky='w')
        ttk.Label(frm, text="Ticket ID (optional):").grid(row=2, column=0, sticky='w', pady=(6,0))
        ttk.Entry(frm, textvariable=self._rm_ticket).grid(row=2, column=1, sticky='ew', pady=(6,0))
        ttk.Label(frm, text="SRX commit-confirm (minutes):").grid(row=3, column=0, sticky='w', pady=(6,0))
        ttk.Spinbox(frm, from_=1, to=60, textvariable=self._rm_confirm, width=6).grid(row=3, column=1, sticky='w', pady=(6,0))
        ttk.Checkbutton(frm, text="Panorama-aware mode (experimental)", variable=self._rm_panorama).grid(row=4, column=0, columnspan=2, sticky='w')
        btns = ttk.Frame(frm); btns.grid(row=5, column=0, columnspan=2, sticky='e', pady=(10,0))
        ttk.Button(btns, text="Cancel", command=top.destroy).grid(row=0, column=0, padx=(0,6))
        ttk.Button(btns, text="Generate Plan", command=lambda: [self._generate_remediation_plan(), top.destroy()]).grid(row=0, column=1)

    def _collect_zero_selection_rows(self):
        header = getattr(self, '_zero_last_header', None)
        rows = getattr(self, '_zero_last_rows', None) or []
        tv = getattr(self, 'console_tree_zero', None)
        if not header or not rows:
            return []
        dict_rows = []
        for r in rows:
            if isinstance(r, dict):
                dict_rows.append(dict(r))
            else:
                d = {}
                for i, col in enumerate(header):
                    if col == '#':
                        d[col] = ''
                    else:
                        idx = i-1
                        d[col] = r[idx] if 0 <= idx < len(r) else ''
                dict_rows.append(d)
        try:
            sel = tv.selection()
        except Exception:
            sel = []
        if sel:
            selected_texts = set()
            for iid in sel:
                vals = tv.item(iid, 'values')
                selected_texts.add('\u0001'.join([str(v) for v in vals]))
            filtered = []
            for d in dict_rows:
                row_vals = []
                for c in header:
                    if c == '#':
                        row_vals.append(str(d.get('#','')))
                    else:
                        row_vals.append(str(d.get(c,'')))
                fp = '\u0001'.join(row_vals)
                if fp in selected_texts:
                    filtered.append(d)
            return filtered
        return dict_rows

    def _generate_remediation_plan(self):
        import os, json, datetime
        from tkinter import messagebox
        rows = self._collect_zero_selection_rows()
        if not rows:
            try: messagebox.showinfo('Remediate', 'No rows to remediate. Load a Zero-hit page and select rows (or leave unselected to include the page).')
            except Exception: pass
            return
        targets = {}
        for r in rows:
            device = (r.get('hostname') or r.get('device') or '').strip() or '(unknown)'
            platform = (r.get('platform') or '').strip() or '(unknown)'
            key = (device, platform)
            if key not in targets:
                targets[key] = {'device': device, 'platform': platform, 'auth_ref': 'global', 'rules': []}
            rule = {
                'source_row_key': 'zero',
                'rule_name': r.get('rule_name') or r.get('name') or '',
                'policy': r.get('policy') or r.get('acl') or '',
                'acl': r.get('acl') or '',
                'line': r.get('line') or r.get('rule_id') or '',
                'src': r.get('src') or '',
                'dst': r.get('dst') or '',
                'apps': r.get('apps') or r.get('application') or '',
                'service': r.get('service') or '',
                'action': r.get('action') or '',
                'zones': r.get('zones') or r.get('from_to') or '',
                'category': r.get('category') or '',
                'remark': r.get('remark') or ''
            }
            targets[key]['rules'].append(rule)
        run_id = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        opts = {
            'dry_run': bool(getattr(self, '_rm_dry', None).get() if getattr(self, '_rm_dry', None) else True),
            'backup': bool(getattr(self, '_rm_backup', None).get() if getattr(self, '_rm_backup', None) else True),
            'ticket_id': (getattr(self, '_rm_ticket', None).get() if getattr(self, '_rm_ticket', None) else ''),
            'srx_commit_confirm_minutes': int(getattr(self, '_rm_confirm', None).get() if getattr(self, '_rm_confirm', None) else 5),
            'panorama_mode': bool(getattr(self, '_rm_panorama', None).get() if getattr(self, '_rm_panorama', None) else False)
        }
        plan = {'run_id': run_id, 'options': opts, 'targets': list(targets.values())}
        try:
            base_dir = os.path.dirname(os.path.abspath(self.risk_path_var.get() or 'dashboard.csv')) or '.'
        except Exception:
            base_dir = '.'
        rep_dir = os.path.join(base_dir, 'remediation', run_id)
        try: os.makedirs(rep_dir, exist_ok=True)
        except Exception: pass
        plan_path = os.path.join(rep_dir, 'plan.json')
        try:
            with open(plan_path,'w',encoding='utf-8') as f:
                json.dump(plan, f, indent=2)
            self._append_ctx(f"[REMED] Plan written -> {plan_path}\n", ctx='logs')
        except Exception as e:
            self._append_ctx(f"[REMED] Failed to write plan: {e}\n", ctx='logs')
            return
        self._run_remediator(plan_path)

    def _run_remediator(self, plan_path:str):
        import os, subprocess, sys
        rem_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools', 'remediator.py')
        if not os.path.isfile(rem_path):
            self._append_ctx(f"[REMED] remediator not found at: {rem_path}\n", ctx='logs')
            try: messagebox.showerror('Remediate', 'remediator.py not found in tools/.')
            except Exception: pass
            return
        try:
            proc = subprocess.run([sys.executable, rem_path, '--plan', plan_path], capture_output=True, text=True, timeout=300)
            out = proc.stdout or ''
            err = proc.stderr or ''
            rc = proc.returncode
            if out: self._append_ctx(out + ('\n' if not out.endswith('\n') else ''), ctx='logs')
            if err: self._append_ctx('[stderr]\n' + err + ('\n' if not err.endswith('\n') else ''), ctx='logs')
            self._append_ctx(f"[REMED] remediator exit code: {rc}\n", ctx='logs')
        except Exception as e:
            self._append_ctx(f"[REMED] Failed to run remediator: {e}\n", ctx='logs')
    """
    if idx != -1 and '_generate_remediation_plan' not in code:
        code = code[:idx] + helpers + '\n' + code[idx:]
    return code

if __name__ == '__main__':
    path = None
    if len(sys.argv) >= 3 and sys.argv[1] == '--file':
        path = sys.argv[2]
    target_path, src = load_target(path)
    patched = patch(src)
    out_path = target_path.replace('.py','_remediate.py')
    with open(out_path,'w',encoding='utf-8') as f:
        f.write(patched)
    print(f"[PATCH] Wrote: {out_path}")
    # Create tools/remediator skeleton too
    tools_dir = os.path.join(os.path.dirname(os.path.abspath(out_path)),'tools')
    adapters_dir = os.path.join(tools_dir,'adapters')
    os.makedirs(adapters_dir, exist_ok=True)
    remediator = '#!/usr/bin/env python3\nimport os, sys, json, argparse, time\n\n\n\ndef main():\n    ap = argparse.ArgumentParser(description=\'Zero-hit ACL Remediator (Sprint 1: dry-run only)\')\n    ap.add_argument(\'--plan\', required=True, help=\'Path to plan.json\')\n    args = ap.parse_args()\n    plan_path = os.path.abspath(args.plan)\n    if not os.path.isfile(plan_path):\n        print(f"[REMED] Plan not found: {plan_path}")\n        return 2\n    with open(plan_path,\'r\',encoding=\'utf-8\') as f:\n        plan = json.load(f)\n    run_id = plan.get(\'run_id\') or time.strftime(\'%Y%m%d-%H%M%S\')\n    base_dir = os.path.dirname(plan_path)\n    auth_dir = os.path.join(base_dir, \'authority\')\n    out_dir  = os.path.join(base_dir, \'out\')\n    os.makedirs(auth_dir, exist_ok=True)\n    os.makedirs(out_dir, exist_ok=True)\n    options = plan.get(\'options\', {})\n    print(f"[REMED] Run: {run_id}")\n    print(f"[REMED] Options: dry_run={bool(options.get(\'dry_run\', True))}, backup={options.get(\'backup\')}, ticket_id={options.get(\'ticket_id\')}, srx_confirm={options.get(\'srx_commit_confirm_minutes\')}, panorama_mode={options.get(\'panorama_mode\')}")\n    targets = plan.get(\'targets\') or []\n    total_rules = 0\n    for t in targets:\n        dev = t.get(\'device\') or \'(unknown)\'\n        plat = t.get(\'platform\') or \'(unknown)\'\n        rules = t.get(\'rules\') or []\n        total_rules += len(rules)\n        auth = {\n            \'device\': dev,\n            \'platform\': plat,\n            \'rules_received\': rules,\n            \'resolution\': \'deferred\',\n            \'note\': \'Sprint 1 dry-run: no device resolution, no changes applied.\'\n        }\n        auth_path = os.path.join(auth_dir, f"{(dev or \'device\').replace(\'\/\', \'_\')}.json")\n        try:\n            with open(auth_path,\'w\',encoding=\'utf-8\') as f:\n                json.dump(auth, f, indent=2)\n        except Exception as e:\n            print(f"[REMED] WARN: failed to write authority for {dev}: {e}")\n    backout = {\'run_id\': run_id, \'targets\': [], \'note\': \'Sprint 1 dry-run: backout will be generated in Sprint 2.\'}\n    with open(os.path.join(out_dir,\'backout_plan.json\'),\'w\',encoding=\'utf-8\') as f:\n        json.dump(backout, f, indent=2)\n    print(f"[REMED] Targets: {len(targets)}, Rules: {total_rules}")\n    print(f"[REMED] Wrote authority packs -> {auth_dir}")\n    print(f"[REMED] Wrote backout skeleton -> {os.path.join(out_dir,\'backout_plan.json\')}")\n    print("[REMED] DRY-RUN COMPLETE (no device changes).")\n    return 0\n\n\nif __name__ == \'__main__\':\n    sys.exit(main())\n'
    with open(os.path.join(tools_dir,'remediator.py'),'w',encoding='utf-8') as f:
        f.write(remediator)
    stub = "Adapter stub for Sprint 1 (dry-run). Real device logic to be added in Sprint 2.\n"
    for name in ['panos.py','srx.py','asa.py','common.py']:
        with open(os.path.join(adapters_dir,name),'w',encoding='utf-8') as f:
            f.write(stub)
    print(f"[PATCH] Created tools/remediator.py and tools/adapters/* stubs next to: {out_path}")
