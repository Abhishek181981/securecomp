# normalize.py
import re

ANSI_RE = re.compile(r'\x1B\[[0-9;]*[A-Za-z]')

def normalize_cli(s: str) -> str:
    if not s:
        return ""

    # Remove carriage returns
    s = s.replace("\r", "")

    # Remove ANSI escape sequences
    s = ANSI_RE.sub("", s)

    # Remove --More-- prompts
    s = re.sub(r'--More--.*$', '', s, flags=re.MULTILINE)

    return s