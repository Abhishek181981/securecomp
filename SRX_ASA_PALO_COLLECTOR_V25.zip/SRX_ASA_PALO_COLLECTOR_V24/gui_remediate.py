﻿# -*- coding: utf-8 -*-
"""
Firewall ACL Automation Tool – LITE (Tabs, Isolated Consoles) + Collector Tab
CLEAN v3.8 — Two‑Row KPI Layout + Global chip + 4‑Tab Dashboard Visuals
 - Row 1: USED KPIs (active exposure)
 - Row 2: ZERO‑HIT KPIs (cleanup)
 - Global chip: Total Firewall Rules
 - Dashboard Visuals (one shared space with 4 tabs):
    1) Pies (Risk (used) + Utilization)
    2) Risk Patterns (stacked bar)
    3) Risk Patterns (grouped bar)
    4) Top Devices (toggle to Top 10 Risky Rules inside)

Retained features:
 - Risky & Zero‑hit tab (prefers risky_zero_acl.csv, fallback: risky_all.csv + tag filter)
 - Zero‑hit tab "Send to Remediation"
 - Collector PROMPTS regex single-line fix
 - Inactive ACL viewer + exports
 - Drag-and-drop column reorder, tooltips, pagination
"""
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont
import os, sys, csv, subprocess, time, threading, re
from openpyxl import Workbook
from datetime import datetime
from collections import defaultdict, Counter

# -------- Monitoring helpers (central syslog reader) --------
def _mon_reports_dir():
    base = _default_reports_latest_dir() if "_default_reports_latest_dir" in globals() else os.path.join(os.getcwd(), 'reports', 'latest')
    path = os.path.join(base, 'monitor')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path

def _safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", (s or '').strip())



# ---- Monitor status (CSV) helpers ----

def _mon_status_path():
    return os.path.join(_mon_reports_dir(), 'monitor_status.csv')


def _mon_status_header():
    return ['key','hostname','platform','rule_filter','is_regex','syslog_root','state',
            'started_at','stopped_at','last_heartbeat','sheet_path','snippet_path',
            'total_rows','unique_pairs','first_seen','last_seen','remarks']


def _mon_status_upsert(row: dict):
    """Create or update a row keyed by 'key' in monitor_status.csv."""
    path = _mon_status_path()
    hdr = _mon_status_header()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rows = []
    seen = False
    if os.path.exists(path):
        try:
            import csv
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    if (r.get('key') or '') == (row.get('key') or ''):
                        base = {k: (r.get(k, '') or '') for k in hdr}
                        for k in hdr:
                            v = row.get(k, None)
                            if v is not None and str(v) != '':
                                base[k] = str(v)
                        rows.append(base)
                        seen = True
                    else:
                        rows.append({k: (r.get(k, '') or '') for k in hdr})
        except Exception:
            pass
    if not seen:
        base = {k: '' for k in hdr}
        for k in hdr:
            if row.get(k) is not None:
                base[k] = str(row.get(k) or '')
        rows.append(base)
    # Write back
    import csv
    with open(path, 'w', encoding='utf-8', newline='') as f:
        dw = csv.DictWriter(f, fieldnames=hdr)
        dw.writeheader()
        for r in rows:
            dw.writerow(r)
    return path

class MonAgg:
    # In-memory aggregation of (src,dst,proto,dport) with first/last seen & counts
    def __init__(self):
        self.data = {}
    def add(self, ts, src, dst, proto, dport):
        key = (src, dst, (proto or '').lower(), str(dport or ''))
        d = self.data.get(key)
        if not d:
            d = {'hits': 0, 'first': ts, 'last': ts}
            self.data[key] = d
        d['hits'] += 1
        d['last'] = ts
    def rows(self):
        for (src,dst,proto,dport), meta in self.data.items():
            service = f"{proto}/{dport}" if dport else proto
            yield (src, dst, service, meta['hits'], meta['first'], meta['last'])

# Very light-weight parsers (baseline). Improve with real samples later.
ASA_PERMIT_RE = re.compile(r"%ASA-\d-106100: access-list\s+(?P<acl>[\w.-]+)\s+permitted\s+(?P<proto>\w+)\s+[^/]+/(?P<src>\d+\.\d+\.\d+\.\d+)/(?:\d+)?\s*->\s*[^/]+/(?P<dst>\d+\.\d+\.\d+\.\d+)/(?:\s*(?P<dport>\d+))?", re.IGNORECASE)
SRX_FLOW_RE = re.compile(r"RT_FLOW.*(session create|ALLOW).*rule-name\s*=\s*(?P<rule>[\w\.-]+).*src\s*=\s*(?P<src>\d+\.\d+\.\d+\.\d+),\s*dst\s*=\s*(?P<dst>\d+\.\d+\.\d+\.\d+),\s*proto\s*=\s*(?P<proto>\w+),\s*sport\s*=\s*(?P<sport>\d+),\s*dport\s*=\s*(?P<dport>\d+)", re.IGNORECASE)
# Palo Alto: kv pairs commonly contain action=allow, rule=..., src=..., dst=..., dport=... etc.
def _parse_kv(line: str):
    kv = {}
    for token in re.split(r'[\s,]+', line.strip()):
        if '=' in token:
            k,v = token.split('=',1)
            kv[k.strip().lower()] = v.strip()
    return kv

def parse_line_for_hit(line: str, platform: str):
    L = line.strip()
    plat = (platform or '').strip().lower()
    if plat in ('asa', 'cisco asa'):
        m = ASA_PERMIT_RE.search(L)
        if not m: return None
        return {
            'rule': m.group('acl') or '',
            'proto': (m.group('proto') or '').lower(),
            'src': m.group('src'),
            'dst': m.group('dst'),
            'dport': (m.group('dport') or ''),
            'action': 'permit'
        }
    elif plat in ('palo alto','palo-alto','paloalto','pa'):
        kv = _parse_kv(L)
        if kv.get('action','').lower() not in ('allow','permitted','permit','pass'): return None
        return {
            'rule': kv.get('rule') or kv.get('policy') or kv.get('policy_name') or '',
            'proto': (kv.get('proto') or kv.get('protocol') or '').lower(),
            'src': kv.get('src',''),
            'dst': kv.get('dst',''),
            'dport': kv.get('dport') or kv.get('destport') or kv.get('dstport') or '',
            'action': 'allow'
        }
    elif plat in ('srx','juniper'):
        m = SRX_FLOW_RE.search(L)
        if not m: return None
        return {
            'rule': m.group('rule') or '',
            'proto': (m.group('proto') or '').lower(),
            'src': m.group('src'),
            'dst': m.group('dst'),
            'dport': (m.group('dport') or ''),
            'action': 'allow'
        }
    return None

# Tail last ~64KB of newest file under <root>/<hostname>
def read_recent_lines_from_host_dir(root_dir: str, hostname: str, limit_bytes: int = 65536):
    lines = []
    try:
        d = os.path.join(root_dir, hostname)
        if not os.path.isdir(d):
            return []
        # pick newest regular file
        files = [os.path.join(d, f) for f in os.listdir(d) if os.path.isfile(os.path.join(d,f))]
        if not files:
            return []
        newest = max(files, key=lambda p: os.path.getmtime(p))
        with open(newest, 'r', encoding='utf-8', errors='ignore') as f:
            try:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - limit_bytes), os.SEEK_SET)
            except Exception:
                pass
            lines = f.read().splitlines()
    except Exception:
        lines = []
    return lines


PAD = 8

# Optional charts
MATPLOT_OK = False
try:
    import matplotlib
    matplotlib.use("TkAgg", force=True)
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
    MATPLOT_OK = True
    import warnings
    warnings.filterwarnings('ignore', message='.*figure layout has changed.*')
except Exception:
    MATPLOT_OK = False

COLORS = {
    "red": "#c66565", "amber": "#d6a85b", "yellow": "#ffd966", "purple": "#8e7cc3",
    "blue": "#9fc5e8", "blue_alt": "#a4c2f4", "teal": "#76a5af", "green": "#93c47d",
    "grey": "#a4a4a4", "olive": "#b7b482",
}

# ---------- Paginator (100 rows/page) ----------
class Paginator:
    def __init__(self, rows, page_size=100):
        self.rows = rows or []
        self.page_size = max(1, int(page_size or 100))
        self.page = 1

    @property
    def total_pages(self):
        from math import ceil
        return max(1, ceil(len(self.rows) / self.page_size))

    def slice(self):
        start = (self.page - 1) * self.page_size
        end = min(start + self.page_size, len(self.rows))
        return self.rows[start:end]

    def set_page(self, p):
        try:
            p = int(str(p).strip() or "1")
        except Exception:
            p = 1
        self.page = max(1, min(self.total_pages, p))

    def next(self):
        self.set_page(self.page + 1)

    def prev(self):
        self.set_page(self.page - 1)

# ---------- Reports path helpers ----------
def _collector_dir_or_here():
    try:
        base = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        base = os.path.abspath(os.getcwd())
    candidates = [
        os.path.join(base, 'collector.py'),
        os.path.join(base, 'modular_collector', 'collector.py'),
        os.path.join(os.path.dirname(base), 'collector.py'),
        os.path.join(os.path.dirname(base), 'modular_collector', 'collector.py'),
        'collector.py',
    ]
    for c in candidates:
        if os.path.isfile(c):
            return os.path.dirname(os.path.abspath(c))
    return base

def _default_reports_latest_dir():
    cdir = _collector_dir_or_here()
    return os.path.join(cdir, 'reports', 'latest')

def _ensure_reports_dir():
    rep_dir = _default_reports_latest_dir()
    try:
        os.makedirs(rep_dir, exist_ok=True)
        _probe = os.path.join(rep_dir, '.write_test')
        with open(_probe, 'w', encoding='utf-8') as f:
            f.write('ok')
        os.remove(_probe)
        return rep_dir, False, f"Using reports dir: {rep_dir}"
    except Exception as e:
        temp_root = os.path.expandvars('%TEMP%') if os.name == 'nt' else (os.getenv('TMPDIR') or '/tmp')
        tmp_base = os.path.join(temp_root, 'acl_tool', 'reports', 'latest')
        try:
            os.makedirs(tmp_base, exist_ok=True)
            _probe = os.path.join(tmp_base, '.write_test')
            with open(_probe, 'w', encoding='utf-8') as f:
                f.write('ok')
            os.remove(_probe)
            return tmp_base, True, f"Default reports dir failed ({e}); falling back to: {tmp_base}"
        except Exception as e2:
            cwd_last = os.path.join(os.path.abspath(os.getcwd()), 'reports_latest_fallback')
            try:
                os.makedirs(cwd_last, exist_ok=True)
                _probe = os.path.join(cwd_last, '.write_test')
                with open(_probe, 'w', encoding='utf-8') as f:
                    f.write('ok')
                os.remove(_probe)
                return cwd_last, True, f"Temp dir failed ({e2}); using cwd fallback: {cwd_last}"
            except Exception as e3:
                return cwd_last, True, f"[WARN] Unable to create any reports dir (last error: {e3}). Console only."

def _open_path(path):
    try:
        if sys.platform.startswith('win'):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == 'darwin':
            subprocess.call(['open', path])
        else:
            subprocess.call(['xdg-open', path])
    except Exception:
        try:
            messagebox.showwarning("Open", f"Unable to open: {path}")
        except Exception: pass

# ---------- GUI ----------
class AclToolGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Firewall ACL Automation Tool – LITE (with Collector) [STABLE]")
        try:
            self.root.geometry("1200x900+80+60")
        except Exception:
            pass
        self.root.minsize(1100, 780)

        # session-only credential memory (not persisted)
        self._mem_user = ""
        self._mem_pass = ""
        self._mem_enable = ""

        self._last_reports_dir = None
        self.nb = None

        # charts state / canvases
        self.canvas_pies = None
        self.canvas_bar_stacked = None
        self.canvas_bar_grouped = None

        # Risk & Compliance
        self.risk_table = None
        self.risk_wrap = None
        self.risk_filter_var = None
        self.risk_category_var = None
        self._risk_rows_cache = []
        self._risk_categories_all = []
        self._risk_selected_categories = set()
        self._risk_field_order = []
        self._risk_acl_field = "raw_ace"
        self._risk_category_field = None
        self.risk_page_label = None
        self._risk_pager = None

        # Zero‑hit
        self.zero_table = None
        self.zero_wrap = None
        self.zero_filter_var = None
        self.zero_category_var = None
        self._zero_rows_cache = []
        self._zero_categories_all = []
        self._zero_selected_categories = set()
        self._zero_field_order = []
        self._zero_acl_field = "raw_ace"
        self._zero_category_field = None
        self.zero_cat_btn = None
        self.zero_page_label = None
        self._zero_pager = None

        # Risky & Zero‑hit
        self.tab_riskyzero = None
        self.rz_table = None
        self.rz_filter_var = None
        self.rz_page_label = None
        self._rz_rows_cache = []
        self._rz_field_order = []
        self._rz_pager = None

        # Remediation
        self.tab_remed = None
        self.remed_wrap = None
        self.remed_table = None
        self._remed_rows = []
        self._remed_field_order = []
        self._remed_seen_keys = set()
        self.remed_dryrun_var = tk.BooleanVar(value=True)
        self.remed_auto_move_var = tk.BooleanVar(value=True)

        # Inactive batch cache
        self._inactive_batch_rows = []
        self._inactive_batch_cols = []

        self._build_layout()
        self._init_table_styles()
        self._build_tabs()

        # Initialize a few badges on first load (safe defaults)
        try:
            self._tab_set_badge(self.tab_risk, 'Risk & Compliance', None, 'blue')
            self._tab_set_badge(self.tab_zero, 'Zero‑hit ACL', None, 'green')
            self._tab_set_badge(self.tab_riskyzero, 'Risky & Zero‑hit', None, 'amber')
            self._tab_set_badge(self.tab_remed, 'Remediation', None, 'blue')
            self._tab_set_badge(self.tab_collect, 'Collector', None, 'blue')
            try:
                self._tab_set_badge_on(self.dash_charts_nb, self.tab_fw_health, 'Firewall Health', None, 'green')
            except Exception:
                pass
        except Exception:
            pass
        self._status("Idle", "blue")

    # --- Table style ---
    def _init_table_styles(self):
        """Initialize TTK styles with Azure-like theme (clam base)."""
        # If already done in this session, return
        try:
            self._table_styles_ready
            return
        except AttributeError:
            pass

        style = ttk.Style(self.root)
        # Base theme and common surfaces
        try:
            style.theme_use('clam')
            style.configure('.', background='#f2f4f8')
            style.configure('TFrame', background='#f2f4f8')
            style.configure('TLabelFrame', background='#f2f4f8', font=('Segoe UI Semibold', 10))
            style.configure('TLabelFrame.Label', background='#f2f4f8')
            # Buttons
            style.configure('TButton', background='#2b77e5', foreground='white', padding=8,
                            font=('Segoe UI Semibold', 10), relief='raised', borderwidth=2)
            style.map('TButton', background=[('active','#1f5bb8'),('pressed','#174387')],
                      relief=[('pressed','sunken')])
            # Notebook / Tabs
            style.configure('TNotebook', background='#e6e9ef', borderwidth=0)
            style.configure('TNotebook.Tab', padding=[14,6], background='#d9dce3', foreground='#2b2b2b',
                            font=('Segoe UI Semibold', 10))
            style.map('TNotebook.Tab', background=[('selected','#ffffff'),('active','#eef1f7')],
                       foreground=[('selected','#2b77e5')])
            # Treeview headings
            style.configure('Treeview.Heading', font=('Segoe UI Semibold',10), background='#e2e6ee',
                            foreground='#2b2b2b', relief='raised')
            style.map('Treeview.Heading', background=[('active','#d5dae4')])
        except Exception:
            pass

        # App-specific table style
        style.configure('Bordered.Treeview', borderwidth=0, relief='flat', rowheight=22, font=('Segoe UI', 9))
        style.configure('Treeview.Heading', font=('Segoe UI Semibold', 9))
        style.map('Bordered.Treeview', background=[('selected', '#d9ead3')], foreground=[('selected', '#000000')])

        # Optional chip label style
        try:
            style.configure('Chip.TLabel', font=('Segoe UI Semibold', 10))
        except Exception:
            pass

        self._table_styles_ready = True
    def _build_layout(self):
        main = ttk.Frame(self.root)
        main.grid(row=0, column=0, sticky='nsew')
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=0)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)
        self.nb = ttk.Notebook(main)
        self.nb.grid(row=0, column=0, sticky='nsew', padx=PAD, pady=PAD)

        status = ttk.Frame(self.root)
        status.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        self.status_label = ttk.Label(status, text="Status: Idle", foreground='blue')
        self.status_label.pack(side='left', padx=5)
        self.progress = ttk.Progressbar(status, mode='indeterminate', length=240)
        self.progress.pack(side='right', padx=5)

    # ---------- tabs ----------
    def _build_tabs(self):
        self._build_dashboard_tab()
        self._build_risk_tab()
        self._build_zero_tab()
        self._build_riskyzero_tab()
        self._build_remed_tab()
        self._build_inactive_tab()
        self._build_logs_tab()
        self._build_collector_tab()
        self._build_inventory_tab()

        def _on_main_tab_changed(_e=None):
            try:
                current = self.nb.tab(self.nb.select(), "text")
                if current == "Risk & Compliance":
                    if self.risk_table is not None and not self.risk_table.get_children():
                        self._risk_load_csv_clicked()
                elif current == "Zero‑hit ACL":
                    if self.zero_table is not None and not self.zero_table.get_children():
                        self._zero_load_csv_clicked()
                elif current == "Risky & Zero‑hit":
                    if self.rz_table is not None and not self.rz_table.get_children():
                        self._riskyzero_load_csv_clicked()
            except Exception:
                pass
        self.nb.bind("<<NotebookTabChanged>>", _on_main_tab_changed)

    # ---------------- Dashboard (TWO-ROW KPIs) ----------------
    def _make_chip(self, parent, text, fg="#1f1f1f", bg="#e6e6e6"):
        try:
            lbl = tk.Label(parent, text=text,
                           font=("Segoe UI Semibold", 10),
                           fg=fg, bg=bg,
                           padx=10, pady=4,
                           bd=1, relief="solid", highlightthickness=0)
            return lbl
        except Exception:
            return ttk.Label(parent, text=text, style="Chip.TLabel", foreground=fg)

    def _find_dashboard_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'dashboard.py'),
            os.path.join(base, 'modular_collector', 'dashboard.py'),
            os.path.join(os.path.dirname(base), 'dashboard.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'dashboard.py'),
            'dashboard.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _find_reports_latest_for_dashboard(self) -> str:
        candidates = []
        try:
            script = self._find_dashboard_script()
        except Exception:
            script = None
        if script:
            dash_dir = os.path.dirname(os.path.abspath(script))
            candidates.append(os.path.join(dash_dir, 'reports', 'latest'))
        try:
            candidates.append(os.path.join(_collector_dir_or_here(), 'reports', 'latest'))
        except Exception:
            pass
        try:
            gui_base = os.path.dirname(os.path.abspath(__file__))
            candidates.append(os.path.join(gui_base, 'reports', 'latest'))
        except Exception:
            pass
        for d in candidates:
            if d and os.path.isdir(d): return d
        return candidates[0] if candidates else os.path.join(os.getcwd(), 'reports', 'latest')

    def _count_total_acls(self, rep_dir: str) -> int:
        path = os.path.join(rep_dir, 'acls.csv')
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                return sum(1 for _ in csv.DictReader(f))
        except Exception:
            return 0

    # --- KPI click helpers (injected, token-based) ---
    def _make_clickable_chip(self, lbl, on_click):
        try:
            import tkinter.font as tkfont
            orig_bg = None; orig_fg = None; orig_font = None
            try: orig_bg = lbl.cget('bg')
            except Exception: pass
            try: orig_fg = lbl.cget('fg')
            except Exception: pass
            try: orig_font = tkfont.Font(font=lbl.cget('font'))
            except Exception: orig_font = None
            def _enter(_e=None):
                try:
                    lbl.config(cursor='hand2')
                    if orig_font is not None:
                        f = tkfont.Font(font=lbl.cget('font'))
                        f.configure(underline=1)
                        lbl.config(font=f)
                    if orig_fg: lbl.config(fg='#1155CC')
                    if orig_bg: lbl.config(bg='#dbe6ff')
                except Exception: pass
            def _leave(_e=None):
                try:
                    lbl.config(cursor='')
                    if orig_font is not None: lbl.config(font=orig_font)
                    if orig_fg: lbl.config(fg=orig_fg)
                    if orig_bg: lbl.config(bg=orig_bg)
                except Exception: pass
            lbl.bind('<Enter>', _enter, add='+')
            lbl.bind('<Leave>', _leave, add='+')
            lbl.bind('<Button-1>', lambda _e=None: on_click(), add='+')
        except Exception: pass

    def _kpi_go_risk(self, categories_substrings=None, host_token=''):
        try:
            self.nb.select(self.tab_risk)
        except Exception:
            pass
        try:
            if getattr(self, 'risk_table', None) is not None and not self.risk_table.get_children():
                self._risk_load_csv_clicked()
        except Exception:
            pass
        try:
            self._risk_selected_categories = set()
            if categories_substrings:
                sel = set()
                for c in (getattr(self, '_risk_categories_all', []) or []):
                    lc = str(c).lower()
                    if any((sub or '').lower() in lc for sub in categories_substrings):
                        sel.add(c)
                self._risk_selected_categories = sel
            self.risk_filter_var.set('')
            self.risk_category_var.set('(All)')
            self._risk_apply_filter()
        except Exception:
            pass
    def _kpi_go_risky_zero(self):
        try: self.nb.select(self.tab_riskyzero)
        except Exception: pass
        try:
            if getattr(self, 'rz_table', None) is not None and not self.rz_table.get_children():
                self._riskyzero_load_csv_clicked()
        except Exception: pass

    def _bind_kpi_clicks(self):
        try:
            if hasattr(self, 'lbl_risky_used'):       self._make_clickable_chip(self.lbl_risky_used, lambda: self._kpi_go_risk(categories_substrings=None))
            if hasattr(self, 'lbl_any_any_used'):     self._make_clickable_chip(self.lbl_any_any_used, lambda: self._kpi_go_risk(categories_substrings=['any_any']))
            if hasattr(self, 'lbl_any_rfc_used'):     self._make_clickable_chip(self.lbl_any_rfc_used, lambda: self._kpi_go_risk(categories_substrings=['rfc1918','any_to_rfc']))
            if hasattr(self, 'lbl_broad_broad_used'): self._make_clickable_chip(self.lbl_broad_broad_used, lambda: self._kpi_go_risk(categories_substrings=['broad_to_broad']))
            if hasattr(self, 'lbl_broad_rfc_used'):   self._make_clickable_chip(self.lbl_broad_rfc_used, lambda: self._kpi_go_risk(categories_substrings=['broad_rfc1918']))
            if hasattr(self, 'lbl_icmp_used'):        self._make_clickable_chip(self.lbl_icmp_used, lambda: self._kpi_go_risk(categories_substrings=[s.lower() for s in ['icmp']]))
            if hasattr(self, 'lbl_p80_used'):         self._make_clickable_chip(self.lbl_p80_used, lambda: self._kpi_go_risk(categories_substrings=[s.lower() for s in ['port=80','port80','p80']]))
            if hasattr(self, 'lbl_p21_used'):         self._make_clickable_chip(self.lbl_p21_used, lambda: self._kpi_go_risk(categories_substrings=['port21','p21']))
            if hasattr(self, 'lbl_risky_zero'):       self._make_clickable_chip(self.lbl_risky_zero, self._kpi_go_risky_zero)
            if hasattr(self, 'lbl_any_any_zero'):     self._make_clickable_chip(self.lbl_any_any_zero, lambda: self._kpi_go_zero(categories_substrings=['any_any']))
            if hasattr(self, 'lbl_any_rfc_zero'):     self._make_clickable_chip(self.lbl_any_rfc_zero, lambda: self._kpi_go_zero(categories_substrings=['rfc1918','any_to_rfc']))
            if hasattr(self, 'lbl_broad_broad_zero'): self._make_clickable_chip(self.lbl_broad_broad_zero, lambda: self._kpi_go_zero(categories_substrings=['broad_to_broad']))
            if hasattr(self, 'lbl_broad_rfc_zero'):   self._make_clickable_chip(self.lbl_broad_rfc_zero, lambda: self._kpi_go_zero(categories_substrings=['broad_rfc1918']))
            if hasattr(self, 'lbl_icmp_zero'):        self._make_clickable_chip(self.lbl_icmp_zero, lambda: self._kpi_go_zero(categories_substrings=['icmp']))
            if hasattr(self, 'lbl_p80_zero'):         self._make_clickable_chip(self.lbl_p80_zero, lambda: self._kpi_go_zero(categories_substrings=[s.lower() for s in ['port=80','port80','p80']]))
            if hasattr(self, 'lbl_p21_zero'):         self._make_clickable_chip(self.lbl_p21_zero, lambda: self._kpi_go_zero(categories_substrings=['port21','p21']))
        except Exception: pass

    def _build_dashboard_tab(self):
        self.tab_dash = ttk.Frame(self.nb)
        self.nb.add(self.tab_dash, text="Dashboard")
        self.tab_dash.columnconfigure(0, weight=1)
        self.tab_dash.rowconfigure(3, weight=1)
        self.tab_dash.rowconfigure(4, weight=1)

        # --- Toolbar ---
        btns = ttk.Frame(self.tab_dash)
        btns.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
        for c in range(6): btns.columnconfigure(c, weight=1)
        ttk.Button(btns, text="Generate Dashboard", command=self._run_dashboard).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(btns, text="Refresh Summary", command=self._refresh_dashboard_summary).grid(row=0, column=1, sticky='ew')
        ttk.Button(btns, text="Open reports/latest", command=lambda: _open_path(_default_reports_latest_dir())).grid(row=0, column=2, sticky='ew')
        # Windows-only scheduler button
        handler = getattr(self, '_collector_schedule_windows', None)
        if handler is None:
            handler = lambda: messagebox.showwarning('Schedule', 'Scheduler not available in this build.')
        sch_btn = ttk.Button(btns, text="Schedule in Windows…", command=handler)
        sch_btn.grid(row=0, column=3, sticky='ew')
        try:
            if os.name != 'nt':
                sch_btn.state(['disabled'])
        except Exception:
            pass
        ttk.Button(btns, text="Refresh Charts", command=self._refresh_dashboard_charts).grid(row=0, column=4, sticky='ew')
        ttk.Button(btns, text="Open dashboard.html",
                   command=lambda: _open_path(os.path.join(self._find_reports_latest_for_dashboard(),'dashboard.html'))).grid(row=0, column=4, sticky='ew')
        mgr_handler = getattr(self, '_monitor_manager_open', None)
        if mgr_handler is None:
            mgr_handler = lambda: messagebox.showwarning('Monitoring Manager', 'Manager not available in this build.')
        ttk.Button(btns, text="Open Monitoring Manager…", command=mgr_handler).grid(row=0, column=6, sticky='ew')

        # --- Row 1: USED KPIs ---
        self.kpi_used = ttk.LabelFrame(self.tab_dash, text="USED KPIs (Active Exposure)")
        self.kpi_used.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, 4))
        for c in range(12): self.kpi_used.columnconfigure(c, weight=1)
        chip_bg_used = "#eef8ee"
        self.lbl_risky_used       = self._make_chip(self.kpi_used, "Risky (used): —",       fg="#215a21", bg=chip_bg_used)
        self.lbl_any_any_used     = self._make_chip(self.kpi_used, "ANY→ANY (used): —",     fg="#7a1f1f", bg=chip_bg_used)
        self.lbl_any_rfc_used     = self._make_chip(self.kpi_used, "ANY→RFC1918 (used): —", fg="#7a4b00", bg=chip_bg_used)
        self.lbl_broad_broad_used = self._make_chip(self.kpi_used, "Broad↔Broad (used): —", fg="#4b2e83", bg=chip_bg_used)
        self.lbl_broad_rfc_used   = self._make_chip(self.kpi_used, "Broad RFC1918 (used): —", fg="#4b5200", bg=chip_bg_used)
        self.lbl_icmp_used        = self._make_chip(self.kpi_used, "ICMP (used): —",        fg="#0b4f56", bg=chip_bg_used)
        self.lbl_p80_used         = self._make_chip(self.kpi_used, "Port 80 (used): —",     fg="#1f3a93", bg=chip_bg_used)
        self.lbl_p21_used         = self._make_chip(self.kpi_used, "Port 21 (used): —",     fg="#1f3a93", bg=chip_bg_used)
        # layout used row
        self.lbl_risky_used.grid      (row=0, column=0, sticky='w', padx=4, pady=6)
        self.lbl_any_any_used.grid    (row=0, column=1, sticky='w', padx=4, pady=6)
        self.lbl_any_rfc_used.grid    (row=0, column=2, sticky='w', padx=4, pady=6)
        self.lbl_broad_broad_used.grid(row=0, column=3, sticky='w', padx=4, pady=6)
        self.lbl_broad_rfc_used.grid  (row=0, column=4, sticky='w', padx=4, pady=6)
        self.lbl_icmp_used.grid       (row=0, column=5, sticky='w', padx=4, pady=6)
        self.lbl_p80_used.grid        (row=0, column=6, sticky='w', padx=4, pady=6)
        self.lbl_p21_used.grid        (row=0, column=7, sticky='w', padx=4, pady=6)

        # --- Row 2: ZERO KPIs ---
        self.kpi_zero = ttk.LabelFrame(self.tab_dash, text="ZERO‑HIT KPIs (Cleanup Opportunity)")
        self.kpi_zero.grid(row=2, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        for c in range(12): self.kpi_zero.columnconfigure(c, weight=1)
        chip_bg_zero = "#f1f6ff"
        self.lbl_risky_zero       = self._make_chip(self.kpi_zero, "Risky (zero‑hit): —",       fg="#0b5394", bg=chip_bg_zero)
        self.lbl_any_any_zero     = self._make_chip(self.kpi_zero, "ANY→ANY (zero): —",         fg="#7a1f1f", bg=chip_bg_zero)
        self.lbl_any_rfc_zero     = self._make_chip(self.kpi_zero, "ANY→RFC1918 (zero): —",     fg="#7a4b00", bg=chip_bg_zero)
        self.lbl_broad_broad_zero = self._make_chip(self.kpi_zero, "Broad↔Broad (zero): —",     fg="#4b2e83", bg=chip_bg_zero)
        self.lbl_broad_rfc_zero   = self._make_chip(self.kpi_zero, "Broad RFC1918 (zero): —",   fg="#4b5200", bg=chip_bg_zero)
        self.lbl_icmp_zero        = self._make_chip(self.kpi_zero, "ICMP (zero): —",            fg="#0b4f56", bg=chip_bg_zero)
        self.lbl_p80_zero         = self._make_chip(self.kpi_zero, "Port 80 (zero): —",         fg="#1f3a93", bg=chip_bg_zero)
        self.lbl_p21_zero         = self._make_chip(self.kpi_zero, "Port 21 (zero): —",         fg="#1f3a93", bg=chip_bg_zero)
        # layout zero row
        self.lbl_risky_zero.grid      (row=0, column=0, sticky='w', padx=4, pady=6)
        self.lbl_any_any_zero.grid    (row=0, column=1, sticky='w', padx=4, pady=6)
        self.lbl_any_rfc_zero.grid    (row=0, column=2, sticky='w', padx=4, pady=6)
        self.lbl_broad_broad_zero.grid(row=0, column=3, sticky='w', padx=4, pady=6)
        self.lbl_broad_rfc_zero.grid  (row=0, column=4, sticky='w', padx=4, pady=6)
        self.lbl_icmp_zero.grid       (row=0, column=5, sticky='w', padx=4, pady=6)
        self.lbl_p80_zero.grid        (row=0, column=6, sticky='w', padx=4, pady=6)
        self.lbl_p21_zero.grid        (row=0, column=7, sticky='w', padx=4, pady=6)

        # --- Inline KPI chip bindings (explicit) ---
        try:
            self._make_clickable_chip(self.lbl_risky_used, lambda: self._kpi_go_risk(categories_substrings=None))
            self._make_clickable_chip(self.lbl_any_any_used, lambda: self._kpi_go_risk(categories_substrings=['any_any']))
            self._make_clickable_chip(self.lbl_any_rfc_used, lambda: self._kpi_go_risk(categories_substrings=['rfc1918','any_to_rfc']))
            self._make_clickable_chip(self.lbl_broad_broad_used, lambda: self._kpi_go_risk(categories_substrings=['broad_to_broad']))
            self._make_clickable_chip(self.lbl_broad_rfc_used, lambda: self._kpi_go_risk(categories_substrings=['broad_rfc1918']))
            self._make_clickable_chip(self.lbl_icmp_used, lambda: self._kpi_go_risk(categories_substrings=[s.lower() for s in ['icmp']]))
            self._make_clickable_chip(self.lbl_p80_used, lambda: self._kpi_go_risk(categories_substrings=[s.lower() for s in ['port=80','port80','p80']]))
            self._make_clickable_chip(self.lbl_p21_used, lambda: self._kpi_go_risk(categories_substrings=['port21','p21']))

            self._make_clickable_chip(self.lbl_risky_zero, self._kpi_go_risky_zero)
            self._make_clickable_chip(self.lbl_any_any_zero, lambda: self._kpi_go_zero(categories_substrings=['any_any']))
            self._make_clickable_chip(self.lbl_any_rfc_zero, lambda: self._kpi_go_zero(categories_substrings=['rfc1918','any_to_rfc']))
            self._make_clickable_chip(self.lbl_broad_broad_zero, lambda: self._kpi_go_zero(categories_substrings=['broad_to_broad']))
            self._make_clickable_chip(self.lbl_broad_rfc_zero, lambda: self._kpi_go_zero(categories_substrings=['broad_rfc1918']))
            self._make_clickable_chip(self.lbl_icmp_zero, lambda: self._kpi_go_zero(categories_substrings=[s.lower() for s in ['icmp']]))
            self._make_clickable_chip(self.lbl_p80_zero, lambda: self._kpi_go_zero(categories_substrings=[s.lower() for s in ['port=80','port80','p80']]))
            self._make_clickable_chip(self.lbl_p21_zero, lambda: self._kpi_go_zero(categories_substrings=['port21','p21']))
        except Exception:
            pass

        # --- Global chip row (Total rules) ---
        self.kpi_global = ttk.Frame(self.tab_dash)
        self.kpi_global.grid(row=1, column=0, sticky='ne', padx=(0, PAD), pady=(0, 4))
        self.lbl_total_acls = self._make_chip(self.kpi_global, "Total Firewall Rules: —", fg="#333333", bg="#eeeeee")
        self.lbl_total_acls.grid(row=0, column=0, sticky='e', padx=4, pady=(0, 2))

        # --- Console (shared) ---
        self.dash_console = ttk.LabelFrame(self.tab_dash, text="Dashboard Console")
        self.dash_console.grid(row=3, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_dash.rowconfigure(3, weight=1)
        self.dash_console.columnconfigure(0, weight=1)
        self.dash_console.rowconfigure(0, weight=1)
        self.output_dash = tk.Text(self.dash_console, width=100, height=10, font=("Consolas", 10), wrap='none')
        self.output_dash.grid(row=0, column=0, sticky='nsew')
        ysb = ttk.Scrollbar(self.dash_console, orient='vertical', command=self.output_dash.yview); ysb.grid(row=0, column=1, sticky='ns')
        hsb = ttk.Scrollbar(self.dash_console, orient='horizontal', command=self.output_dash.xview); hsb.grid(row=1, column=0, sticky='ew')
        self.output_dash.configure(yscrollcommand=ysb.set, xscrollcommand=hsb.set)

        # --- Dashboard Visuals (Notebook sharing the same space) ---
        self.dash_charts = ttk.LabelFrame(self.tab_dash, text="Dashboard Visuals")
        self.dash_charts.grid(row=4, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_dash.rowconfigure(4, weight=1)
        self.dash_charts.columnconfigure(0, weight=1)
        self.dash_charts.rowconfigure(0, weight=1)

        self.dash_charts_nb = ttk.Notebook(self.dash_charts)
        self.dash_charts_nb.grid(row=0, column=0, sticky='nsew')

        # Tab 1: Pies (Risk (used) + Utilization)
        self.tab_pies = ttk.Frame(self.dash_charts_nb)
        self.dash_charts_nb.add(self.tab_pies, text="Pies")
        self.tab_pies.columnconfigure(0, weight=1)
        self.tab_pies.rowconfigure(0, weight=1)

        # Tab 2: Risk Patterns (stacked bar)
        self.tab_bar_stacked = ttk.Frame(self.dash_charts_nb)
        self.dash_charts_nb.add(self.tab_bar_stacked, text="Risk Patterns (stacked)")
        self.tab_bar_stacked.columnconfigure(0, weight=1)
        self.tab_bar_stacked.rowconfigure(0, weight=1)

        # Tab 3: Risk Patterns (grouped bar)
        self.tab_bar_grouped = ttk.Frame(self.dash_charts_nb)
        self.dash_charts_nb.add(self.tab_bar_grouped, text="Risk Patterns (grouped)")
        self.tab_bar_grouped.columnconfigure(0, weight=1)
        self.tab_bar_grouped.rowconfigure(0, weight=1)

        # Tab 4: Top Devices (and Top 10 Risky Rules toggle)
        self.tab_top = ttk.Frame(self.dash_charts_nb)
        self.dash_charts_nb.add(self.tab_top, text="Top Devices")
        # Tab 5: Firewall Health
        self.tab_fw_health = ttk.Frame(self.dash_charts_nb)
        self.dash_charts_nb.add(self.tab_fw_health, text="Firewall Health")
        self.tab_fw_health.columnconfigure(0, weight=1)
        self.tab_fw_health.rowconfigure(2, weight=1)

        # KPIs row
        fh_kpi = ttk.Frame(self.tab_fw_health)
        fh_kpi.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(6, 6))
        for c in range(12): fh_kpi.columnconfigure(c, weight=1)
        self.lbl_fw_total = self._make_chip(fh_kpi, "Total Firewalls: —", fg="#1f3a93", bg="#e7f0ff")
        self.lbl_fw_ok    = self._make_chip(fh_kpi, "Successful: —",    fg="#215a21", bg="#eef8ee")
        self.lbl_fw_fail  = self._make_chip(fh_kpi, "Failed: —",        fg="#7a1f1f", bg="#ffecec")
        self.lbl_fw_total.grid(row=0, column=0, sticky='w', padx=4, pady=4)
        self.lbl_fw_ok.grid   (row=0, column=1, sticky='w', padx=4, pady=4)
        self.lbl_fw_fail.grid (row=0, column=2, sticky='w', padx=4, pady=4)

        # Failed table
        fh_wrap = ttk.Frame(self.tab_fw_health, borderwidth=1, relief='solid')
        fh_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        fh_wrap.columnconfigure(0, weight=1)
        fh_wrap.rowconfigure(1, weight=1)
        ttk.Label(fh_wrap, text="Failed Firewalls").grid(row=0, column=0, sticky='w', padx=6, pady=(6, 2))
        self.table_fw_failed = ttk.Treeview(fh_wrap, columns=("hostname","platform","ip"), show='headings', height=14, style='Bordered.Treeview', selectmode='browse')
        self.table_fw_failed.heading("hostname", text="Hostname"); self.table_fw_failed.column("hostname", width=260, anchor='w', stretch=True)
        self.table_fw_failed.heading("platform", text="Platform"); self.table_fw_failed.column("platform", width=140, anchor='center')
        self.table_fw_failed.heading("ip",       text="IP");       self.table_fw_failed.column("ip", width=180, anchor='w')
        self.table_fw_failed.grid(row=1, column=0, sticky='nsew', padx=(6,6), pady=(0,6))
        fh_vsb = ttk.Scrollbar(fh_wrap, orient='vertical', command=self.table_fw_failed.yview)
        fh_vsb.grid(row=1, column=1, sticky='ns')
        self.table_fw_failed.configure(yscrollcommand=fh_vsb.set)

        try: self._refresh_firewall_health()
        except Exception: pass
        self.tab_top.columnconfigure(0, weight=1)
        self.tab_top.rowconfigure(1, weight=1)

        # toolbar inside Top tab
        top_toolbar = ttk.Frame(self.tab_top)
        top_toolbar.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 0))
        self.top_mode = tk.StringVar(value="devices")
        ttk.Radiobutton(top_toolbar, text="Top Devices", variable=self.top_mode, value="devices",
                        command=lambda: self._toggle_top_lists()).pack(side="left")
        ttk.Radiobutton(top_toolbar, text="Top 10 Risky Rules", variable=self.top_mode, value="rules",
                        command=lambda: self._toggle_top_lists()).pack(side="left")

        # stack: two frames, we show/hide based on top_mode
        self.frame_top_devices = ttk.Frame(self.tab_top)
        self.frame_top_devices.grid(row=1, column=0, sticky="nsew")
        self.frame_top_rules = ttk.Frame(self.tab_top)
        self.frame_top_rules.grid(row=1, column=0, sticky="nsew")
        self.tab_top.rowconfigure(1, weight=1)

        # Top Devices tree
        self.frame_top_devices.columnconfigure(0, weight=1)
        self.frame_top_devices.rowconfigure(0, weight=1)
        self.tree_top_dev = ttk.Treeview(
            self.frame_top_devices,
            columns=("hostname","risky_used","risky_zero","total_risky"),
            show="headings", height=12, style="Bordered.Treeview", selectmode="browse"
        )
        for c in ("hostname","risky_used","risky_zero","total_risky"):
            self.tree_top_dev.heading(c, text=c.replace("_"," ").title())
            w = 280 if c=="hostname" else 130
            anchor = 'w' if c=="hostname" else 'center'
            self.tree_top_dev.column(c, width=w, anchor=anchor, stretch=(c=="hostname"))
        self.tree_top_dev.grid(row=0, column=0, sticky="nsew")
        sb_dev = ttk.Scrollbar(self.frame_top_devices, orient="vertical", command=self.tree_top_dev.yview)
        sb_dev.grid(row=0, column=1, sticky="ns")
        self.tree_top_dev.configure(yscrollcommand=sb_dev.set)

        # Top 10 Risky Rules tree
        self.frame_top_rules.columnconfigure(0, weight=1)
        self.frame_top_rules.rowconfigure(0, weight=1)
        self.tree_top_rules = ttk.Treeview(
            self.frame_top_rules,
            columns=("hostname","rule_id","hit_count","src","dst","remark"),
            show="headings", height=12, style="Bordered.Treeview", selectmode="browse"
        )
        heads = {"hostname":"Hostname","rule_id":"Rule/Policy","hit_count":"Hits","src":"Source","dst":"Destination","remark":"Remark / Tags"}
        widths= {"hostname":220,"rule_id":180,"hit_count":90,"src":240,"dst":240,"remark":420}
        anchors={"hostname":'w',"rule_id":'center',"hit_count":'center',"src":'w',"dst":'w',"remark":'w'}
        for c in ("hostname","rule_id","hit_count","src","dst","remark"):
            self.tree_top_rules.heading(c, text=heads[c])
            self.tree_top_rules.column(c, width=widths[c], anchor=anchors[c], stretch=(c in ("hostname","src","dst","remark")))
        self.tree_top_rules.grid(row=0, column=0, sticky="nsew")
        sb_rules = ttk.Scrollbar(self.frame_top_rules, orient="vertical", command=self.tree_top_rules.yview)
        sb_rules.grid(row=0, column=1, sticky="ns")
        self.tree_top_rules.configure(yscrollcommand=sb_rules.set)
        try:
            self._attach_treeview_tooltip(self.tree_top_rules, "remark")
        except Exception:
            pass

        # default to Top Devices view
        self._toggle_top_lists()

    def _append_dash(self, text: str):
        try:
            self.output_dash.config(state='normal')
            self.output_dash.insert('end', text)
            self.output_dash.see('end')
            self.output_dash.config(state='disabled')
        except Exception:
            pass

    def _run_dashboard(self):
        script = self._find_dashboard_script()
        if not script:
            self._status('dashboard.py not found', 'red')
            self._append_dash('[ERROR] Could not find dashboard.py\n')
            return
        run_cwd = os.path.dirname(os.path.abspath(script))
        cmd = [sys.executable, os.path.basename(script)]
        rep_dir = self._find_reports_latest_for_dashboard()
        run_report = os.path.join(rep_dir, 'dashboard_run_report.txt')
        try:
            self.output_dash.config(state='normal'); self.output_dash.delete('1.0', 'end'); self.output_dash.config(state='disabled')
        except Exception: pass
        self._status("Generating dashboard...", "orange")
        try: self.progress.start(10)
        except Exception: pass

        def worker():
            try:
                start = time.time()
                res = subprocess.run(cmd, cwd=run_cwd, capture_output=True, text=True, timeout=900)
                dur = round(time.time() - start, 2)
                out = (res.stdout or '').strip(); err = (res.stderr or '').strip()
                with open(run_report, 'w', encoding='utf-8') as f:
                    f.write(f"[cmd] {' '.join(cmd)}\n[rc] {res.returncode} ({dur}s)\n\n[stdout]\n{out}\n\n[stderr]\n{err}\n")
                self.root.after(0, self._append_dash, f"[stdout]\n{out}\n")
                if err: self.root.after(0, self._append_dash, f"[stderr]\n{err}\n")
                if res.returncode == 0:
                    self.root.after(0, self._status, "Dashboard updated", "green")
                    self.root.after(0, self._refresh_dashboard_summary)
                    self.root.after(0, self._refresh_dashboard_charts)
                else:
                    self.root.after(0, self._status, f"Dashboard failed (exit={res.returncode})", "red")
                self.root.after(0, self._append_dash, f"\n[REPORT] {run_report}\n")
            except subprocess.TimeoutExpired:
                self.root.after(0, self._status, "Dashboard timeout (900s)", "red")
                self.root.after(0, self._append_dash, "[ERROR] Timeout after 900 seconds\n")
            except FileNotFoundError as e:
                self.root.after(0, self._status, "Python or script not found", "red")
                self.root.after(0, self._append_dash, f"[ERROR] {e}\n")
            except Exception as e:
                self.root.after(0, self._status, "Dashboard run failed", "red")
                self.root.after(0, self._append_dash, f"[ERROR] {e}\n")
            finally:
                try: self.progress.stop()
                except Exception: pass
        threading.Thread(target=worker, daemon=True).start()

    def _refresh_dashboard_summary(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path_csv = os.path.join(rep_dir, 'dashboard.csv')
        if not os.path.exists(path_csv):
            self._append_dash("[ERROR] dashboard.csv not found. Run dashboard first.\n")
            return
        metrics = {}
        try:
            with open(path_csv, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f)
                for r in dr:
                    k = (r.get('metric') or '').strip()
                    v = (r.get('value') or '').strip()
                    if k: metrics[k] = v
        except Exception as e:
            self._append_dash(f"[ERROR] Failed to read dashboard metrics file: {e}\n")
            return

        def _ival(name, default=0):
            try: return int(float(str(metrics.get(name, default)).split()[0]))
            except Exception: return default

        # Row-1 USED
        self.lbl_risky_used.config      (text=f"Risky (used): {_ival('risky_used_rules')}")
        self.lbl_any_any_used.config    (text=f"ANY→ANY (used): {_ival('any_any_allow_used')}")
        self.lbl_any_rfc_used.config    (text=f"ANY→RFC1918 (used): {_ival('any_to_rfc1918_permit_used')}")
        self.lbl_broad_broad_used.config(text=f"Broad↔Broad (used): {_ival('broad_to_broad_used')}")
        self.lbl_broad_rfc_used.config  (text=f"Broad RFC1918 (used): {_ival('broad_rfc1918_used')}")
        self.lbl_icmp_used.config       (text=f"ICMP (used): {_ival('icmp_rules_used')}")
        self.lbl_p80_used.config        (text=f"Port 80 (used): {_ival('port80_rules_used')}")
        self.lbl_p21_used.config        (text=f"Port 21 (used): {_ival('port21_rules_used')}")

        # Row-2 ZERO
        self.lbl_risky_zero.config      (text=f"Risky (zero‑hit): {_ival('risky_zero_hit_rules')}")
        self.lbl_any_any_zero.config    (text=f"ANY→ANY (zero): {_ival('any_any_allow_zero')}")
        self.lbl_any_rfc_zero.config    (text=f"ANY→RFC1918 (zero): {_ival('any_to_rfc1918_permit_zero')}")
        self.lbl_broad_broad_zero.config(text=f"Broad↔Broad (zero): {_ival('broad_to_broad_zero')}")
        self.lbl_broad_rfc_zero.config  (text=f"Broad RFC1918 (zero): {_ival('broad_rfc1918_zero')}")
        self.lbl_icmp_zero.config       (text=f"ICMP (zero): {_ival('icmp_rules_zero')}")
        self.lbl_p80_zero.config        (text=f"Port 80 (zero): {_ival('port80_rules_zero')}")
        self.lbl_p21_zero.config        (text=f"Port 21 (zero): {_ival('port21_rules_zero')}")

        # Global chip: Total rules (from acls.csv)
        total_acls = self._count_total_acls(rep_dir)
        self.lbl_total_acls.config(text=f"Total Firewall Rules: {total_acls}")

        # Also refresh Top Lists (keeps lists in sync even on manual refresh)
        self._refresh_top_lists()

        # --- Tab badges ---
        try:
            risky_used = _ival('risky_used_rules', 0)
            zero_total = (
                _ival('any_any_allow_zero', 0) + _ival('any_to_rfc1918_permit_zero', 0) +
                _ival('broad_to_broad_zero', 0) + _ival('broad_rfc1918_zero', 0) +
                _ival('icmp_rules_zero', 0) + _ival('port80_rules_zero', 0) + _ival('port21_rules_zero', 0)
            )
            risky_zero = _ival('risky_zero_hit_rules', 0)
            self._tab_set_badge(self.tab_risk, "Risk & Compliance", risky_used if risky_used>0 else None, "blue")
            self._tab_set_badge(self.tab_zero, "Zero‑hit ACL", zero_total if zero_total>0 else None, "green")
            self._tab_set_badge(self.tab_riskyzero, "Risky & Zero‑hit", risky_zero if risky_zero>0 else None, "amber")
        except Exception:
            pass


        self._status("Dashboard summary refreshed", "blue")

    def _refresh_dashboard_charts(self):
        if not MATPLOT_OK:
            self._append_dash("[INFO] Matplotlib not available. Charts are disabled in this build.\n")
            return

        rep_dir = self._find_reports_latest_for_dashboard()
        path_csv = os.path.join(rep_dir, 'dashboard.csv')
        if not os.path.exists(path_csv):
            self._append_dash("[ERROR] dashboard.csv not found. Generate Dashboard and try again.\n")
            return

        # Load metrics
        metrics = {}
        with open(path_csv, 'r', encoding='utf-8', newline='') as f:
            dr = csv.DictReader(f)
            for r in dr:
                k = (r.get('metric') or '').strip()
                v = (r.get('value') or '').strip()
                if k: metrics[k] = v

        def _ival(name, default=0):
            try: return int(float(str(metrics.get(name, default)).split()[0]))
            except Exception: return default

        # ------- helpers to clear a tab frame
        def _clear(frame):
            for ch in frame.winfo_children():
                try: ch.destroy()
                except Exception: pass

        # ------- Tab 1: Pies (Risk(used) + Utilization)
        _clear(self.tab_pies)
        fig_p = Figure(figsize=(12.8, 4.2), dpi=100, constrained_layout=True)
        axL = fig_p.add_subplot(1,2,1)
        axR = fig_p.add_subplot(1,2,2)

        # Risk (used)
        used_permit = _ival('pie_used_permit_rules', 0)
        risky_used = min(max(_ival('risky_used_rules', 0), 0), used_permit)
        safe_used  = max(0, used_permit - risky_used)
        sizes_p1 = [risky_used, safe_used]
        if sum(sizes_p1) <= 0:
            sizes_p1, labels_p1, colors_p1 = [1], ["No used rules"], [COLORS["grey"]]
        else:
            labels_p1 = ["Risky (used)", "Safe (used)"]
            colors_p1 = [COLORS["red"], COLORS["grey"]]
        axL.pie(sizes_p1, labels=labels_p1, colors=colors_p1, startangle=90, autopct="%1.0f%%", pctdistance=0.8)
        axL.set_title("Risk (Used permit): Risky vs Safe")

        # Utilization
        total_permit = _ival('pie_total_permit_rules', 0)
        zero_hit_permit = _ival('pie_zero_hit_rules', 0)
        used_permit_calc = max(0, total_permit - zero_hit_permit)
        sizes_p2 = [used_permit_calc, zero_hit_permit]
        if sum(sizes_p2) <= 0:
            sizes_p2, labels_p2, colors_p2 = [1], ["No permit rules"], [COLORS["grey"]]
        else:
            labels_p2 = ["Used (permit)", "Zero‑hit"]
            colors_p2 = [COLORS["green"], COLORS["blue"]]
        axR.pie(sizes_p2, labels=labels_p2, colors=colors_p2, startangle=90, autopct="%1.0f%%", pctdistance=0.8)
        axR.set_title("Utilization (permit): Used vs Zero‑hit")

        canvas_p = FigureCanvasTkAgg(fig_p, master=self.tab_pies)
        canvas_p.draw()
        canvas_p.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        tb_p = ttk.Frame(self.tab_pies); tb_p.grid(row=1, column=0, sticky='ew')
        NavigationToolbar2Tk(canvas_p, tb_p)

        # ------- data for bars
        labels = ["ANY→ANY", "ANY→RFC1918", "Broad↔Broad", "Broad RFC1918", "ICMP", "P80", "P21"]
        used_vals = [
            _ival('any_any_allow_used'), _ival('any_to_rfc1918_permit_used'),
            _ival('broad_to_broad_used'), _ival('broad_rfc1918_used'),
            _ival('icmp_rules_used'), _ival('port80_rules_used'), _ival('port21_rules_used')
        ]
        zero_vals = [
            _ival('any_any_allow_zero'), _ival('any_to_rfc1918_permit_zero'),
            _ival('broad_to_broad_zero'), _ival('broad_rfc1918_zero'),
            _ival('icmp_rules_zero'), _ival('port80_rules_zero'), _ival('port21_rules_zero')
        ]

        # ------- Tab 2: stacked bar
        _clear(self.tab_bar_stacked)
        fig_s = Figure(figsize=(12.8, 4.2), dpi=100, constrained_layout=True)
        axS = fig_s.add_subplot(1,1,1)
        x = list(range(len(labels)))
        axS.bar(x, used_vals, color=COLORS["green"], label="Used")
        axS.bar(x, zero_vals, bottom=used_vals, color=COLORS["blue"], label="Zero")
        axS.set_xticks(list(range(len(labels))))
        axS.set_xticklabels(labels, rotation=12)
        axS.set_title("Risk Patterns: Used vs Zero (stacked)")
        axS.set_ylabel("Rules"); axS.grid(axis='y', linestyle=':', alpha=0.3)
        axS.legend()
        canvas_s = FigureCanvasTkAgg(fig_s, master=self.tab_bar_stacked)
        canvas_s.draw()
        canvas_s.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        tb_s = ttk.Frame(self.tab_bar_stacked); tb_s.grid(row=1, column=0, sticky='ew')
        NavigationToolbar2Tk(canvas_s, tb_s)

        # ------- Tab 3: grouped bar
        _clear(self.tab_bar_grouped)
        fig_g = Figure(figsize=(12.8, 4.2), dpi=100, constrained_layout=True)
        axG = fig_g.add_subplot(1,1,1)
        n = len(labels); width = 0.42
        left_positions  = [i - width/2 for i in range(n)]
        right_positions = [i + width/2 for i in range(n)]
        axG.bar(left_positions,  used_vals,  width=width, color=COLORS["green"], label="Used")
        axG.bar(right_positions, zero_vals, width=width, color=COLORS["blue"],  label="Zero")
        axG.set_xticks(list(range(n)))
        axG.set_xticklabels(labels, rotation=12)
        axG.set_title("Risk Patterns: Used vs Zero (grouped)")
        axG.set_ylabel("Rules"); axG.grid(axis='y', linestyle=':', alpha=0.3)
        axG.legend()
        canvas_g = FigureCanvasTkAgg(fig_g, master=self.tab_bar_grouped)
        canvas_g.draw()
        canvas_g.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        tb_g = ttk.Frame(self.tab_bar_grouped); tb_g.grid(row=1, column=0, sticky='ew')
        NavigationToolbar2Tk(canvas_g, tb_g)

        # ------- Tab 4 lists
        self._refresh_top_lists()

    

    def _refresh_firewall_health(self):
        """Compute Total/Successful/Failed firewalls with fuzzy hostname match (>=80%).

        Total = unique hostnames in modular_collector/firewall.csv
        Successful = inventory hostname fuzzy-matches (>=80%) any hostname in reports/latest/acls.csv
        Failed = Total - Successful
        """
        import csv, os
        from difflib import SequenceMatcher

        # Resolve paths
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
        except Exception:
            base_here = os.path.dirname(os.path.abspath(__file__))
            rep_dir = os.path.join(base_here, 'modular_collector', 'reports', 'latest')

        base = os.path.dirname(os.path.abspath(__file__))
        fw_csv = os.path.join(base, 'modular_collector', 'firewall.csv')
        acls_csv = os.path.join(rep_dir, 'acls.csv')

        # Load firewall inventory (Total)
        scope_rows = []
        scope_by_host = {}
        if os.path.isfile(fw_csv):
            try:
                with open(fw_csv, 'r', encoding='utf-8', newline='') as f:
                    dr = csv.DictReader(f)
                    for r in dr:
                        h = (r.get('hostname') or '').strip()
                        if not h:
                            continue
                        plat = (r.get('platform') or r.get('vendor') or r.get('type') or '').strip()
                        ip = (r.get('ip') or r.get('mgmt_ip') or '').strip()
                        scope_rows.append((h, plat, ip))
                        scope_by_host[h] = (h, plat, ip)
            except Exception:
                scope_rows = []
                scope_by_host = {}

        total_hosts = {h for (h, _, _) in scope_rows}

        # Load ACL hostnames (observed)
        acl_hosts = set()
        if os.path.isfile(acls_csv):
            try:
                with open(acls_csv, 'r', encoding='utf-8', newline='') as f:
                    dr = csv.DictReader(f)
                    for r in dr:
                        h = (r.get('hostname') or '').strip()
                        if h:
                            acl_hosts.add(h)
            except Exception:
                acl_hosts = set()

        # Normalize and fuzzy match
        def norm(s: str) -> str:
            return (s or '').strip().lower()

        total_hosts_norm = {h: norm(h) for h in total_hosts}
        acl_hosts_norm = [norm(h) for h in acl_hosts]

        THRESH = 0.80  # 80% similarity threshold

        ok_hosts = set()
        fail_list = []

        # Fast path: exact normalized matches
        acl_exact = set(acl_hosts_norm)
        for h in sorted(total_hosts):
            hn = total_hosts_norm[h]

            if hn in acl_exact:
                ok_hosts.add(h)
                continue

            # Fuzzy match against any ACL hostname
            best = 0.0
            for other in acl_hosts_norm:
                if not other:
                    continue
                ratio = SequenceMatcher(None, hn, other).ratio()
                if ratio > best:
                    best = ratio
                if best >= THRESH:  # early stop
                    break

            if best >= THRESH:
                ok_hosts.add(h)
            else:
                fail_list.append(scope_by_host.get(h, (h, '', '')))

        # KPIs
        try:
            self.lbl_fw_total.config(text='Total Firewalls: {}'.format(len(total_hosts)))
        except Exception:
            pass
        try:
            self.lbl_fw_ok.config(text='Successful: {}'.format(len(ok_hosts)))
        except Exception:
            pass
        try:
            self.lbl_fw_fail.config(text='Failed: {}'.format(len(fail_list)))
        except Exception:
            pass

        # Failed table
        try:
            for iid in self.table_fw_failed.get_children():
                self.table_fw_failed.delete(iid)
            for i, row in enumerate(fail_list):
                self.table_fw_failed.insert('', 'end', values=row, tags=('even' if i % 2 == 0 else 'odd',))
        except Exception:
            pass

        # Badge on the charts notebook tab for Firewall Health
        try:
            failed_count = 0
            try:
                failed_count = len(fail_list)
            except Exception:
                try:
                    failed_count = int(self.lbl_fw_fail.cget('text').split(':')[-1].strip())
                except Exception:
                    failed_count = 0
            color = 'red' if failed_count > 0 else 'green'
            self._tab_set_badge_on(self.dash_charts_nb, self.tab_fw_health, 'Firewall Health', failed_count if failed_count>0 else None, color)
        except Exception:
            pass

    def _refresh_top_lists(self):
        """Populate Top Devices (by risky-used & risky-zero) and Top 10 Risky Rules (by hits)."""
        # Top Devices
        rep_dir = self._find_reports_latest_for_dashboard()
        path_used  = os.path.join(rep_dir, "risky_acl.csv")         # used-only risky
        path_zero  = os.path.join(rep_dir, "risky_zero_acl.csv")    # risky & zero-hit

        from collections import Counter
        used_by_host = Counter()
        zero_by_host = Counter()

        def load_and_count(path, counter):
            if not os.path.exists(path): return
            with open(path, "r", encoding="utf-8", newline="") as f:
                dr = csv.DictReader(f)
                for r in dr:
                    h = (r.get("hostname") or "").strip()
                    if h: counter[h] += 1

        load_and_count(path_used, used_by_host)
        load_and_count(path_zero, zero_by_host)

        all_hosts = set(used_by_host) | set(zero_by_host)
        rows = []
        for h in all_hosts:
            u = used_by_host.get(h, 0)
            z = zero_by_host.get(h, 0)
            rows.append((h, u, z, u+z))
        rows.sort(key=lambda t: (t[3], t[1]), reverse=True)
        rows = rows[:20]

        for iid in self.tree_top_dev.get_children(): self.tree_top_dev.delete(iid)
        for i, (h,u,z,t) in enumerate(rows):
            self.tree_top_dev.insert("", "end", values=(h, u, z, t), tags=("even" if i%2==0 else "odd",))

        # Top 10 Risky Rules (by hit_count, used-only)
        top_rules = []
        if os.path.exists(path_used):
            with open(path_used, "r", encoding="utf-8", newline="") as f:
                dr = csv.DictReader(f)
                for r in dr:
                    try:
                        hits = int(str(r.get("hit_count") or "0"))
                    except Exception:
                        hits = 0
                    top_rules.append((
                        hits,
                        (r.get("hostname") or "").strip(),
                        (r.get("rule_id") or r.get("policy_name") or r.get("rule_name") or "").strip(),
                        (r.get("src") or "").strip(),
                        (r.get("dst") or "").strip(),
                        (r.get("remark") or r.get("risk_description") or "").strip()
                    ))
        top_rules.sort(key=lambda t: t[0], reverse=True)
        top_rules = top_rules[:10]

        for iid in self.tree_top_rules.get_children(): self.tree_top_rules.delete(iid)
        for i, (hits,h,rule,src,dst,rem) in enumerate(top_rules):
            self.tree_top_rules.insert("", "end",
                    values=(h, rule, hits, src, dst, rem),
                    tags=("even" if i%2==0 else "odd",))

        # ensure correct frame raised based on mode
        self._toggle_top_lists()

    def _toggle_top_lists(self):
        mode = getattr(self, 'top_mode', tk.StringVar(value='devices')).get()
        try:
            if mode == "devices":
                self.frame_top_devices.tkraise()
            else:
                self.frame_top_rules.tkraise()
        except Exception:
            pass

    # ---------- Tiny tooltip helper for Treeview cells ----------
    def _attach_treeview_tooltip(self, tree, col_id):
        tip = tk.Toplevel(self.root)
        tip.withdraw()
        tip.overrideredirect(True)
        lbl = ttk.Label(tip, text="", background="#ffffe0", relief="solid", borderwidth=1)
        lbl.pack(ipadx=4, ipady=2)

        def show_tip(event, text):
            try:
                lbl.config(text=text)
                tip.update_idletasks()
                x = event.x_root + 12
                y = event.y_root + 12
                tip.geometry(f"+{x}+{y}")
                tip.deiconify()
            except Exception:
                pass

        def hide_tip(_e=None):
            try:
                tip.withdraw()
            except Exception:
                pass

        def on_motion(e):
            try:
                region = tree.identify("region", e.x, e.y)
                if region != "cell":
                    hide_tip(); return
                col = tree.identify_column(e.x) # '#1', '#2', ...
                iid = tree.identify_row(e.y)
                if not iid:
                    hide_tip(); return
                if col == "#0":
                    hide_tip(); return
                cols = list(tree.cget("columns") or [])
                try:
                    idx = int(col.replace("#", "")) - 1
                except Exception:
                    hide_tip(); return
                if idx < 0 or idx >= len(cols):
                    hide_tip(); return
                cid = cols[idx]
                if cid != col_id:
                    hide_tip(); return
                vals = tree.item(iid, "values") or ()
                try:
                    pos = cols.index(col_id)
                except ValueError:
                    hide_tip(); return
                text = vals[pos] if pos < len(vals) else ""
                if not text:
                    hide_tip(); return
                show_tip(e, str(text))
            except Exception:
                hide_tip()

        def on_leave(_e): hide_tip()

        def on_dclick(e):
            try:
                region = tree.identify("region", e.x, e.y)
                if region != "cell": return
                col = tree.identify_column(e.x)
                if col == "#0": return
                iid = tree.identify_row(e.y)
                cols = list(tree.cget("columns") or [])
                if not iid or col_id not in cols: return
                pos = cols.index(col_id)
                vals = tree.item(iid, "values") or ()
                text = vals[pos] if pos < len(vals) else ""
                if not text: return
                p = tk.Toplevel(self.root)
                p.title(col_id + " (full)")
                p.transient(self.root); p.grab_set()
                frm = ttk.Frame(p, padding=10); frm.grid(row=0, column=0, sticky="nsew")
                p.columnconfigure(0, weight=1); p.rowconfigure(0, weight=1)
                txt = tk.Text(frm, wrap="word", width=96, height=14)
                txt.grid(row=0, column=0, sticky="nsew")
                ysb = ttk.Scrollbar(frm, orient="vertical", command=txt.yview)
                ysb.grid(row=0, column=1, sticky="ns")
                txt.configure(yscrollcommand=ysb.set)
                txt.insert("end", str(text))
                txt.config(state="disabled")
                ttk.Button(frm, text="Close", command=p.destroy).grid(row=1, column=0, sticky="e", pady=(8,0))
                try:
                    p.update_idletasks()
                    sw, sh = p.winfo_screenwidth(), p.winfo_screenheight()
                    w, h = p.winfo_width(), p.winfo_height()
                    p.geometry(f"+{(sw-w)//2}+{(sh-h)//3}")
                except Exception:
                    pass
            except Exception:
                pass

        tree.bind("<Motion>", on_motion, add="+")
        tree.bind("<Leave>", on_leave, add="+")
        tree.bind("<Double-1>", on_dclick, add="+")
        return tip

    # ---------------- Header drag (column reorder) ----------------
    def _enable_header_drag(self, tree: ttk.Treeview):
        state = {"start_idx": None, "start_col": None, "dragging": False}
        def _get_cols(): return list(tree.cget("columns") or [])
        def _col_from_xy(x, y):
            if tree.identify_region(x, y) != "heading": return (None, None)
            col_token = tree.identify_column(x)
            try: idx = int(col_token.replace("#", "")) - 1
            except Exception: return (None, None)
            cols = _get_cols()
            return (cols[idx], idx) if 0 <= idx < len(cols) else (None, None)
        def _capture_config(cols):
            htxt = {c: tree.heading(c, "text") for c in cols}
            conf = {}
            for c in cols:
                conf[c] = {
                    "width": tree.column(c, "width"),
                    "minwidth": tree.column(c, "minwidth"),
                    "anchor": tree.column(c, "anchor"),
                    "stretch": bool(tree.column(c, "stretch")),
                }
            return htxt, conf
        def _reorder_columns(new_cols):
            old_cols = _get_cols()
            if old_cols == new_cols: return
            htxt, conf = _capture_config(old_cols)
            old_index = {c: i for i, c in enumerate(old_cols)}
            for iid in tree.get_children(""):
                vals = list(tree.item(iid, "values") or [])
                new_vals = []
                for c in new_cols:
                    oi = old_index.get(c, None)
                    new_vals.append(vals[oi] if (oi is not None and oi < len(vals)) else "")
                tree.item(iid, values=tuple(new_vals))
            tree["columns"] = tuple(new_cols)
            for c in new_cols:
                tree.heading(c, text=htxt.get(c, c))
                cc = conf.get(c, {})
                tree.column(c, width=cc.get("width", 120),
                               minwidth=cc.get("minwidth", 20),
                               anchor=cc.get("anchor", "w"),
                               stretch=cc.get("stretch", False))
        def on_press(e):
            col, idx = _col_from_xy(e.x, e.y)
            if col is None: return
            state["start_idx"] = idx; state["start_col"] = col; state["dragging"] = True
            try: tree.configure(cursor="fleur")
            except Exception: pass
        def on_release(e):
            if not state["dragging"]: return
            try: tree.configure(cursor="")
            except Exception: pass
            tgt_col, tgt_idx = _col_from_xy(e.x, e.y)
            start_idx = state["start_idx"]; state["dragging"] = False
            if tgt_idx is None or start_idx is None or tgt_idx == start_idx: return
            cols = _get_cols()
            moving = cols.pop(start_idx)
            if start_idx < tgt_idx: tgt_idx -= 1
            cols.insert(tgt_idx, moving)
            _reorder_columns(cols)
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(tree, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        def on_motion(e): pass
        tree.bind("<ButtonPress-1>", on_press, add="+")
        tree.bind("<ButtonRelease-1>", on_release, add="+")
        tree.bind("<B1-Motion>", on_motion, add="+")

    # ---------------- Autofit primary column helper ----------------
    def _autofit_tree_columns(self, tree: ttk.Treeview, primary_col="#0", fixed_cols=("platform",), pad_px=32, min_w=260, max_w=1600):
        try:
            fnt = tkfont.nametofont(tree.cget("font")) if tree.cget("font") else tkfont.nametofont("TkDefaultFont")
        except Exception:
            fnt = tkfont.nametofont("TkDefaultFont")
        try:
            header_text = tree.heading(primary_col).get("text", primary_col)
        except Exception:
            header_text = str(primary_col)
        max_px = fnt.measure(str(header_text))
        for iid in tree.get_children(""):
            txt = tree.item(iid, "text") if primary_col == "#0" else tree.set(iid, primary_col)
            if txt:
                px = fnt.measure(str(txt)); max_px = max(max_px, px)
        measured = max(min_w, min(max_w, max_px + pad_px))
        try:
            tree.update_idletasks()
        except Exception:
            pass
        try:
            total_w = tree.winfo_width(); total_w = total_w if total_w > 1 else tree.winfo_reqwidth()
            fixed_sum = 0
            for col in fixed_cols:
                try: fixed_sum += int(tree.column(col, option="width") or 0)
                except Exception: pass
            vscroll_allow = 18
            remaining = max(0, total_w - fixed_sum - vscroll_allow)
            target_w = max(measured, remaining)
        except Exception:
            target_w = measured
        tree.column(primary_col, width=target_w, minwidth=min_w, stretch=True)
        for col in fixed_cols: tree.column(col, stretch=False)

    # ---------------- Risk & Compliance ----------------
    def _build_risk_tab(self):
        self.tab_risk = ttk.Frame(self.nb); self.nb.add(self.tab_risk, text="Risk & Compliance")
        self.tab_risk.columnconfigure(0, weight=1); self.tab_risk.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_risk); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(13): tbar.columnconfigure(c, weight=1)

        ttk.Button(tbar, text="Load risky_acl.csv", command=self._risk_load_csv_clicked).grid(row=0, column=0, sticky='w')
        ttk.Label(tbar, text="Filter (Hostname / tokens)").grid(row=0, column=2, sticky='e')
        self.risk_filter_var = tk.StringVar(value=""); flt = ttk.Entry(tbar, textvariable=self.risk_filter_var, width=28)
        flt.grid(row=0, column=3, sticky='w', padx=(6, 0)); flt.bind("<KeyRelease>", lambda _e: self._risk_apply_filter())

        ttk.Label(tbar, text="Category").grid(row=0, column=4, sticky='e')
        self.risk_category_var = tk.StringVar(value="(All)")
        self.risk_category_combo = ttk.Combobox(tbar, textvariable=self.risk_category_var, values=["(All)"], width=22, state="readonly")
        self.risk_category_combo.grid(row=0, column=5, sticky='w', padx=(6, 0))
        self.risk_category_combo.bind("<<ComboboxSelected>>", lambda _e: self._risk_apply_filter())

        ttk.Button(tbar, text="Categories…", command=self._risk_open_category_picker).grid(row=0, column=6, sticky='w', padx=(6, 0))
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._risk_export_shown).grid(row=0, column=8, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._risk_export_shown_excel).grid(row=0, column=9, sticky='e', padx=(6, 0))
        ttk.Button(tbar, text="Monitor (syslog)…", command=self._monitor_open_dialog).grid(row=0, column=1, sticky='w', padx=(6,0))
        mgr2_handler = getattr(self, '_monitor_manager_open', None)
        if mgr2_handler is None:
            mgr2_handler = lambda: messagebox.showwarning('Monitoring Manager', 'Manager not available in this build.')
        ttk.Button(tbar, text="Monitoring Manager…", command=mgr2_handler).grid(row=0, column=7, sticky='w', padx=(6,0))

        # Pagination controls
        self.risk_page_label = ttk.Label(tbar, text="Page 0/0")
        self.risk_page_label.grid(row=0, column=10, sticky='e', padx=(6, 4))
        ttk.Button(tbar, text="◀ Prev", command=self._risk_page_prev).grid(row=0, column=11, sticky='e')
        ttk.Button(tbar, text="Next ▶", command=self._risk_page_next).grid(row=0, column=12, sticky='e', padx=(6, 0))

        self.risk_wrap = ttk.Frame(self.tab_risk, borderwidth=1, relief="solid"); self.risk_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_risk.rowconfigure(2, weight=1); self.tab_risk.columnconfigure(0, weight=1)
        self.risk_wrap.rowconfigure(0, weight=1); self.risk_wrap.columnconfigure(0, weight=1); self.risk_wrap.columnconfigure(1, weight=0)

        self.risk_table = ttk.Treeview(self.risk_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="browse")
        vsb = ttk.Scrollbar(self.risk_wrap, orient="vertical", command=self.risk_table.yview)
        hsb = ttk.Scrollbar(self.risk_wrap, orient="horizontal", command=self.risk_table.xview)
        self.risk_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.risk_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.risk_table.tag_configure("odd", background="#f5f5f5"); self.risk_table.tag_configure("even", background="#ffffff")
        self._enable_header_drag(self.risk_table)

        def _refit(_e=None):
            cols = list(self.risk_table.cget("columns") or [])
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(self.risk_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        self.risk_table.bind("<Map>", _refit); self.risk_table.bind("<Configure>", _refit)

    def _detect_acl_field(self, fieldnames):
        if not fieldnames:
            return None
        original = [s for s in fieldnames if s]
        lower_map = {s.lower(): s for s in original}
        prefs = [
            "raw_ace", "acl_name", "acl",
            "policy_name", "policy",
            "rule_name", "rule",
            "rulebase",
        ]
        for p in prefs:
            if p in lower_map:
                return lower_map[p]
        return None

    def _risk_load_csv_clicked(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path = os.path.join(rep_dir, 'risky_acl.csv')
        for iid in self.risk_table.get_children(): self.risk_table.delete(iid)
        self._risk_rows_cache = []; self._risk_categories_all = []; self._risk_selected_categories = set()
        self._risk_field_order = []; self._risk_category_field = None
        if not os.path.exists(path):
            try:
                messagebox.showwarning("Risky ACL", f"File not found:\n{path}")
            except Exception: pass
            return
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f); rows = list(dr); fieldnames = list(dr.fieldnames or [])
                self._risk_field_order = fieldnames
                self._risk_acl_field = self._detect_acl_field(fieldnames) or "raw_ace"
                low = {c.lower(): c for c in fieldnames}
                self._risk_category_field = low.get("risk") or low.get("category") or None
                def _has_risky_zero(d):
                    blob = ((d.get('risk','') or '') + ' ' + (d.get('risk_description','') or '')).lower()
                    return 'risky_zero_hit' in blob
                rows = [r for r in rows if not _has_risky_zero(r)]
        except Exception as e:
            try:
                messagebox.showerror("Risky ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return
        self._risk_rows_cache = rows
        self.risk_table["columns"] = tuple(self._risk_field_order)
        for col in self._risk_field_order:
            head_text = "ACL" if col == self._risk_acl_field else col
            self.risk_table.heading(col, text=head_text)
            w = 140; anchor = 'w'; stretch = False
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
            if lc in ("raw_ace", self._risk_acl_field.lower()): w, anchor, stretch = max(420, w), 'w', True
            if lc in ("remark", "risk_description"): w, anchor, stretch = max(320, w), 'w', True
            self.risk_table.column(col, width=w, anchor=anchor, stretch=stretch)

        cat_set = set()
        if self._risk_category_field:
            for r in rows:
                val = (r.get(self._risk_category_field) or "").strip()
                if val: cat_set.add(val)
        self._risk_categories_all = sorted(cat_set, key=lambda s: s.lower())
        values = ["(All)"] + self._risk_categories_all if self._risk_categories_all else ["(All)"]
        self.risk_category_combo.configure(values=values, state="readonly" if self._risk_categories_all else "disabled")
        self.risk_category_var.set("(All)")

        for cid in ("hostname", self._risk_acl_field, "remark", "risk_description"):
            if cid in self._risk_field_order:
                try: self._attach_treeview_tooltip(self.risk_table, cid)
                except Exception: pass

        self._risk_apply_filter()

    def _risk_apply_filter(self):
        raw = (self.risk_filter_var.get() or '').strip()
        host_token = raw
        token_cats = None
        m = re.search(r'(category|risk)\s*:\s*([a-zA-Z0-9_,\-\s]+)', raw, flags=re.IGNORECASE)
        if m:
            parts = [p.strip() for p in re.split(r'[;,]', m.group(2)) if p.strip()]
            token_cats = set(p.lower() for p in parts) if parts else None
            host_token = (raw[:m.start()] + raw[m.end():]).strip()
        if token_cats is not None:
            host_token = ''
        if self._risk_selected_categories:
            active_categories = set(c.lower() for c in self._risk_selected_categories)
        elif token_cats is not None:
            active_categories = token_cats
        else:
            sel = (self.risk_category_var.get() or '').strip()
            active_categories = {sel.lower()} if (sel and sel != '(All)' and self._risk_category_field) else None
        for iid in self.risk_table.get_children():
            self.risk_table.delete(iid)
        def gv(r,k): return (r.get(k,'') or '').strip()
        host_sub = host_token.lower(); out_rows = []
        for r in self._risk_rows_cache:
            if host_sub and 'hostname' in self._risk_field_order:
                if host_sub not in gv(r,'hostname').lower():
                    continue
            if active_categories and self._risk_category_field:
                cell = gv(r, self._risk_category_field).lower()
                if token_cats is not None:
                    if not any(tok in cell for tok in active_categories):
                        continue
                else:
                    if cell not in active_categories:
                        continue
            out_rows.append(r)
        self._risk_pager = Paginator(out_rows, page_size=100)
        self._risk_render_page()

    def _risk_render_page(self):
        try:
            for iid in self.risk_table.get_children(): self.risk_table.delete(iid)
        except Exception: pass
        rows = self._risk_pager.slice() if getattr(self, "_risk_pager", None) else []
        cols = list(self._risk_field_order or (self.risk_table.cget("columns") or []))
        def gv(r, k): return (r.get(k, "") or "").strip()
        for i, r in enumerate(rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [gv(r, c) for c in cols]
            self.risk_table.insert("", "end", values=tuple(vals), tags=(tag,))
        try:
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                self._autofit_tree_columns(self.risk_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
        except Exception: pass
        try:
            self.risk_page_label.config(text=f"Page {self._risk_pager.page}/{self._risk_pager.total_pages}")
        except Exception: pass

    def _risk_page_prev(self):
        if getattr(self, "_risk_pager", None):
            self._risk_pager.prev(); self._risk_render_page()

    def _risk_page_next(self):
        if getattr(self, "_risk_pager", None):
            self._risk_pager.next(); self._risk_render_page()

    def _risk_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_acl_filtered.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_acl_filtered.csv")
        cols = list(self._risk_field_order or (self.risk_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols); dw.writeheader()
                for iid in self.risk_table.get_children():
                    vals = list(self.risk_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export CSV", f"Exported {len(self.risk_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _risk_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_acl_filtered.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_acl_filtered.xlsx")
        cols = list(self._risk_field_order or (self.risk_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Risky ACL (filtered)"; ws.append(cols)
            for iid in self.risk_table.get_children():
                vals = list(self.risk_table.item(iid, "values") or []); ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None: continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 120)
            wb.save(out_path)
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export Excel", f"Exported {len(self.risk_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _risk_open_category_picker(self):
        if not (self._risk_categories_all and self._risk_category_field):
            try:
                messagebox.showinfo("Categories", "No categories available. Load risky_acl.csv first.")
            except Exception: pass
            return
        top = tk.Toplevel(self.root); top.title("Select Categories"); top.transient(self.root); top.grab_set()
        try: top.resizable(False, True)
        except Exception: pass
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1); top.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)
        # Status strip (debugging aid): shows ledger path + row count
        status = ttk.Label(frm, text="", foreground="grey")
        status.grid(row=2, column=0, sticky='ew', pady=(6,0))
        canvas = tk.Canvas(frm, highlightthickness=0); cscroll = ttk.Scrollbar(frm, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas); inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw"); canvas.configure(yscrollcommand=cscroll.set, width=360, height=260)
        canvas.grid(row=0, column=0, sticky='nsew'); cscroll.grid(row=0, column=1, sticky='ns')
        frm.rowconfigure(0, weight=1); frm.columnconfigure(0, weight=1)
        # Status strip (debugging aid): shows ledger path + row count
        status = ttk.Label(frm, text="", foreground="grey")
        status.grid(row=2, column=0, sticky='ew', pady=(6,0))
        var_map = {}
        for i, cat in enumerate(self._risk_categories_all):
            v = tk.BooleanVar(value=(cat in self._risk_selected_categories))
            ttk.Checkbutton(inner, text=cat, variable=v).grid(row=i, column=0, sticky='w', padx=4, pady=2); var_map[cat] = v
        btns = ttk.Frame(frm); btns.grid(row=1, column=0, columnspan=2, sticky='e', pady=(8, 0))
        def on_ok():
            selected = {c for c, v in var_map.items() if v.get()}
            self._risk_selected_categories = selected
            if selected: self.risk_category_var.set("(All)")
            self._risk_apply_filter(); top.destroy()
        def on_clear():
            for v in var_map.values(): v.set(False)
        ttk.Button(btns, text="Clear", command=on_clear).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)
        try:
            top.update_idletasks()
            w = top.winfo_width(); h = top.winfo_height()
            sw = top.winfo_screenwidth(); sh = top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception: pass

    # ---------------- Zero‑hit ACL ----------------
    def _build_zero_tab(self):
        self.tab_zero = ttk.Frame(self.nb); self.nb.add(self.tab_zero, text="Zero‑hit ACL")
        self.tab_zero.columnconfigure(0, weight=1); self.tab_zero.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_zero); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(15): tbar.columnconfigure(c, weight=1)

        ttk.Button(tbar, text="Load zero_acl.csv", command=self._zero_load_csv_clicked).grid(row=0, column=0, sticky='w')
        ttk.Label(tbar, text="Filter (Hostname / tokens)").grid(row=0, column=2, sticky='e')
        self.zero_filter_var = tk.StringVar(value=""); zflt = ttk.Entry(tbar, textvariable=self.zero_filter_var, width=28)
        zflt.grid(row=0, column=3, sticky='w', padx=(6, 0)); zflt.bind("<KeyRelease>", lambda _e: self._zero_apply_filter())

        ttk.Label(tbar, text="Category").grid(row=0, column=4, sticky='e')
        self.zero_category_var = tk.StringVar(value="(All)")
        self.zero_category_combo = ttk.Combobox(tbar, textvariable=self.zero_category_var, values=["(All)"], width=22, state="disabled")
        self.zero_category_combo.grid(row=0, column=5, sticky='w', padx=(6, 0))
        self.zero_category_combo.bind("<<ComboboxSelected>>", lambda _e: self._zero_apply_filter())
        self.zero_cat_btn = ttk.Button(tbar, text="Categories…", command=self._zero_open_category_picker, state="disabled")
        self.zero_cat_btn.grid(row=0, column=6, sticky='w', padx=(6, 0))

        ttk.Button(tbar, text="Send to Remediation", command=self._zero_send_selected_to_remediation).grid(row=0, column=7, sticky='w', padx=(12, 0))
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._zero_export_shown).grid(row=0, column=10, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._zero_export_shown_excel).grid(row=0, column=11, sticky='e', padx=(6, 0))

        self.zero_page_label = ttk.Label(tbar, text="Page 0/0")
        self.zero_page_label.grid(row=0, column=12, sticky='e', padx=(6, 4))
        ttk.Button(tbar, text="◀ Prev", command=self._zero_page_prev).grid(row=0, column=13, sticky='e')
        ttk.Button(tbar, text="Next ▶", command=self._zero_page_next).grid(row=0, column=14, sticky='e', padx=(6, 0))

        self.zero_wrap = ttk.Frame(self.tab_zero, borderwidth=1, relief="solid"); self.zero_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_zero.rowconfigure(2, weight=1); self.tab_zero.columnconfigure(0, weight=1)
        self.zero_wrap.rowconfigure(0, weight=1); self.zero_wrap.columnconfigure(0, weight=1); self.zero_wrap.columnconfigure(1, weight=0)

        self.zero_table = ttk.Treeview(self.zero_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        self.zero_table.bind("<Control-a>", lambda e: (self.zero_table.selection_set(self.zero_table.get_children()), "break"))
        vsb = ttk.Scrollbar(self.zero_wrap, orient="vertical", command=self.zero_table.yview)
        hsb = ttk.Scrollbar(self.zero_wrap, orient="horizontal", command=self.zero_table.xview)
        self.zero_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.zero_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.zero_table.tag_configure("odd", background="#f5f5f5"); self.zero_table.tag_configure("even", background="#ffffff")
        self._enable_header_drag(self.zero_table)

        def _refit_zero(_e=None):
            cols = list(self.zero_table.cget("columns") or [])
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                try:
                    self._autofit_tree_columns(self.zero_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
                except Exception: pass
        self.zero_table.bind("<Map>", _refit_zero); self.zero_table.bind("<Configure>", _refit_zero)

    def _zero_load_csv_clicked(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path = os.path.join(rep_dir, 'zero_acl.csv')
        for iid in self.zero_table.get_children(): self.zero_table.delete(iid)
        self._zero_rows_cache = []; self._zero_categories_all = []; self._zero_selected_categories = set()
        self._zero_field_order = []; self._zero_category_field = None
        if not os.path.exists(path):
            try:
                messagebox.showwarning("Zero‑hit ACL", f"File not found:\n{path}")
            except Exception: pass
            return
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f); rows = list(dr); fieldnames = list(dr.fieldnames or [])
                self._zero_field_order = fieldnames
                self._zero_acl_field = self._detect_acl_field(fieldnames) or "raw_ace"
                low = {c.lower(): c for c in fieldnames}
                self._zero_category_field = low.get("category") or low.get("risk") or None
        except Exception as e:
            try:
                messagebox.showerror("Zero‑hit ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return
        self._zero_rows_cache = rows
        self.zero_table["columns"] = tuple(self._zero_field_order)
        for col in self._zero_field_order:
            head_text = "ACL" if col == self._zero_acl_field else col
            self.zero_table.heading(col, text=head_text)
            w = 140; anchor = 'w'; stretch = False
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
            if lc in ("raw_ace", self._zero_acl_field.lower()): w, anchor, stretch = max(420, w), 'w', True
            if lc in ("remark", "risk_description"): w, anchor, stretch = max(320, w), 'w', True
            self.zero_table.column(col, width=w, anchor=anchor, stretch=stretch)

        for cid in ("hostname", self._zero_acl_field, "remark", "risk_description"):
            if cid in self._zero_field_order:
                try: self._attach_treeview_tooltip(self.zero_table, cid)
                except Exception: pass

        self._zero_apply_filter()

    def _zero_apply_filter(self):
        raw = (self.zero_filter_var.get() or '').strip()
        host_token = raw
        token_cats = None
        m = re.search(r'(category|risk)\s*:\s*([a-zA-Z0-9_,\-\s]+)', raw, flags=re.IGNORECASE)
        if m:
            parts = [p.strip() for p in re.split(r'[;,]', m.group(2)) if p.strip()]
            token_cats = set(p.lower() for p in parts) if parts else None
            host_token = (raw[:m.start()] + raw[m.end():]).strip()
        if token_cats is not None:
            host_token = ''
        if self._zero_selected_categories:
            active_categories = set(c.lower() for c in self._zero_selected_categories)
        elif token_cats is not None:
            active_categories = token_cats
        else:
            sel = (self.zero_category_var.get() or '').strip()
            active_categories = {sel.lower()} if (sel and sel != '(All)' and self._zero_category_field) else None
        for iid in self.zero_table.get_children():
            self.zero_table.delete(iid)
        def gv(r,k): return (r.get(k,'') or '').strip()
        host_sub = host_token.lower(); out_rows = []
        for r in self._zero_rows_cache:
            if host_sub and 'hostname' in self._zero_field_order:
                if host_sub not in gv(r,'hostname').lower():
                    continue
            if active_categories and self._zero_category_field:
                cell = gv(r, self._zero_category_field).lower()
                if token_cats is not None:
                    if not any(tok in cell for tok in active_categories):
                        continue
                else:
                    if cell not in active_categories:
                        continue
            out_rows.append(r)
        self._zero_pager = Paginator(out_rows, page_size=100)
        self._zero_render_page()

    def _zero_render_page(self):
        try:
            for iid in self.zero_table.get_children(): self.zero_table.delete(iid)
        except Exception: pass
        rows = self._zero_pager.slice() if getattr(self, "_zero_pager", None) else []
        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        def gv(r, k): return (r.get(k, "") or "").strip()
        for i, r in enumerate(rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [gv(r, c) for c in cols]
            self.zero_table.insert("", "end", values=tuple(vals), tags=(tag,))
        try:
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                self._autofit_tree_columns(self.zero_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
        except Exception: pass
        try:
            self.zero_page_label.config(text=f"Page {self._zero_pager.page}/{self._zero_pager.total_pages}")
        except Exception: pass

    def _zero_page_prev(self):
        if getattr(self, "_zero_pager", None):
            self._zero_pager.prev(); self._zero_render_page()

    def _zero_page_next(self):
        if getattr(self, "_zero_pager", None):
            self._zero_pager.next(); self._zero_render_page()

    def _zero_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "zero_acl_filtered.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "zero_acl_filtered.csv")
        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols)
                dw.writeheader()
                for iid in self.zero_table.get_children():
                    vals = list(self.zero_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export CSV", f"Exported {len(self.zero_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _zero_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "zero_acl_filtered.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "zero_acl_filtered.xlsx")
        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Zero‑hit ACL (filtered)"
            ws.append(cols)
            for iid in self.zero_table.get_children():
                vals = list(self.zero_table.item(iid, "values") or [])
                ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None:
                        continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 120)
            wb.save(out_path)
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export Excel", f"Exported {len(self.zero_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _zero_open_category_picker(self):
        if not (self._zero_categories_all and self._zero_category_field):
            try:
                messagebox.showinfo("Categories", "No categories available. Load zero_acl.csv first.")
            except Exception: pass
            return
        top = tk.Toplevel(self.root)
        top.title("Select Categories")
        top.transient(self.root)
        top.grab_set()
        try:
            top.resizable(False, True)
        except Exception:
            pass
        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1)
        top.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)
        # Status strip (debugging aid): shows ledger path + row count
        status = ttk.Label(frm, text="", foreground="grey")
        status.grid(row=2, column=0, sticky='ew', pady=(6,0))
        canvas = tk.Canvas(frm, highlightthickness=0)
        cscroll = ttk.Scrollbar(frm, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=cscroll.set, width=360, height=260)
        canvas.grid(row=0, column=0, sticky='nsew')
        cscroll.grid(row=0, column=1, sticky='ns')
        frm.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)
        # Status strip (debugging aid): shows ledger path + row count
        status = ttk.Label(frm, text="", foreground="grey")
        status.grid(row=2, column=0, sticky='ew', pady=(6,0))
        var_map = {}
        for i, cat in enumerate(self._zero_categories_all):
            v = tk.BooleanVar(value=(cat in self._zero_selected_categories))
            ttk.Checkbutton(inner, text=cat, variable=v).grid(row=i, column=0, sticky='w', padx=4, pady=2)
            var_map[cat] = v
        btns = ttk.Frame(frm)
        btns.grid(row=1, column=0, columnspan=2, sticky='e', pady=(8, 0))
        def on_ok():
            selected = {c for c, v in var_map.items() if v.get()}
            self._zero_selected_categories = selected
            if selected:
                self.zero_category_var.set("(All)")
            self._zero_apply_filter()
            top.destroy()
        def on_clear():
            for v in var_map.values():
                v.set(False)
        ttk.Button(btns, text="Clear", command=on_clear).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)
        try:
            top.update_idletasks()
            w, h = top.winfo_width(), top.winfo_height()
            sw, sh = top.winfo_screenwidth(), top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception:
            pass

    def _zero_send_selected_to_remediation(self):
        iids = self.zero_table.selection()
        if not iids:
            try:
                messagebox.showinfo(
                    "Send to Remediation",
                    "No rows selected. Use multi‑select or Ctrl+A, then retry."
                )
            except Exception:
                pass
            return
        cols = list(self._zero_field_order or (self.zero_table.cget("columns") or []))
        rows = []
        for iid in iids:
            vals = list(self.zero_table.item(iid, "values") or [])
            row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
            rows.append(row)
        added = self._remed_add_rows(rows, cols)
        try:
            messagebox.showinfo("Send to Remediation", f"Sent {added} new row(s) to Remediation.")
        except Exception: pass
        try:
            self.nb.select(self.tab_remed)
        except Exception:
            pass

    # ---------------- Risky & Zero‑hit (NEW TAB) ----------------
    def _build_riskyzero_tab(self):
        self.tab_riskyzero = ttk.Frame(self.nb)
        self.nb.add(self.tab_riskyzero, text="Risky & Zero‑hit")
        self.tab_riskyzero.columnconfigure(0, weight=1)
        self.tab_riskyzero.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_riskyzero)
        tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(15): tbar.columnconfigure(c, weight=1)

        ttk.Button(tbar, text="Load risky_zero_acl.csv", command=self._riskyzero_load_csv_clicked).grid(row=0, column=0, sticky='w')
        ttk.Label(tbar, text="Filter (Hostname / tokens)").grid(row=0, column=2, sticky='e')
        self.rz_filter_var = tk.StringVar(value="")
        rzflt = ttk.Entry(tbar, textvariable=self.rz_filter_var, width=28)
        rzflt.grid(row=0, column=3, sticky='w', padx=(6, 0))
        rzflt.bind("<KeyRelease>", lambda _e: self._riskyzero_apply_filter())

        ttk.Button(tbar, text="Send to Remediation", command=self._riskyzero_send_selected_to_remediation).grid(row=0, column=7, sticky='w', padx=(12, 0))
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._riskyzero_export_shown).grid(row=0, column=10, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._riskyzero_export_shown_excel).grid(row=0, column=11, sticky='e', padx=(6, 0))
        self.rz_page_label = ttk.Label(tbar, text="Page 0/0")
        self.rz_page_label.grid(row=0, column=12, sticky='e', padx=(6, 4))
        ttk.Button(tbar, text="◀ Prev", command=self._riskyzero_page_prev).grid(row=0, column=13, sticky='e')
        ttk.Button(tbar, text="Next ▶", command=self._riskyzero_page_next).grid(row=0, column=14, sticky='e', padx=(6, 0))

        self.rz_wrap = ttk.Frame(self.tab_riskyzero, borderwidth=1, relief="solid")
        self.rz_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_riskyzero.rowconfigure(2, weight=1)
        self.tab_riskyzero.columnconfigure(0, weight=1)
        self.rz_wrap.rowconfigure(0, weight=1)
        self.rz_wrap.columnconfigure(0, weight=1)
        self.rz_wrap.columnconfigure(1, weight=0)

        self.rz_table = ttk.Treeview(self.rz_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        self.rz_table.bind("<Control-a>", lambda e: (self.rz_table.selection_set(self.rz_table.get_children()), "break"))
        vsb = ttk.Scrollbar(self.rz_wrap, orient="vertical", command=self.rz_table.yview)
        hsb = ttk.Scrollbar(self.rz_wrap, orient="horizontal", command=self.rz_table.xview)
        self.rz_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.rz_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.rz_table.tag_configure("odd", background="#f5f5f5"); self.rz_table.tag_configure("even", background="#ffffff")
        self._enable_header_drag(self.rz_table)

        # init caches
        self._rz_rows_cache = []
        self._rz_field_order = []
        self._rz_pager = None

    def _riskyzero_load_csv_clicked(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path_primary  = os.path.join(rep_dir, 'risky_zero_acl.csv')
        path_backup   = os.path.join(rep_dir, 'risky_all.csv')

        for iid in self.rz_table.get_children(): self.rz_table.delete(iid)
        self._rz_rows_cache = []; self._rz_field_order = []; self._rz_pager = None

        src = None
        if os.path.exists(path_primary):
            src = ('direct', path_primary)
        elif os.path.exists(path_backup):
            src = ('filter', path_backup)
        else:
            try: messagebox.showwarning("Risky & Zero‑hit",
                                       f"Not found:\n - {path_primary}\n - {path_backup}\nRun dashboard.py and try again.")
            except Exception: pass
            return

        try:
            with open(src[1], 'r', encoding='utf-8', newline='') as f:
                dr = csv.DictReader(f); rows = list(dr); fieldnames = list(dr.fieldnames or [])
        except Exception as e:
            try:
                messagebox.showerror("Risky & Zero‑hit", f"Failed to read:\n{src[1]}\n\n{e}")
            except Exception: pass
            return

        if src[0] == 'filter':
            def _has_tag(d):
                r = (d.get('risk','') or '') + ' ' + (d.get('risk_description','') or '')
                return 'risky_zero_hit' in r.lower()
            rows = [r for r in rows if _has_tag(r)]

        self._rz_rows_cache = rows
        self._rz_field_order = fieldnames
        self.rz_table["columns"] = tuple(self._rz_field_order or ())
        for col in (self._rz_field_order or []):
            self.rz_table.heading(col, text=col)
            w = 140; anchor = 'w'; stretch = False
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
            if lc in ("raw_ace", "remark", "risk_description"): w, anchor, stretch = max(420, w), 'w', True
            self.rz_table.column(col, width=w, anchor=anchor, stretch=stretch)
        for cid in ("hostname","raw_ace","remark","risk_description"):
            if self._rz_field_order and cid in self._rz_field_order:
                try: self._attach_treeview_tooltip(self.rz_table, cid)
                except Exception: pass
        self._riskyzero_apply_filter()

    def _riskyzero_apply_filter(self):
        raw = (self.rz_filter_var.get() or "").strip()
        host_token = raw
        def gv(r, k): return (r.get(k, "") or "").strip()
        host_sub = host_token.lower()
        out_rows = []
        for r in self._rz_rows_cache:
            if host_sub and self._rz_field_order and "hostname" in self._rz_field_order:
                if host_sub not in gv(r, "hostname").lower(): continue
            out_rows.append(r)
        self._rz_pager = Paginator(out_rows, page_size=100)
        self._riskyzero_render_page()

    def _riskyzero_render_page(self):
        try:
            for iid in self.rz_table.get_children(): self.rz_table.delete(iid)
        except Exception: pass
        rows = self._rz_pager.slice() if getattr(self, "_rz_pager", None) else []
        cols = list(self._rz_field_order or (self.rz_table.cget("columns") or []))
        def gv(r, k): return (r.get(k, "") or "").strip()
        for i, r in enumerate(rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [gv(r, c) for c in cols]
            self.rz_table.insert("", "end", values=tuple(vals), tags=(tag,))
        try:
            if "hostname" in cols:
                fixed = tuple([c for c in cols if c != "hostname"])
                self._autofit_tree_columns(self.rz_table, primary_col="hostname", fixed_cols=fixed, pad_px=32, min_w=260, max_w=2000)
        except Exception: pass
        try:
            self.rz_page_label.config(text=f"Page {self._rz_pager.page}/{self._rz_pager.total_pages}")
        except Exception: pass

    def _riskyzero_page_prev(self):
        if getattr(self, "_rz_pager", None):
            self._rz_pager.prev(); self._riskyzero_render_page()

    def _riskyzero_page_next(self):
        if getattr(self, "_rz_pager", None):
            self._rz_pager.next(); self._riskyzero_render_page()

    def _riskyzero_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_zero_hit_filtered.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_zero_hit_filtered.csv")
        cols = list(self._rz_field_order or (self.rz_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols); dw.writeheader()
                for iid in self.rz_table.get_children():
                    vals = list(self.rz_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export CSV", f"Exported {len(self.rz_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _riskyzero_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "risky_zero_hit_filtered.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "risky_zero_hit_filtered.xlsx")
        cols = list(self._rz_field_order or (self.rz_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Risky & Zero‑hit (filtered)"; ws.append(cols)
            for iid in self.rz_table.get_children():
                vals = list(self.rz_table.item(iid, "values") or []); ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None: continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 120)
            wb.save(out_path)
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export Excel", f"Exported {len(self.rz_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _riskyzero_send_selected_to_remediation(self):
        iids = self.rz_table.selection()
        if not iids:
            try:
                messagebox.showinfo(
                    "Send to Remediation",
                    "No rows selected. Use multi‑select or Ctrl+A, then retry."
                )
            except Exception:
                pass
            return
        cols = list(self._rz_field_order or (self.rz_table.cget("columns") or []))
        rows = []
        for iid in iids:
            vals = list(self.rz_table.item(iid, "values") or [])
            row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
            rows.append(row)
        added = self._remed_add_rows(rows, cols)
        try:
            messagebox.showinfo("Send to Remediation", f"Sent {added} new row(s) to Remediation.")
        except Exception: pass
        try:
            self.nb.select(self.tab_remed)
        except Exception:
            pass


    # --------- Monitoring (Syslog reader for wide rules) ---------
    def _monitor_open_dialog(self):
        sel = self.risk_table.selection()
        # Try to prefill hostname & rule
        pre_host = ''
        pre_rule = ''
        cols = list(self._risk_field_order or (self.risk_table.cget('columns') or []))
        if sel:
            vals = list(self.risk_table.item(sel[0], 'values') or [])
            m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
            pre_host = (m.get('hostname') or m.get('device') or '').strip()
            # prefer known rule id fields
            for k in ('rule_id','policy_name','rule_name','acl_name','acl','policy','rule'):
                if k in m and m[k]: pre_rule = m[k]; break
        top = tk.Toplevel(self.root); top.title('Monitor ACL (Syslog)'); top.transient(self.root); top.grab_set()
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        for c in range(4): frm.columnconfigure(c, weight=1)
        ttk.Label(frm, text='Syslog root (UNC path)').grid(row=0, column=0, sticky='w')
        self._mon_root = tk.StringVar(value=r'\\syslog\logs\firewalls')
        ttk.Entry(frm, textvariable=self._mon_root, width=48).grid(row=0, column=1, columnspan=3, sticky='ew')
        ttk.Label(frm, text='Hostname').grid(row=1, column=0, sticky='w')
        self._mon_host = tk.StringVar(value=pre_host)
        ttk.Entry(frm, textvariable=self._mon_host, width=28).grid(row=1, column=1, sticky='w')
        ttk.Label(frm, text='Platform').grid(row=1, column=2, sticky='e')
        self._mon_plat = tk.StringVar(value='Palo Alto')
        ttk.Combobox(frm, textvariable=self._mon_plat, values=['Palo Alto','ASA','SRX'], state='readonly', width=14).grid(row=1, column=3, sticky='w')
        ttk.Label(frm, text='Wide Rule (filter)').grid(row=2, column=0, sticky='w')
        self._mon_rule = tk.StringVar(value=pre_rule)
        ttk.Entry(frm, textvariable=self._mon_rule, width=48).grid(row=2, column=1, columnspan=3, sticky='ew')
        self._mon_regex = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text='Regex', variable=self._mon_regex).grid(row=3, column=1, sticky='w', pady=(6,0))
        btns = ttk.Frame(frm); btns.grid(row=4, column=0, columnspan=4, sticky='e', pady=(10,0))
        ttk.Button(btns, text='Start', command=lambda: (self._monitor_start() and top.destroy())).grid(row=0, column=0, padx=(0,8))
        ttk.Button(btns, text='Stop', command=lambda: (self._monitor_stop() and top.destroy())).grid(row=0, column=1)
        try:
            top.update_idletasks(); sw, sh = top.winfo_screenwidth(), top.winfo_screenheight(); w, h = top.winfo_width(), top.winfo_height(); top.geometry(f"+{(sw-w)//2}+{(sh-h)//3}")
        except Exception:
            pass

    def _monitor_key(self, host, rule):
        return f"{_safe_name(host)}__{_safe_name(rule)}"

    def _monitor_sheet_path(self, host, rule):
        return os.path.join(_mon_reports_dir(), f"{_safe_name(host)}__{_safe_name(rule)}.csv")

    def _monitor_start(self):
        root = (self._mon_root.get() or '').strip(); host = (self._mon_host.get() or '').strip(); plat = (self._mon_plat.get() or '').strip(); rule = (self._mon_rule.get() or '').strip()
        if not (root and host and plat and rule):
            try: messagebox.showwarning('Monitor', 'Please enter Syslog root, Hostname, Platform, and Wide Rule filter.');
            except Exception: pass
            return False
        key = self._monitor_key(host, rule)
        if not hasattr(self, '_monitors'): self._monitors = {}
        if key in self._monitors and self._monitors[key]['running']:
            try: messagebox.showinfo('Monitor', 'Already running for this host/rule.');
            except Exception: pass
            return False
        # init state
        self._monitors[key] = {
            'root': root, 'host': host, 'plat': plat, 'rule': rule, 'regex': bool(self._mon_regex.get()),
            'agg': MonAgg(), 'running': True, 'last_hashes': set()
        }
        # Ensure sheet header exists
        path = self._monitor_sheet_path(host, rule)
        if not os.path.exists(path):
            try:
                with open(path, 'w', encoding='utf-8', newline='') as f:
                    dw = csv.writer(f); dw.writerow(['timestamp','src','dst','proto','dport'])
            except Exception: pass
        # --- monitor status: mark running ---
        now = time.strftime('%Y-%m-%d %H:%M:%S')
        sheet = self._monitor_sheet_path(host, rule)
        _mon_status_upsert({
            'key': self._monitor_key(host, rule),
            'hostname': host, 'platform': plat,
            'rule_filter': rule, 'is_regex': '1' if bool(self._mon_regex.get()) else '0',
            'syslog_root': root, 'state': 'running',
            'started_at': now, 'stopped_at': '',
            'last_heartbeat': now,
            'sheet_path': sheet, 'snippet_path': '',
            'total_rows': '0', 'unique_pairs': '0',
            'first_seen': '', 'last_seen': '', 'remarks': '',
        })

        # spawn worker
        threading.Thread(target=self._monitor_worker, args=(key,), daemon=True).start()
        self._status(f"Monitoring started: {host} / {rule}", 'blue')
        return True

    def _monitor_stop(self):
        if not hasattr(self, '_monitors') or not self._monitors:
            return False
        # stop all for now (v1)
        for k in list(self._monitors.keys()):
            self._monitors[k]['running'] = False
            # on stop: build ACL snippet and push to remediation
            try:
                self._monitor_finalize_to_remediation(k)
            except Exception:
                pass
        self._status('Monitoring stopped', 'orange')
        return True

    def _monitor_worker(self, key):
        try:
            st = self._monitors.get(key)
            if not st: return
            root = st['root']; host = st['host']; plat = st['plat']; rule = st['rule']; regex = st['regex']
            path_csv = self._monitor_sheet_path(host, rule)
            rx = None
            if regex:
                try: rx = re.compile(rule, re.IGNORECASE)
                except Exception: rx = None
            # polling loop
            while st['running']:
                lines = read_recent_lines_from_host_dir(root, host, limit_bytes=65536)
                now_str = time.strftime('%Y-%m-%d %H:%M:%S')
                for ln in lines[-1000:]:  # process last chunk
                    hit = parse_line_for_hit(ln, plat)
                    if not hit: continue
                    rname = hit.get('rule','') or ''
                    ok = False
                    if rx: ok = bool(rx.search(rname))
                    else: ok = (rule.lower() in rname.lower()) if rname else False
                    if not ok: continue
                    src, dst, proto, dport = hit.get('src'), hit.get('dst'), hit.get('proto'), hit.get('dport')
                    # de-dup within this poll pass
                    h = (src, dst, proto, dport, ln[-64:])
                    if h in st['last_hashes']: continue
                    st['last_hashes'].add(h)
                    # append to sheet
                    try:
                        with open(path_csv, 'a', encoding='utf-8', newline='') as f:
                            dw = csv.writer(f); dw.writerow([now_str, src, dst, proto, dport])
                    except Exception:
                        pass
                    st['agg'].add(now_str, src, dst, proto, dport)
                # ---- heartbeat/status update ----
                try:
                    key2 = self._monitor_key(host, rule)
                    agg_rows = list(st['agg'].rows())
                    unique_pairs = len(agg_rows)
                    total_rows = 0
                    try:
                        with open(path_csv, 'r', encoding='utf-8', newline='') as f:
                            total_rows = max(0, sum(1 for _ in f) - 1)
                    except Exception:
                        total_rows = 0
                    first_seen = min((r[4] for r in agg_rows), default='')
                    last_seen  = max((r[5] for r in agg_rows), default='')
                    _mon_status_upsert({
                        'key': key2, 'hostname': host, 'platform': plat,
                        'rule_filter': rule, 'is_regex': '1' if regex else '0',
                        'syslog_root': root, 'state': 'running',
                        'started_at': '', 'stopped_at': '',
                        'last_heartbeat': time.strftime('%Y-%m-%d %H:%M:%S'),
                        'sheet_path': path_csv, 'snippet_path': '',
                        'total_rows': str(total_rows), 'unique_pairs': str(unique_pairs),
                        'first_seen': first_seen, 'last_seen': last_seen, 'remarks': ''
                    })
                except Exception:
                    pass

                # trim hash set
                if len(st['last_hashes']) > 5000:
                    st['last_hashes'] = set(list(st['last_hashes'])[-2500:])
                time.sleep(3)
        except Exception:
            pass

    def _monitor_finalize_to_remediation(self, key):
        st = self._monitors.get(key)
        if not st: return
        host = st['host']; plat = st['plat']; rule = st['rule']
        rows = list(st['agg'].rows())
        # Build object-groups
        srcs = sorted({r[0] for r in rows})
        dsts = sorted({r[1] for r in rows})
        services = sorted({r[2] for r in rows})  # proto/port
        ts_tag = time.strftime('%Y%m%d_%H%M')
        src_og = f"SRC_{_safe_name(rule)}_{ts_tag}"
        dst_og = f"DST_{_safe_name(rule)}_{ts_tag}"
        svc_og = f"SVC_{_safe_name(rule)}_{ts_tag}"
        snippet = []
        if plat.lower() in ('asa','cisco asa'):
            snippet.append(f"object-group network {src_og}")
            for ip in srcs: snippet.append(f" network-object host {ip}")
            snippet.append(f"object-group network {dst_og}")
            for ip in dsts: snippet.append(f" network-object host {ip}")
            # Services: split by proto
            tcp_ports = sorted({p.split('/')[1] for p in services if p.lower().startswith('tcp/') and p.count('/')==1 and p.split('/')[1]})
            udp_ports = sorted({p.split('/')[1] for p in services if p.lower().startswith('udp/') and p.count('/')==1 and p.split('/')[1]})
            if tcp_ports:
                snippet.append(f"object-group service {svc_og}_TCP tcp")
                for po in tcp_ports: snippet.append(f" port-object eq {po}")
            if udp_ports:
                snippet.append(f"object-group service {svc_og}_UDP udp")
                for po in udp_ports: snippet.append(f" port-object eq {po}")
            # Proposed ACL line(s) – place above wide rule
            acl_name = rule  # using wide rule id/name as ACL reference
            if tcp_ports:
                snippet.append(f"access-list {acl_name} extended permit tcp object-group {src_og} object-group {dst_og} object-group {svc_og}_TCP")
            if udp_ports:
                snippet.append(f"access-list {acl_name} extended permit udp object-group {src_og} object-group {dst_og} object-group {svc_og}_UDP")
        else:
            # Generic placeholder (to be extended per platform)
            snippet.append(f"# Platform {plat}: create address/service groups and allow rules above {rule}")
            for (src,dst,svc,_,_,_) in rows[:20]:
                snippet.append(f"# allow {src} -> {dst} {svc}")
        txt = "".join(snippet)+""
        # Write snippet file
        snip_dir = os.path.join(_mon_reports_dir(), 'snippets'); os.makedirs(snip_dir, exist_ok=True)
        snip_path = os.path.join(snip_dir, f"{_safe_name(host)}__{_safe_name(rule)}.txt")
        try:
            with open(snip_path,'w',encoding='utf-8') as f: f.write(txt)
        except Exception:
            pass
        # --- mark stopped & attach snippet path ---
        try:
            key2 = self._monitor_key(host, rule)
            path_csv = self._monitor_sheet_path(host, rule)
            total_rows = 0
            try:
                with open(path_csv, 'r', encoding='utf-8', newline='') as f:
                    total_rows = max(0, sum(1 for _ in f) - 1)
            except Exception:
                total_rows = 0
            agg_rows = list(st['agg'].rows())
            unique_pairs = len(agg_rows)
            first_seen = min((r[4] for r in agg_rows), default='')
            last_seen  = max((r[5] for r in agg_rows), default='')
            _mon_status_upsert({
                'key': key2, 'hostname': host, 'platform': plat,
                'rule_filter': rule, 'is_regex': '1' if st.get('regex') else '0',
                'syslog_root': st.get('root',''), 'state': 'stopped',
                'started_at': '',
                'stopped_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'last_heartbeat': time.strftime('%Y-%m-%d %H:%M:%S'),
                'sheet_path': path_csv, 'snippet_path': snip_path,
                'total_rows': str(total_rows), 'unique_pairs': str(unique_pairs),
                'first_seen': first_seen, 'last_seen': last_seen, 'remarks': ''
            })
        except Exception:
            pass

        # Push a row into Remediation: action=add_acl, raw_ace=snippet path reference
        row = {
            'hostname': host,
            'platform': plat,
            'action': 'add_acl',
            'rule_id': rule,
            'raw_ace': txt,
            'remark': f'Generated from monitoring {host}/{rule} on '+time.strftime('%Y-%m-%d %H:%M')
        }
        self._remed_add_rows([row], list(row.keys()))

    def _mon_status_read_all(self):
        """
        Robust reader for monitor_status.csv:
        - accepts UTF-8 with BOM (utf-8-sig)
        - trims stray spaces from header names
        - maps fields to the exact keys the Manager expects
        Returns (header, rows[list of dict]).
        """
        import csv, os
        path = _mon_status_path()
        hdr = _mon_status_header()
        rows = []
        try:
            if not os.path.isfile(path):
                return hdr, rows
            # utf-8-sig eats BOM if present
            with open(path, 'r', encoding='utf-8-sig', newline='') as f:
                dr = csv.DictReader(f)
                if not dr.fieldnames:
                    return hdr, rows
                # Normalize header names: strip + lowercase
                norm = {h: (h or '').strip().lower() for h in dr.fieldnames}
                for r in dr:
                    z = {norm.get(k, k): (r.get(k, '') or '') for k in dr.fieldnames}
                    rows.append({
                        'key':            z.get('key',''),
                        'hostname':       z.get('hostname',''),
                        'platform':       z.get('platform',''),
                        'rule_filter':    z.get('rule_filter',''),
                        'state':          z.get('state',''),
                        'started_at':     z.get('started_at',''),
                        'stopped_at':     z.get('stopped_at',''),
                        'last_heartbeat': z.get('last_heartbeat',''),
                        'total_rows':     z.get('total_rows',''),
                        'unique_pairs':   z.get('unique_pairs',''),
                        'sheet_path':     z.get('sheet_path',''),
                        'snippet_path':   z.get('snippet_path',''),
                        # extras kept for completeness (not all shown in grid)
                        'is_regex':       z.get('is_regex',''),
                        'syslog_root':    z.get('syslog_root',''),
                        'first_seen':     z.get('first_seen',''),
                        'last_seen':      z.get('last_seen',''),
                        'remarks':        z.get('remarks',''),
                    })
        except Exception:
            rows = []
        return hdr, rows

    def _monitor_manager_open(self):
        """Open Monitoring Manager (per-session control)."""
        top = tk.Toplevel(self.root)
        top.title('Monitoring Manager (per-session control)')
        try:
            top.transient(self.root); top.grab_set()
        except Exception:
            pass
        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1); top.rowconfigure(0, weight=1)
        frm.columnconfigure(0, weight=1)
        # Status strip (debugging aid): shows ledger path + row count
        status = ttk.Label(frm, text="", foreground="grey")
        status.grid(row=2, column=0, sticky='ew', pady=(6,0))
        # Toolbar
        tbar = ttk.Frame(frm)
        tbar.grid(row=0, column=0, sticky='ew')
        for c in range(6):
            tbar.columnconfigure(c, weight=1)
        holder = {'tree': None}
        ttk.Button(tbar, text='Refresh', command=lambda: self._monitor_manager_refresh(holder['tree'])).grid(row=0, column=0, sticky='w')
        ttk.Button(tbar, text='Open Sheet', command=lambda: self._monitor_manager_open_path(holder['tree'], 'sheet_path')).grid(row=0, column=1, sticky='w')
        ttk.Button(tbar, text='Open Snippet', command=lambda: self._monitor_manager_open_path(holder['tree'], 'snippet_path')).grid(row=0, column=2, sticky='w')
        ttk.Button(tbar, text='Resume', command=lambda: self._monitor_manager_resume_selected(holder['tree'])).grid(row=0, column=3, sticky='w')
        ttk.Button(tbar, text='Stop', command=lambda: self._monitor_manager_stop_selected(holder['tree'])).grid(row=0, column=4, sticky='w')
        ttk.Button(tbar, text='Mark Closed', command=lambda: self._monitor_manager_close_selected(holder['tree'])).grid(row=0, column=5, sticky='e')
        # Table
        wrap = ttk.Frame(frm, borderwidth=1, relief='solid')
        wrap.grid(row=1, column=0, sticky='nsew', pady=(8,0))
        frm.rowconfigure(1, weight=1)
        wrap.columnconfigure(0, weight=1); wrap.rowconfigure(0, weight=1)
        hdr, rows = self._mon_status_read_all()
        cols = ['hostname','platform','rule_filter','state','total_rows','unique_pairs','first_seen','last_seen','last_heartbeat','sheet_path','snippet_path','remarks','key']
        avail = cols
        tree = ttk.Treeview(wrap, columns=tuple(avail), show='headings', height=18, style='Bordered.Treeview', selectmode='browse')
        for c in avail:
            txt = c.replace('_',' ').title()
            tree.heading(c, text=txt)
            w = 160
            if c in ('hostname','rule_filter'): w = 220
            if c in ('sheet_path','snippet_path'): w = 300
            if c in ('state','platform','unique_pairs','total_rows'): w = 110
            if c in ('remarks','key'): w = 220
            anchor = 'w'
            if c in ('state','platform','unique_pairs','total_rows'): anchor = 'center'
            tree.column(c, width=w, anchor=anchor, stretch=True)
        tree.grid(row=0, column=0, sticky='nsew')
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tree.yview); vsb.grid(row=0, column=1, sticky='ns')
        tree.configure(yscrollcommand=vsb.set)
        holder['tree'] = tree
        self._monitor_manager_fill(tree, rows, avail)
        try:
            path = _mon_status_path()
            status.config(text=f"Loaded {len(rows)} row(s) from: {path}")
        except Exception:
            pass

    def _monitor_manager_fill(self, tree, rows, cols):
        # clear existing
        for iid in tree.get_children():
            tree.delete(iid)
        # columns to show
        try:
            cols = list(cols or (tree.cget('columns') or ()))
        except Exception:
            cols = list(cols or [])
        # insert rows
        for i, r in enumerate(rows or []):
            vals = [(r.get(c, '') or '') for c in cols]
            tag = 'even' if (i % 2 == 0) else 'odd'
            try:
                tree.insert('', 'end', values=tuple(vals), tags=(tag,))
            except Exception:
                try:
                    tree.insert('', 'end', values=tuple(vals[:len(cols)]), tags=(tag,))
                except Exception:
                    pass
        # optional: autosize primary column
        try:
            if 'hostname' in cols:
                fixed = tuple([c for c in cols if c != 'hostname'])
                self._autofit_tree_columns(tree, primary_col='hostname', fixed_cols=fixed, pad_px=24, min_w=220, max_w=1800)
        except Exception:
            pass

    def _monitor_manager_refresh(self, tree):
        hdr, rows = self._mon_status_read_all()
        cols = list(tree.cget('columns') or [])
        self._monitor_manager_fill(tree, rows, cols)
        # Update status strip if present
        try:
            parent = tree.master.master  # wrap -> frm
            for ch in parent.winfo_children():
                if isinstance(ch, ttk.Label) and ch.cget('foreground') == 'grey':
                    ch.config(text=f"Loaded {len(rows)} row(s) from: {_mon_status_path()}")
                    break
        except Exception:
            pass

    def _monitor_manager_open_path(self, tree, field):
        sel = tree.selection()
        if not sel:
            try: messagebox.showinfo('Monitoring Manager', 'No row selected.')
            except Exception: pass
            return
        cols = list(tree.cget('columns') or [])
        vals = list(tree.item(sel[0], 'values') or [])
        m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
        p = (m.get(field) or '').strip()
        if p:
            _open_path(p)
        else:
            try: messagebox.showinfo('Monitoring Manager', f'No {field.replace("_"," ")} recorded for this row.')
            except Exception: pass


    def _monitor_manager_resume_selected(self, tree):
        sel = tree.selection()
        if not sel:
            try: messagebox.showinfo('Monitoring Manager', 'No row selected.')
            except Exception: pass
            return
        cols = list(tree.cget('columns') or [])
        vals = list(tree.item(sel[0], 'values') or [])
        m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
        # Ensure vars exist
        if not hasattr(self, '_mon_root'): self._mon_root = tk.StringVar()
        if not hasattr(self, '_mon_host'): self._mon_host = tk.StringVar()
        if not hasattr(self, '_mon_plat'): self._mon_plat = tk.StringVar()
        if not hasattr(self, '_mon_rule'): self._mon_rule = tk.StringVar()
        if not hasattr(self, '_mon_regex'): self._mon_regex = tk.BooleanVar()
        self._mon_root.set(m.get('sheet_path',''))  # derive root from path fallback
        # Better: use stored syslog_root if column exists
        if 'syslog_root' in cols:
            self._mon_root.set(m.get('syslog_root',''))
        self._mon_host.set(m.get('hostname',''))
        self._mon_plat.set(m.get('platform',''))
        self._mon_rule.set(m.get('rule_filter',''))
        # is_regex may be '1'/'0'
        rx = (m.get('is_regex','') or '').strip()
        self._mon_regex.set(True if rx in ('1','true','True','YES','yes') else False)
        self._monitor_start()


    def _monitor_manager_stop_selected(self, tree):
        sel = tree.selection()
        if not sel:
            try: messagebox.showinfo('Monitoring Manager', 'No row selected.')
            except Exception: pass
            return
        cols = list(tree.cget('columns') or [])
        vals = list(tree.item(sel[0], 'values') or [])
        m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
        key = m.get('key') or self._monitor_key(m.get('hostname',''), m.get('rule_filter',''))
        self._monitor_stop_one(key)
        self._monitor_manager_refresh(tree)


    def _monitor_stop_one(self, key):
        st = getattr(self, '_monitors', {}).get(key)
        if not st:
            return False
        st['running'] = False
        try:
            self._monitor_finalize_to_remediation(key)
        except Exception:
            pass
        # status will be updated by finalize; ensure a stopped state as fallback
        try:
            _mon_status_upsert({'key': key, 'state': 'stopped', 'stopped_at': time.strftime('%Y-%m-%d %H:%M:%S')})
        except Exception:
            pass
        return True


    def _monitor_manager_close_selected(self, tree):
        sel = tree.selection()
        if not sel:
            try: messagebox.showinfo('Monitoring Manager', 'No row selected.')
            except Exception: pass
            return
        cols = list(tree.cget('columns') or [])
        vals = list(tree.item(sel[0], 'values') or [])
        m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
        key = m.get('key') or self._monitor_key(m.get('hostname',''), m.get('rule_filter',''))
        _mon_status_upsert({'key': key, 'state': 'closed', 'stopped_at': time.strftime('%Y-%m-%d %H:%M:%S')})
        self._monitor_manager_refresh(tree)



    def _build_remed_tab(self):
        self.tab_remed = ttk.Frame(self.nb); self.nb.add(self.tab_remed, text="Remediation")
        self.tab_remed.columnconfigure(0, weight=1); self.tab_remed.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_remed); tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        ttk.Checkbutton(tbar, text='Auto-move validated to Inactive', variable=self.remed_auto_move_var).grid(row=0, column=3, sticky='w')
        ttk.Checkbutton(tbar, text='Dry-run (no changes)', variable=self.remed_dryrun_var).grid(row=0, column=4, sticky='w')
        for c in range(12): tbar.columnconfigure(c, weight=1)
        ttk.Button(tbar, text="Execute (disable)", command=self._remed_execute).grid(row=0, column=5, sticky='w')
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._remed_export_shown).grid(row=0, column=6, sticky='e')
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._remed_export_shown_excel).grid(row=0, column=7, sticky='e', padx=(6,0))
        ttk.Button(tbar, text="Clear Selected", command=self._remed_clear_selected).grid(row=0, column=8, sticky='e', padx=(12,0))
        ttk.Button(tbar, text="Clear All", command=self._remed_clear_all).grid(row=0, column=9, sticky='e')
        ttk.Button(tbar, text="Add ACL", command=self._remed_apply_add_acl).grid(row=0, column=2, sticky='w', padx=(6,0))

        self.remed_wrap = ttk.Frame(self.tab_remed, borderwidth=1, relief="solid"); self.remed_wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_remed.rowconfigure(2, weight=1); self.tab_remed.columnconfigure(0, weight=1)
        self.remed_wrap.rowconfigure(0, weight=1); self.remed_wrap.columnconfigure(0, weight=1); self.remed_wrap.columnconfigure(1, weight=0)

        self.remed_table = ttk.Treeview(self.remed_wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        self.remed_table.bind("<Control-a>", lambda e: (self.remed_table.selection_set(self.remed_table.get_children()), "break"))
        vsb = ttk.Scrollbar(self.remed_wrap, orient="vertical", command=self.remed_table.yview)
        hsb = ttk.Scrollbar(self.remed_wrap, orient="horizontal", command=self.remed_table.xview)
        self.remed_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.remed_table.grid(row=0, column=0, sticky='nsew'); vsb.grid(row=0, column=1, sticky='ns'); hsb.grid(row=1, column=0, sticky='ew')
        self.remed_table.tag_configure("odd", background="#f5f5f5"); self.remed_table.tag_configure("even", background="#ffffff")
        self._enable_header_drag(self.remed_table)

    def _remed_add_rows(self, rows, field_order):
        new_unique = []
        for r in rows:
            if r.get('ace_hash'):
                key = ('hash', r['ace_hash'])
            else:
                key = ('tuple', r.get('hostname',''), r.get('rule_id',''), r.get('action',''), r.get('src',''), r.get('dst',''))
            if key in self._remed_seen_keys:
                continue
            self._remed_seen_keys.add(key)
            try:
                plat = (r.get('platform') or '').strip().lower()
                rule_id = (r.get('rule_id') or '').strip()
                raw_ace = (r.get('raw_ace') or '').strip()
                if plat in ('srx','palo alto','palo-alto','paloalto','pa') and rule_id:
                    r['policy_name'] = rule_id
                    r['rule_name'] = rule_id
                    r['acl_name']  = rule_id
                if plat == 'srx' and not r.get('policy_name') and rule_id:
                    if (' policy ' + rule_id) in (' ' + raw_ace + ' '):
                        r['policy_name'] = rule_id
            except Exception:
                pass
            new_unique.append(r)
        if not new_unique:
            return 0

        if not self._remed_field_order:
            self._remed_field_order = list(field_order)
            self._remed_configure_columns(self._remed_field_order)
        else:
            merged = list(self._remed_field_order)
            for c in field_order:
                if c not in merged:
                    merged.append(c)
            if merged != self._remed_field_order:
                self._remed_field_order = merged
                self._remed_configure_columns(self._remed_field_order, rebuild=True)

        cols = self._remed_field_order
        for i, r in enumerate(new_unique):
            vals = [(r.get(c, '') or '') for c in cols]
            tag = 'even' if ((len(self._remed_rows) + i) % 2 == 0) else 'odd'
            self.remed_table.insert('', 'end', values=tuple(vals), tags=(tag,))
        self._remed_rows.extend(new_unique)

        for cid in ('hostname', 'raw_ace', 'remark', 'risk_description'):
            if cid in cols:
                try:
                    self._attach_treeview_tooltip(self.remed_table, cid)
                except Exception:
                    pass
        try:
            self._remed_refresh_badge()
        except Exception:
            pass
        return len(new_unique)

    def _remed_configure_columns(self, cols, rebuild=False):
        if rebuild:
            existing = []
            for iid in self.remed_table.get_children():
                existing.append(self.remed_table.item(iid, "values") or ())
            self.remed_table["columns"] = tuple(cols)
            for col in cols:
                self.remed_table.heading(col, text=col)
                w = 140; anchor = 'w'; stretch = False
                lc = col.lower()
                if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
                if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
                if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
                if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
                if lc in ("raw_ace",): w, anchor, stretch = 560, 'w', True
                if lc in ("remark", "risk_description"): w, anchor, stretch = 360, 'w', True
                self.remed_table.column(col, width=w, anchor=anchor, stretch=stretch)
            for iid in self.remed_table.get_children():
                self.remed_table.delete(iid)
            for i, r in enumerate(self._remed_rows):
                vals = [ (r.get(c,"") or "") for c in cols ]
                tag = "even" if (i % 2 == 0) else "odd"
                self.remed_table.insert("", "end", values=tuple(vals), tags=(tag,))
        else:
            self.remed_table["columns"] = tuple(cols)
            for col in cols:
                self.remed_table.heading(col, text=col)
                w = 140; anchor = 'w'; stretch = False
                lc = col.lower()
                if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
                if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
                if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
                if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', False
                if lc in ("raw_ace",): w, anchor, stretch = 560, 'w', True
                if lc in ("remark", "risk_description"): w, anchor, stretch = 360, 'w', True
                self.remed_table.column(col, width=w, anchor=anchor, stretch=stretch)

    def _remed_export_shown(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "remediation_queue.csv")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "remediation_queue.csv")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.DictWriter(f, fieldnames=cols); dw.writeheader()
                for iid in self.remed_table.get_children():
                    vals = list(self.remed_table.item(iid, "values") or [])
                    row = {k: (vals[i] if i < len(vals) else "") for i, k in enumerate(cols)}
                    dw.writerow(row)
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export CSV", f"Exported {len(self.remed_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _remed_export_shown_excel(self):
        try:
            rep_dir = self._find_reports_latest_for_dashboard()
            out_path = os.path.join(rep_dir, "remediation_queue.xlsx")
        except Exception:
            out_path = os.path.join(os.path.abspath(os.getcwd()), "remediation_queue.xlsx")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Remediation Queue"; ws.append(cols)
            for iid in self.remed_table.get_children():
                vals = list(self.remed_table.item(iid, "values") or []); ws.append(vals)
            for col_idx, col_name in enumerate(cols, start=1):
                max_len = len(str(col_name))
                for row_idx in range(2, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is None: continue
                    max_len = max(max_len, len(str(val)))
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 140)
            wb.save(out_path)
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass
            return
        try:
            messagebox.showinfo("Export Excel", f"Exported {len(self.remed_table.get_children())} rows to:\n{out_path}")
        except Exception: pass

    def _find_remediation_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'remediation.py'),
            os.path.join(base, 'modular_collector', 'remediation.py'),
            os.path.join(os.path.dirname(base), 'remediation.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'remediation.py'),
            'remediation.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _remed_export_queue_to_dir(self, rep_dir: str) -> str:
        out_path = os.path.join(rep_dir, "remediation_queue.csv")
        cols = list(self._remed_field_order or (self.remed_table.cget("columns") or []))
        if not cols:
            raise RuntimeError("No remediation rows to export.")
        with open(out_path, "w", encoding="utf-8", newline="") as f:
            dw = csv.DictWriter(f, fieldnames=cols)
            dw.writeheader()
            for iid in self.remed_table.get_children():
                vals = list(self.remed_table.item(iid, "values") or [])
                row = {k: (vals[i] if i < len(cols) else "") for i, k in enumerate(cols)}
                dw.writerow(row)
        return out_path

    def _remed_execute(self):
        row_count = len(self.remed_table.get_children())
        if row_count == 0:
            try:
                messagebox.showinfo("Execute Remediation", "No rows in the remediation queue.")
            except Exception: pass
            return
        if not self._ask_creds():
            self._status("Remediation cancelled (credentials required)", "orange")
            return
        os.environ["FW_USERNAME"] = self._mem_user
        os.environ["FW_PASSWORD"] = self._mem_pass
        os.environ["FW_ENABLE"] = self._mem_enable
        if self.remed_dryrun_var.get():
            os.environ.pop("APPLY_CHANGES", None)
        else:
            os.environ["APPLY_CHANGES"] = "1"

        try:
            ok = messagebox.askyesno(
                "Confirm Execute",
                f"This will disable {row_count} rule(s).\n\n"
                "• Queue will be exported to modular_collector/reports/latest/remediation_queue.csv\n"
                "• Script: remediation.py\n"
                "• Expected output: modular_collector/reports/latest/disable.csv\n\n"
                "Proceed?"
            )
        except Exception:
            ok = True
        if not ok:
            self._status("Remediation cancelled", "orange")
            return

        script = self._find_remediation_script()
        if not script:
            self._status("remediation.py not found", "red")
            try:
                messagebox.showerror("Execute Remediation", "Could not locate remediation.py")
            except Exception: pass
            return
        run_cwd = os.path.dirname(os.path.abspath(script))
        rep_dir = os.path.join(run_cwd, 'reports', 'latest'); os.makedirs(rep_dir, exist_ok=True)
        run_report = os.path.join(rep_dir, "remediation_run_report.txt")
        self._last_reports_dir = rep_dir

        try:
            _ = self._remed_export_queue_to_dir(rep_dir)
        except Exception as e:
            self._status("Failed to export remediation queue", "red")
            try:
                messagebox.showerror(
                    "Execute Remediation",
                    f"Cannot export remediation queue:\n{e}"
                )
            except Exception:
                pass
            return

        try:
            self.output_dash.config(state='normal'); self.output_dash.delete('1.0', 'end'); self.output_dash.config(state='disabled')
        except Exception:
            pass

        self._status("Executing remediation...", "orange")
        try: self.progress.start(10)
        except Exception: pass
        cmd = [sys.executable, os.path.basename(script)]

        def append_console(s: str):
            try:
                self.output_dash.config(state='normal')
                self.output_dash.insert('end', s)
                self.output_dash.see('end')
                self.output_dash.config(state='disabled')
            except Exception:
                pass

        def worker():
            try:
                start = time.time()
                env = os.environ.copy()
                env["PYTHONUNBUFFERED"] = "1"
                env["REPORTS_DIR"] = rep_dir
                res = subprocess.run(
                    cmd, cwd=run_cwd, capture_output=True, text=True, timeout=1800, env=env
                )
                dur = round(time.time() - start, 2)
                out = (res.stdout or '').strip()
                err = (res.stderr or '').strip()
                try:
                    with open(run_report, 'w', encoding='utf-8') as f:
                        f.write(f"[cmd] {' '.join(cmd)}\n[rc] {res.returncode} ({dur}s)\n\n[stdout]\n{out}\n\n[stderr]\n{err}\n")
                except Exception:
                    pass
                if out:
                    self.root.after(0, append_console, f"[stdout]\n{out}\n")
                if err:
                    self.root.after(0, append_console, f"[stderr]\n{err}\n")
                if res.returncode == 0:
                    self.root.after(0, self._status, "Remediation completed. Check disable.csv", "green")
                    self.root.after(0, append_console, f"\n[REPORT] {run_report}\n")
                else:
                    self.root.after(0, self._status, f"Remediation failed (exit={res.returncode})", "red")
                    self.root.after(0, append_console, f"\n[REPORT] {run_report}\n")
            except subprocess.TimeoutExpired:
                self.root.after(0, self._status, "Remediation timeout (1800s)", "red")
                self.root.after(0, append_console, "[ERROR] Timeout after 1800 seconds\n")
            except FileNotFoundError as e:
                self.root.after(0, self._status, "Python or remediation.py not found", "red")
                self.root.after(0, append_console, f"[ERROR] {e}\n")
            except Exception as e:
                self.root.after(0, self._status, "Remediation run failed", "red")
                self.root.after(0, append_console, f"[ERROR] {e}\n")
            finally:
                try: self.progress.stop()
                except Exception: pass
            try:
                self.root.after(0, self._remed_refresh_badge)
            except Exception:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def _remed_clear_selected(self):
        iids = self.remed_table.selection()
        if not iids:
            try:
                messagebox.showinfo("Remediation", "No rows selected.")
            except Exception: pass
            return
        cols = list(self._remed_field_order)
        def row_key_from_vals(vals):
            d = {cols[i]: (vals[i] if i < len(cols) else "") for i in range(len(cols))}
            if d.get('ace_hash'): return ('hash', d['ace_hash'])
            return ('tuple', d.get('hostname',''), d.get('rule_id',''), d.get('action',''), d.get('src',''), d.get('dst',''))
        for iid in iids:
            vals = list(self.remed_table.item(iid, "values") or [])
            key = row_key_from_vals(vals)
            if key in self._remed_seen_keys: self._remed_seen_keys.discard(key)
            self.remed_table.delete(iid)
        remain = []
        for iid in self.remed_table.get_children():
            vals = list(self.remed_table.item(iid, "values") or [])
            d = {cols[i]: (vals[i] if i < len(cols) else "") for i in range(len(cols))}
            remain.append(d)
        self._remed_rows = remain
        try:
            self._remed_refresh_badge()
        except Exception:
            pass

    def _remed_clear_all(self):
        for iid in self.remed_table.get_children(): self.remed_table.delete(iid)
        self._remed_rows = []; self._remed_field_order = []; self._remed_seen_keys = set()
        try:
            self._remed_refresh_badge()
        except Exception:
            pass


    def _remed_apply_add_acl(self):
        sel = self.remed_table.selection()
        if not sel:
            try: messagebox.showinfo('Add ACL', 'No row selected.');
            except Exception: pass
            return
        # Apply for selected rows that are action=add_acl (v1: write snippet to file and open path)
        applied = 0
        for iid in sel:
            vals = list(self.remed_table.item(iid, 'values') or [])
            cols = list(self._remed_field_order or (self.remed_table.cget('columns') or []))
            m = {cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(cols))}
            if (m.get('action') or '').lower() != 'add_acl':
                continue
            # Write snippet to reports (already saved by finalize); open path for visibility
            try:
                out_dir = os.path.join(_mon_reports_dir(), 'applied'); os.makedirs(out_dir, exist_ok=True)
                fname = f"applied__{_safe_name(m.get('hostname',''))}__{_safe_name(m.get('rule_id',''))}_{time.strftime('%Y%m%d_%H%M%S')}.txt"
                path = os.path.join(out_dir, fname)
                with open(path,'w',encoding='utf-8') as f: f.write(m.get('raw_ace',''))
                _open_path(path)
                applied += 1
            except Exception:
                pass
        try: messagebox.showinfo('Add ACL', f'Prepared {applied} ACL snippet file(s). Review and apply on device.');
        except Exception: pass

    # ---------------- Inactive ACL Tab (viewer) ----------------
    def _build_inactive_tab(self):
        self.tab_inactive = ttk.Frame(self.nb)
        self.nb.add(self.tab_inactive, text="Inactive ACL")
        self.tab_inactive.columnconfigure(0, weight=1)
        self.tab_inactive.rowconfigure(2, weight=1)

        tbar = ttk.Frame(self.tab_inactive)
        tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(8): tbar.columnconfigure(c, weight=1)
        ttk.Button(tbar, text="Reload from inactive.csv", command=self._inactive_reload_from_csv).grid(row=0, column=0, sticky='w')
        ttk.Button(tbar, text="Export (shown) to CSV", command=self._inactive_export_to_csv).grid(row=0, column=1, sticky='w', padx=(6, 0))
        ttk.Button(tbar, text="Export (shown) to Excel", command=self._inactive_export_to_xlsx).grid(row=0, column=2, sticky='w', padx=(6, 0))

        wrap = ttk.Frame(self.tab_inactive, borderwidth=1, relief="solid")
        wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_inactive.rowconfigure(2, weight=1)
        self.tab_inactive.columnconfigure(0, weight=1)
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)
        wrap.columnconfigure(1, weight=0)

        self.inactive_table = ttk.Treeview(wrap, columns=(), show="headings", height=22, style="Bordered.Treeview", selectmode="extended")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.inactive_table.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self.inactive_table.xview)
        self.inactive_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.inactive_table.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        self.inactive_table.tag_configure("odd", background="#f5f5f5")
        self.inactive_table.tag_configure("even", background="#ffffff")
        self._inactive_field_order = []
        self._enable_header_drag(self.inactive_table)

    def _inactive_reload_from_csv(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        path = os.path.join(rep_dir, "inactive.csv")
        for iid in self.inactive_table.get_children(): self.inactive_table.delete(iid)
        self._inactive_field_order = []
        if not os.path.exists(path):
            try:
                messagebox.showwarning("Inactive ACL", f"File not found:\n{path}")
            except Exception: pass
            return
        try:
            with open(path, "r", encoding="utf-8", newline="") as f:
                dr = csv.DictReader(f); rows = list(dr); cols = list(dr.fieldnames or [])
        except Exception as e:
            try:
                messagebox.showerror("Inactive ACL", f"Failed to read:\n{path}\n\n{e}")
            except Exception: pass
            return
        self._inactive_field_order = cols
        self.inactive_table["columns"] = tuple(cols)
        for col in cols:
            w, anchor, stretch = 140, 'w', True
            lc = col.lower()
            if lc in ("platform", "action", "service"): w, anchor, stretch = 110, 'center', False
            if lc in ("rule_id", "hit_count"): w, anchor, stretch = 90, 'center', False
            if lc in ("hostname",): w, anchor, stretch = 320, 'w', True
            if lc in ("src", "dst"): w, anchor, stretch = 220, 'w', True
            if lc in ("raw_ace", "remark", "risk_description"): w, anchor, stretch = 560, 'w', True
            self.inactive_table.heading(col, text=col)
            self.inactive_table.column(col, width=w, anchor=anchor, stretch=stretch)
        for i, r in enumerate(rows):
            tag = "even" if (i % 2 == 0) else "odd"
            vals = [(r.get(c, "") or "") for c in cols]
            self.inactive_table.insert("", "end", values=tuple(vals), tags=(tag,))

    def _inactive_export_to_csv(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        out_path = os.path.join(rep_dir, "inactive.csv")
        cols = list(self.inactive_table.cget("columns") or [])
        if not cols:
            try:
                messagebox.showwarning("Export CSV", "No data to export.")
            except Exception: pass
            return
        try:
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                dw = csv.writer(f); dw.writerow(cols)
                for iid in self.inactive_table.get_children():
                    vals = list(self.inactive_table.item(iid, "values") or [])
                    dw.writerow(vals)
            try:
                messagebox.showinfo("Export CSV", f"Exported to:\n{out_path}")
            except Exception: pass
        except Exception as e:
            try:
                messagebox.showerror("Export CSV", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass

    def _inactive_export_to_xlsx(self):
        rep_dir = self._find_reports_latest_for_dashboard()
        out_path = os.path.join(rep_dir, "inactive.xlsx")
        cols = list(self.inactive_table.cget("columns") or [])
        if not cols:
            try:
                messagebox.showwarning("Export Excel", "No data to export.")
            except Exception: pass
            return
        try:
            wb = Workbook(); ws = wb.active; ws.title = "Inactive ACL"; ws.append(cols)
            for iid in self.inactive_table.get_children():
                vals = list(self.inactive_table.item(iid, "values") or [])
                ws.append(vals)
            wb.save(out_path)
            try:
                messagebox.showinfo("Export Excel", f"Exported to:\n{out_path}")
            except Exception: pass
        except Exception as e:
            try:
                messagebox.showerror("Export Excel", f"Failed to export:\n{out_path}\n\n{e}")
            except Exception: pass

    # ---------------- Logs & Reports ----------------
    def _build_logs_tab(self):
        try:
            self.tab_logs = ttk.Frame(self.nb); self.nb.add(self.tab_logs, text="Logs & Reports")
            self.tab_logs.columnconfigure(0, weight=1)
            frame = ttk.LabelFrame(self.tab_logs, text="Location"); frame.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
            for c in range(3): frame.columnconfigure(c, weight=1)
            try: base_dir = os.path.abspath(os.path.join(_collector_dir_or_here(), 'reports'))
            except Exception: base_dir = os.path.join(_collector_dir_or_here(), 'reports')
            self.logs_base_var = tk.StringVar(value=base_dir or '-')
            ttk.Label(frame, text="Reports Dir:").grid(row=0, column=0, sticky='w')
            ttk.Label(frame, textvariable=self.logs_base_var, foreground='blue').grid(row=0, column=1, sticky='w')
            ttk.Button(frame, text="Open", command=lambda: _open_path(self.logs_base_var.get() or '.')).grid(row=0, column=2, sticky='ew')

            lframe = ttk.LabelFrame(self.tab_logs, text="Logs Console"); lframe.grid(row=1, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
            self.tab_logs.rowconfigure(1, weight=1); lframe.columnconfigure(0, weight=1); lframe.rowconfigure(0, weight=1); lframe.rowconfigure(1, weight=0)
            self.output_logs = tk.Text(lframe, width=100, height=24, font=("Consolas", 10), wrap='none'); self.output_logs.grid(row=0, column=0, sticky='nsew')
            hsb = ttk.Scrollbar(lframe, orient='horizontal', command=self.output_logs.xview); self.output_logs.configure(xscrollcommand=hsb.set); hsb.grid(row=1, column=0, sticky='ew')
            try:
                self.output_logs.config(state='normal'); self.output_logs.insert('end', f"[INIT] Logs tab ready. Base dir: {self.logs_base_var.get()}\n"); self.output_logs.config(state='disabled')
            except Exception: pass
        except Exception as e:
            try:
                print("[INIT] _build_logs_tab failed:", e)
            except Exception:
                pass
            try:
                placeholder = ttk.Frame(self.nb); self.nb.add(placeholder, text="Logs & Reports")
                ttk.Label(placeholder, text=f"Logs tab failed to initialize: {e}", foreground='red').grid(row=0, column=0, sticky='w', padx=PAD, pady=PAD)
            except Exception: pass

    # ---------------- Collector ----------------
    def _build_collector_tab(self):
        self.tab_collect = ttk.Frame(self.nb); self.nb.add(self.tab_collect, text="Collector")
        self.tab_collect.columnconfigure(0, weight=1); self.tab_collect.rowconfigure(2, weight=1)

        cfrm = ttk.LabelFrame(self.tab_collect, text="Run Common Collector"); cfrm.grid(row=0, column=0, sticky='ew', padx=PAD, pady=PAD)
        for c in range(10): cfrm.columnconfigure(c, weight=1)
        ttk.Label(cfrm, text="Threads").grid(row=0, column=0, sticky='w'); self.collect_threads_var = tk.StringVar(value='8')
        ttk.Entry(cfrm, textvariable=self.collect_threads_var, width=7).grid(row=0, column=1, sticky='w')
        ttk.Label(cfrm, text="Device Timeout (s)").grid(row=0, column=2, sticky='w'); self.collect_timeout_var = tk.StringVar(value='120')
        ttk.Entry(cfrm, textvariable=self.collect_timeout_var, width=9).grid(row=0, column=3, sticky='w')
        ttk.Label(cfrm, text="Read Timeout (s)").grid(row=1, column=0, sticky='w'); self.collect_read_to_var = tk.StringVar(value='120')
        ttk.Entry(cfrm, textvariable=self.collect_read_to_var, width=9).grid(row=1, column=1, sticky='w')
        ttk.Label(cfrm, text="ACL Timeout (s)").grid(row=1, column=2, sticky='w'); self.collect_acl_to_var = tk.StringVar(value='180')
        ttk.Entry(cfrm, textvariable=self.collect_acl_to_var, width=9).grid(row=1, column=3, sticky='w')
        ttk.Label(cfrm, text="Publish every (s)").grid(row=1, column=4, sticky='w'); self.collect_pubint_var = tk.StringVar(value='10')
        ttk.Entry(cfrm, textvariable=self.collect_pubint_var, width=7).grid(row=1, column=5, sticky='w')
        ttk.Label(cfrm, text="ACL method").grid(row=1, column=6, sticky='w')
        self.collect_acl_method = tk.StringVar(value='adaptive')
        ttk.Combobox(cfrm, textvariable=self.collect_acl_method, width=10, values=['prompt', 'timing', 'adaptive'], state='readonly').grid(row=1, column=7, sticky='w')
        self.collect_asa_allctx = tk.BooleanVar(value=False); ttk.Checkbutton(cfrm, text="ASA: all contexts", variable=self.collect_asa_allctx).grid(row=1, column=8, sticky='w')

        btns = ttk.Frame(cfrm); btns.grid(row=2, column=0, columnspan=10, sticky='ew', pady=(6, 0))
        for c in range(5): btns.columnconfigure(c, weight=1)
        ttk.Button(btns, text="Start Collector", command=self._start_collector).grid(row=0, column=0, sticky='ew', padx=(0, PAD))
        ttk.Button(btns, text="Stop", command=self._stop_collector).grid(row=0, column=1, sticky='ew')
        ttk.Button(btns, text="Open reports/latest", command=lambda: _open_path(_default_reports_latest_dir())).grid(row=0, column=2, sticky='ew')
        # Windows-only scheduler button
        handler = getattr(self, '_collector_schedule_windows', None)
        if handler is None:
            handler = lambda: messagebox.showwarning('Schedule', 'Scheduler not available in this build.')
        sch_btn = ttk.Button(btns, text="Schedule in Windows…", command=handler)
        sch_btn.grid(row=0, column=3, sticky='ew')
        try:
            if os.name != 'nt':
                sch_btn.state(['disabled'])
        except Exception:
            pass

        stat = ttk.Frame(self.tab_collect); stat.grid(row=1, column=0, sticky='ew', padx=PAD, pady=(0, PAD))
        stat.columnconfigure(0, weight=1); stat.columnconfigure(1, weight=0)
        self.collect_status_label = ttk.Label(stat, text="Collector Status: Idle", foreground='blue'); self.collect_status_label.grid(row=0, column=0, sticky='w')
        self.collect_prog = ttk.Progressbar(stat, mode='indeterminate', length=250); self.collect_prog.grid(row=0, column=1, sticky='e')

        cons = ttk.LabelFrame(self.tab_collect, text="Collector Console"); cons.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        cons.columnconfigure(0, weight=1); cons.rowconfigure(0, weight=1); cons.rowconfigure(1, weight=0)
        self.output_collect = tk.Text(cons, width=100, height=24, font=("Consolas", 10), wrap='none'); self.output_collect.grid(row=0, column=0, sticky='nsew')
        hsb = ttk.Scrollbar(cons, orient='horizontal', command=self.output_collect.xview); self.output_collect.configure(xscrollcommand=hsb.set); hsb.grid(row=1, column=0, sticky='ew')

        self.col_proc = None; self.collect_run_report = ''

    def _find_collector_script(self):
        base = os.path.dirname(os.path.abspath(__file__))
        candidates = [
            os.path.join(base, 'collector.py'),
            os.path.join(base, 'modular_collector', 'collector.py'),
            os.path.join(os.path.dirname(base), 'collector.py'),
            os.path.join(os.path.dirname(base), 'modular_collector', 'collector.py'),
            'collector.py',
        ]
        for c in candidates:
            if os.path.isfile(c): return c
        return None

    def _collector_status(self, msg, color="blue"):
        try:
            self.collect_status_label.config(text=f"Collector Status: {msg}")
            self.collect_status_label.config(foreground=color)
            self.root.update_idletasks()
        except Exception: pass

        # Update Collector tab badge to reflect status
        try:
            bcolor = 'blue'
            m = (msg or '').lower()
            if 'running' in m:
                bcolor = 'blue'
            elif 'completed' in m:
                bcolor = 'green'
            elif 'finished' in m or 'error' in m:
                bcolor = 'red'
            elif 'idle' in m:
                bcolor = 'blue'
            self._tab_set_badge(self.tab_collect, 'Collector', None, bcolor)
        except Exception:
            pass

    def _append_collect(self, text: str):
        try:
            self.output_collect.config(state='normal'); self.output_collect.insert('end', text); self.output_collect.see('end'); self.output_collect.config(state='disabled')
        except Exception: pass

    def _collector_build_cmd(self, script_path: str):
        cmd = [sys.executable, '-u', os.path.basename(script_path)]
        # Threads
        try:
            th = int(self.collect_threads_var.get() or '0')
            if th > 0: cmd += ['--threads', str(th)]
        except Exception: pass
        # Device timeout
        try:
            dt = int(self.collect_timeout_var.get() or '0')
            if dt > 0: cmd += ['--device-timeout', str(dt)]
        except Exception: pass
        # Inline credentials (global once)
        try:
            if getattr(self, '_mem_user', ''):
                cmd += ['--username', self._mem_user, '--password', self._mem_pass or '']
                cmd += ['--force-global-creds']
            if getattr(self, '_mem_enable', ''):
                cmd += ['--enable-secret', self._mem_enable]
        except Exception: pass
        # ASA all-context toggle
        try:
            if self.collect_asa_allctx.get():
                cmd += ['--asa-all-contexts']
        except Exception: pass
        return cmd

    def _ask_creds(self) -> bool:
        top = tk.Toplevel(self.root); top.title("Enter credentials for this run"); top.transient(self.root); top.grab_set(); top.resizable(False, False)
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        for c in range(2): frm.columnconfigure(c, weight=1)
        ttk.Label(frm, text="Username").grid(row=0, column=0, sticky='w'); uvar = tk.StringVar(value=self._mem_user)
        ttk.Entry(frm, textvariable=uvar, width=28).grid(row=0, column=1, sticky='ew')
        ttk.Label(frm, text="Password").grid(row=1, column=0, sticky='w', pady=(4, 0)); pvar = tk.StringVar(value=self._mem_pass)
        ttk.Entry(frm, textvariable=pvar, width=28, show='•').grid(row=1, column=1, sticky='ew', pady=(4, 0))
        ttk.Label(frm, text="ASA Enable Secret (optional)").grid(row=2, column=0, sticky='w', pady=(4, 0)); evar = tk.StringVar(value=self._mem_enable)
        ttk.Entry(frm, textvariable=evar, width=28, show='•').grid(row=2, column=1, sticky='ew', pady=(4, 0))
        remember = tk.BooleanVar(value=True); ttk.Checkbutton(frm, text="Remember in session (memory only)", variable=remember).grid(row=3, column=0, columnspan=2, sticky='w', pady=(6, 0))
        btns = ttk.Frame(frm); btns.grid(row=4, column=0, columnspan=2, sticky='e', pady=(10, 0))
        ok = {'v': False}
        def on_ok():
            if not uvar.get().strip() or not pvar.get().strip():
                try:
                    messagebox.showwarning("Credentials", "Username and Password are required.")
                except Exception: pass
                return
            ok['v'] = True
            if remember.get():
                self._mem_user = uvar.get().strip(); self._mem_pass = pvar.get(); self._mem_enable = evar.get()
            top.destroy()
        def on_cancel(): top.destroy()
        ttk.Button(btns, text="Cancel", command=on_cancel).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(btns, text="OK", command=on_ok).grid(row=0, column=1)
        try:
            top.update_idletasks()
            w = top.winfo_width(); h = top.winfo_height()
            sw = top.winfo_screenwidth(); sh = top.winfo_screenheight()
            top.geometry(f"+{(sw - w)//2}+{(sh - h)//3}")
        except Exception: pass
        top.wait_window(); return ok['v']

    def _start_collector(self):
        if getattr(self, 'col_proc', None):
            self._collector_status("Already running", "orange"); return
        if not self._ask_creds():
            self._collector_status("Cancelled (credentials required)", "orange"); return
        script = self._find_collector_script()
        if not script:
            self._collector_status("collector.py not found", "red"); self._append_collect("[ERROR] Could not find collector.py\n"); return
        run_cwd = os.path.dirname(os.path.abspath(script))
        cmd = self._collector_build_cmd(script)
        self._append_collect(f"[INFO] Using collector script: {script}\n"); self._append_collect(f"[INFO] Working directory: {run_cwd}\n")
        rep_dir, used_fallback, rep_note = _ensure_reports_dir()
        self.collect_run_report = os.path.join(rep_dir, "collector_run_report.txt")
        try:
            with open(self.collect_run_report, 'w', encoding='utf-8') as rf:
                rf.write("[START] Collector launched\n"); rf.write("[CWD] " + run_cwd + "\n"); rf.write("[CMD] " + " ".join(cmd) + "\n"); rf.flush()
        except Exception as e:
            self._append_collect(f"[WARN] Cannot open run report for writing: {self.collect_run_report}\n{e}\n")

        try:
            self.output_collect.config(state='normal'); self.output_collect.delete('1.0','end'); self.output_collect.config(state='disabled')
        except Exception: pass
        self._collector_status("Starting...", "orange")
        try: self.collect_prog['mode'] = 'indeterminate'; self.collect_prog.start(10)
        except Exception: pass
        env = os.environ.copy(); env["PYTHONUNBUFFERED"] = "1"; env["REPORTS_DIR"] = rep_dir
        try:
            self.col_proc = subprocess.Popen(cmd, cwd=run_cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                             stdin=subprocess.PIPE, text=True, bufsize=1, universal_newlines=True, env=env)
        except FileNotFoundError as e:
            self._collector_status("Python or collector not found", "red"); self._append_collect(f"[ERROR] {e}\n"); return
        except Exception as e:
            self._collector_status("Failed to start", "red"); self._append_collect(f"[ERROR] {e}\n"); return

        # PROMPTS regex are kept SINGLE-LINE to avoid unterminated strings
        PROMPTS = [
            ("banner",   re.compile(r"Enter credentials.*firewall\.csv\s*$", re.IGNORECASE)),
            ("username", re.compile(r"(?:User(?:name)?|Login)\s*:\s*$", re.IGNORECASE)),
            ("password", re.compile(r"Password\s*:\s*$", re.IGNORECASE)),
            ("enable",   re.compile(r"(?:Enable(?:\s+secret)?)\s*:\s*$", re.IGNORECASE)),
        ]
        NL = "\r\n" if os.name == 'nt' else "\n"

        def reader():
            try:
                rf = None
                try: rf = open(self.collect_run_report, 'a', encoding='utf-8')
                except Exception as e:
                    self.root.after(0, self._append_collect, f"[WARN] Report file not writable: {self.collect_run_report} ({e})\n")

                buf = ""; line_buf = ""; last_user_sent_ts = 0.0; password_sent = False
                tail_active = {"banner": False, "username": False, "password": False, "enable": False}
                def log_console(s: str):
                    try:
                        if rf: rf.write(s); rf.flush()
                    except Exception: pass
                    self.root.after(0, self._append_collect, s)
                def match_prompt_tail(b: str):
                    for kind, rx in PROMPTS:
                        if rx.search(b): return kind
                    return None

                while True:
                    ch = self.col_proc.stdout.read(1)
                    if ch == "" or ch is None:
                        if line_buf: log_console(line_buf); line_buf = ""
                        break
                    buf += ch; line_buf += ch
                    if ch == "\n":
                        log_console(line_buf); line_buf = ""
                    for k in tail_active.keys(): tail_active[k] = False
                    kind = match_prompt_tail(buf)
                    for k in list(tail_active.keys()):
                        if kind != k and tail_active[k]: tail_active[k] = False
                    if kind is not None and not tail_active[kind]:
                        tail_active[kind] = True
                        if kind == "username":
                            log_console("[INPUT] sending username\n")
                            try: self.col_proc.stdin.write(self._mem_user + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                            last_user_sent_ts = time.time(); password_sent = False
                        elif kind == "password":
                            log_console("[INPUT] sending password\n")
                            try: self.col_proc.stdin.write(self._mem_pass + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                            password_sent = True
                        elif kind == "enable":
                            log_console("[INPUT] sending enable secret\n")
                            try: self.col_proc.stdin.write((self._mem_enable or "") + NL); self.col_proc.stdin.flush()
                            except Exception: pass
                    if (not password_sent) and (last_user_sent_ts > 0) and (time.time() - last_user_sent_ts > 1.2):
                        log_console("[INPUT] (fallback) sending password\n")
                        try: self.col_proc.stdin.write(self._mem_pass + NL); self.col_proc.stdin.flush()
                        except Exception: pass
                        password_sent = True; last_user_sent_ts = 0.0
                    m = re.search(r"Progress:\s*(\d+)\s*/\s*(\d+)", buf)
                    if m:
                        try:
                            done = int(m.group(1)); total = int(m.group(2))
                            self.root.after(0, self._collector_update_progress, done, total)
                        except Exception: pass
                    if len(buf) > 8192: buf = buf[-4096:]
            except Exception:
                pass
            finally:
                try:
                    if rf: rf.close()
                except Exception: pass
                rc = self.col_proc.wait() if self.col_proc else -1
                self.col_proc = None
                self.root.after(0, self._collector_finish, rc)

        threading.Thread(target=reader, daemon=True).start()
        self._collector_status(f"Running: {' '.join(cmd)}", "blue")

    def _collector_update_progress(self, done, total):
        try:
            if total and total > 0:
                self.collect_prog.stop(); self.collect_prog['mode'] = 'determinate'
                self.collect_prog['maximum'] = total; self.collect_prog['value'] = done
        except Exception: pass

    def _collector_finish(self, rc: int):
        try:
            self.collect_prog.stop(); self.collect_prog['value'] = 0; self.collect_prog['mode'] = 'indeterminate'
        except Exception: pass
        if rc == 0: self._collector_status("Completed (exit=0). See report.", "green")
        else: self._collector_status(f"Finished with errors (exit={rc}). See report.", "red")
        try: self._append_collect(f"\n[REPORT] {self.collect_run_report}\n")
        except Exception: pass

    def _stop_collector(self):
        p = getattr(self, 'col_proc', None)
        if not p: self._collector_status("No active collector", "orange"); return
        try: p.terminate(); self._collector_status("Terminate signal sent", "orange")
        except Exception as e: self._collector_status(f"Terminate failed: {e}", "red")


    def _collector_schedule_windows(self):
        """
        Windows-only: Open a dialog to create/register a Scheduled Task that runs collector.py
        using current collector options. Uses env FW_USER/FW_PASS/FW_ENABLE at runtime.
        No secrets are stored by this GUI.
        """
        if os.name != 'nt':
            try:
                messagebox.showinfo("Schedule in Windows", "Available only on Windows.")
            except Exception:
                pass
            return
        import datetime as dt
        top = tk.Toplevel(self.root); top.title("Schedule Collector in Windows Task Scheduler")
        top.transient(self.root); top.grab_set()
        try: top.resizable(False, False)
        except Exception: pass
        frm = ttk.Frame(top, padding=10); frm.grid(row=0, column=0, sticky='nsew')
        for c in range(4): frm.columnconfigure(c, weight=1)
        ttk.Label(frm, text="Task Name").grid(row=0, column=0, sticky='w')
        name_var = tk.StringVar(value="ACL Collector - Nightly")
        ttk.Entry(frm, textvariable=name_var, width=34).grid(row=0, column=1, columnspan=3, sticky='ew')
        mode = tk.StringVar(value="daily")
        ttk.Radiobutton(frm, text="Once",   variable=mode, value="once").grid(row=1, column=0, sticky='w')
        ttk.Radiobutton(frm, text="Daily",  variable=mode, value="daily").grid(row=1, column=1, sticky='w')
        ttk.Radiobutton(frm, text="Weekly", variable=mode, value="weekly").grid(row=1, column=2, sticky='w')
        now = dt.datetime.now()
        ttk.Label(frm, text="Date (YYYY-MM-DD)").grid(row=2, column=0, sticky='w')
        d_var = tk.StringVar(value=now.strftime("%Y-%m-%d"))
        ttk.Entry(frm, textvariable=d_var, width=12).grid(row=2, column=1, sticky='w')
        ttk.Label(frm, text="Time (HH:MM 24h)").grid(row=2, column=2, sticky='w')
        t_var = tk.StringVar(value="23:30")
        ttk.Entry(frm, textvariable=t_var, width=8).grid(row=2, column=3, sticky='w')
        ttk.Label(frm, text="Weekday").grid(row=3, column=0, sticky='w')
        wk_var = tk.StringVar(value="Mon")
        ttk.Combobox(frm, textvariable=wk_var, values=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], state="readonly", width=8).grid(row=3, column=1, sticky='w')
        run_cur = tk.BooleanVar(value=True)
        ttk.Checkbutton(frm, text="Run as current user (recommended)", variable=run_cur).grid(row=4, column=0, columnspan=2, sticky='w', pady=(6,0))
        ttk.Label(frm, text="Or specify account (DOMAIN User)").grid(row=5, column=0, sticky='w')
        acct_var = tk.StringVar(value="")
        ttk.Entry(frm, textvariable=acct_var, width=28).grid(row=5, column=1, columnspan=3, sticky='w')
        info = (
            "The scheduled task will use environment variables for firewall credentials:"
            "  FW_USER / FW_PASS / FW_ENABLE"
            "No passwords are stored by this GUI. The task sets REPORTS_DIR automatically."
        )
        ttk.Label(frm, text=info, foreground="#1155CC").grid(row=6, column=0, columnspan=4, sticky='w', pady=(8,0))
        btns = ttk.Frame(frm); btns.grid(row=7, column=0, columnspan=4, sticky='e', pady=(10,0))
        def on_register():
            try:
                task_name = name_var.get().strip() or "ACL Collector"
                time_txt  = t_var.get().strip() or "23:30"
                date_txt  = d_var.get().strip() or now.strftime("%Y-%m-%d")
                weekday   = wk_var.get().strip() or "Mon"
                use_cur   = bool(run_cur.get())
                account   = acct_var.get().strip()
                if not use_cur and not account:
                    try: messagebox.showwarning("Schedule", "Specify account or tick 'Run as current user'.")
                    except Exception: pass
                    return
                ok, path_ps1, err = self._collector_register_windows_task(task_name, mode.get(), date_txt, time_txt, weekday, use_cur, account)
                if ok:
                    try:
                        messagebox.showinfo("Schedule", f"Windows task registered.Task: {task_name}Script: {path_ps1}")
                    except Exception: pass
                    top.destroy()
                else:
                    try:
                        messagebox.showerror("Schedule", f"Failed to register task.{err}Script:{path_ps1}")
                    except Exception: pass
            except Exception as e:
                try: messagebox.showerror("Schedule", f"Unexpected error:{e}")
                except Exception: pass
        ttk.Button(btns, text="Cancel", command=top.destroy).grid(row=0, column=0, padx=(0,8))
        ttk.Button(btns, text="Register", command=on_register).grid(row=0, column=1)
        try:
            top.update_idletasks()
            sw, sh = top.winfo_screenwidth(), top.winfo_screenheight()
            w, h = top.winfo_width(), top.winfo_height()
            top.geometry(f"+{(sw-w)//2}+{(sh-h)//3}")
        except Exception:
            pass


    def _collector_register_windows_task(self, task_name, mode, date_txt, time_txt, weekday, run_current_user, account_user):
        """
        Fully patched version – stable PowerShell output.
        Handles quoting, escaping, REPORTS_DIR insertion,
        and ensures all lines break correctly.
        """
        import os, sys, json, subprocess

        try:
            if os.name != 'nt':
                return (False, "", "Not on Windows")

            # Resolve paths
            script = self._find_collector_script()
            if not script:
                return (False, "", "collector.py not found")

            run_cwd = os.path.dirname(os.path.abspath(script))
            try:
                rep_dir, _, _ = _ensure_reports_dir()
            except Exception:
                # Fallback: reports/latest under run_cwd
                rep_dir = os.path.join(run_cwd, 'reports', 'latest')
                os.makedirs(rep_dir, exist_ok=True)

            # Build collector command (same options as Start Collector)
            cmd = self._collector_build_cmd(script)
            args_only = cmd[1:] if len(cmd) > 1 else []

            # Escape helper for PowerShell double-quoted strings
            def psq(v: str) -> str:
                return str(v).replace('`', '``').replace('"', '`"')

            args_quoted = ' '.join(f'"{psq(a)}"' for a in args_only)

            # Weekday mapping
            wk_map = {
                'Mon': 'Monday', 'Tue': 'Tuesday', 'Wed': 'Wednesday',
                'Thu': 'Thursday', 'Fri': 'Friday', 'Sat': 'Saturday', 'Sun': 'Sunday'
            }
            ps_weekday = wk_map.get(weekday, 'Monday')

            # ----- Trigger -----
            if mode == 'once':
                ps_trig = f"$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date '{date_txt} {time_txt}')"
            elif mode == 'weekly':
                ps_trig = f"$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek {ps_weekday} -At '{time_txt}'"
            else:
                ps_trig = f"$trigger = New-ScheduledTaskTrigger -Daily -At '{time_txt}'"

            # ----- Command executed inside powershell.exe -Command -----
            # Use the real reports dir and python exe; ensure correct quoting
            ps_cmd = (
                f"$env:REPORTS_DIR = '{rep_dir}'; "
                f"& '{sys.executable}' -u 'collector.py' {args_quoted}; "
            )
            # Escape for embedding into -Command "..."
            ps_cmd_escaped = ps_cmd.replace('`', '``').replace('"', '`"')

            # ----- Action -----
            ps_action = (
                "$action = New-ScheduledTaskAction -Execute 'powershell.exe' "
                f'-Argument "-NoProfile -WindowStyle Hidden -Command `"{ps_cmd_escaped}`"" '
                f"-WorkingDirectory '{run_cwd}'"
            )

            # ----- Settings -----
            ps_settings = "$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable"

            # Combine the PowerShell file
            ps_lines = []
            ps_lines.append("$ErrorActionPreference = 'Stop';" + "\n")
            ps_lines.append(ps_trig + "\n")
            ps_lines.append(ps_action + "\n")
            ps_lines.append(ps_settings + "\n")

            # ----- Registration -----
            # Support either current-user registration or explicit domain account
            if run_current_user:
                reg = (
                    f"Register-ScheduledTask -TaskName {json.dumps(task_name)} "
                    f"-Action $action -Trigger $trigger -Settings $settings "
                )
                ps_lines.append(reg + "\n")
            else:
                if not account_user:
                    return (False, "", "Account user required when not running as current user")
                # Prepare credential prompt first, then pass to Register-ScheduledTask
                acc_escaped = account_user.replace('`', '``').replace("'", "''")
                ps_lines.append(f"$cred = Get-Credential -UserName '{acc_escaped}' -Message 'Enter password for the scheduled task'\n")
                ps_lines.append("if (-not $cred) { throw 'No credentials supplied.' }\n")
                reg = (
                    f"Register-ScheduledTask -TaskName {json.dumps(task_name)} "
                    f"-Action $action -Trigger $trigger -Settings $settings "
                    f"-User $cred.UserName -Password ($cred.GetNetworkCredential().Password) "
                )
                ps_lines.append(reg + "\n")

            ps1_path = os.path.join(rep_dir, 'register_task.ps1')
            with open(ps1_path, 'w', encoding='utf-8') as f:
                f.write(''.join(ps_lines))

            # Execute the generated PS1 to register the task
            proc = subprocess.run(
                ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps1_path],
                capture_output=True, text=True, cwd=run_cwd, timeout=120
            )
            if proc.returncode == 0:
                return (True, ps1_path, None)
            err = (proc.stdout or '') + "\n" + (proc.stderr or '')
            return (False, ps1_path, err.strip())

        except subprocess.TimeoutExpired:
            return (False, '', 'PowerShell timed out while registering the task')
        except Exception as e:
            return (False, '', str(e))
    # ---------- status ----------
    def _status(self, message, color="blue"):
        try:
            self.status_label.config(text=f"Status: {message}")
            self.status_label.config(foreground=color)
            self.root.update_idletasks()
        except Exception: pass




    def _tab_set_badge_on(self, notebook, tab_widget, text_base: str, count: int | None = None, color: str = "blue"):
        """
        Set a colored badge (emoji dot + optional count) on a specific notebook's tab.
        color: one of 'blue','green','amber','red','purple','grey','yellow'.
        """
        try:
            dots = {"red":"🟥","amber":"🟧","yellow":"🟨","green":"🟩","blue":"🟦","purple":"🟪","grey":"⬜"}
            dot = dots.get(color, "🟦")
            suffix = f" ({count})" if isinstance(count, int) and count >= 0 else ""
            label = f"{dot} {text_base}{suffix}"
            notebook.tab(tab_widget, text=label)
        except Exception:
            pass

    def _tab_set_badge(self, tab_widget, text_base: str, count: int | None = None, color: str = "blue"):
        try:
            return self._tab_set_badge_on(self.nb, tab_widget, text_base, count, color)
        except Exception:
            pass

    def _remed_refresh_badge(self):
        try:
            qsize = len(self.remed_table.get_children()) if getattr(self, 'remed_table', None) else 0
        except Exception:
            qsize = 0
        color = 'red' if qsize > 0 else 'blue'
        try:
            self._tab_set_badge(self.tab_remed, 'Remediation', qsize if qsize>0 else None, color)
        except Exception:
            pass

    # ---------------- Firewall Inventory (editable) ----------------
    def _build_inventory_tab(self):
        import csv, os
        # Create tab and UI
        self.tab_inventory = ttk.Frame(self.nb)
        # Temporarily add at end, then reposition next to Collector
        self.nb.add(self.tab_inventory, text='Firewall Inventory')

        # Try to reposition right after Collector tab
        try:
            tabs = self.nb.tabs()
            if hasattr(self, 'tab_collect') and self.tab_collect in tabs:
                idx = tabs.index(self.tab_collect)
                # Move Inventory tab to index right after Collector
                self.nb.insert(idx+1, self.tab_inventory)
        except Exception:
            pass

        self.tab_inventory.columnconfigure(0, weight=1)
        self.tab_inventory.rowconfigure(2, weight=1)

        # Paths
        base = os.path.dirname(os.path.abspath(__file__))
        self.inv_csv_path = os.path.join(base, 'modular_collector', 'firewall.csv')

        # Toolbar
        tbar = ttk.Frame(self.tab_inventory)
        tbar.grid(row=0, column=0, sticky='ew', padx=PAD, pady=(PAD, 4))
        for c in range(8):
            tbar.columnconfigure(c, weight=1)

        ttk.Label(tbar, text='Inventory File:').grid(row=0, column=0, sticky='w')
        self.inv_path_var = tk.StringVar(value=self.inv_csv_path)
        ttk.Label(tbar, textvariable=self.inv_path_var, foreground='blue').grid(row=0, column=1, sticky='w')
        ttk.Button(tbar, text='Reload', command=self._inv_reload).grid(row=0, column=2, sticky='w', padx=(6,0))
        ttk.Button(tbar, text='Add Row', command=self._inv_add_row).grid(row=0, column=3, sticky='w', padx=(12,0))
        ttk.Button(tbar, text='Edit Selected', command=self._inv_edit_selected).grid(row=0, column=4, sticky='w', padx=(6,0))
        ttk.Button(tbar, text='Delete Selected', command=self._inv_delete_selected).grid(row=0, column=5, sticky='w', padx=(6,0))
        ttk.Button(tbar, text='Save Changes', command=self._inv_save).grid(row=0, column=6, sticky='e')

        # Table wrapper
        wrap = ttk.Frame(self.tab_inventory, borderwidth=1, relief='solid')
        wrap.grid(row=2, column=0, sticky='nsew', padx=PAD, pady=(0, PAD))
        self.tab_inventory.columnconfigure(0, weight=1)
        self.tab_inventory.rowconfigure(2, weight=1)
        wrap.columnconfigure(0, weight=1)
        wrap.rowconfigure(0, weight=1)

        self.inv_table = ttk.Treeview(wrap, columns=(), show='headings', height=22, style='Bordered.Treeview', selectmode='browse')
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=self.inv_table.yview)
        hsb = ttk.Scrollbar(wrap, orient='horizontal', command=self.inv_table.xview)
        self.inv_table.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.inv_table.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        self.inv_table.tag_configure('odd', background='#f5f5f5')
        self.inv_table.tag_configure('even', background='#ffffff')

        # Key bindings for quick actions
        self.inv_table.bind('<Delete>', lambda e: (self._inv_delete_selected(), 'break'))
        self.inv_table.bind('<F2>', lambda e: (self._inv_edit_selected(), 'break'))
        self.tab_inventory.bind_all('<Control-n>', lambda e: self._inv_add_row())
        self.tab_inventory.bind_all('<Control-s>', lambda e: self._inv_save())

        # Data holders
        self.inv_cols = []
        self.inv_rows = []

        # Initial load
        self._inv_reload()

    def _inv_reload(self):
        import csv, os
        cols, rows = [], []
        path = getattr(self, 'inv_csv_path', '')
        if os.path.isfile(path):
            try:
                with open(path, 'r', encoding='utf-8', newline='') as f:
                    dr = csv.DictReader(f)
                    cols = list(dr.fieldnames or [])
                    for r in dr:
                        rows.append({k: (r.get(k,'') or '') for k in cols})
            except Exception:
                cols, rows = [], []
        if not cols:
            cols = ['hostname','platform','ip']
        self.inv_cols = cols
        self.inv_rows = rows
        self._inv_refresh_table()

    def _inv_refresh_table(self):
        # Configure columns
        self.inv_table['columns'] = tuple(self.inv_cols)
        for c in self.inv_cols:
            self.inv_table.heading(c, text=c)
            anchor = 'w'
            w = 200 if c == 'hostname' else 140
            if c.lower() in ('platform',):
                anchor = 'center'; w = 120
            self.inv_table.column(c, width=w, anchor=anchor, stretch=True)
        # Clear and re-populate
        for iid in self.inv_table.get_children():
            self.inv_table.delete(iid)
        for i, r in enumerate(self.inv_rows):
            vals = [r.get(c,'') for c in self.inv_cols]
            tag = 'even' if (i % 2 == 0) else 'odd'
            self.inv_table.insert('', 'end', values=tuple(vals), tags=(tag,))

    def _inv_add_row(self):
        self._inv_open_editor()

    def _inv_edit_selected(self):
        sel = self.inv_table.selection()
        if not sel:
            try:
                messagebox.showinfo('Edit Row', 'No row selected.')
            except Exception: pass
            return
        iid = sel[0]
        vals = list(self.inv_table.item(iid, 'values') or [])
        data = {self.inv_cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(self.inv_cols))}
        self._inv_open_editor(data, iid=iid)

    def _inv_delete_selected(self):
        sel = self.inv_table.selection()
        if not sel:
            try:
                messagebox.showinfo('Delete Row', 'No row selected.')
            except Exception: pass
            return
        iid = sel[0]
        vals = list(self.inv_table.item(iid, 'values') or [])
        row = {self.inv_cols[i]: (vals[i] if i < len(vals) else '') for i in range(len(self.inv_cols))}
        # Remove from data list (match by hostname + platform + ip when present, else by index)
        if row.get('hostname'):
            self.inv_rows = [r for r in self.inv_rows if r.get('hostname') != row.get('hostname') or any(r.get(k) != row.get(k) for k in self.inv_cols if k != 'hostname')]
        else:
            # fallback: remove first identical tuple
            tup = tuple(row.get(c,'') for c in self.inv_cols)
            removed = False
            new_rows = []
            for r in self.inv_rows:
                if not removed and tuple(r.get(c,'') for c in self.inv_cols) == tup:
                    removed = True
                    continue
                new_rows.append(r)
            self.inv_rows = new_rows
        try:
            self.inv_table.delete(iid)
        except Exception:
            pass
        self._inv_refresh_table()

    def _inv_open_editor(self, data=None, iid=None):
        import tkinter as tk
        from tkinter import ttk
        data = data or {c: '' for c in self.inv_cols}
        # Ensure columns exist
        if not self.inv_cols:
            self.inv_cols = ['hostname','platform','ip']
            data = {c: data.get(c,'') for c in self.inv_cols}

        top = tk.Toplevel(self.root)
        top.title('Firewall Row' + (' (edit)' if iid else ' (new)'))
        top.transient(self.root)
        top.grab_set()
        try:
            top.resizable(False, False)
        except Exception:
            pass

        frm = ttk.Frame(top, padding=10)
        frm.grid(row=0, column=0, sticky='nsew')
        top.columnconfigure(0, weight=1)
        top.rowconfigure(0, weight=1)

        entries = {}
        for i, c in enumerate(self.inv_cols):
            ttk.Label(frm, text=c).grid(row=i, column=0, sticky='w', padx=(0,8), pady=4)
            var = tk.StringVar(value=data.get(c,'') )
            ent = ttk.Entry(frm, textvariable=var, width=36)
            ent.grid(row=i, column=1, sticky='ew', pady=4)
            entries[c] = var
        frm.columnconfigure(1, weight=1)

        btns = ttk.Frame(frm)
        btns.grid(row=len(self.inv_cols), column=0, columnspan=2, sticky='e', pady=(10,0))

        def on_ok():
            new_row = {c: (entries[c].get() or '').strip() for c in self.inv_cols}
            if not new_row.get('hostname'):
                try:
                    messagebox.showwarning('Validation', 'Hostname is required.')
                except Exception: pass
                return
            if iid is None:
                self.inv_rows.append(new_row)
            else:
                # Update both the data list and the Treeview item
                # Find the matching row by old values
                old_vals = list(self.inv_table.item(iid, 'values') or [])
                old_row = {self.inv_cols[i]: (old_vals[i] if i < len(old_vals) else '') for i in range(len(self.inv_cols))}
                # Replace first match
                replaced = False
                for idx, r in enumerate(self.inv_rows):
                    if all((r.get(k,'') == old_row.get(k,'')) for k in self.inv_cols):
                        self.inv_rows[idx] = new_row
                        replaced = True
                        break
                if not replaced:
                    self.inv_rows.append(new_row)
            self._inv_refresh_table()
            top.destroy()

        def on_cancel():
            top.destroy()

        ttk.Button(btns, text='Cancel', command=on_cancel).grid(row=0, column=0, padx=(0,8))
        ttk.Button(btns, text='OK', command=on_ok).grid(row=0, column=1)

        try:
            top.update_idletasks()
            sw, sh = top.winfo_screenwidth(), top.winfo_screenheight()
            w, h = top.winfo_width(), top.winfo_height()
            top.geometry(f"+{(sw-w)//2}+{(sh-h)//3}")
        except Exception:
            pass

    def _inv_save(self):
        import csv, os
        path = getattr(self, 'inv_csv_path', '')
        # Ensure directory exists
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
        except Exception:
            pass
        cols = list(self.inv_cols or ['hostname','platform','ip'])
        try:
            with open(path, 'w', encoding='utf-8', newline='') as f:
                dw = csv.DictWriter(f, fieldnames=cols)
                dw.writeheader()
                for r in self.inv_rows:
                    # only keep known columns
                    row = {c: (r.get(c,'') or '') for c in cols}
                    dw.writerow(row)
            try:
                messagebox.showinfo('Save Inventory', f"Saved {len(self.inv_rows)} rows to\n{path}")
            except Exception: pass
        except Exception as e:
            try:
                messagebox.showerror('Save Inventory', f"Failed to save to\n{path}\n\n{e}")
            except Exception: pass
if __name__ == '__main__':
    root = tk.Tk()
    app = AclToolGUI(root)
    root.mainloop()